import * as THREE from 'three';
import {
  createGhostPanel, Panel, attachMaterialsPalette, registerExporter, MATERIAL_DRAG_MIME,
} from 'ghost-panel';
import { LINE_STYLES } from '../core/PostFX.js';
import { injectPanelStyles } from './panel.css.js';
import { createToolStrip } from './Toolbar.js';
import { HOME_ICON } from './toolIcons.js';


/** ghost-panel's exporter registry is module-level; only add ours once. */
let registeredPNG = false;

/**
 * Which element owns each tool, for tools whose definition doesn't say. The
 * inspector shows that element's folder while its tool is active; the three
 * terrain tools map to nothing, since the ground has no folder of its own.
 */
const TOOL_ELEMENT = {
  sculpt: null, mask: null, path: null,
  grass: 'grass', comb: 'grass',
  flowers: 'flowers',
  pond: 'water', river: 'water', waterfall: 'water',
  rocks: 'rocks', trees: 'trees', fire: 'fire', clouds: 'clouds',
};

/** Folders that describe the whole scene rather than the tool in hand. */
const GLOBAL_FOLDERS = ['Style', 'Wind', 'Sun'];

/** Numbers only ever have to agree to within this to count as "in sync". */
const EPS = 1e-4;

/**
 * True when a control's displayed value no longer matches the model.
 * @param {*} a
 * @param {*} b
 * @returns {boolean}
 */
function differs(a, b) {
  if (typeof a === 'number' && typeof b === 'number') return Math.abs(a - b) > EPS;
  return a !== b;
}

/**
 * Save a Blob to disk through a temporary object URL.
 * @param {Blob} blob
 * @param {string} filename
 */
function downloadBlob(blob, filename) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  a.click();
  URL.revokeObjectURL(url);
}

/** @returns {string} filename-safe local timestamp */
function stamp() {
  return new Date().toISOString().replace(/[:.]/g, '-').slice(0, 19);
}

/**
 * Mount the ghost-panel inspector and wire it to the app.
 *
 * The panel is model-driven: every control writes straight into `app.ctx`, and
 * a per-frame `sync()` pushes state that changed elsewhere (hotkeys, wheel
 * zoom, Ctrl-erase) back into the widgets. Elements register their own folders
 * from `buildPanel(ui)` and their own rows (via `sceneObjects()`) in the Scene
 * outliner as they appear in `ctx.elements`.
 *
 * @param {{ ctx: object, sky?: import('three').Object3D, toJSON: () => object,
 *           fromJSON: (o: object) => void,
 *           onFrame: (Array<Function>|Function), renderOnce?: () => void }} app
 * @returns {object} the ghost-panel `ui` handle, plus `refreshTools()`
 */
export function createPanel(app) {
  const { scene, camera, renderer, iso, sun, wind, layers, terrain, brush, style } = app.ctx;

  injectPanelStyles();

  let gizmoDragging = false;

  // The materials palette scans the scene while it mounts and remembers every
  // material it saw, so anything that must not become a swatch has to be
  // opted out BEFORE createGhostPanel runs (materials.js:452). Ours are the
  // sky quad and the brush cursor; everything ghost-panel adds while mounting
  // is inspector chrome — the transform gizmo and its helpers — so that whole
  // window is opted out too (see `gizmoWatch` below for when it closes).
  [app.sky, brush.cursor].forEach((object) => {
    if (object) object.userData.__duiIgnore = true;
  });
  /** @type {THREE.Group} the Outliner's "World" row: selecting it shows the globals */
  const world = new THREE.Group();
  world.name = 'World';

  const sceneAdd = scene.add.bind(scene);
  scene.add = (...objects) => {
    objects.forEach((object) => { if (object) object.userData.__duiIgnore = true; });
    return sceneAdd(...objects);
  };

  const ui = createGhostPanel({
    title: 'EnvPaint',
    scene,
    camera,
    renderer,
    scenePanel: true,
    scenePanelTitle: 'Scene',
    // The palette gets a pane of its own below the Scene panel, mounted by hand
    // further down, so ghost-panel must not put it inside the outliner.
    materialsPanel: false,
    gizmo: true,
    // Painted and structural objects are inspected, never dragged.
    beforeGizmoAttach: (obj) => !obj?.userData?.envpaintLocked,
    onDraggingChanged: (active) => {
      gizmoDragging = active;
      brush.enabled = !active;
    },
    cameraControl: false,
    workflowPicker: false,
    autoRegister: false,
    // Not ['3d', 'shader']: the shader workflow only mounts a "Uniforms" folder
    // for uniforms passed in `workflowOpts` (workflows.js:288) — selecting one
    // of our ShaderMaterial meshes adds nothing but an unwired System/Time
    // folder, so it would be dead chrome.
    workflow: '3d',
    saveLoad: true,
    liquidGlass: false,
    theme: 'zinc',
    visible: true,
  });

  // One undo stack for strokes and panel edits alike: History pushes its
  // entries into ghost-panel's, so a single Ctrl+Z walks back through both.
  app.history?.attachUI?.(ui);

  // ── model → control sync ──
  // Ghost-panel's setValue() never re-fires onChange (controls.js:181 only
  // fires when the change came from the widget), so pushing model state into a
  // control cannot loop back into the model.
  /** @type {{ ctrl: { getValue: () => *, setValue: (v: *) => void }, read: () => * }[]} */
  const bindings = [];

  /**
   * Add a control and remember how to read its value back off the model.
   * @param {object} folder
   * @param {'addSlider'|'addCheckbox'|'addColor'} method
   * @param {string} label
   * @param {object} opts
   * @param {() => *} read
   */
  function bound(folder, method, label, opts, read) {
    folder[method](label, opts);
    bindings.push({ ctrl: folder.get(opts.id || label), read });
  }

  // ── 0. Style ──────────────────────────────────────────────────────────
  // First folder in the panel: the material style everything is drawn in, and
  // the look controls that style's lighting block reads. Sliders write into
  // `sun.uniforms`, which every toon material spreads by reference, so one
  // slider moves the whole scene — and a style switch rewrites those same
  // uniforms, which the per-frame sync() then reads back into the widgets.
  const styleFolder = ui.addFolder('Style');

  if (style) {
    bound(styleFolder, 'addSelect', 'Style', {
      options: style.list().map((s) => ({ value: s.id, label: s.label })),
      value: style.current,
      onChange: (id) => style.set(id),
    }, () => style.current);
  }

  const look = sun.uniforms;
  // uShadowTint is a LINEAR vec3, but the colour widget speaks sRGB hex. Both
  // conversions are done by hand, so the raw component values are read and
  // written with LinearSRGBColorSpace — three's automatic colour management
  // would otherwise convert a second time and wash the swatch out.
  const tintColor = new THREE.Color();

  /** @returns {string} the shadow tint as an sRGB hex string */
  function readShadowTint() {
    const c = look.uShadowTint.value;
    tintColor.setRGB(c.r, c.g, c.b).convertLinearToSRGB();
    return `#${tintColor.getHexString(THREE.LinearSRGBColorSpace)}`;
  }

  bound(styleFolder, 'addColor', 'Shadow tint colour', {
    value: readShadowTint(),
    onChange: (hex) => {
      tintColor.setStyle(hex, THREE.LinearSRGBColorSpace).convertSRGBToLinear();
      look.uShadowTint.value.setRGB(tintColor.r, tintColor.g, tintColor.b);
    },
  }, readShadowTint);

  bound(styleFolder, 'addSlider', 'Band edge', {
    min: -0.5, max: 1, step: 0.01, value: look.uBandEdge.value,
    onChange: (v) => { look.uBandEdge.value = v; },
  }, () => look.uBandEdge.value);

  bound(styleFolder, 'addSlider', 'Band softness', {
    min: 0, max: 0.4, step: 0.005, value: look.uBandSoft.value,
    onChange: (v) => { look.uBandSoft.value = v; },
  }, () => look.uBandSoft.value);

  bound(styleFolder, 'addSlider', 'Half-tone', {
    min: 0, max: 1, step: 0.01, value: look.uHalfTone.value,
    onChange: (v) => { look.uHalfTone.value = v; },
  }, () => look.uHalfTone.value);

  bound(styleFolder, 'addSlider', 'Rim', {
    min: 0, max: 1, step: 0.01, value: look.uRim.value,
    onChange: (v) => { look.uRim.value = v; },
  }, () => look.uRim.value);

  bound(styleFolder, 'addSlider', 'Grain', {
    min: 0, max: 3, step: 0.01, value: look.uGrain.value,
    onChange: (v) => { look.uGrain.value = v; },
  }, () => look.uGrain.value);

  // ── Ink & paper ───────────────────────────────────────────────────────
  // The screen-space half of a style: outlines, hatching and paper. Each
  // style's `post` block sets these; the widgets read the live uniforms back,
  // so switching style visibly moves every one of them.
  const postfx = app.ctx.postfx;
  if (postfx) {
    const ink = postfx.material.uniforms;
    styleFolder.addInfo('— Ink & paper —');

    bound(styleFolder, 'addCheckbox', 'Enable ink', {
      value: postfx.enabled,
      onChange: (v) => { postfx.enabled = v; },
    }, () => postfx.enabled);

    bound(styleFolder, 'addSelect', 'Line style', {
      options: Object.keys(LINE_STYLES).map((id) => ({ value: id, label: id })),
      value: postfx.lineStyle,
      onChange: (id) => postfx.setLineStyle(id),
    }, () => postfx.lineStyle);

    bound(styleFolder, 'addSlider', 'Line width', {
      min: 0, max: 4, step: 0.05, value: ink.uLineWidth.value, suffix: ' px',
      onChange: (v) => { ink.uLineWidth.value = v; },
    }, () => ink.uLineWidth.value);

    bound(styleFolder, 'addSlider', 'Line wobble', {
      min: 0, max: 3, step: 0.05, value: ink.uWobble.value,
      onChange: (v) => { ink.uWobble.value = v; },
    }, () => ink.uWobble.value);

    bound(styleFolder, 'addSlider', 'Line break', {
      min: 0, max: 0.6, step: 0.01, value: ink.uBreak.value,
      onChange: (v) => { ink.uBreak.value = v; },
    }, () => ink.uBreak.value);

    // uInkColor holds display-space values, so read and write it raw — the
    // default sRGB conversion of get/setHexString would double-encode it.
    const readInk = () => `#${ink.uInkColor.value.getHexString(THREE.LinearSRGBColorSpace)}`;
    bound(styleFolder, 'addColor', 'Ink colour', {
      value: readInk(),
      onChange: (hex) => { ink.uInkColor.value.set(hex).convertLinearToSRGB(); },
    }, readInk);

    bound(styleFolder, 'addSlider', 'Ink opacity', {
      min: 0, max: 1, step: 0.01, value: ink.uInkOpacity.value,
      onChange: (v) => { ink.uInkOpacity.value = v; },
    }, () => ink.uInkOpacity.value);

    bound(styleFolder, 'addSlider', 'Hatch', {
      min: 0, max: 1, step: 0.01, value: ink.uHatch.value,
      onChange: (v) => { ink.uHatch.value = v; },
    }, () => ink.uHatch.value);

    bound(styleFolder, 'addSlider', 'Hatch scale', {
      min: 0.5, max: 12, step: 0.1, value: app.postfx.hatchScale,
      onChange: (v) => { app.postfx.hatchScale = v; },
    }, () => app.postfx.hatchScale);

    bound(styleFolder, 'addSlider', 'Paper', {
      min: 0, max: 2, step: 0.01, value: ink.uPaper.value,
      onChange: (v) => { ink.uPaper.value = v; },
    }, () => ink.uPaper.value);

    bound(styleFolder, 'addSlider', 'Pooling', {
      min: 0, max: 1, step: 0.01, value: ink.uPooling.value,
      onChange: (v) => { ink.uPooling.value = v; },
    }, () => ink.uPooling.value);
  }

  // ── 1. Brush ──────────────────────────────────────────────────────────
  // Tool choice lives on the strip at the bottom of the viewport; this folder
  // is only what the active brush does when it touches the ground.
  const tools = ui.addFolder('Brush');

  bound(tools, 'addSlider', 'Radius', {
    min: 0.3, max: 12, step: 0.1, value: brush.settings.radius, suffix: ' m',
    // setRadius flashes the footprint on the canvas so the size is visible
    // where it will land while the slider is dragged.
    onChange: (v) => { brush.setRadius(v); },
  }, () => brush.settings.radius);

  bound(tools, 'addSlider', 'Strength', {
    min: 0.05, max: 1, step: 0.01, value: brush.settings.strength,
    onChange: (v) => { brush.settings.strength = v; },
  }, () => brush.settings.strength);

  bound(tools, 'addSlider', 'Hardness', {
    min: 0, max: 1, step: 0.01, value: brush.settings.hardness,
    onChange: (v) => { brush.settings.hardness = v; },
  }, () => brush.settings.hardness);

  bound(tools, 'addSlider', 'Spacing', {
    min: 0.1, max: 1, step: 0.01, value: brush.settings.spacing,
    onChange: (v) => { brush.settings.spacing = v; },
  }, () => brush.settings.spacing);

  // Edge shape: how far from a clean disc each dab is. The cursor ring
  // previews the noise; spatter and aspect only show in the stroke.
  bound(tools, 'addSlider', 'Edge noise', {
    min: 0, max: 1, step: 0.01, value: brush.settings.edgeNoise,
    tooltip: 'How far the rim wanders in and out',
    onChange: (v) => { brush.setShape({ edgeNoise: v }); },
  }, () => brush.settings.edgeNoise);

  bound(tools, 'addSlider', 'Edge detail', {
    min: 1, max: 8, step: 0.1, value: brush.settings.edgeScale,
    tooltip: 'Lobes around the rim: low is blobby, high is ragged',
    onChange: (v) => { brush.setShape({ edgeScale: v }); },
  }, () => brush.settings.edgeScale);

  bound(tools, 'addSlider', 'Spatter', {
    min: 0, max: 1, step: 0.01, value: brush.settings.spatter,
    tooltip: 'Dissolves the feathered edge into dry-brush speckle',
    onChange: (v) => { brush.setShape({ spatter: v }); },
  }, () => brush.settings.spatter);

  bound(tools, 'addSlider', 'Aspect', {
    min: 0.25, max: 1, step: 0.01, value: brush.settings.aspect,
    tooltip: 'Below 1 each dab is an oval stretched along the stroke',
    onChange: (v) => { brush.setShape({ aspect: v }); },
  }, () => brush.settings.aspect);

  /** @returns {object|null} the layer the active tool paints into */
  function activeLayer() {
    const tool = brush.tools.get(brush.tool);
    return tool && tool.layer ? layers.get(tool.layer) || null : null;
  }

  /**
   * Run a layer mutation as one undo step. Without the wrap the change still
   * happens, but Ctrl+Z cannot walk back over it.
   * @param {string} label
   * @param {() => void} fn
   */
  function edit(label, fn) {
    if (app.history) app.history.wrap(label, fn);
    else fn();
  }

  tools.addButtonRow([
    {
      label: 'Clear layer',
      tooltip: "Reset the active tool's layer",
      onClick: () => edit('Clear layer', () => activeLayer()?.clear()),
    },
    {
      label: 'Fill layer',
      tooltip: "Fill the active tool's layer",
      onClick: () => edit('Fill layer', () => activeLayer()?.clear(1)),
    },
  ]);

  bound(tools, 'addCheckbox', 'Show mask', {
    value: !!terrain.showMask,
    onChange: (v) => { terrain.showMask = v; },
  }, () => !!terrain.showMask);

  // ── 2. Wind ───────────────────────────────────────────────────────────
  const windFolder = ui.addFolder('Wind');

  bound(windFolder, 'addSlider', 'Direction', {
    min: -180, max: 180, step: 1, value: wind.direction, suffix: '°',
    onChange: (v) => {
      if (typeof wind.setDirection === 'function') wind.setDirection(v);
      else wind.direction = v;
    },
  }, () => wind.direction);

  bound(windFolder, 'addSlider', 'Strength', {
    min: 0, max: 1, step: 0.01, value: wind.strength,
    onChange: (v) => { wind.strength = v; },
  }, () => wind.strength);

  bound(windFolder, 'addSlider', 'Speed', {
    min: 0, max: 3, step: 0.01, value: wind.speed,
    onChange: (v) => { wind.speed = v; },
  }, () => wind.speed);

  bound(windFolder, 'addSlider', 'Gustiness', {
    min: 0, max: 1, step: 0.01, value: wind.gustiness,
    onChange: (v) => { wind.gustiness = v; },
  }, () => wind.gustiness);

  // ── 3. Sun ────────────────────────────────────────────────────────────
  const sunFolder = ui.addFolder('Sun');

  bound(sunFolder, 'addSlider', 'Azimuth', {
    min: 0, max: 360, step: 1, value: sun.azimuth, suffix: '°',
    onChange: (v) => sun.setAngles(v, sun.elevation),
  }, () => sun.azimuth);

  bound(sunFolder, 'addSlider', 'Elevation', {
    min: 10, max: 85, step: 1, value: sun.elevation, suffix: '°',
    onChange: (v) => sun.setAngles(sun.azimuth, v),
  }, () => sun.elevation);

  bound(sunFolder, 'addColor', 'Sun colour', {
    value: `#${sun.light.color.getHexString()}`,
    onChange: (v) => sun.light.color.set(v),
  }, () => `#${sun.light.color.getHexString()}`);

  bound(sunFolder, 'addSlider', 'Intensity', {
    min: 0, max: 4, step: 0.05, value: sun.light.intensity,
    onChange: (v) => { sun.light.intensity = v; },
  }, () => sun.light.intensity);

  // ── 4. Save / load ────────────────────────────────────────────────────
  // No folder of its own: the panel header's two buttons are the whole UI.
  function saveJSON() {
    downloadBlob(
      new Blob([JSON.stringify(app.toJSON(), null, 2)], { type: 'application/json' }),
      `envpaint-${stamp()}.json`,
    );
  }

  function loadJSON() {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = 'application/json,.json';
    input.addEventListener('change', () => {
      const file = input.files && input.files[0];
      if (!file) return;
      file.text()
        .then((text) => app.fromJSON(JSON.parse(text)))
        .catch((err) => console.warn('[EnvPaint] could not load scene:', err));
    });
    input.click();
  }

  // Route the header Save / Load buttons at the scene, not at ghost-panel's own
  // control snapshot. `save` becomes the first entry of the export menu the
  // header opens; `load` replaces the built-in JSON picker (index.js:1126).
  ui.panel.setSaveLoadHandlers({
    save: saveJSON,
    load: loadJSON,
    label: 'EnvPaint scene (JSON)',
  });

  // The export menu's built-in PNG exporter shoots `document.querySelector`'s
  // canvas without re-rendering it (exports.js:126), which is blank without
  // preserveDrawingBuffer — so the menu gets one of ours that draws the frame
  // first. Registered once per page: the registry is module-level.
  if (!registeredPNG) {
    registeredPNG = true;
    registerExporter({
      id: 'envpaint-png',
      label: 'Viewport PNG',
      description: 'The painted world exactly as it is on screen',
      mime: 'image/png',
      extension: 'png',
      workflows: ['*'],
      run: () => new Promise((resolve, reject) => {
        if (typeof app.renderOnce === 'function') app.renderOnce();
        else if (app.ctx.postfx?.enabled) app.ctx.postfx.render(scene, camera);
        else renderer.render(scene, camera);
        renderer.domElement.toBlob((blob) => {
          if (blob) resolve({ blob, filename: `envpaint-${stamp()}.png` });
          else reject(new Error('Canvas could not be exported as PNG'));
        }, 'image/png');
      }),
    });
  }

  /** Frame the whole world again: centred, default zoom, default yaw. */
  function resetView() {
    iso.target?.set?.(0, 0, 0);
    if (typeof iso.setZoom === 'function') iso.setZoom(14);
    else iso.frustumHalfHeight = 14;
    if (typeof iso.setYawIndex === 'function') iso.setYawIndex(0);
    else if (iso.yawIndex) iso.rotate(-iso.yawIndex);
  }

  // The inspector only ever shows what the current selection is about: the
  // brush in hand, the object or material picked, or — for the scene-wide
  // folders — the "World" row in the Outliner. With nothing chosen it says so.
  tools.showWhen = () => !!brush.tool;
  GLOBAL_FOLDERS.forEach((name) => {
    const folder = ui.panel.folders[name];
    if (folder) folder.showWhen = worldSelected;
  });
  // Brush before Style, so the two states each read top-down in their own order.
  ui.panel.body.insertBefore(styleFolder.element, windFolder.element);

  const emptyRow = document.createElement('div');
  emptyRow.className = 'ep-empty';
  emptyRow.textContent = 'Select a brush, an object, a material, or World.';
  ui.panel.body.appendChild(emptyRow);

  // Style now sits collapsed at the bottom, so its header carries the name of
  // the active style — ghost-panel folders have no value slot of their own.
  const styleValue = document.createElement('span');
  styleValue.className = 'ep-folder-value';
  styleFolder.element.querySelector('.dui-folder-header')
    ?.insertBefore(styleValue, styleFolder.element.querySelector('.dui-arrow'));

  /** @returns {string} label of the active style, or '' when there is none */
  function styleLabel() {
    if (!style) return '';
    return style.list().find((s) => s.id === style.current)?.label || style.current || '';
  }

  // ── Materials ─────────────────────────────────────────────────────────
  // One swatch per material the palette finds in the scene, in a third pane of
  // its own docked under the Scene panel. Elements name their materials for
  // people and mark their own helper geometry `__duiIgnore`.
  const om = ui.objectManager;

  const DOCK_GAP = 10;
  const materialsPane = new Panel({
    title: 'Materials',
    side: 'left',
    width: 260,
    visible: ui.panel.isVisible(),
    theme: 'zinc',
  });
  // State lives on the main panel; this one is a palette, not a document.
  materialsPane.setSaveLoadHandlers({ save: null, load: null });

  ui.materials = attachMaterialsPalette(ui, { panel: materialsPane, title: 'Materials' });
  // The pane's own header already says "Materials"; drop the folder's.
  ui.materials?.folder?.element?.querySelector('.dui-folder-header')?.remove();

  // The tool strip: built here rather than with the Brush folder so it can be
  // handed the same `resetView` the panes use. It floats over the panes at the
  // bottom centre of the viewport and remembers wherever the user drags it.
  const strip = createToolStrip(brush, {
    extras: [{ icon: HOME_ICON, tooltip: 'Reset view', onClick: resetView }],
  });
  if (typeof brush.on === 'function') brush.on('toolschanged', strip.refresh);

  // Docked under the Scene panel until the user drags it somewhere else. Only
  // the position is followed, not the width, so the pane's own resizer keeps
  // working. Panel.js already gives every panel header drag + collapse, so the
  // pane behaves exactly like the two ghost-panel made.
  let paneDocked = true;
  function dockMaterialsPane() {
    if (!paneDocked || !ui.scenePanel) return;
    const r = ui.scenePanel.element.getBoundingClientRect();
    const top = Math.round(r.bottom + DOCK_GAP);
    const el = materialsPane.element;
    el.style.right = 'auto';
    el.style.left = `${r.left}px`;
    el.style.top = `${top}px`;
    // The stylesheet's 92vh ceiling assumes a panel anchored at the top, so a
    // docked pane needs its own or it runs off the bottom of the window.
    el.style.maxHeight = `${Math.max(120, window.innerHeight - top - DOCK_GAP)}px`;
  }
  materialsPane.header.addEventListener('pointerdown', (e) => {
    if (!e.target.closest('.dui-header-btn')) paneDocked = false;
  });
  if (ui.scenePanel) {
    new ResizeObserver(dockMaterialsPane).observe(ui.scenePanel.element);
    window.addEventListener('resize', dockMaterialsPane);
    // Panels slide in with a 12 px translate, so a position measured before
    // that animation ends is off by up to 12 px — dock again when it settles.
    ui.scenePanel.element.addEventListener('animationend', dockMaterialsPane);
    dockMaterialsPane();
  }

  // The transform gizmo reaches the scene from an async init that resolves a
  // microtask after createGhostPanel returns (three-extensions.js:73) — before
  // the palette's next scan, which would then remember its two dozen axis
  // materials for good (materials.js:452). So the wrapper above stays on until
  // the gizmo has landed, and only then is `scene.add` handed back.
  let gizmoWaits = 0;
  const gizmoWatch = setInterval(() => {
    const helper = om?.gizmo?.getHelper?.();
    if (helper) {
      helper.userData.__duiIgnore = true;
      ui.materials?.refresh?.();
    }
    if (helper || ++gizmoWaits > 200) {
      scene.add = sceneAdd;
      clearInterval(gizmoWatch);
    }
  }, 25);

  /** @param {THREE.Object3D|null|undefined} object */
  const isLocked = (object) => !!object?.userData?.envpaintLocked;
  /** @param {DragEvent} e */
  const isMaterialDrag = (e) => !!e.dataTransfer?.types?.includes?.(MATERIAL_DRAG_MIME);

  // `assignMaterial` (materials.js:229) has no notion of a protected object, so
  // the drops that reach it are filtered here. The canvas is a painting
  // surface, never a drop target; refusing to let the palette preventDefault
  // its dragover is enough to make the browser reject the drop outright.
  ['dragover', 'drop'].forEach((type) => {
    renderer.domElement.addEventListener(type, (e) => {
      if (isMaterialDrag(e)) e.stopImmediatePropagation();
    }, true);
  });

  const scenePanelEl = ui.scenePanel?.element;
  if (scenePanelEl) {
    // Outliner rows accept drops too — all but the locked ones.
    ['dragover', 'drop'].forEach((type) => {
      scenePanelEl.addEventListener(type, (e) => {
        if (!isMaterialDrag(e)) return;
        const row = e.target.closest?.('.dui-list-item[data-name]');
        if (isLocked(om?.getObject?.(row?.dataset.name))) e.stopImmediatePropagation();
      }, true);
    });
    // …and so does the palette's "assign to the selected object" button.
    scenePanelEl.addEventListener('click', (e) => {
      if (!e.target.closest?.('[data-act="assign"]')) return;
      const names = om?.getSelectedNames?.() || (om?.activeName ? [om.activeName] : []);
      if (names.some((name) => isLocked(om.getObject(name)))) e.stopImmediatePropagation();
    }, true);
  }

  /**
   * @param {string[]} colors
   * @returns {string} a CSS background: one flat colour, or hard-edged bands
   */
  function swatchBackground(colors) {
    const fill = colors.length === 1
      ? colors[0]
      : `linear-gradient(155deg, ${colors.map((c, i) => {
        const a = (i * 100) / colors.length;
        const b = ((i + 1) * 100) / colors.length;
        return `${c} ${a}%, ${c} ${b}%`;
      }).join(', ')})`;
    // A soft highlight in the corner keeps these reading as the shaded balls
    // ghost-panel draws for everything else.
    return `radial-gradient(circle at 32% 26%, rgba(255,255,255,0.38), rgba(255,255,255,0) 58%), ${fill}`;
  }

  /**
   * Ghost-panel previews a material by drawing it on a sphere in a scratch
   * renderer (materials.js:265), which cannot light a shader that needs our
   * painted layer textures — every one of ours came out an empty checkerboard.
   * Materials that declare `userData.swatch` (one hex, or two or three for a
   * ramp) get a flat chip instead; label, drag and selection are untouched.
   */
  function paintSwatches() {
    const grid = ui.materials?.element?.querySelector('.dui-matgrid');
    if (!grid) return;
    const byId = new Map((ui.materials.getMaterials?.() || []).map((m) => [m.uuid, m]));
    grid.querySelectorAll('.dui-mat-swatch').forEach((cell) => {
      const thumb = cell.querySelector('.dui-mat-thumb');
      if (!thumb || thumb.querySelector('.ep-swatch')) return;
      const swatch = byId.get(cell.dataset.id)?.userData?.swatch;
      if (!swatch) return;
      const chip = document.createElement('span');
      chip.className = 'ep-swatch';
      chip.style.background = swatchBackground(Array.isArray(swatch) ? swatch : [swatch]);
      thumb.querySelector('img, .dui-mat-chip')?.remove();
      thumb.prepend(chip);
    });
  }

  const swatchGrid = ui.materials?.element?.querySelector('.dui-matgrid');
  if (swatchGrid) {
    // The palette rebuilds the grid wholesale on every render; childList on the
    // grid itself sees that without seeing the chips we put inside the cells.
    new MutationObserver(paintSwatches).observe(swatchGrid, { childList: true });
    paintSwatches();
  }

  /**
   * Add one `uiProps` descriptor row.
   * @param {object} folder
   * @param {{label:string, kind?:string, get:() => *, set:(v:*) => void,
   *          min?:number, max?:number, step?:number, options?:Array, tooltip?:string}} prop
   * @returns {HTMLElement|null} the row element, for re-ordering
   */
  function addMaterialProp(folder, prop) {
    // Namespaced so a descriptor called 'Name' or 'Side' can't collide with
    // the rows ghost-panel already put in this folder.
    const id = `uip:${prop.label}`;
    const opts = { id, tooltip: prop.tooltip, value: prop.get(), onChange: prop.set };
    if (prop.kind === 'color') folder.addColor(prop.label, opts);
    else if (prop.kind === 'boolean') folder.addCheckbox(prop.label, opts);
    else if (prop.kind === 'select') folder.addSelect(prop.label, { ...opts, options: prop.options || [] });
    else {
      folder.addSlider(prop.label, {
        ...opts,
        min: prop.min ?? 0,
        max: prop.max ?? 1,
        step: prop.step ?? 0.01,
      });
    }
    return folder.get(id)?.element || null;
  }

  /**
   * The first material under `object` — elements whose Outliner row is a Group
   * (Rocks, Trees, Fire, …) still have exactly one material to show.
   * @param {THREE.Object3D|null|undefined} object
   * @returns {THREE.Material|null}
   */
  function materialOf(object) {
    let found = null;
    object?.traverse?.((node) => {
      if (found || !node.material) return;
      found = Array.isArray(node.material) ? node.material[0] : node.material;
    });
    return found;
  }

  /** @returns {THREE.Material|null} whichever material the Inspector is showing */
  function activeMaterial() {
    // The palette tracks both routes: it sets its active material from the
    // clicked swatch, and from the selection on every manager change
    // (materials.js:1165).
    return ui.materials?.active
      || (om?.activeName ? materialOf(om.getObject(om.activeName)) : null);
  }

  /**
   * Append the rows a material declares in `userData.uiProps` to the shared
   * 'Material' folder, whoever built it — the palette (materials.js:621) and
   * the contextual inspector (contextual.js:1178) both rebuild that folder
   * from scratch and neither has an extension hook.
   * @param {object} folder
   * @param {THREE.Material|null} [material]
   */
  function decorateMaterialFolder(folder, material = activeMaterial()) {
    if (!folder || folder.envpaintProps) return;
    const props = material?.userData?.uiProps;
    if (!Array.isArray(props) || !props.length) return;
    folder.envpaintProps = true;
    // Neither row says anything true about a hand-written toon shader.
    folder.remove('shader-info');
    folder.remove('Wireframe');
    const anchor = folder.get('Name')?.element?.nextSibling || folder.body.firstChild;
    props.forEach((prop) => {
      const row = addMaterialProp(folder, prop);
      if (row) folder.body.insertBefore(row, anchor);
    });
  }

  const addFolder = ui.panel.addFolder.bind(ui.panel);
  ui.panel.addFolder = (name, opts) => {
    const folder = addFolder(name, opts);
    // A microtask: both builders fill the folder synchronously after creating
    // it, so by the time this runs there are rows to place ours against.
    if (name === 'Material') {
      // Keep it above the "nothing selected" row.
      ui.panel.body.insertBefore(folder.element, emptyRow);
      queueMicrotask(() => {
        if (ui.panel.folders.Material === folder) decorateMaterialFolder(folder);
      });
    }
    return folder;
  };

  /** @type {object|null} a Material folder we opened ourselves */
  let ownMaterialFolder = null;
  let lastSelected;

  /**
   * Selecting an element whose Outliner row is a Group leaves the contextual
   * inspector with nothing to show (it wants `object.material`), so the folder
   * is opened here instead — and dropped again on the next selection change,
   * since the contextual layer only ever removes folders it built itself.
   */
  function syncMaterialFolder() {
    const name = om?.activeName ?? null;
    const existing = ui.panel.folders.Material || null;
    const changed = name !== lastSelected;
    // Also rebuild when the folder went missing under a standing selection:
    // the palette's selection listener now registers after the contextual
    // layer's (it mounts into our own pane, later), so a swatch click followed
    // by an Outliner click can leave the contextual folder released.
    if (!changed && (existing || !name)) return;
    if (changed) {
      if (ownMaterialFolder && existing === ownMaterialFolder) ui.panel.removeFolder('Material');
      ownMaterialFolder = null;
      lastSelected = name;
    }
    if (!name || ui.panel.folders.Material) return;
    const material = materialOf(om.getObject(name));
    if (!material?.userData?.uiProps?.length) return;
    ownMaterialFolder = ui.panel.addFolder('Material', { transient: true });
    ownMaterialFolder.addInfo(`Shared by all of ${name}`);
    decorateMaterialFolder(ownMaterialFolder, material);
  }

  // ── Outliner ──────────────────────────────────────────────────────────
  // `autoRegister: false` keeps the brush cursor, gizmo internals and helpers
  // out of the list, so everything worth selecting is named here by hand.
  /**
   * @param {string} name row name in the Outliner
   * @param {import('three').Object3D|null|undefined} object
   * @param {boolean} [locked=false] inspectable, but never gizmo-draggable
   */
  function registerObject(name, object, locked = false) {
    if (!om || !object || om.has(name)) return;
    if (locked) object.userData.envpaintLocked = true;
    om.register(name, object);
  }

  // The Outliner gives every row a trash button (and Delete/Backspace) that
  // removes AND disposes the object. Losing the terrain or a painted element
  // that way is unrecoverable, so locked rows refuse deletion.
  if (om) {
    const removeObject = om.remove.bind(om);
    om.remove = (name) => {
      if (om.getObject(name)?.userData?.envpaintLocked) return;
      removeObject(name);
    };
  }

  function registerCoreObjects() {
    // An empty stand-in for "the scene itself", so the globals have something
    // to hang off: selecting this row is what shows Style, Wind and Sun. NOT
    // marked `__duiIgnore` — that flag would drop the row from the Outliner too
    // (three-extensions.js:772), and an empty Group has no material for the
    // palette to find in the first place.
    if (!om?.has?.('World')) {
      // Straight past the `scene.add` wrapper above: that one marks everything
      // it sees `__duiIgnore`, which would drop this row from the Outliner.
      sceneAdd(world);
      registerObject('World', world, true);
    }
    registerObject('Terrain', terrain.mesh, true);
    // NOT 'Sun': selecting a light mounts a contextual folder named after its
    // row (contextual.js:1973) and `addFolder` hands back an existing folder of
    // that name — a row called 'Sun' would fill our Sun folder with its rows and
    // then delete it on deselect.
    registerObject('Sun light', sun.light);
    registerObject('Sky', sun.hemi);
    registerObject('Sky dome', app.sky, true);
    registerObject('Demo cube', scene.getObjectByName('demoCube'));
  }

  /**
   * @param {object} element
   * @param {string} id
   */
  function registerElementObjects(element, id) {
    const objects = (typeof element.sceneObjects === 'function' && element.sceneObjects()) || [];
    const label = element.constructor?.label || id;
    objects.forEach((object, i) => {
      const name = objects.length > 1 ? `${label} ${i + 1}` : label;
      // Painted surfaces are inspected, never dragged; a *prop* element (the
      // Master Sword) marks its root `envpaintProp` and stays unlocked, so it
      // is gizmo-draggable and deletable like anything the user placed.
      registerObject(name, object, object?.userData?.envpaintProp !== true);
      // Remembered so selecting a row — or its material's swatch — can bring
      // that element's folder back even when another tool is in hand.
      rowElement.set(name, id);
      const material = materialOf(object);
      if (material) materialElement.set(material, id);
    });
  }

  let sceneChildCount = -1;

  /** Catch objects added to the scene after their element was first seen. */
  function syncSceneObjects() {
    if (!om || scene.children.length === sceneChildCount) return;
    sceneChildCount = scene.children.length;
    registerCoreObjects();
    app.ctx.elements?.forEach(registerElementObjects);
    ui.refreshSceneObjects();
  }

  // ── Element folders ───────────────────────────────────────────────────
  // Elements are constructed after the panel exists, so poll the map. Only the
  // folders that matter right now are shown: the element behind the active
  // tool, plus whatever is selected in the Outliner or picked in the palette.
  const builtElements = new Set();
  /** @type {Map<string, {id: string, folder: object}>} folder name → owner */
  const elementFolders = new Map();
  /** @type {Map<string, string>} Outliner row name → element id */
  const rowElement = new Map();
  /** @type {Map<object, string>} material → element id */
  const materialElement = new Map();
  let lastShown = '';

  /** @returns {string|null} the element owning the tool in hand */
  function activeToolElement() {
    const tool = brush.tools.get(brush.tool);
    return tool?.element || TOOL_ELEMENT[brush.tool] || null;
  }

  /** @returns {string|null} the element behind the current selection, if any */
  function selectedElement() {
    const byRow = om?.activeName ? rowElement.get(om.activeName) : null;
    return byRow || materialElement.get(ui.materials?.active) || null;
  }

  /** @returns {Set<string>} element ids whose folders belong on screen */
  function shownElements() {
    const shown = new Set();
    const active = activeToolElement();
    const selected = selectedElement();
    if (active) shown.add(active);
    if (selected) shown.add(selected);
    return shown;
  }

  /** Expand the folders on screen, collapse the ones they replaced. */
  function focusActiveElementFolder() {
    const shown = shownElements();
    lastShown = [...shown].sort().join(',');
    elementFolders.forEach(({ id, folder }) => {
      if (shown.has(id)) folder.expand();
      else folder.collapse();
    });
  }

  /** @returns {boolean} whether the "World" row owns the selection */
  function worldSelected() {
    return om?.activeName === 'World';
  }

  /**
   * @returns {boolean} whether any folder is on screen — including the ones
   * ghost-panel mounts itself (Material, a selected light), which is why this
   * reads the DOM rather than our own rules. `ui.update()` has already applied
   * every `showWhen` by the time this runs.
   */
  function inspectorBusy() {
    return Object.values(ui.panel.folders).some((f) => f.element?.style.display !== 'none');
  }

  function buildElementPanels() {
    const map = app.ctx.elements;
    if (!map || builtElements.size === map.size) return;
    map.forEach((element, id) => {
      if (builtElements.has(id)) return;
      builtElements.add(id);
      // Whatever folders appear across this call belong to this element —
      // more reliable than matching folder names to element labels.
      const before = new Set(Object.keys(ui.panel.folders));
      try {
        element.buildPanel?.(ui);
      } catch (err) {
        console.warn(`[EnvPaint] ${id}.buildPanel() failed:`, err);
      }
      Object.keys(ui.panel.folders)
        .filter((name) => !before.has(name))
        .forEach((name) => {
          const folder = ui.panel.folders[name];
          elementFolders.set(name, { id, folder });
          // ghost-panel re-evaluates `showWhen` for every folder on each
          // ui.update() (index.js:476), so this is the whole hide rule.
          folder.showWhen = () => shownElements().has(id);
        });
      registerElementObjects(element, id);
    });
    focusActiveElementFolder();
    ui.panel.body.appendChild(emptyRow);
    ui.refreshSceneObjects();
  }

  registerCoreObjects();
  buildElementPanels();
  ui.refreshSceneObjects();

  // ── per-frame sync ────────────────────────────────────────────────────
  function sync() {
    strip.sync();
    if (styleValue.textContent !== styleLabel()) styleValue.textContent = styleLabel();
    // Cheap: two map lookups, then a string compare against the last set.
    if ([...shownElements()].sort().join(',') !== lastShown) focusActiveElementFolder();
    emptyRow.hidden = inspectorBusy();
    for (const { ctrl, read } of bindings) {
      const v = read();
      if (differs(v, ctrl.getValue())) ctrl.setValue(v);
    }
    buildElementPanels();
    syncSceneObjects();
    syncMaterialFolder();
    // Shift+D toggles ghost-panel's own two panes directly (index.js:445), so
    // the pane and the strip follow the main panel rather than the keystroke.
    const panelsShown = ui.panel.isVisible();
    if (materialsPane.isVisible() !== panelsShown) {
      if (panelsShown) { materialsPane.show(); dockMaterialsPane(); }
      else materialsPane.hide();
    }
    if (strip.isVisible() !== panelsShown) strip.setVisible(panelsShown);
    // Hovering or dragging a transform handle must not paint through it.
    const gizmo = om?.gizmo;
    brush.enabled = !gizmoDragging && !(gizmo?.object && (gizmo.axis || gizmo.dragging));
  }

  ui.refreshTools = strip.refresh;

  // `ui.update` is deliberately NOT wrapped: ghost-panel's diagnostics pass
  // instruments it and restores its own reference on the first call
  // (diagnostics.js:210), which would silently drop any wrapper of ours.
  const onFrame = () => {
    ui.update();
    sync();
  };
  if (Array.isArray(app.onFrame)) app.onFrame.push(onFrame);
  else if (typeof app.onFrame === 'function') app.onFrame(onFrame);

  return ui;
}
