/**
 * `envpaint/ui` — the optional, DOM-side half.
 *
 * Unlike `envpaint/core` this entry needs **ghost-panel** (a peer dependency)
 * and a browser: the tool strip builds real elements and reads localStorage.
 */

export { createToolStrip } from './Toolbar.js';
export { toolIcon, ERASER_ICON, HOME_ICON } from './toolIcons.js';
