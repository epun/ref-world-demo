// Hand-drawn monochrome icons for the tool strip. One 24×24 glyph per tool id,
// stroke-only so a button can tint the whole thing with the tool's colour by
// setting `color`. Keep new glyphs on the same skeleton: 24 viewBox, 1.6 stroke,
// round caps and joins, no fills.

const OPEN = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" '
  + 'stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round">';

/** @param {string} body inner SVG markup @returns {string} */
const icon = (body) => `${OPEN}${body}</svg>`;

/** Tool id → glyph. Ids come from `brush.registerTool`. */
const ICONS = {
  // Mountain range with one sharp peak.
  sculpt: icon('<path d="M2.5 19.5 8.5 8l4 5.5 2.5-3.5 6.5 9.5Z"/><path d="M8.5 8l1.8 3.2"/>'),
  // No-go circle: the exclusion mask.
  mask: icon('<circle cx="12" cy="12" r="8"/><path d="M6.3 17.7 17.7 6.3"/>'),
  // Winding road with centre markings.
  path: icon('<path d="M8 21c0-5 7-5.5 7-9.5S9.5 6.5 9.5 3"/><path d="M9.6 17.7l1.9.6M13.4 12.8l1.7 1M12.6 7.2l1.9-.8"/>'),
  // Three blades from one root.
  grass: icon('<path d="M12 21V9.5"/><path d="M12 21c0-4.5-1.3-7.6-4.4-10.4"/><path d="M12 21c0-5.2 1.4-8.6 4.6-11.4"/>'),
  // Comb: spine and teeth.
  comb: icon('<path d="M4 7.5h16"/><path d="M6.5 7.5v9M10 7.5v9M14 7.5v9M17.5 7.5v9"/>'),
  // Five petals, an eye and a stem.
  flowers: icon(
    '<circle cx="12" cy="6.6" r="2.5"/><circle cx="16.1" cy="9.6" r="2.5"/>'
    + '<circle cx="14.5" cy="14.4" r="2.5"/><circle cx="9.5" cy="14.4" r="2.5"/>'
    + '<circle cx="7.9" cy="9.6" r="2.5"/><circle cx="12" cy="11" r="1.3"/>'
    + '<path d="M12 16.5V21"/>',
  ),
  // A drop landing on still water.
  pond: icon('<path d="M12 3.2c2.7 3.2 4 5.5 4 7.3a4 4 0 0 1-8 0c0-1.8 1.3-4.1 4-7.3Z"/><path d="M3 18.5c1.8-1.6 3.2-1.6 5 0s3.2 1.6 5 0 3.2-1.6 5 0"/>'),
  // S-curve with flow ticks.
  river: icon('<path d="M6.5 3c0 5 11 5 11 9.5S12 17 12 21"/><path d="M8.6 8.2l2.6 1M15.6 15.2l2.4-1.1"/>'),
  // Three falls over a splash arc.
  waterfall: icon('<path d="M8 3.5v9.5M12 3.5v10.5M16 3.5v9.5"/><path d="M4.5 16.5c2.2 2.4 4.8 3.6 7.5 3.6s5.3-1.2 7.5-3.6"/>'),
  // Faceted boulder.
  rocks: icon('<path d="M3.5 18.5 6.8 10l5.4-3 6 4.2 2.3 7.3Z"/><path d="M6.8 10l5.4 3.4 6-2.2M12.2 13.4v5.1"/>'),
  // Round canopy on a trunk.
  trees: icon('<circle cx="12" cy="9" r="5.6"/><path d="M12 14.6V21"/><path d="M12 18.2l2.8-2.4M12 17.1 9.4 15"/>'),
  // Flame with an inner tongue.
  fire: icon('<path d="M12 21c3.5 0 6-2.4 6-5.7 0-4.6-4.4-6.2-4.4-10.8 0 0-3.2 1.7-3.2 5.7 0 1.5-1 2-1.6 1.2C8 10 8 8.6 8 8.6 6.8 10.2 6 12.6 6 15.3 6 18.6 8.5 21 12 21Z"/><path d="M12 21c1.7 0 2.8-1.2 2.8-2.7 0-2-2-2.9-2-4.9-1.4 1.1-2 2.3-2 3.6 0 .8-.5 1-.9.5-.6 1.3-.7 3.5 2.1 3.5Z"/>'),
  // Cloud.
  clouds: icon('<path d="M7.2 18.5h9.9a4.1 4.1 0 0 0 .7-8.1 5.6 5.6 0 0 0-10.6-1.2 3.9 3.9 0 0 0 0 9.3Z"/>'),
};

/** Eraser, for the strip's erase toggle. */
export const ERASER_ICON = icon(
  '<path d="M8.6 19.5H20.5"/>'
  + '<path d="M15.4 5.1 4.9 15.6a2 2 0 0 0 0 2.9l1.5 1.5a2 2 0 0 0 2.9 0L19.8 9.5a2 2 0 0 0 0-2.9l-1.5-1.5a2 2 0 0 0-2.9 0Z"/>'
  + '<path d="M10 10.5 14.9 15.4"/>',
);

/** House, for the strip's reset-view button. */
export const HOME_ICON = icon('<path d="M3.5 10.5 12 3.5l8.5 7"/><path d="M5.5 9.6V20h13V9.6"/><path d="M9.8 20v-5.6h4.4V20"/>');

/** Shown for a tool id with no glyph of its own. */
const FALLBACK_ICON = icon('<circle cx="12" cy="12" r="3.4"/>');

/**
 * @param {string} id tool id
 * @returns {string} inline SVG markup, never empty
 */
export function toolIcon(id) {
  return ICONS[id] || FALLBACK_ICON;
}
