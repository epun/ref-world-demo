// Extra styles for the surfaces EnvPaint adds to ghost-panel: the material
// swatch chips, the inspector's empty state, and the bottom tool strip.
// Selectors are prefixed with `.ghost-panel` / `.dui-toolbar` so they
// out-specify ghost-panel's own element resets (styles.js:167) and inherit its
// design tokens, so everything follows the zinc / light themes.
const CSS = `
.ghost-panel .ep-swatch {
  display: block;
  width: 100%;
  height: 100%;
}
.ghost-panel .ep-folder-value {
  margin-left: auto;
  margin-right: 8px;
  color: hsl(var(--muted-foreground));
  font-size: 11px;
  font-weight: 400;
}
.ghost-panel .ep-empty {
  padding: 14px 12px;
  color: hsl(var(--muted-foreground));
  font-size: 12px;
  line-height: 1.5;
}

/* ── Tool strip ──
   Rides on ghost-panel's own .dui-toolbar chrome; these rules only size the
   icons up and add the per-tool tint, the hotkey glyph and the active ring. */
.dui-toolbar.ep-strip {
  padding: 5px;
  gap: 2px;
  /* ghost-panel stacks its panes at 9999 and its own toolbars at 9998
     (styles.js:43, :2383). A strip centred in the viewport would otherwise
     slide under the inspector or the Scene / Materials panes, so it sits one
     step above them — and still below popovers and modals at 10001+. */
  z-index: 10000;
  cursor: default;
}
.dui-toolbar.ep-strip .ep-strip-grip {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  width: 14px;
  height: 26px;
  margin: 0 1px 0 -1px;
  border-radius: 6px;
  color: hsl(0 0% 100% / 0.35);
  cursor: grab;
  flex: none;
  transition: color 0.12s ease, background 0.12s ease;
}
.dui-toolbar.ep-strip .ep-strip-grip:hover {
  color: hsl(0 0% 100% / 0.8);
  background: hsl(0 0% 100% / 0.08);
}
.dui-toolbar.ep-strip .ep-strip-grip:active,
.dui-toolbar.ep-strip.ep-strip-dragging .ep-strip-grip {
  cursor: grabbing;
}
.dui-toolbar.ep-strip .ep-strip-grip svg {
  width: 10px;
  height: 16px;
  display: block;
}
.dui-toolbar .ep-strip-btn {
  position: relative;
  padding: 4px;
  min-width: 34px;
  min-height: 34px;
  justify-content: center;
  border-radius: 9px;
}
.dui-toolbar .ep-strip-icon {
  width: 24px;
  height: 24px;
}
.dui-toolbar .ep-strip-icon svg {
  width: 24px;
  height: 24px;
}
.dui-toolbar .ep-strip-btn:hover {
  color: var(--ep-tool, hsl(0 0% 100%));
}
.dui-toolbar .ep-strip-btn.dui-active {
  color: var(--ep-tool, hsl(0 0% 100%));
  border-color: transparent;
  background: hsl(0 0% 100% / 0.1);
  box-shadow:
    inset 0 0 0 1.5px var(--ep-tool, hsl(0 0% 100%)),
    0 0 12px -4px var(--ep-tool, hsl(0 0% 100%));
}
.dui-toolbar .ep-strip-btn:focus-visible {
  outline: none;
  box-shadow: 0 0 0 3px hsl(0 0% 100% / 0.25);
}
.dui-toolbar .ep-strip-key {
  position: absolute;
  right: 3px;
  bottom: 1px;
  font-family: var(--dui-font-mono);
  font-size: 9px;
  line-height: 1;
  opacity: 0.5;
  text-transform: uppercase;
  pointer-events: none;
}
.dui-toolbar .ep-strip-erase {
  --ep-tool: #ff8a63;
}
`;

let injected = false;

/** Inject the EnvPaint panel stylesheet once per document. */
export function injectPanelStyles() {
  if (injected || typeof document === 'undefined') return;
  const style = document.createElement('style');
  style.setAttribute('data-envpaint-panel', '');
  style.textContent = CSS;
  document.head.appendChild(style);
  injected = true;
}
