import { Toolbar } from 'ghost-panel';
import { toolIcon, ERASER_ICON } from './toolIcons.js';

/** Tools that shape the ground, kept together at the head of the strip. */
const LANDSCAPE_TOOLS = new Set(['sculpt', 'mask', 'path']);

/**
 * Gap between the docked strip and the bottom of the viewport: small enough
 * to read as "on the edge", large enough to keep a shadow's worth of air
 * beneath it. Once the user drags the strip the offset stops applying.
 */
const DOCK_OFFSET = 14;

/** localStorage slot holding `{ docked, left, top }`. */
const STORE_KEY = 'envpaint.toolstrip';

/** Pointer travel, in px, before a press counts as a drag rather than a click. */
const DRAG_SLOP = 3;

/** Six-dot drag grip, in ghost-panel's flat monochrome idiom. */
const GRIP_ICON = `<svg viewBox="0 0 10 16" fill="currentColor" aria-hidden="true">
  <circle cx="3" cy="3" r="1.1"/><circle cx="7" cy="3" r="1.1"/>
  <circle cx="3" cy="8" r="1.1"/><circle cx="7" cy="8" r="1.1"/>
  <circle cx="3" cy="13" r="1.1"/><circle cx="7" cy="13" r="1.1"/>
</svg>`;

/**
 * @param {number} v
 * @param {number} lo
 * @param {number} hi
 * @returns {number}
 */
const clamp = (v, lo, hi) => Math.max(lo, Math.min(hi, v));

/**
 * The floating tool strip: one icon button per registered tool, in
 * registration order, plus an erase toggle. Built on ghost-panel's `Toolbar`
 * so the chrome (blur, border, radius, shadow, tokens) is literally the same
 * as its own bottom-anchored bars.
 *
 * It defaults to the bottom-centre of the *viewport* and stays there across
 * resizes while `docked`. Dragging the grip (or any empty part of the bar)
 * moves it anywhere inside the viewport and clears the flag; double-clicking
 * the grip docks it again. Position and flag persist in localStorage.
 *
 * @param {object} brush the Brush instance (`tools`, `tool`, `setTool`, `erase`)
 * @param {{ extras?: Array<{icon: string, tooltip: string, onClick: () => void}> }} [opts]
 *   `extras` are extra buttons pinned after the erase toggle
 * @returns {{ element: HTMLElement, refresh: () => void, sync: () => void,
 *             reposition: () => void, isVisible: () => boolean,
 *             setVisible: (v: boolean) => void, dispose: () => void }}
 */
export function createToolStrip(brush, opts = {}) {
  const bar = new Toolbar({ side: 'bottom', visible: true, compact: true });
  bar.element.classList.add('ep-strip');

  /** @type {Map<string, HTMLElement>} */
  const buttons = new Map();
  let eraseButton = null;
  let toolCount = -1;

  /** Placement: docked = bottom-centre of the viewport; otherwise left/top px. */
  const place = { docked: true, left: 0, top: 0, ...readStore() };

  // ── grip ────────────────────────────────────────────────────────────────
  const grip = document.createElement('span');
  grip.className = 'ep-strip-grip';
  grip.innerHTML = GRIP_ICON;
  grip.dataset.tooltip = 'Drag to move · double-click to re-dock';

  /** @returns {{docked: boolean, left: number, top: number}|null} */
  function readStore() {
    try {
      const raw = JSON.parse(localStorage.getItem(STORE_KEY) || 'null');
      if (!raw || typeof raw !== 'object') return null;
      const left = Number(raw.left);
      const top = Number(raw.top);
      if (!Number.isFinite(left) || !Number.isFinite(top)) return { docked: true };
      return { docked: raw.docked !== false, left, top };
    } catch {
      return null;
    }
  }

  function writeStore() {
    try {
      localStorage.setItem(STORE_KEY, JSON.stringify(place));
    } catch {
      /* private mode / quota — the strip just won't remember where it was */
    }
  }

  /**
   * @param {string} html inline SVG
   * @returns {HTMLButtonElement}
   */
  function makeButton(html) {
    const btn = document.createElement('button');
    btn.type = 'button';
    btn.className = 'dui-toolbar-btn ep-strip-btn';
    btn.innerHTML = `<span class="dui-toolbar-icon ep-strip-icon">${html}</span>`;
    return btn;
  }

  /** Rebuild every button. Cheap, and only runs when the tool set changes. */
  function refresh() {
    toolCount = brush.tools.size;
    buttons.clear();
    bar.element.textContent = '';
    // The grip is a child of the bar, so it goes back on after every rebuild.
    bar.element.appendChild(grip);
    let landscapeDone = false;

    brush.tools.forEach((tool, id) => {
      if (!landscapeDone && buttons.size && !LANDSCAPE_TOOLS.has(id)) {
        landscapeDone = true;
        bar.element.appendChild(divider());
      }
      const btn = makeButton(toolIcon(id));
      btn.dataset.tooltip = tool.label || id;
      btn.style.setProperty('--ep-tool', tool.color || 'currentColor');
      if (tool.key) {
        const key = document.createElement('span');
        key.className = 'ep-strip-key';
        key.textContent = tool.key;
        btn.appendChild(key);
      }
      // Clicking the tool in hand puts it down again: with no active tool the
      // inspector empties out and the brush paints nothing. Assigned rather
      // than routed through setTool(), which only accepts a registered id.
      btn.addEventListener('click', () => {
        if (brush.tool === id) brush.tool = null;
        else brush.setTool(id);
      });
      bar.element.appendChild(btn);
      buttons.set(id, btn);
    });

    if (buttons.size) bar.element.appendChild(divider());
    eraseButton = makeButton(ERASER_ICON);
    eraseButton.dataset.tooltip = 'Erase (X, or hold Ctrl)';
    eraseButton.classList.add('ep-strip-erase');
    eraseButton.addEventListener('click', () => { brush.erase = !brush.erase; });
    bar.element.appendChild(eraseButton);

    (opts.extras || []).forEach((extra) => {
      const btn = makeButton(extra.icon);
      btn.dataset.tooltip = extra.tooltip;
      btn.addEventListener('click', extra.onClick);
      bar.element.appendChild(btn);
    });

    sync();
    position();
  }

  /** @returns {HTMLElement} */
  function divider() {
    const el = document.createElement('span');
    el.className = 'dui-toolbar-divider';
    return el;
  }

  /** Mirror `brush.tool` / `brush.erase` onto the buttons. */
  function sync() {
    if (toolCount !== brush.tools.size) {
      refresh();
      return;
    }
    buttons.forEach((btn, id) => btn.classList.toggle('dui-active', id === brush.tool));
    eraseButton?.classList.toggle('dui-active', !!brush.erase);
  }

  /**
   * Write `place` to the element: bottom-centre of the viewport while docked,
   * otherwise the dragged position clamped so the whole bar stays reachable.
   * Anchored by left/top throughout, so a drag needs no coordinate flip.
   */
  function position() {
    const el = bar.element;
    const w = el.offsetWidth;
    const h = el.offsetHeight;
    // Hidden (Shift+D): it measures 0×0, so leave the last position alone and
    // place it again when it comes back.
    if (!w || !h) return;

    if (place.docked) {
      place.left = Math.round((window.innerWidth - w) / 2);
      place.top = Math.round(window.innerHeight - h - DOCK_OFFSET);
    }
    place.left = Math.round(clamp(place.left, 0, Math.max(0, window.innerWidth - w)));
    place.top = Math.round(clamp(place.top, 0, Math.max(0, window.innerHeight - h)));

    el.style.right = 'auto';
    el.style.bottom = 'auto';
    el.style.transform = 'none';
    el.style.left = `${place.left}px`;
    el.style.top = `${place.top}px`;
  }

  // ── dragging ────────────────────────────────────────────────────────────
  let drag = null;
  /**
   * Whether the press in progress started on the grip and has stayed still.
   * Capturing the pointer retargets the whole click pair to the bar, so the
   * grip never sees its own `dblclick` — this flag is what identifies it.
   */
  let pressOnGrip = false;

  /** @param {PointerEvent} e */
  function onPointerDown(e) {
    if (e.button !== 0) return;
    const target = e.target instanceof Element ? e.target : null;
    pressOnGrip = !!target?.closest('.ep-strip-grip');
    // Buttons keep their clicks; the grip and the bar's own background drag.
    if (target?.closest('.ep-strip-btn')) return;
    const r = bar.element.getBoundingClientRect();
    drag = { id: e.pointerId, x: e.clientX, y: e.clientY, left: r.left, top: r.top, moved: false };
    bar.element.setPointerCapture(e.pointerId);
    e.preventDefault();
  }

  /** @param {PointerEvent} e */
  function onPointerMove(e) {
    if (!drag || e.pointerId !== drag.id) return;
    const dx = e.clientX - drag.x;
    const dy = e.clientY - drag.y;
    if (!drag.moved && Math.hypot(dx, dy) < DRAG_SLOP) return;
    // The first real movement is what undocks it — a stray click does not.
    drag.moved = true;
    // A press that turned into a drag is no longer half of a double-click.
    pressOnGrip = false;
    bar.element.classList.add('ep-strip-dragging');
    place.docked = false;
    place.left = drag.left + dx;
    place.top = drag.top + dy;
    position();
  }

  /** @param {PointerEvent} e */
  function onPointerUp(e) {
    if (!drag || e.pointerId !== drag.id) return;
    const moved = drag.moved;
    drag = null;
    bar.element.classList.remove('ep-strip-dragging');
    if (bar.element.hasPointerCapture?.(e.pointerId)) {
      bar.element.releasePointerCapture(e.pointerId);
    }
    if (moved) writeStore();
  }

  /**
   * Double-clicking the grip sends the strip home to the bottom centre.
   *
   * Listened for on the bar, not the grip: `setPointerCapture` retargets the
   * click pair to the capture element, so a `dblclick` handler on the grip
   * itself never runs. `pressOnGrip` says where the press that produced this
   * double-click began; the target check covers the uncaptured case.
   *
   * @param {MouseEvent} e
   */
  function onDoubleClick(e) {
    const target = e.target instanceof Element ? e.target : null;
    if (!pressOnGrip && !target?.closest('.ep-strip-grip')) return;
    place.docked = true;
    position();
    writeStore();
  }

  bar.element.addEventListener('pointerdown', onPointerDown);
  bar.element.addEventListener('pointermove', onPointerMove);
  bar.element.addEventListener('pointerup', onPointerUp);
  bar.element.addEventListener('pointercancel', onPointerUp);
  bar.element.addEventListener('dblclick', onDoubleClick);
  window.addEventListener('resize', position);

  refresh();
  // The bar's own fonts and icons settle a frame later, so its width — and
  // with it the centred left edge — is only final after one more tick.
  requestAnimationFrame(position);

  return {
    element: bar.element,
    refresh,
    sync,
    reposition: position,
    isVisible: () => bar.element.classList.contains('dui-visible'),
    setVisible: (v) => {
      if (v) { bar.show(); position(); } else bar.hide();
    },
    dispose: () => {
      window.removeEventListener('resize', position);
      bar.element.remove();
    },
  };
}
