/**
 * Vector illustration: no lighting model at all. Every surface is its own flat
 * colour under one tint, there is no terminator anywhere, and a cast shadow is
 * a single darker tone with a crisp edge (`post.shadowRadius = 0`). Elements
 * drop their gradients too — see the `uStyleId == 1.0` branches.
 *
 * @type {import('../core/Style.js').StyleDef}
 */
export default {
  id: 'flat',
  label: 'Flat / unlit',
  lightingGLSL: /* glsl */ `
uniform float uStyleFlatTint;   // how much of the sky/ground hue tints the fill
uniform float uStyleFlatShade;  // the one flat tone a cast shadow multiplies by

// Unlit: there is no ramp. Cast shadows are the only tonal step, and they are
// hard, so this returns a hard step for callers that ramp a shadow themselves.
float toonRamp(float ndl, float bands, float soft) {
  return 1.0;
}

// One tint for the whole frame, normalised to average 1.0 so it recolours
// without darkening.
vec3 styleFlatTint() {
  vec3 hemi = mix(uGroundColor, uSkyColor, 0.65);
  float m = max(dot(hemi, vec3(0.3333)), 1e-4);
  return mix(vec3(1.0), hemi / m, uStyleFlatTint);
}

vec3 toonShadowColor(vec3 albedo, vec3 n) {
  return albedo * styleFlatTint() * uStyleFlatShade;
}

vec3 toonLight(vec3 albedo, vec3 n, float shadow, float bands) {
  // No n·l term at all: the only tonal step in the frame is the cast shadow,
  // and it is one flat tone with a hard edge.
  float shade = mix(uStyleFlatShade, 1.0, step(0.5, shadow));
  return albedo * styleFlatTint() * shade;
}
`,
  uniforms: {
    uStyleId: { value: 1 },
    uStyleFlatTint: { value: 0.25 },
    uStyleFlatShade: { value: 0.78 },
  },
  // Saturated and a touch lighter: poster inks, not pigment.
  palette: {
    sun: '#ffffff',
    sky: '#d6efff',
    ground: '#a8c774',
    background: '#a9dcff',
    skyTop: '#a9dcff',
    skyHorizon: '#ffe9b0',
    fog: '#dcf0ff',
    terrain: {
      meadow: '#7ede43',
      lush: '#46bd38',
      dirt: '#eeb45f',
      dirtEdge: '#b87434',
      wetSand: '#9a9448',
      rock: '#a3aab8',
      snow: '#ffffff',
      ash: '#514c48',
      char: '#2b2522',
    },
    grass: { base: '#42bd39', tip: '#8ee04a', dry: '#e8dd52' },
    rocks: { rock: '#9ea69f', warm: '#dcd5bf', cool: '#5470b4', moss: '#5fc73c' },
    clouds: { lit: '#ffffff', shade: '#b9cfe8' },
    // Slightly more saturated and lighter than the Ghibli defaults: poster
    // inks, not embers.
    fire: {
      rim: '#e83a12', outer: '#ff8a1a', mid: '#ffc22a', core: '#fff05a', hot: '#ffffe0',
      pool: '#ffc060', light: '#ffab2a', ember: '#ffe040', emberEdge: '#ff9a1a',
    },
    smoke: { dark: '#9a9db8', mid: '#c2c4d8', light: '#f0f1f8' },
    trees: { canopyShade: '#2f9145', canopyLight: '#63cf50', highlight: '#c9ee63', trunk: '#8a6242' },
    // Poster ink: a flat white spark, a flat yellow stone.
    sword: { glintTint: '#ffffff', gemTint: '#ffd93a' },
    // One printed blue and a white rim; the fall is two poster tones.
    water: {
      deep: '#1f7fd6', mid: '#1f7fd6', shallow: '#5cb4f5', foam: '#ffffff', wet: '#1f7fd6', highlight: '#ffffff',
      sheetBody: '#ffffff', sheetStreak: '#8ccbf7', sheetLine: '#8ccbf7', mist: '#ffffff',
    },
  },
  post: {
    // A crisp shape, not a soft one: no penumbra on the cast shadow.
    shadowRadius: 0,
    enabled: true,
    lineStyle: 'clean',
    lineWidth: 1.2,
    wobble: 0,
    break: 0,
    ink: '#1e1e2a',
    inkOpacity: 0.9,
    hatch: 0,
    paper: 0,
    pooling: 0,
    vignette: 0,
  },
};
