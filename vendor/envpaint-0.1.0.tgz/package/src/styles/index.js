import ghibliToon from './ghibli-toon.js';
import flat from './flat.js';
import realistic from './realistic.js';
import painterly from './painterly.js';
import pixel from './pixel.js';

/**
 * Every shipped style, in panel order. The first entry is the default the app
 * boots with — and the one whose `lightingGLSL` is compiled into
 * `toonParsFragment`, so booting into it needs no shader rewrite.
 *
 * @type {import('../core/Style.js').StyleDef[]}
 */
export const STYLES = [ghibliToon, flat, realistic, painterly, pixel];

export { ghibliToon, flat, realistic, painterly, pixel };
export default STYLES;
