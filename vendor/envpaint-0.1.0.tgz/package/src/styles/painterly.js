/**
 * Gouache on paper: the toon two-tone, but the terminator wanders through an
 * fbm field so band edges wobble like a brush stroke, shadows lose saturation
 * toward a warm paper tone, and the whole frame carries a heavier grain.
 *
 * Reuses the six Ghibli look uniforms (they keep their names so the panel's
 * look sliders keep driving the terminator) and adds its own `uStyle*` set.
 *
 * @type {import('../core/Style.js').StyleDef}
 */
export default {
  id: 'painterly',
  label: 'Painterly',
  lightingGLSL: /* glsl */ `
uniform vec3  uShadowTint;
uniform float uBandEdge;
uniform float uBandSoft;
uniform float uHalfTone;
uniform float uRim;
uniform float uGrain;

uniform float uStyleWobble;   // how far the terminator wanders
uniform float uStylePaper;    // shadow desaturation toward the paper tone
uniform vec3  uStylePaperCol; // the paper the shadows dry into

float toonRamp(float ndl, float bands, float soft) {
  float e = uBandEdge;
  float lit = smoothstep(e - uBandSoft, e + uBandSoft, ndl);
  float mid = smoothstep(e + 0.12 - uBandSoft, e + 0.12 + uBandSoft, ndl);
  return mix(lit, mix(lit * 0.5 + 0.5 * mid, lit, 1.0 - uHalfTone), step(1.5, bands));
}

// Shadows dry into paper: pulled toward their own luminance and the paper hue.
vec3 toonShadowColor(vec3 albedo, vec3 n) {
  vec3 s = albedo * uShadowTint;
  float l = dot(s, vec3(0.2126, 0.7152, 0.0722));
  s = mix(s, vec3(l) * uStylePaperCol, uStylePaper);
  s += uSkyColor * 0.05 * clamp(n.y, 0.0, 1.0);
  return s;
}

vec3 toonLight(vec3 albedo, vec3 n, float shadow, float bands) {
  // Wobbly terminator: the band edge follows the paint, not the geometry.
  float ndl = dot(n, uSunDir);
  ndl += (fbm(vWorldPos.xz * 2.5, 3) - 0.5) * 0.25 * uStyleWobble;

  float lit = toonRamp(ndl, bands, uBandSoft) * shadow;
  gToonLit = lit;

  vec3 shade = toonShadowColor(albedo, n);
  vec3 sunlit = albedo * uSunColor * 1.08;
  vec3 col = mix(shade, sunlit, lit);

  // A soft rim, wobbled by the same field so it breaks up along the edge.
  vec3 viewDir = normalize(cameraPosition - vWorldPos);
  float fres = 1.0 - max(dot(n, viewDir), 0.0);
  float edge = fbm(vWorldPos.xz * 5.0 + 11.0, 2) - 0.5;
  float rim = smoothstep(0.55, 0.78, fres + edge * 0.2) * (1.0 - lit) * uRim;
  col += uSunColor * rim;

  // Heavier grain than the toon style: broad wash mottle plus a dry fine tooth.
  float wash = fbm(vWorldPos.xz * 1.6 + vWorldPos.y * 0.4, 3) - 0.5;
  float tooth = hash21(floor(vWorldPos.xz * 42.0)) - 0.5;
  col *= 1.0 + uGrain * (0.20 * wash + 0.09 * tooth);

  return col;
}
`,
  uniforms: {
    uStyleId: { value: 3 },
    // Warm grey rather than the toon violet: gouache shadows are muddied, not
    // cooled.
    uShadowTint: { value: [0.72, 0.68, 0.64] },
    uBandEdge: { value: 0.26 },
    uBandSoft: { value: 0.12 },
    uHalfTone: { value: 0.55 },
    uRim: { value: 0.3 },
    uGrain: { value: 1.6 },
    uStyleWobble: { value: 1.0 },
    uStylePaper: { value: 0.45 },
    uStylePaperCol: { value: [1.0, 0.93, 0.82] },
  },
  // Pastel: chalky, low-contrast, everything a step toward white.
  palette: {
    sun: '#fff0dd',
    sky: '#e6efff',
    ground: '#b3bd93',
    background: '#d6e9f7',
    skyTop: '#cfe4f7',
    skyHorizon: '#fbeedd',
    fog: '#eef3f7',
    terrain: {
      meadow: '#a8d089',
      lush: '#8bbb72',
      dirt: '#d8b58c',
      dirtEdge: '#bb9670',
      wetSand: '#a09b7d',
      rock: '#b6b3bd',
      snow: '#fdfcff',
      ash: '#6a635d',
      char: '#4a423c',
    },
    grass: { base: '#84bd76', tip: '#dbeda0', dry: '#e9dfa6' },
    flowers: { white: '#fffaf2', yellow: '#ffeaa0', pink: '#ffc2d8', blue: '#b6cbf5', stem: '#7bb268', centre: '#f6d98b' },
    rocks: { rock: '#b0aca6', warm: '#d9d2c4', cool: '#8b9ab8', moss: '#95bd7c' },
    clouds: { lit: '#fffdf8', shade: '#d3dcef' },
    // Pastel: chalky, low-contrast, everything a step toward white.
    fire: {
      rim: '#e08a70', outer: '#ffab6e', mid: '#ffcb85', core: '#ffe4a8', hot: '#fff6dd',
      pool: '#ffcf94', light: '#ffb677', ember: '#ffdd9a', emberEdge: '#ffb27a',
    },
    smoke: { dark: '#b0aec2', mid: '#cdccdc', light: '#eeedf4' },
    trees: { canopyShade: '#79ab6f', canopyLight: '#c2e094', highlight: '#e8f3b8', trunk: '#a08268' },
    // Watercolour: the spark is a pale wash, the stone a soft amber.
    sword: { glintTint: '#fff4e8', gemTint: '#f0c878' },
    water: {
      deep: '#5f86bf', mid: '#86aede', shallow: '#b6d8f2', foam: '#fdfbf4', wet: '#5878ac', highlight: '#f6fbff',
      sheetBody: '#f7f4ec', sheetStreak: '#bcd8ef', sheetLine: '#87abd2', mist: '#fdfbf4',
    },
  },
  post: {
    enabled: true,
    lineStyle: 'brush',
    lineWidth: 2.2,
    wobble: 1.6,
    break: 0.35,
    ink: '#3a2c46',
    inkOpacity: 0.7,
    hatch: 0.45,
    hatchScale: 3.0,
    paper: 1.0,
    // Wet paint: edges darken as pigment pools, and colour smears a little
    // across them; directional strokes lie over the whole frame.
    pooling: 0.8,
    brush: 1.0,
    bleed: 0.7,
    vignette: 0.08,
  },
};
