/**
 * Physically-flavoured: lambert diffuse against the sun, a hemisphere ambient
 * fill and a Blinn-Phong highlight, with no quantisation anywhere. The shadow
 * map is softened (`post.shadowRadius`) so the terminator and the cast shadows
 * both read as smooth gradients instead of cel edges.
 *
 * @type {import('../core/Style.js').StyleDef}
 */
export default {
  id: 'realistic',
  label: 'Realistic',
  lightingGLSL: /* glsl */ `
uniform float uStyleSpec;       // specular strength
uniform float uStyleShininess;  // Blinn exponent
uniform float uStyleAmbient;    // hemisphere fill strength
uniform float uStyleSkyFill;    // how blue the shadow side goes
uniform float uStyleExposure;   // overall gain on the direct term

// No banding: the "ramp" is the raw clamped lambert term.
float toonRamp(float ndl, float bands, float soft) {
  return clamp(ndl, 0.0, 1.0);
}

// Ambient-only shading: sky above, bounced ground light below. What is in
// shadow goes sky-blue, the way an overcast fill really behaves.
vec3 toonShadowColor(vec3 albedo, vec3 n) {
  vec3 hemi = mix(uGroundColor, uSkyColor, clamp(n.y * 0.5 + 0.5, 0.0, 1.0));
  vec3 ambient = albedo * hemi * uStyleAmbient;
  return mix(ambient, ambient * uSkyColor * 1.25, uStyleSkyFill);
}

vec3 toonLight(vec3 albedo, vec3 n, float shadow, float bands) {
  float ndl = toonRamp(dot(n, uSunDir), bands, 0.0);
  float s = clamp(shadow, 0.0, 1.0);

  vec3 ambient = toonShadowColor(albedo, n);
  vec3 diffuse = albedo * uSunColor * ndl * s * uStyleExposure;

  // Blinn-Phong glint, killed on back faces and inside cast shadows.
  vec3 viewDir = normalize(cameraPosition - vWorldPos);
  vec3 halfDir = normalize(viewDir + uSunDir);
  float spec = pow(max(dot(n, halfDir), 0.0), max(uStyleShininess, 1.0));
  spec *= uStyleSpec * s * step(0.001, ndl);

  return ambient + diffuse + uSunColor * spec;
}
`,
  uniforms: {
    uStyleId: { value: 2 },
    uStyleSpec: { value: 0.55 },
    uStyleShininess: { value: 28 },
    uStyleAmbient: { value: 0.42 },
    uStyleSkyFill: { value: 0.45 },
    uStyleExposure: { value: 1.0 },
  },
  // Naturalistic, muted: desaturated greens and warm earth browns.
  palette: {
    sun: '#fff0cf',
    sky: '#b9cfe6',
    ground: '#6d6a4c',
    background: '#9dc2dd',
    skyTop: '#8fb9dc',
    skyHorizon: '#dfe3dc',
    fog: '#cfdae2',
    terrain: {
      meadow: '#6f8a4a',
      lush: '#556f39',
      dirt: '#96795a',
      dirtEdge: '#6f5942',
      wetSand: '#6c6a55',
      rock: '#8b8781',
      snow: '#eef2f5',
      ash: '#514c47',
      char: '#332e2a',
    },
    grass: { base: '#4d7038', tip: '#8fa356', dry: '#a89b62' },
    flowers: { white: '#e8e0d2', yellow: '#d6c05a', pink: '#c99aa6', blue: '#8fa0c0', stem: '#4e6b38', centre: '#c2a24e' },
    rocks: { rock: '#807c76', warm: '#a29a8c', cool: '#5a6472', moss: '#5f7a44' },
    clouds: { lit: '#f4f6f8', shade: '#a9b6c6' },
    // Naturalistic: deeper reds and oranges, a warmer (less yellow) white
    // core, and greyer smoke than the toon default.
    fire: {
      rim: '#8f2410', outer: '#c8500f', mid: '#d97f1e', core: '#e8a83c', hot: '#fbe4b0',
      pool: '#c97a2e', light: '#e0762a', ember: '#e8a13a', emberEdge: '#c05a1a',
    },
    smoke: { dark: '#565a5f', mid: '#7c7f83', light: '#a6a8ab' },
    trees: { canopyShade: '#35502c', canopyLight: '#6f8c47', highlight: '#9aa963', trunk: '#5d4632' },
    // A real specular is near-white and the stone barely glows.
    sword: { glintTint: '#fff3e2', gemTint: '#e8b94a' },
    water: {
      deep: '#1e3f5c', mid: '#2f6480', shallow: '#6b9fb2', foam: '#dfe9ec', wet: '#24506a', highlight: '#c9dde4',
      sheetBody: '#e6eef1', sheetStreak: '#9fbdc9', sheetLine: '#6b8f9f', mist: '#e9eef2',
    },
  },
  // No ink: a plain render, so the style reads as photographic next to the
  // hand-drawn ones.
  post: {
    // Soft, wide penumbra — the giveaway of a real light source.
    shadowRadius: 6,
    // The pass stays ON but draws no lines and no grain: a mild unsharp mask
    // and a touch of vignette, the way a photographic render is finished.
    enabled: true,
    lineStyle: 'none',
    lineWidth: 0,
    inkOpacity: 0,
    hatch: 0,
    paper: 0,
    pooling: 0,
    sharpen: 0.2,
    vignette: 0.05,
  },
};
