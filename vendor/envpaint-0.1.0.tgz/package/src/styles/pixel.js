/**
 * Posterised: the diffuse term snaps to three hard bands with zero softness,
 * and the finished colour is quantised to `uStyleLevels` steps per channel in
 * gamma space, so the palette collapses to a small set of flat inks like a
 * 16-bit sprite. (Screen-space pixel snapping is deliberately out of scope —
 * this is a material style, not a post pass.)
 *
 * @type {import('../core/Style.js').StyleDef}
 */
export default {
  id: 'pixel',
  label: 'Pixel',
  lightingGLSL: /* glsl */ `
uniform float uStyleLevels;   // colour steps per channel
uniform float uStyleShadeMix; // how dark the unlit band is
uniform vec3  uStyleShadeCol; // the ink shadows are mixed toward

// Three hard bands, no softness at all: 0.0, 0.5, 1.0.
float toonRamp(float ndl, float bands, float soft) {
  float t = clamp(ndl, 0.0, 1.0);
  return min(floor(t * 3.0), 2.0) * 0.5;
}

vec3 toonShadowColor(vec3 albedo, vec3 n) {
  return mix(albedo, albedo * uStyleShadeCol, uStyleShadeMix);
}

// Snap each channel to uStyleLevels steps. Done in gamma space so the steps
// land evenly on screen, then returned to linear for the colourspace encode.
vec3 stylePosterise(vec3 col) {
  float levels = max(uStyleLevels, 2.0);
  vec3 g = pow(max(col, vec3(0.0)), vec3(1.0 / 2.2));
  g = floor(g * levels + 0.5) / levels;
  return pow(g, vec3(2.2));
}

// Three hard bands, a hard cast shadow, no rim and no grain: every pixel of a
// sprite comes from a small set of inks.
vec3 toonLight(vec3 albedo, vec3 n, float shadow, float bands) {
  float ndl = dot(n, uSunDir);
  float lit = min(toonRamp(ndl, bands, 0.0), step(0.5, shadow));
  gToonLit = lit;

  vec3 shade = toonShadowColor(albedo, n);
  vec3 mid = mix(shade, albedo * uSunColor, 0.55);
  vec3 sunlit = albedo * uSunColor * 1.1;
  vec3 col = lit >= 0.99 ? sunlit : (lit >= 0.49 ? mid : shade);

  return stylePosterise(col);
}
`,
  uniforms: {
    uStyleId: { value: 4 },
    uStyleLevels: { value: 5 },
    uStyleShadeMix: { value: 0.85 },
    uStyleShadeCol: { value: [0.42, 0.5, 0.78] },
  },
  // Saturated sprite inks.
  palette: {
    sun: '#ffffff',
    sky: '#bfe4ff',
    ground: '#7ba03a',
    background: '#5cc8ff',
    skyTop: '#4fbfff',
    skyHorizon: '#ffd98a',
    fog: '#9fdcff',
    terrain: {
      meadow: '#4ec53a',
      lush: '#1f9e2c',
      dirt: '#d99b45',
      dirtEdge: '#96602a',
      wetSand: '#8f8a3c',
      rock: '#8f93a8',
      snow: '#ffffff',
      ash: '#565056',
      char: '#241d24',
    },
    grass: { base: '#2fae35', tip: '#c8f03a', dry: '#f0d63a' },
    flowers: { white: '#ffffff', yellow: '#ffd800', pink: '#ff5fa2', blue: '#3f7bff', stem: '#2fae35', centre: '#ffa800' },
    rocks: { rock: '#8a8f9c', warm: '#d3cfbc', cool: '#3f5aa8', moss: '#3fbe3a' },
    clouds: { lit: '#ffffff', shade: '#9fc0ef' },
    // Saturated, limited sprite inks.
    fire: {
      rim: '#c81a00', outer: '#ff5a00', mid: '#ff9e00', core: '#ffe400', hot: '#ffffff',
      pool: '#ff9e00', light: '#ff8000', ember: '#ffd800', emberEdge: '#ff6a00',
    },
    smoke: { dark: '#5a5f7a', mid: '#8a8faa', light: '#c8ccdc' },
    trees: { canopyShade: '#1f8f24', canopyLight: '#7ce03a', highlight: '#e0ff4a', trunk: '#8a4f1f' },
    // Two more inks in the sprite palette: a white sparkle and gold.
    sword: { glintTint: '#ffffff', gemTint: '#ffd000' },
    water: {
      deep: '#1440a8', mid: '#2a7de0', shallow: '#4ec3ff', foam: '#ffffff', wet: '#12358c', highlight: '#d9fbff',
      sheetBody: '#ffffff', sheetStreak: '#4ec3ff', sheetLine: '#2a7de0', mist: '#ffffff',
    },
  },
  post: {
    enabled: true,
    // The scene is rendered into a third-size buffer and sampled NEAREST, so
    // the outline below is one pixel-art pixel wide, drawn after pixelation.
    pixelSize: 3,
    dither: 1,
    levels: 5,
    lineStyle: 'clean',
    lineWidth: 1.0,
    wobble: 0,
    break: 0,
    ink: '#1b1430',
    inkOpacity: 0.9,
    hatch: 0,
    paper: 0,
    pooling: 0,
    vignette: 0,
    // Nearest sampling of a hard shadow map keeps the sprite edges square.
    shadowRadius: 1,
  },
};
