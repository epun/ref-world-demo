import { ghibliLightingGLSL } from '../core/shaders/toon.glsl.js';

/**
 * The default look: two flat tones, a cool hue-shifted shadow, a hard rim on
 * the shadow side and a painterly grain. Its GLSL is the block that ships
 * inside `toonParsFragment`, so switching back to this style restores the
 * shaders byte for byte.
 *
 * @type {import('../core/Style.js').StyleDef}
 */
export default {
  id: 'ghibli-toon',
  label: 'Ghibli toon',
  lightingGLSL: ghibliLightingGLSL,
  // The six look controls live on sun.uniforms; these are their defaults, so a
  // style switch back to toon also restores the panel sliders.
  uniforms: {
    uStyleId: { value: 0 },
    uShadowTint: { value: [0.5, 0.66, 0.82] },
    uBandEdge: { value: 0.22 },
    uBandSoft: { value: 0.04 },
    uHalfTone: { value: 0.35 },
    uRim: { value: 0.18 },
    uGrain: { value: 1.0 },
  },
  palette: {
    sun: '#fff3d6',
    sky: '#dcecff',
    ground: '#9cb07a',
    background: '#bfe0ff',
    skyTop: '#bfe0ff',
    skyHorizon: '#f3ecd8',
    fog: '#e9f0f6',
    terrain: {
      meadow: '#8fcf5a',
      lush: '#6ab545',
      dirt: '#c69a63',
      dirtEdge: '#a57b4d',
      wetSand: '#7f7a55',
      rock: '#9a9aa6',
      snow: '#f6f9ff',
      ash: '#4a4643',
      char: '#2f2a27',
    },
    grass: { base: '#5aa845', tip: '#cfe872', dry: '#e2d977' },
    flowers: { white: '#fff8f0', yellow: '#ffe45c', pink: '#ff9fc4', blue: '#8fb4ff', stem: '#4f9a3c', centre: '#f7c948' },
    rocks: { rock: '#8f8c88', warm: '#bfb8ab', cool: '#5f7396', moss: '#6fa04a' },
    clouds: { lit: '#ffffff', shade: '#b9c8e6' },
    fire: {
      rim: '#d63a1a', outer: '#ff7a1c', mid: '#ffb128', core: '#ffe36b', hot: '#fff7cf',
      pool: '#ffb15a', light: '#ff9a3a', ember: '#ffd24a', emberEdge: '#ff8a2a',
    },
    smoke: { dark: '#8c8fa3', mid: '#b0b2c2', light: '#dcdde6' },
    trees: { canopyShade: '#3f7d34', canopyLight: '#9ad35a', highlight: '#d8f08a', trunk: '#7a5a3a' },
    // Steel catches a warm painted spark; the pommel stone is Ghibli gold.
    sword: { glintTint: '#fff6da', gemTint: '#ffd257' },
    water: {
      deep: '#2b6ec2', mid: '#3d8fe0', shallow: '#79c6f4', foam: '#f7ffff', wet: '#2a62b0', highlight: '#f6fdff',
      sheetBody: '#f2fbff', sheetStreak: '#a9d8ff', sheetLine: '#5fa8e8', mist: '#ffffff',
    },
  },
  post: {
    shadowRadius: 1.5,
    enabled: true,
    lineStyle: 'pencil',
    lineWidth: 1.5,
    wobble: 0.7,
    break: 0.2,
    ink: '#2a2340',
    inkOpacity: 0.8,
    hatch: 0.3,
    hatchScale: 3.5,
    paper: 0.6,
    pooling: 0.15,
  },
};
