import { App } from './core/App.js';
import { ELEMENTS } from './elements/index.js';
import { createPanel } from './ui/Panel.js';

const app = new App(document.getElementById('app'));
await app.init();

for (const ElementClass of ELEMENTS) {
  await app.addElement(new ElementClass(app.ctx));
}

app.ui = createPanel(app);

app.ctx.elements.get('grass')?.fillMeadow();
app.brush.setTool('grass');

app.start();

/** @type {App} exposed for debugging and the screenshot script */
window.envpaint = app;
