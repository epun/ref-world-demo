import * as THREE from 'three';
import { Element } from '../core/Element.js';
import { Cutouts } from '../core/Cutouts.js';
import { PaintLayer } from '../core/PaintLayers.js';
import { WORLD_SIZE, HALF, LAYER_RES, worldToUV } from '../core/constants.js';
import { noiseGLSL, toonParsVertex, toonShadowVertex, toonParsFragment } from '../core/shaders/toon.glsl.js';

/** Segments along a stem; (SEG + 1) * 2 vertices, then 4 more for the head quad. */
const SEG = 2;

/** Seconds between scorch scans — burning must not cost a full-layer scan every frame. */
const SCORCH_TICK = 0.25;

/** Scorch value above which the flowers under it are gone. */
const SCORCH_KILL = 0.3;

/** Layer uniforms whose owners may register after Flowers. */
const EXTERNAL_LAYERS = [
  ['uHeight', 'height'],
  ['uMask', 'mask'],
  ['uPath', 'path'],
  ['uWater', 'water'],
  ['uPress', 'press'],
  ['uGrass', 'grass'],
];

/**
 * 1x1 stand-in for a layer that has no owner yet.
 * @param {number[]} rgba four bytes
 * @param {string} name
 * @returns {THREE.DataTexture}
 */
function placeholderTexture(rgba, name) {
  const tex = new THREE.DataTexture(new Uint8Array(rgba), 1, 1);
  tex.name = name;
  tex.minFilter = THREE.NearestFilter;
  tex.magFilter = THREE.NearestFilter;
  tex.generateMipmaps = false;
  tex.needsUpdate = true;
  return tex;
}

/**
 * Deterministic 32-bit PRNG so a reload lays out identical flowers.
 * @param {number} seed
 * @returns {() => number} generator of floats in [0, 1)
 */
function mulberry32(seed) {
  let a = seed >>> 0;
  return function next() {
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

const vertexShader = /* glsl */ `
#define WORLD_SIZE ${WORLD_SIZE.toFixed(1)}
#define TEXEL ${(1 / LAYER_RES).toFixed(8)}
#define TAU 6.2831853

${toonParsVertex}
${noiseGLSL}
#include <fog_pars_vertex>

uniform sampler2D uFlowers;
uniform sampler2D uGrass;
uniform sampler2D uMask;
uniform sampler2D uHeight;
uniform sampler2D uPath;
uniform sampler2D uWater;
uniform sampler2D uPress;

uniform float uDensity;
uniform float uNoiseScale;
uniform float uNoiseStrength;
uniform float uStemHeight;
uniform float uStemWidth;
uniform float uHeadSize;
uniform float uWindResponse;
uniform float uNeedGrass;
uniform float uZoom;        // camera frustum half-height: how far away we are
#define MAX_CUTOUTS 8
uniform vec3 uCutouts[MAX_CUTOUTS]; // x, z, radius of bare discs under props
uniform int uCutoutCount;
uniform vec4 uMix;          // colour weights: white, yellow, pink, blue
uniform vec3 uWhite;
uniform vec3 uYellow;
uniform vec3 uPink;
uniform vec3 uBlue;
uniform vec3 uCentre;

attribute vec2 aOffset;
attribute vec4 aRand;
attribute vec3 aVert;       // x = side/corner, y = t or corner, z = 0 stem / 1 head

varying vec4 vInfo;         // xy = head quad coords, z = t along the stem, w = part
varying vec3 vColor;
varying vec3 vCentreColor;

const vec2 NOISE_SEED = vec2(31.7, 11.9);

void main() {
  vec2 luv = aOffset / WORLD_SIZE + 0.5;

  float density = texture2D(uFlowers, luv).r;
  float grassV = texture2D(uGrass, luv).r;
  float maskV = texture2D(uMask, luv).r;
  float waterV = texture2D(uWater, luv).r;
  float pathV = texture2D(uPath, luv).r;
  float h = texture2D(uHeight, luv).r;

  // Terrain normal from central differences of the height layer: nothing
  // flowers on a cliff face.
  float hx0 = texture2D(uHeight, luv - vec2(TEXEL, 0.0)).r;
  float hx1 = texture2D(uHeight, luv + vec2(TEXEL, 0.0)).r;
  float hz0 = texture2D(uHeight, luv - vec2(0.0, TEXEL)).r;
  float hz1 = texture2D(uHeight, luv + vec2(0.0, TEXEL)).r;
  float span = 2.0 * TEXEL * WORLD_SIZE;
  vec3 groundN = normalize(vec3(-(hx1 - hx0) / span, 1.0, -(hz1 - hz0) / span));

  float base = density * uDensity * step(maskV, 0.35)
    * step(pathV, 0.5) * step(waterV, 0.15) * smoothstep(0.45, 0.7, groundN.y);
  // Wild flowers grow in the meadow, not on bare ground.
  base *= mix(1.0, step(0.15, grassV), step(0.5, uNeedGrass));

  float p = 0.0;
  if (base > aRand.x) {
    float n = fbm(luv * uNoiseScale * 40.0 + NOISE_SEED, 4);
    p = base * mix(1.0, smoothstep(0.3, 0.8, n), uNoiseStrength);
  }

  vInfo = vec4(0.0);
  vColor = vec3(0.0);
  vCentreColor = vec3(0.0);
  vWorldPos = vec3(0.0);
  vNormalW = vec3(0.0, 1.0, 0.0);
  #ifdef USE_FOG
    vFogDepth = 0.0;
  #endif

  if (p <= aRand.x) {
    gl_Position = vec4(2.0, 2.0, 2.0, 1.0);
    return;
  }
  // Bare discs under props (see core/Cutouts.js): nothing grows inside one.
  for (int i = 0; i < MAX_CUTOUTS; i++) {
    if (i >= uCutoutCount) break;
    if (distance(aOffset, uCutouts[i].xy) < uCutouts[i].z) {
      gl_Position = vec4(2.0, 2.0, 2.0, 1.0);
      return;
    }
  }

  float far = smoothstep(9.0, 22.0, uZoom);

  // Stem length and the bend that carries the bloom with it.
  float bh = uStemHeight * mix(0.25, 0.6, aRand.z);

  // Same gust lead / spring-back as the grass, a little softer on a stem.
  float tw = uTime * uWindSpeed;
  vec2 wNow = windAtT(aOffset, tw);
  vec2 wPast = windAtT(aOffset, tw - 0.12);
  vec2 windV = (wNow + (wNow - wPast) * 1.4) * uWindResponse;
  windV += uWindDir * length(wNow) * 0.18 * sin(tw * 5.0 + aRand.y * TAU + aOffset.x * 0.6) * uWindResponse;
  vec2 bend2 = windV + vec2(cos(aRand.y * TAU), sin(aRand.y * TAU)) * 0.06;

  // Anything heavy rolling over the ground presses flowers flat (Rocks write
  // this layer; RG is a direction in layer UV, whose axes are world XZ).
  vec4 pr = texture2D(uPress, luv);
  vec2 pushDir = pr.rg * 2.0 - 1.0;
  float push = pr.b;
  bend2 += pushDir * push * 2.2;
  bh *= 1.0 - 0.6 * push;

  // Far away the stems all but vanish and only the coloured heads remain.
  bh *= 1.0 - 0.45 * far;

  float bendAmt = length(bend2);
  float part = aVert.z;
  // The head rides the tip, so its corner coordinate must not drive the curve.
  float t = part < 0.5 ? aVert.y : 1.0;

  // The stem curve, quadratic in t; the head rides its tip.
  vec3 tip = vec3(
    bend2.x * bh * t * t,
    bh * t * (1.0 - 0.3 * bendAmt * t * t),
    bend2.y * bh * t * t
  );

  // Billboard basis: the view matrix's right and up, so a head always faces
  // the orthographic camera.
  vec3 right = normalize(vec3(viewMatrix[0][0], viewMatrix[1][0], viewMatrix[2][0]));
  vec3 upv = normalize(vec3(viewMatrix[0][1], viewMatrix[1][1], viewMatrix[2][1]));

  vec3 pos = tip;
  if (part < 0.5) {
    float width = uStemWidth * (1.0 - 0.5 * far);
    pos += right * aVert.x * width * 0.5;
  } else {
    // Head: a camera-facing quad at the stem tip, spun by aRand.y.
    // The rose fills ~0.72 of the quad, so widen it to land on the asked-for
    // bloom diameter.
    float halfSize = uHeadSize * mix(0.14, 0.32, aRand.z) * 0.7;
    float a = aRand.y * TAU;
    float ca = cos(a);
    float sa = sin(a);
    vec2 c = vec2(aVert.x * ca - aVert.y * sa, aVert.x * sa + aVert.y * ca);
    pos += (right * c.x + upv * c.y) * halfSize;
  }

  vec3 world = vec3(aOffset.x, h, aOffset.y) + pos;

  // Colour by weighted pick, so a meadow is mostly white with yellow, pink
  // and the occasional blue.
  vec4 w = max(uMix, vec4(0.0));
  float total = max(w.x + w.y + w.z + w.w, 1e-4);
  float pick = aRand.w * total;
  vec3 head = uWhite;
  vec3 centre = uCentre;
  if (pick >= w.x + w.y + w.z) {
    head = uBlue;
    centre = uWhite;   // a blue bloom wants a pale eye, not a yellow one
  } else if (pick >= w.x + w.y) {
    head = uPink;
  } else if (pick >= w.x) {
    head = uYellow;
  }
  head *= mix(0.96, 1.04, hash21(aOffset * 3.7));

  vInfo = vec4(aVert.xy, t, part);
  vColor = head;
  vCentreColor = centre;

  // Heads are lit as if facing the sky, so a whole bloom lands in one cel
  // band and the shadow side of a hill cools all of its flowers together.
  vec3 nrm = normalize(mix(vec3(0.0, 1.0, 0.0), groundN, 0.5) + vec3(bend2.x, 0.0, bend2.y) * 0.25);

  vec4 worldPosition = vec4(world, 1.0);
  vec3 transformedNormal = normalize(mat3(viewMatrix) * nrm);
${toonShadowVertex}
  #include <fog_vertex>
}
`;

const fragmentShader = /* glsl */ `
${toonParsFragment}
#include <fog_pars_fragment>

uniform vec3 uStem;
uniform float uZoom;

varying vec4 vInfo;
varying vec3 vColor;
varying vec3 vCentreColor;

void main() {
  vec3 n = normalize(vNormalW) * (gl_FrontFacing ? 1.0 : -1.0);
  float far = smoothstep(9.0, 22.0, uZoom);

  vec3 col;
  if (vInfo.w < 0.5) {
    // Stem: flat green, darker where it meets the ground.
    col = uStem * mix(0.7, 1.0, smoothstep(0.0, 0.35, vInfo.z));
  } else {
    // Head: five rounded petals around a small eye, cut out of the quad.
    vec2 q = vInfo.xy;
    float r = length(q);
    float ang = atan(q.y, q.x);
    // Zoomed out the rose collapses to a disc, so a distant meadow speckles
    // instead of shimmering.
    float petal = mix(0.5 + 0.22 * cos(5.0 * ang), 0.64, far);
    if (r > petal) discard;

    col = vColor;
    col = mix(col, col * 0.8, step(petal - 0.14, r) * (1.0 - far));
    col = mix(vCentreColor, col, step(0.2, r));
  }

  vec3 lit = toonLight(col, n, toonShadow(), 1.0);

  // Alpha is the PostFX ink mask, not opacity: 0 keeps the ink pass from
  // drawing a contour around every single bloom.
  gl_FragColor = vec4(lit, 0.0);
  #include <fog_fragment>
  #include <colorspace_fragment>
}
`;

/**
 * Painted wild flowers: one instanced stem-and-bloom mesh covering the world,
 * culled and shaped in the vertex shader from the painted `flowers` layer.
 * Painting never touches an instance buffer.
 */
export class Flowers extends Element {
  static id = 'flowers';
  static label = 'Flowers';
  static order = 12;

  /**
   * @param {object} ctx shared app context
   */
  constructor(ctx) {
    super(ctx);
    /** @type {Cutouts} bare discs under props, culled in the vertex shader */
    this.cutouts = new Cutouts();

    /** @type {object} panel-editable parameters */
    this.params = {
      count: 40000,
      density: 1,
      noiseScale: 0.3,
      noiseStrength: 0.5,
      size: 1,
      height: 1.4,
      windResponse: 0.8,
      needGrass: true,
      colorWhite: '#fff8f0',
      colorYellow: '#ffe45c',
      colorPink: '#ff9fc4',
      colorBlue: '#8fb4ff',
      colorStem: '#4f9a3c',
      colorCentre: '#f7c948',
      mix: { white: 0.35, yellow: 0.3, pink: 0.2, blue: 0.15 },
    };

    /** @type {THREE.Group|null} */
    this.root = null;
    /** @type {THREE.Mesh|null} */
    this.mesh = null;
    /** @type {THREE.ShaderMaterial|null} */
    this.material = null;
    /** @type {THREE.InstancedBufferGeometry|null} */
    this.geometry = null;
    /** @type {PaintLayer|null} */
    this.layer = null;

    /** @private @type {THREE.DataTexture|null} 1x1 black stand-in */
    this._placeholder = null;
    /** @private @type {THREE.DataTexture|null} 1x1 press-layer rest state */
    this._pressPlaceholder = null;
    /** @private @type {Array<[string, string]>} uniform/layer pairs still unresolved */
    this._pending = EXTERNAL_LAYERS.slice();
    /** @private @type {number} seconds since the last scorch scan */
    this._scorchTick = 0;
    /** @private @type {number} scorch layer version the last scan consumed */
    this._scorchVersion = -1;
  }

  /** Register the layer and tool, build the flower mesh. */
  async init() {
    const ctx = this.ctx;

    this.layer = ctx.layers.add(new PaintLayer('flowers', { channels: 1, float: false, initial: 0 }));

    ctx.brush.registerTool({
      id: 'flowers',
      label: 'Flowers',
      color: '#ff9fc4',
      excludes: ['path'],   // flowers grow back over a road
      key: 'w',
      layer: 'flowers',
      mode: 'add',
      channel: 0,
      eraseMode: 'erase',
    });

    this._placeholder = placeholderTexture([0, 0, 0, 255], 'flowers:placeholder');
    this._pressPlaceholder = placeholderTexture([128, 128, 0, 255], 'flowers:pressPlaceholder');

    this.material = this._buildMaterial();
    this.material.userData.uiProps = this._materialProps();
    this.material.userData.swatch = [this.params.colorWhite, this.params.colorPink, this.params.colorYellow];
    ctx.style?.attach?.(this.material, { element: Flowers.id });
    this.geometry = this._buildGeometry(this.params.count);

    this.mesh = new THREE.Mesh(this.geometry, this.material);
    this.mesh.name = 'flowers';
    this.mesh.frustumCulled = false;
    this.mesh.receiveShadow = true;
    this.mesh.matrixAutoUpdate = false;

    this.root = new THREE.Group();
    this.root.name = 'Flowers';
    this.root.matrixAutoUpdate = false;
    this.root.add(this.mesh);
    ctx.scene.add(this.root);

    this._resolveLayerTextures();
  }

  /**
   * Rebuild the instance buffers for a new flower count. Never called by painting.
   * @param {number} count number of flowers
   */
  rebuild(count) {
    const n = Math.max(1, Math.round(count));
    this.params.count = n;
    if (!this.mesh || !this.geometry || this.geometry.instanceCount === n) return;
    const old = this.geometry;
    this.geometry = this._buildGeometry(n);
    this.mesh.geometry = this.geometry;
    old.dispose();
  }

  /** Flower the whole world (the shader still respects mask, path, water and grass). */
  fillFlowers() {
    this.layer?.clear(1);
  }

  /** Remove every painted flower. */
  clearFlowers() {
    this.layer?.clear(0);
  }

  /**
   * Burn the flowers away inside a world-space disc. Fire calls this; anything
   * else that destroys ground cover can too.
   * @param {number} x world x
   * @param {number} z world z
   * @param {number} radius world units
   * @param {number} [amount=1] how much density to remove, 0..1
   * @returns {this}
   */
  burnAt(x, z, radius, amount = 1) {
    if (!this.layer) return this;
    const { u, v } = worldToUV(x, z);
    this.layer.stamp({
      u,
      v,
      radius: Math.max(radius, 1e-4) / WORLD_SIZE,
      strength: Math.max(0, Math.min(1, amount)),
      hardness: 0.5,
      mode: 'erase',
    });
    return this;
  }

  /**
   * @param {object} ui ghost-panel root or folder
   * @returns {object} the folder
   */
  buildPanel(ui) {
    const f = ui.addFolder('Flowers');
    const p = this.params;
    const u = this.material.uniforms;

    f.addSlider('Count', {
      min: 10000,
      max: 120000,
      step: 5000,
      value: p.count,
      onChange: (v) => this.rebuild(v),
    });
    f.addSlider('Density', {
      min: 0,
      max: 2,
      step: 0.01,
      value: p.density,
      onChange: (v) => {
        p.density = v;
        u.uDensity.value = v;
      },
    });
    f.addSlider('Noise scale', {
      min: 0.02,
      max: 1,
      step: 0.01,
      value: p.noiseScale,
      onChange: (v) => {
        p.noiseScale = v;
        u.uNoiseScale.value = v;
      },
    });
    f.addSlider('Noise strength', {
      min: 0,
      max: 1,
      step: 0.01,
      value: p.noiseStrength,
      onChange: (v) => {
        p.noiseStrength = v;
        u.uNoiseStrength.value = v;
      },
    });
    f.addSlider('Size', {
      min: 0.3,
      max: 3,
      step: 0.01,
      value: p.size,
      onChange: (v) => {
        p.size = v;
        u.uHeadSize.value = v;
      },
    });
    f.addSlider('Height', {
      min: 0.2,
      max: 3,
      step: 0.01,
      value: p.height,
      onChange: (v) => {
        p.height = v;
        u.uStemHeight.value = v;
      },
    });
    f.addSlider('Wind response', {
      min: 0,
      max: 2,
      step: 0.01,
      value: p.windResponse,
      onChange: (v) => {
        p.windResponse = v;
        u.uWindResponse.value = v;
      },
    });
    f.addCheckbox('Need grass', {
      value: p.needGrass,
      onChange: (v) => {
        p.needGrass = Boolean(v);
        u.uNeedGrass.value = v ? 1 : 0;
      },
    });
    f.addColor('White', {
      value: p.colorWhite,
      onChange: (hex) => this.applyPalette({ white: hex }),
    });
    f.addColor('Yellow', {
      value: p.colorYellow,
      onChange: (hex) => this.applyPalette({ yellow: hex }),
    });
    f.addColor('Pink', {
      value: p.colorPink,
      onChange: (hex) => this.applyPalette({ pink: hex }),
    });
    f.addColor('Blue', {
      value: p.colorBlue,
      onChange: (hex) => this.applyPalette({ blue: hex }),
    });
    f.addColor('Stem', {
      value: p.colorStem,
      onChange: (hex) => this.applyPalette({ stem: hex }),
    });
    f.addColor('Centre', {
      value: p.colorCentre,
      onChange: (hex) => this.applyPalette({ centre: hex }),
    });
    for (const key of ['white', 'yellow', 'pink', 'blue']) {
      f.addSlider(`Mix ${key}`, {
        min: 0,
        max: 1,
        step: 0.01,
        value: p.mix[key],
        onChange: (v) => {
          p.mix[key] = v;
          this._applyMix();
        },
      });
    }
    f.addButtonRow([
      { label: 'Fill flowers', onClick: () => this.fillFlowers() },
      { label: 'Clear flowers', onClick: () => this.clearFlowers() },
    ]);
    return f;
  }

  /**
   * Per frame: late layer textures, the zoom, and the scorch sweep that makes
   * flowers vanish wherever the ground burned.
   * @param {number} dt seconds since the last frame
   */
  update(dt = 0) {
    if (this._pending.length) this._resolveLayerTextures();
    const zoom = this.ctx.iso?.frustumHalfHeight;
    if (this.material && typeof zoom === 'number') this.material.uniforms.uZoom.value = zoom;

    this._scorchTick += dt;
    if (this._scorchTick >= SCORCH_TICK) {
      this._scorchTick = 0;
      this._burnScorched();
    }
  }

  /**
   * @param {import('../core/PaintLayers.js').PaintLayer} layer the layer that changed
   */
  onLayerChanged(layer) {
    if (this._pending.length && this._pending.some(([, id]) => id === layer.id)) {
      this._resolveLayerTextures();
    }
  }

  /** @returns {object} panel parameters */
  serialize() {
    return { ...this.params, mix: { ...this.params.mix } };
  }

  /**
   * @param {object} o output of `serialize()`
   */
  deserialize(o = {}) {
    const p = this.params;
    for (const key of Object.keys(p)) {
      if (o[key] === undefined) continue;
      if (key === 'mix') Object.assign(p.mix, o.mix);
      else p[key] = o[key];
    }
    this._applyParams();
    this.rebuild(p.count);
  }

  dispose() {
    if (this.root) this.ctx.scene.remove(this.root);
    if (this.material) this.ctx.style?.detach?.(this.material);
    this.geometry?.dispose();
    this.material?.dispose();
    this._placeholder?.dispose();
    this._pressPlaceholder?.dispose();
    this.root = null;
    this.mesh = null;
    this.geometry = null;
    this.material = null;
    this._placeholder = null;
    this._pressPlaceholder = null;
  }

  /**
   * Re-colour the blooms for a style. Writes `params` as well as the uniforms
   * so the panel and `serialize()` keep telling the truth.
   * @param {{white?:string, yellow?:string, pink?:string, blue?:string, stem?:string, centre?:string}} [p]
   * @returns {this}
   */
  applyPalette(p) {
    if (!p || !this.material) return this;
    const u = this.material.uniforms;
    if (p.white != null) { this.params.colorWhite = p.white; u.uWhite.value.set(p.white); }
    if (p.yellow != null) { this.params.colorYellow = p.yellow; u.uYellow.value.set(p.yellow); }
    if (p.pink != null) { this.params.colorPink = p.pink; u.uPink.value.set(p.pink); }
    if (p.blue != null) { this.params.colorBlue = p.blue; u.uBlue.value.set(p.blue); }
    if (p.stem != null) { this.params.colorStem = p.stem; u.uStem.value.set(p.stem); }
    if (p.centre != null) { this.params.colorCentre = p.centre; u.uCentre.value.set(p.centre); }
    return this;
  }

  /**
   * @private Bloom colours and shape, for the inspector's Material folder.
   * Colours go through `applyPalette` so `params` stays in step with the
   * uniforms. See "Material descriptors" in ARCHITECTURE.md.
   * @returns {Array<object>}
   */
  _materialProps() {
    const p = this.params;
    const u = this.material.uniforms;
    return [
      {
        label: 'White', kind: 'color', tooltip: 'The pale bloom',
        get: () => p.colorWhite, set: (v) => this.applyPalette({ white: v }),
      },
      {
        label: 'Yellow', kind: 'color', tooltip: 'The yellow bloom',
        get: () => p.colorYellow, set: (v) => this.applyPalette({ yellow: v }),
      },
      {
        label: 'Pink', kind: 'color', tooltip: 'The pink bloom',
        get: () => p.colorPink, set: (v) => this.applyPalette({ pink: v }),
      },
      {
        label: 'Blue', kind: 'color', tooltip: 'The blue bloom',
        get: () => p.colorBlue, set: (v) => this.applyPalette({ blue: v }),
      },
      {
        label: 'Stem', kind: 'color', tooltip: 'Stem green',
        get: () => p.colorStem, set: (v) => this.applyPalette({ stem: v }),
      },
      {
        label: 'Centre', kind: 'color', tooltip: 'The eye at the middle of a bloom',
        get: () => p.colorCentre, set: (v) => this.applyPalette({ centre: v }),
      },
      {
        label: 'Density', min: 0, max: 2, step: 0.01, tooltip: 'How much of the painted density flowers',
        get: () => p.density, set: (v) => { p.density = v; u.uDensity.value = v; },
      },
      {
        label: 'Size', min: 0.3, max: 3, step: 0.01, tooltip: 'Bloom width multiplier',
        get: () => p.size, set: (v) => { p.size = v; u.uHeadSize.value = v; },
      },
      {
        label: 'Height', min: 0.2, max: 3, step: 0.01, tooltip: 'Stem length multiplier',
        get: () => p.height, set: (v) => { p.height = v; u.uStemHeight.value = v; },
      },
      {
        label: 'Wind response', min: 0, max: 2, step: 0.01, tooltip: 'How far the wind leans a stem',
        get: () => p.windResponse, set: (v) => { p.windResponse = v; u.uWindResponse.value = v; },
      },
    ];
  }

  /**
   * @private
   * @returns {THREE.ShaderMaterial}
   */
  _buildMaterial() {
    const ctx = this.ctx;
    const p = this.params;
    const uniforms = THREE.UniformsUtils.merge([THREE.UniformsLib.lights, THREE.UniformsLib.fog]);
    // Same objects, by reference, so Sun/Wind updates reach this material.
    Object.assign(uniforms, ctx.sun.uniforms, ctx.wind.uniforms);

    Object.assign(uniforms, {
      uFlowers: { value: this.layer.texture },
      uGrass: { value: this._placeholder },
      uMask: { value: this._placeholder },
      uPath: { value: this._placeholder },
      uWater: { value: this._placeholder },
      uHeight: { value: this._placeholder },
      uPress: { value: this._pressPlaceholder },
      uDensity: { value: p.density },
      uNoiseScale: { value: p.noiseScale },
      uNoiseStrength: { value: p.noiseStrength },
      uStemHeight: { value: p.height },
      uStemWidth: { value: 0.03 },
      uHeadSize: { value: p.size },
      uWindResponse: { value: p.windResponse },
      uNeedGrass: { value: p.needGrass ? 1 : 0 },
      uZoom: { value: ctx.iso?.frustumHalfHeight ?? 14 },
      uCutouts: this.cutouts.uniforms.uCutouts,
      uCutoutCount: this.cutouts.uniforms.uCutoutCount,
      uMix: { value: new THREE.Vector4(p.mix.white, p.mix.yellow, p.mix.pink, p.mix.blue) },
      uWhite: { value: new THREE.Color(p.colorWhite) },
      uYellow: { value: new THREE.Color(p.colorYellow) },
      uPink: { value: new THREE.Color(p.colorPink) },
      uBlue: { value: new THREE.Color(p.colorBlue) },
      uStem: { value: new THREE.Color(p.colorStem) },
      uCentre: { value: new THREE.Color(p.colorCentre) },
    });

    return new THREE.ShaderMaterial({
      name: 'Flower',
      uniforms,
      vertexShader,
      fragmentShader,
      lights: true,
      fog: true,
      side: THREE.DoubleSide,
      toneMapped: false,
    });
  }

  /**
   * @private Stem strip + head quad, plus the jittered-grid instance attributes.
   * @param {number} count
   * @returns {THREE.InstancedBufferGeometry}
   */
  _buildGeometry(count) {
    const geo = new THREE.InstancedBufferGeometry();
    geo.name = 'flower';

    const rows = SEG + 1;
    const verts = new Float32Array((rows * 2 + 4) * 3);
    for (let row = 0; row < rows; row++) {
      const t = row / SEG;
      verts.set([-1, t, 0], (row * 2) * 3);
      verts.set([1, t, 0], (row * 2 + 1) * 3);
    }
    const headBase = rows * 2;
    verts.set([-1, -1, 1], (headBase + 0) * 3);
    verts.set([1, -1, 1], (headBase + 1) * 3);
    verts.set([-1, 1, 1], (headBase + 2) * 3);
    verts.set([1, 1, 1], (headBase + 3) * 3);
    geo.setAttribute('aVert', new THREE.BufferAttribute(verts, 3));

    const index = new Uint16Array(SEG * 6 + 6);
    for (let s = 0; s < SEG; s++) {
      const a = s * 2;
      index.set([a, a + 2, a + 1, a + 1, a + 2, a + 3], s * 6);
    }
    const b = headBase;
    index.set([b, b + 1, b + 2, b + 2, b + 1, b + 3], SEG * 6);
    geo.setIndex(new THREE.BufferAttribute(index, 1));

    const offsets = new Float32Array(count * 2);
    const rands = new Float32Array(count * 4);
    const k = Math.ceil(Math.sqrt(count));
    const cell = WORLD_SIZE / k;
    const rand = mulberry32(0x5f356495);
    for (let i = 0; i < count; i++) {
      const gx = i % k;
      const gz = (i / k) | 0;
      offsets[i * 2] = -HALF + (gx + 0.5 + (rand() - 0.5) * 0.95) * cell;
      offsets[i * 2 + 1] = -HALF + (gz + 0.5 + (rand() - 0.5) * 0.95) * cell;
      rands[i * 4] = rand();
      rands[i * 4 + 1] = rand();
      rands[i * 4 + 2] = rand();
      rands[i * 4 + 3] = rand();
    }
    geo.setAttribute('aOffset', new THREE.InstancedBufferAttribute(offsets, 2));
    geo.setAttribute('aRand', new THREE.InstancedBufferAttribute(rands, 4));
    geo.instanceCount = count;
    return geo;
  }

  /** @private Push every parameter into its uniform. */
  _applyParams() {
    if (!this.material) return;
    const p = this.params;
    const u = this.material.uniforms;
    u.uDensity.value = p.density;
    u.uNoiseScale.value = p.noiseScale;
    u.uNoiseStrength.value = p.noiseStrength;
    u.uStemHeight.value = p.height;
    u.uHeadSize.value = p.size;
    u.uWindResponse.value = p.windResponse;
    u.uNeedGrass.value = p.needGrass ? 1 : 0;
    this._applyMix();
    this.applyPalette({
      white: p.colorWhite,
      yellow: p.colorYellow,
      pink: p.colorPink,
      blue: p.colorBlue,
      stem: p.colorStem,
      centre: p.colorCentre,
    });
  }

  /** @private Push the four colour weights into their uniform. */
  _applyMix() {
    if (!this.material) return;
    const m = this.params.mix;
    this.material.uniforms.uMix.value.set(m.white, m.yellow, m.pink, m.blue);
  }

  /**
   * @private Flowers do not survive a burn: wherever the `scorch` layer went
   * past SCORCH_KILL, clear the painted density. Throttled by the layer's
   * version so an unchanging scorch layer costs nothing.
   */
  _burnScorched() {
    const scorch = this.ctx.layers?.get('scorch');
    if (!scorch || !this.layer) return;
    if (scorch.version === this._scorchVersion) return;
    this._scorchVersion = scorch.version;

    const src = scorch.data;
    const sres = scorch.res;
    const sch = scorch.channels;
    const kill = scorch.float ? SCORCH_KILL : SCORCH_KILL * 255;
    const dst = this.layer.data;
    const dres = this.layer.res;
    const scale = sres / dres;

    let x0 = dres;
    let y0 = dres;
    let x1 = -1;
    let y1 = -1;
    for (let y = 0; y < dres; y++) {
      const sy = scale === 1 ? y : Math.min(sres - 1, (y * scale) | 0);
      const srow = sy * sres;
      const drow = y * dres;
      for (let x = 0; x < dres; x++) {
        if (dst[drow + x] === 0) continue;
        const sx = scale === 1 ? x : Math.min(sres - 1, (x * scale) | 0);
        if (src[(srow + sx) * sch] <= kill) continue;
        dst[drow + x] = 0;
        if (x < x0) x0 = x;
        if (x > x1) x1 = x;
        if (y < y0) y0 = y;
        if (y > y1) y1 = y;
      }
    }
    if (x1 >= x0) this.layer.markDirtyRect(x0, y0, x1, y1);
  }

  /** @private Swap placeholders for real layer textures once their owners exist. */
  _resolveLayerTextures() {
    if (!this.material) return;
    const u = this.material.uniforms;
    for (let i = this._pending.length - 1; i >= 0; i--) {
      const [name, id] = this._pending[i];
      const layer = this.ctx.layers.get(id);
      if (!layer) continue;
      u[name].value = layer.texture;
      this._pending.splice(i, 1);
    }
  }
}
