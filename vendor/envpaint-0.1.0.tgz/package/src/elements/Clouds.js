import * as THREE from 'three';
import { Element } from '../core/Element.js';
import { PaintLayer } from '../core/PaintLayers.js';
import { worldToUV, uvToWorld } from '../core/constants.js';
import { toonParsVertex, toonShadowVertex, toonParsFragment } from '../core/shaders/toon.glsl.js';

const TAU = Math.PI * 2;

/** Rescan grid: cells across the world per side. */
const GRID = 32;
/** A grid cell spawns a cloud above this painted density. */
const CLOUD_THRESHOLD = 0.35;
/** Hard cap on live cloud instances. */
const MAX_CLOUDS = 120;
/** How far a cloud may drift from its origin cell before it wraps back. */
const WRAP_DIST = 6;
/** Base drift speed multiplier applied to the sampled wind. */
const DRIFT_BASE = 1.2;
/** Vertical bob amplitude, world units. */
const BOB_AMP = 0.15;
/** Cloud count that counts as full sky coverage for the wetness mood shift. */
const FULL_COVERAGE = 40;

/** Rain droplet pool size (streaks = 2 vertices each). */
const MAX_DROPS = 5000;
/** Droplets budgeted per cloud at rainAmount 1. */
const DROPS_PER_CLOUD = 60;
const FALL_MIN = 14;
const FALL_MAX = 18;
/** Horizontal drop speed per unit of sampled wind, world units/s. */
const RAIN_DRIFT = 9;
const STREAK_MIN = 0.5;
const STREAK_MAX = 0.9;
/** Alpha of an ordinary streak head, and of the brightest tenth. */
const RAIN_ALPHA = 0.55;
const RAIN_BRIGHT_ALPHA = 0.8;
const BRIGHT_FRACTION = 0.1;
/** Tail vertex keeps this fraction of the head alpha, which tapers the streak. */
const STREAK_TAPER = 0.22;

/** Splash-crown pool size; 3 line segments each. */
const MAX_SPLASHES = 400;
const SPLASH_LIFE = 0.22;
const SPLASH_MIN = 0.12;
const SPLASH_MAX = 0.2;
/** Water ring splashes handed to the water element per second, at most. */
const WATER_SPLASH_RATE = 60;

const FLASH_DUR = 0.25;
const BOLT_LIFE = 0.15;
const BOLT_SEGMENTS = 12;
const BOLT_FORK_SEGMENTS = 5;
const BOLT_MAX_SEGMENTS = BOLT_SEGMENTS + BOLT_FORK_SEGMENTS;
const BOLT_CORE_WIDTH = 0.16;
const BOLT_GLOW_WIDTH = 0.52;
const FLASH_LIGHT_INTENSITY = 40;

/** Overcast targets the scene lerps toward at wetness 1 (GhibliGenerator "Overcast"). */
const WET_SUN_COLOR = new THREE.Color('#c9d3e3');
const WET_SKY_COLOR = new THREE.Color('#9fb1c9');
const WET_GREY_COLOR = new THREE.Color('#b9c7d8');
/** Overcast zenith for the App's gradient sky. */
const WET_SKY_TOP_COLOR = new THREE.Color('#8e9fb5');

/** Shared up axis for the per-cloud yaw. */
const UP = new THREE.Vector3(0, 1, 0);

/**
 * Normal colour blending that leaves destination alpha at 0, so the PostFX ink
 * pass reads these pixels as "do not outline". Spread into every transparent
 * weather material; the clouds themselves keep alpha 1 and do get outlines.
 */
const INK_EXEMPT_BLEND = {
  blending: THREE.CustomBlending,
  blendEquation: THREE.AddEquation,
  blendSrc: THREE.SrcAlphaFactor,
  blendDst: THREE.OneMinusSrcAlphaFactor,
  blendEquationAlpha: THREE.AddEquation,
  blendSrcAlpha: THREE.ZeroFactor,
  blendDstAlpha: THREE.ZeroFactor,
};

/**
 * Deterministic 32-bit PRNG so a repainted cell rebuilds the same cloud.
 * @param {number} seed
 * @returns {() => number} generator of floats in [0, 1)
 */
function mulberry32(seed) {
  let a = seed >>> 0;
  return function next() {
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

const vertexShader = /* glsl */ `
${toonParsVertex}
#include <fog_pars_vertex>

attribute float aH;
varying float vH;

void main() {
  vH = aH;
  vec3 objectNormal = normal;
  vec4 localPosition = vec4(position, 1.0);
  #ifdef USE_INSTANCING
    localPosition = instanceMatrix * localPosition;
    objectNormal = mat3(instanceMatrix) * objectNormal;
  #endif
  vec4 worldPosition = modelMatrix * localPosition;
  vec3 transformedNormal = normalMatrix * objectNormal;
  ${toonShadowVertex}
  #include <fog_vertex>
}
`;

const fragmentShader = /* glsl */ `
${toonParsFragment}
#include <fog_pars_fragment>

uniform float uStyleId;   // 0 ghibli · 1 flat · 2 realistic · 3 painterly · 4 pixel
uniform vec3 uCloudLit;
uniform vec3 uCloudShade;

varying float vH;

void main() {
  vec3 n = normalize(vNormalW);

  // Lumpy break-up so the band edge on the underside is not a clean sphere line.
  float mottle = fbm(vWorldPos.xz * 0.24 + vec2(uTime * 0.02), 3);
  float belly = 1.0 - smoothstep(0.12, 0.78, vH + (mottle - 0.5) * 0.28);

  // --- style branches (see "Style branches" in ARCHITECTURE.md) ---
  if (uStyleId > 0.5 && uStyleId < 1.5) {
    // Flat: white with one flat blue-grey underside, no mottle.
    belly = 1.0 - step(0.45, vH);
  } else if (uStyleId > 1.5 && uStyleId < 2.5) {
    // Realistic: a soft, wide falloff into the shadowed base.
    belly = 1.0 - smoothstep(-0.1, 1.0, vH);
  } else if (uStyleId > 2.5 && uStyleId < 3.5) {
    // Painterly: heavier mottle, so the underside breaks into dabs.
    belly = 1.0 - smoothstep(0.12, 0.78, vH + (mottle - 0.5) * 0.7);
  } else if (uStyleId > 3.5) {
    // Pixel: two inks, hard edge.
    belly = 1.0 - step(0.5, vH + (mottle - 0.5) * 0.2);
  }

  vec3 albedo = mix(uCloudLit, uCloudShade, belly * 0.85);
  vec3 col = toonLight(albedo, n, toonShadow(), 1.0);

  gl_FragColor = vec4(col, 1.0);
  #include <fog_fragment>
  #include <colorspace_fragment>
}
`;

const rainVertexShader = /* glsl */ `
attribute float aAlpha;
attribute float aBright;

varying float vAlpha;
varying float vBright;

void main() {
  vAlpha = aAlpha;
  vBright = aBright;
  gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
}
`;

const rainFragmentShader = /* glsl */ `
uniform vec3 uColor;
uniform vec3 uBrightColor;
uniform float uFlash;

varying float vAlpha;
varying float vBright;

void main() {
  vec3 col = mix(uColor, uBrightColor, vBright);
  gl_FragColor = vec4(col, clamp(vAlpha * uFlash, 0.0, 1.0));
  #include <colorspace_fragment>
}
`;

/**
 * Painted clouds that drift with the wind and cast shadows, the Ghibli rain
 * that falls under them (streaks, splash crowns, a wet mood shift on the whole
 * scene) and the lightning that flashes through it.
 */
export class Clouds extends Element {
  static id = 'clouds';
  static label = 'Clouds';
  static order = 60;

  /**
   * @param {object} ctx shared app context
   */
  constructor(ctx) {
    super(ctx);

    /** @type {{altitude:number, cloudScale:number, driftSpeed:number, rain:boolean, rainAmount:number, rainVolume:number, lightning:boolean, lightningFreq:number}} */
    this.params = {
      altitude: 5,
      cloudScale: 1,
      driftSpeed: 1,
      rain: true,
      rainAmount: 0.6,
      rainVolume: 0.01,
      lightning: false,
      lightningFreq: 1,
    };

    /** @type {number} 0..1 smoothed "how wet is the world", read by the mood shift */
    this.wetness = 0;

    /** @type {PaintLayer|null} */
    this.layer = null;
    /** @type {THREE.InstancedMesh|null} */
    this.mesh = null;
    /** @type {Array<{key:number, ox:number, oz:number, x:number, z:number, alt:number, scale:number, phase:number, density:number}>} */
    this.clouds = [];

    /** @private @type {Map<number, object>} live clouds by grid-cell key */
    this._cloudByKey = new Map();
    /** @private @type {boolean} */
    this._needsRescan = false;

    /** @private @type {THREE.LineSegments|null} */
    this._rainMesh = null;
    /** @private @type {THREE.LineSegments|null} */
    this._splashMesh = null;
    /** @private @type {THREE.Mesh|null} */
    this._boltMesh = null;
    /** @private @type {THREE.Mesh|null} */
    this._boltGlow = null;
    /** @private @type {THREE.PointLight|null} */
    this._flashLight = null;

    /** @private @type {number} live droplets */
    this._dropCount = 0;
    /** @private @type {number} live splash crowns */
    this._splashCount = 0;
    /** @private @type {number} water-splash allowance, refilled every frame */
    this._waterBudget = 0;

    /** @private @type {number} seconds until the next automatic strike */
    this._nextStrike = 4;
    /** @private @type {number} seconds since the current flash started, or Infinity */
    this._flashT = Infinity;
    /** @private @type {number} 0..1 current flash envelope */
    this._flash = 0;

    /** @private @type {object|null} dry-scene values captured while the weather is neutral */
    this._baseline = null;

    /** @private @type {object|null} panel handles kept for deserialize */
    this._controls = null;
    /** @private @type {number} throttle for the wetness readout */
    this._infoT = 0;

    this._tmpV = new THREE.Vector3();
    this._tmpV2 = new THREE.Vector3();
    this._tmpQ = new THREE.Quaternion();
    this._tmpM = new THREE.Matrix4();
    this._tmpScale = new THREE.Vector3();
    this._tmpSide = new THREE.Vector3();
  }

  /** Register the cloud layer and tool, build the cloud, rain and bolt meshes. */
  async init() {
    const ctx = this.ctx;

    this.layer = ctx.layers.add(new PaintLayer('cloud', { channels: 1, float: false, initial: 0 }));

    ctx.brush.registerTool({
      id: 'clouds',
      label: 'Clouds',
      color: '#f0f6ff',
      key: 'c',
      layer: 'cloud',
      mode: 'add',
      channel: 0,
      eraseMode: 'erase',
    });

    this._buildClouds();
    this._buildRain();
    this._buildSplashes();
    this._buildLightning();

    this._needsRescan = true;
  }

  /**
   * Fire a lightning strike right now, at a random cloud (or the sky centre when
   * nothing is painted). Exposed so the panel and tests can force one.
   * @returns {boolean} true if a strike was started
   */
  lightningNow() {
    const cloud = this.clouds.length
      ? this.clouds[Math.floor(Math.random() * this.clouds.length)]
      : null;
    const x = cloud ? cloud.x : 0;
    const z = cloud ? cloud.z : 0;
    const y = cloud ? this.params.altitude + cloud.alt : this.params.altitude;
    this._flashT = 0;
    this._flash = 1;
    this._buildBolt(x, y - 0.6, z);
    this._setBolt(true, 0.95);
    if (this._flashLight) this._flashLight.position.set(x, y, z);
    return true;
  }

  /** Erase every painted cloud. */
  clearClouds() {
    this.layer?.clear(0);
  }

  /**
   * @param {object} ui ghost-panel root or folder
   * @returns {object} the folder
   */
  buildPanel(ui) {
    const f = ui.addFolder('Clouds & Weather');
    const p = this.params;

    const altitude = f.addSlider('Altitude', {
      min: 5,
      max: 24,
      step: 0.5,
      value: p.altitude,
      onChange: (v) => {
        p.altitude = v;
      },
    });
    const cloudScale = f.addSlider('Cloud scale', {
      min: 0.3,
      max: 2.5,
      step: 0.05,
      value: p.cloudScale,
      onChange: (v) => {
        p.cloudScale = v;
      },
    });
    const driftSpeed = f.addSlider('Drift speed', {
      min: 0,
      max: 4,
      step: 0.05,
      value: p.driftSpeed,
      onChange: (v) => {
        p.driftSpeed = v;
      },
    });
    const rain = f.addCheckbox('Rain', {
      value: p.rain,
      onChange: (v) => {
        p.rain = v;
      },
    });
    const rainAmount = f.addSlider('Rain amount', {
      min: 0,
      max: 1,
      step: 0.01,
      value: p.rainAmount,
      onChange: (v) => {
        p.rainAmount = v;
      },
    });
    const rainVolume = f.addSlider('Rain volume', {
      min: 0,
      max: 0.05,
      step: 0.001,
      value: p.rainVolume,
      onChange: (v) => {
        p.rainVolume = v;
      },
    });
    const lightning = f.addCheckbox('Lightning', {
      value: p.lightning,
      onChange: (v) => {
        p.lightning = v;
        if (v) this._nextStrike = 1.5;
      },
    });
    const lightningFreq = f.addSlider('Lightning frequency', {
      min: 0.1,
      max: 4,
      step: 0.05,
      value: p.lightningFreq,
      onChange: (v) => {
        p.lightningFreq = v;
      },
    });
    f.addButtonRow([
      { label: 'Strike now', onClick: () => this.lightningNow() },
      { label: 'Clear clouds', onClick: () => this.ctx.history.wrap('Clear clouds', () => this.clearClouds(), { element: 'clouds' }) },
    ]);
    const wetInfo = f.addInfo('Wetness 0.00 · clouds 0');

    this._controls = {
      altitude,
      cloudScale,
      driftSpeed,
      rain,
      rainAmount,
      rainVolume,
      lightning,
      lightningFreq,
      wetInfo,
    };
    return f;
  }

  /**
   * @param {number} dt seconds
   * @param {number} time seconds since start
   */
  update(dt, time) {
    if (this._needsRescan) {
      this._needsRescan = false;
      this._rescan();
    }

    this._updateClouds(dt, time);
    this._updateWeatherState(dt);
    this._updateLightning(dt);
    this._updateRain(dt, time);
    this._updateSplashes(dt);
    this._applyMood();
    this._updateInfo(dt);
  }

  /**
   * @param {import('../core/PaintLayers.js').PaintLayer} layer the layer that changed
   */
  onLayerChanged(layer) {
    if (layer.id === 'cloud') this._needsRescan = true;
  }

  /** @returns {object} panel parameters */
  serialize() {
    return { ...this.params };
  }

  /**
   * @param {object} o output of `serialize()`
   */
  deserialize(o = {}) {
    const p = this.params;
    for (const key of Object.keys(p)) {
      if (o[key] !== undefined) p[key] = o[key];
    }
    const c = this._controls;
    if (c) {
      c.altitude?.setValue?.(p.altitude);
      c.cloudScale?.setValue?.(p.cloudScale);
      c.driftSpeed?.setValue?.(p.driftSpeed);
      c.rain?.setValue?.(p.rain);
      c.rainAmount?.setValue?.(p.rainAmount);
      c.rainVolume?.setValue?.(p.rainVolume);
      c.lightning?.setValue?.(p.lightning);
      c.lightningFreq?.setValue?.(p.lightningFreq);
    }
  }

  dispose() {
    this._restoreBaseline();
    if (this.mesh) this.ctx.style?.detach?.(this.mesh.material);
    const scene = this.ctx.scene;
    const owned = [this.mesh, this._rainMesh, this._splashMesh, this._boltMesh, this._boltGlow, this._flashLight];
    for (const obj of owned) {
      if (!obj) continue;
      scene.remove(obj);
      /** @type {any} */ (obj).geometry?.dispose();
      /** @type {any} */ (obj).material?.dispose();
    }
    this.mesh = null;
    this._rainMesh = null;
    this._splashMesh = null;
    this._boltMesh = null;
    this._boltGlow = null;
    this._flashLight = null;
    this.clouds = [];
    this._cloudByKey.clear();
  }

  // ── build ────────────────────────────────────────────────────────────────

  /** @private Merged four-puff geometry + the instanced cloud mesh. */
  _buildClouds() {
    const ctx = this.ctx;
    const geometry = this._buildPuffGeometry();

    const uniforms = THREE.UniformsUtils.merge([THREE.UniformsLib.lights, THREE.UniformsLib.fog]);
    // Same objects, by reference, so Sun/Wind updates reach this material.
    Object.assign(uniforms, ctx.sun.uniforms, ctx.wind.uniforms);
    Object.assign(uniforms, {
      uCloudLit: { value: new THREE.Color('#ffffff') },
      uCloudShade: { value: new THREE.Color('#b9c8e6') },
    });

    const material = new THREE.ShaderMaterial({
      name: 'Cloud',
      uniforms,
      vertexShader,
      fragmentShader,
      lights: true,
      fog: true,
      toneMapped: false,
    });

    material.userData.uiProps = this._materialProps(material);
    material.userData.swatch = ['#ffffff', '#b9c8e6'];
    ctx.style?.attach?.(material, { element: 'clouds' });

    const mesh = new THREE.InstancedMesh(geometry, material, MAX_CLOUDS);
    mesh.name = 'clouds';
    mesh.count = 0;
    mesh.castShadow = true;
    mesh.receiveShadow = false;
    mesh.frustumCulled = false;
    mesh.instanceMatrix.setUsage(THREE.DynamicDrawUsage);
    ctx.scene.add(mesh);
    this.mesh = mesh;
  }

  /**
   * @private Cloud colours, for the inspector's Material folder. Both setters
   * go through `applyPalette`, the same path a style switch takes.
   * See "Material descriptors" in ARCHITECTURE.md.
   * @param {THREE.ShaderMaterial} material
   * @returns {Array<object>}
   */
  _materialProps(material) {
    const u = material.uniforms;
    const swatch = (label, key, name, tooltip) => ({
      label,
      kind: 'color',
      tooltip,
      get: () => `#${u[name].value.getHexString()}`,
      set: (v) => this.applyPalette({ [key]: v }),
    });
    return [
      swatch('Lit', 'lit', 'uCloudLit', 'Sunlit top of a cloud'),
      swatch('Shade', 'shade', 'uCloudShade', 'Underside of a cloud'),
    ];
  }

  /**
   * @private Four flat-shaded icosahedron puffs merged into one blob whose
   * horizontal radius is normalised to 1 so per-cloud scale reads in world units.
   * @returns {THREE.BufferGeometry}
   */
  _buildPuffGeometry() {
    const puffs = [
      { o: [0, 0, 0], s: 1 },
      { o: [1.15, -0.18, 0.28], s: 0.72 },
      { o: [-1.05, -0.12, -0.3], s: 0.8 },
      { o: [0.1, 0.42, -0.12], s: 0.62 },
    ];
    const base = new THREE.IcosahedronGeometry(1, 2);
    const src = base.index ? base.toNonIndexed() : base;
    const srcPos = src.attributes.position.array;
    const vertsPerPuff = src.attributes.position.count;
    const total = vertsPerPuff * puffs.length;

    const positions = new Float32Array(total * 3);
    let w = 0;
    for (const puff of puffs) {
      const [ox, oy, oz] = puff.o;
      for (let i = 0; i < vertsPerPuff; i++) {
        const x = srcPos[i * 3];
        const y = srcPos[i * 3 + 1];
        const z = srcPos[i * 3 + 2];
        // Smooth, direction-only bumpiness: shared vertices agree, so the puff
        // stays closed while the silhouette goes lumpy.
        const r = 1 + 0.13 * Math.sin(3.1 * x + 1.7) * Math.sin(2.7 * y + 0.4) * Math.sin(2.3 * z + 2.2);
        positions[w++] = ox + x * r * 1.6 * puff.s;
        positions[w++] = oy + y * r * 0.8 * puff.s;
        positions[w++] = oz + z * r * 1.2 * puff.s;
      }
    }
    if (src !== base) src.dispose();
    base.dispose();

    // Normalise so a cloud of scale s is roughly s world units in horizontal radius.
    let maxR = 0;
    let minY = Infinity;
    let maxY = -Infinity;
    for (let i = 0; i < total; i++) {
      const x = positions[i * 3];
      const y = positions[i * 3 + 1];
      const z = positions[i * 3 + 2];
      const r = Math.sqrt(x * x + z * z);
      if (r > maxR) maxR = r;
      if (y < minY) minY = y;
      if (y > maxY) maxY = y;
    }
    const inv = 1 / maxR;
    const spanY = maxY - minY || 1;
    const heights = new Float32Array(total);
    for (let i = 0; i < total; i++) {
      heights[i] = (positions[i * 3 + 1] - minY) / spanY;
      positions[i * 3] *= inv;
      positions[i * 3 + 1] *= inv;
      positions[i * 3 + 2] *= inv;
    }

    const geometry = new THREE.BufferGeometry();
    geometry.setAttribute('position', new THREE.BufferAttribute(positions, 3));
    geometry.setAttribute('aH', new THREE.BufferAttribute(heights, 1));
    geometry.computeVertexNormals(); // non-indexed → flat, faceted toon puffs
    geometry.computeBoundingSphere();
    return geometry;
  }

  /** @private Streak pool. */
  _buildRain() {
    const positions = new Float32Array(MAX_DROPS * 2 * 3);
    const alpha = new Float32Array(MAX_DROPS * 2);
    const bright = new Float32Array(MAX_DROPS * 2);

    const geometry = new THREE.BufferGeometry();
    const posAttr = new THREE.BufferAttribute(positions, 3);
    posAttr.setUsage(THREE.DynamicDrawUsage);
    geometry.setAttribute('position', posAttr);
    const alphaAttr = new THREE.BufferAttribute(alpha, 1);
    alphaAttr.setUsage(THREE.DynamicDrawUsage);
    geometry.setAttribute('aAlpha', alphaAttr);
    const brightAttr = new THREE.BufferAttribute(bright, 1);
    brightAttr.setUsage(THREE.DynamicDrawUsage);
    geometry.setAttribute('aBright', brightAttr);
    geometry.setDrawRange(0, 0);
    geometry.boundingSphere = new THREE.Sphere(new THREE.Vector3(), 1e4);

    const material = new THREE.ShaderMaterial({
      name: 'rain',
      uniforms: {
        uColor: { value: new THREE.Color('#e6f2ff') },
        uBrightColor: { value: new THREE.Color('#ffffff') },
        uFlash: { value: 1 },
      },
      vertexShader: rainVertexShader,
      fragmentShader: rainFragmentShader,
      transparent: true,
      depthWrite: false,
      fog: false,
      toneMapped: false,
      ...INK_EXEMPT_BLEND,
    });

    const mesh = new THREE.LineSegments(geometry, material);
    mesh.name = 'rain';
    mesh.userData.__duiIgnore = true;
    mesh.frustumCulled = false;
    mesh.renderOrder = 30;
    mesh.visible = false;
    this.ctx.scene.add(mesh);
    this._rainMesh = mesh;

    /** @private per-drop state, structure of arrays */
    this._drop = {
      x: new Float32Array(MAX_DROPS),
      y: new Float32Array(MAX_DROPS),
      z: new Float32Array(MAX_DROPS),
      speed: new Float32Array(MAX_DROPS),
      ground: new Float32Array(MAX_DROPS),
      len: new Float32Array(MAX_DROPS),
      bright: new Float32Array(MAX_DROPS),
    };
  }

  /** @private Splash-crown pool: 3 line segments per crown. */
  _buildSplashes() {
    const positions = new Float32Array(MAX_SPLASHES * 3 * 2 * 3);
    const alpha = new Float32Array(MAX_SPLASHES * 3 * 2);
    const bright = new Float32Array(MAX_SPLASHES * 3 * 2).fill(1);

    const geometry = new THREE.BufferGeometry();
    const posAttr = new THREE.BufferAttribute(positions, 3);
    posAttr.setUsage(THREE.DynamicDrawUsage);
    geometry.setAttribute('position', posAttr);
    const alphaAttr = new THREE.BufferAttribute(alpha, 1);
    alphaAttr.setUsage(THREE.DynamicDrawUsage);
    geometry.setAttribute('aAlpha', alphaAttr);
    geometry.setAttribute('aBright', new THREE.BufferAttribute(bright, 1));
    geometry.setDrawRange(0, 0);
    geometry.boundingSphere = new THREE.Sphere(new THREE.Vector3(), 1e4);

    const material = new THREE.ShaderMaterial({
      name: 'rain-splash',
      uniforms: {
        uColor: { value: new THREE.Color('#dff1ff') },
        uBrightColor: { value: new THREE.Color('#ffffff') },
        uFlash: { value: 1 },
      },
      vertexShader: rainVertexShader,
      fragmentShader: rainFragmentShader,
      transparent: true,
      depthWrite: false,
      fog: false,
      toneMapped: false,
      ...INK_EXEMPT_BLEND,
    });

    const mesh = new THREE.LineSegments(geometry, material);
    mesh.name = 'rain-splash';
    mesh.userData.__duiIgnore = true;
    mesh.frustumCulled = false;
    mesh.renderOrder = 31;
    mesh.visible = false;
    this.ctx.scene.add(mesh);
    this._splashMesh = mesh;

    /** @private per-splash state */
    this._splash = {
      x: new Float32Array(MAX_SPLASHES),
      y: new Float32Array(MAX_SPLASHES),
      z: new Float32Array(MAX_SPLASHES),
      age: new Float32Array(MAX_SPLASHES),
      size: new Float32Array(MAX_SPLASHES),
      angle: new Float32Array(MAX_SPLASHES),
    };
  }

  /**
   * @private A ribbon mesh the bolt writes its quads into.
   * @param {string} name
   * @param {string} color
   * @param {number} renderOrder
   * @returns {THREE.Mesh}
   */
  _buildBoltRibbon(name, color, renderOrder) {
    const geometry = new THREE.BufferGeometry();
    const posAttr = new THREE.BufferAttribute(new Float32Array(BOLT_MAX_SEGMENTS * 6 * 3), 3);
    posAttr.setUsage(THREE.DynamicDrawUsage);
    geometry.setAttribute('position', posAttr);
    geometry.boundingSphere = new THREE.Sphere(new THREE.Vector3(), 1e4);

    const mesh = new THREE.Mesh(
      geometry,
      new THREE.MeshBasicMaterial({
        name,
        color: new THREE.Color(color),
        transparent: true,
        opacity: 0.95,
        depthWrite: false,
        side: THREE.DoubleSide,
        fog: false,
        toneMapped: false,
        ...INK_EXEMPT_BLEND,
      }),
    );
    mesh.name = name;
    mesh.userData.__duiIgnore = true;
    mesh.frustumCulled = false;
    mesh.renderOrder = renderOrder;
    mesh.visible = false;
    this.ctx.scene.add(mesh);
    return mesh;
  }

  /** @private Bolt ribbons + flash point light. */
  _buildLightning() {
    // A wide blue halo under a narrow white core: the bolt has to stay legible
    // against the whole-scene brightening of its own flash.
    this._boltGlow = this._buildBoltRibbon('lightning-glow', '#7ea6ff', 32);
    this._boltMesh = this._buildBoltRibbon('lightning-bolt', '#ffffff', 33);

    // Added up-front (never removed) so no strike triggers a shader recompile.
    const light = new THREE.PointLight(new THREE.Color('#dfe8ff'), 0, 90, 1.4);
    light.name = 'lightning-flash';
    light.castShadow = false;
    this.ctx.scene.add(light);
    this._flashLight = light;
  }

  // ── clouds ───────────────────────────────────────────────────────────────

  /** @private Re-derive the cloud set from the painted layer, keeping drifted positions. */
  _rescan() {
    const layer = this.layer;
    if (!layer) return;

    const cells = [];
    for (let gy = 0; gy < GRID; gy++) {
      for (let gx = 0; gx < GRID; gx++) {
        const u = (gx + 0.5) / GRID;
        const v = (gy + 0.5) / GRID;
        const value = layer.sample(u, v);
        if (value > CLOUD_THRESHOLD) cells.push({ key: gy * GRID + gx, value, u, v });
      }
    }
    cells.sort((a, b) => b.value - a.value);
    if (cells.length > MAX_CLOUDS) cells.length = MAX_CLOUDS;

    const kept = new Map();
    const clouds = [];
    for (const cell of cells) {
      let cloud = this._cloudByKey.get(cell.key);
      if (!cloud) cloud = this._makeCloud(cell);
      cloud.density = cell.value;
      kept.set(cell.key, cloud);
      clouds.push(cloud);
    }
    this._cloudByKey = kept;
    this.clouds = clouds;
    if (this.mesh) {
      this.mesh.count = clouds.length;
      this.mesh.visible = clouds.length > 0;
    }
  }

  /**
   * @private
   * @param {{key:number, value:number, u:number, v:number}} cell
   * @returns {object} a fresh cloud sitting on its origin cell
   */
  _makeCloud(cell) {
    const rand = mulberry32(cell.key * 9781 + 12345);
    const { x, z } = uvToWorld(cell.u, cell.v);
    return {
      key: cell.key,
      ox: x,
      oz: z,
      x,
      z,
      alt: rand() * 2,
      scale: 1.5 + rand() * 2,
      phase: rand() * TAU,
      density: cell.value,
    };
  }

  /**
   * @private Advect every cloud with the wind and rewrite the instance matrices.
   * @param {number} dt
   * @param {number} time
   */
  _updateClouds(dt, time) {
    const mesh = this.mesh;
    if (!mesh) return;
    const p = this.params;
    const wind = this.ctx.wind;
    const drift = DRIFT_BASE * p.driftSpeed;
    const wrapSq = WRAP_DIST * WRAP_DIST;

    for (let i = 0; i < this.clouds.length; i++) {
      const c = this.clouds[i];
      if (drift > 0) {
        const w = wind.sampleAt(c.x, c.z, time);
        c.x += w.x * drift * dt;
        c.z += w.z * drift * dt;
        const dx = c.x - c.ox;
        const dz = c.z - c.oz;
        if (dx * dx + dz * dz > wrapSq) {
          c.x = c.ox;
          c.z = c.oz;
        }
      }
      const s = c.scale * p.cloudScale;
      const y = p.altitude + c.alt + Math.sin(time * 0.5 + c.phase) * BOB_AMP;
      this._tmpV.set(c.x, y, c.z);
      this._tmpQ.setFromAxisAngle(UP, c.phase);
      this._tmpScale.set(s, s, s);
      this._tmpM.compose(this._tmpV, this._tmpQ, this._tmpScale);
      mesh.setMatrixAt(i, this._tmpM);
    }
    mesh.count = this.clouds.length;
    mesh.visible = this.clouds.length > 0;
    mesh.instanceMatrix.needsUpdate = true;
  }

  // ── weather state ────────────────────────────────────────────────────────

  /**
   * @private Smooth the wetness toward cloud coverage × rain amount.
   * @param {number} dt
   */
  _updateWeatherState(dt) {
    const p = this.params;
    const coverage = Math.min(1, this.clouds.length / FULL_COVERAGE);
    const target = p.rain ? coverage * p.rainAmount : 0;
    // ~2 s to settle.
    this.wetness += (target - this.wetness) * (1 - Math.exp(-dt * 1.2));
    if (this.wetness < 1e-4) this.wetness = 0;
  }

  // ── rain ─────────────────────────────────────────────────────────────────

  /**
   * @private Advance every droplet, respawn the ones that landed.
   * @param {number} dt
   * @param {number} time
   */
  _updateRain(dt, time) {
    const mesh = this._rainMesh;
    if (!mesh) return;
    const p = this.params;
    const raining = p.rain && p.rainAmount > 0 && this.clouds.length > 0;

    const want = raining
      ? Math.min(MAX_DROPS, Math.round(this.clouds.length * DROPS_PER_CLOUD * p.rainAmount))
      : 0;
    if (!want) {
      this._dropCount = 0;
      mesh.visible = false;
      mesh.geometry.setDrawRange(0, 0);
      return;
    }

    const drop = this._drop;
    // New droplets start in mid-air so turning rain up does not show a curtain edge.
    for (let i = this._dropCount; i < want; i++) this._spawnDrop(i, true);
    this._dropCount = want;
    mesh.visible = true;

    const wind = this.ctx.wind.sampleAt(0, 0, time);
    const vx = wind.x * RAIN_DRIFT;
    const vz = wind.z * RAIN_DRIFT;

    const positions = mesh.geometry.attributes.position.array;
    const alpha = mesh.geometry.attributes.aAlpha.array;
    const brightAttr = mesh.geometry.attributes.aBright.array;

    this._waterBudget = Math.min(WATER_SPLASH_RATE, this._waterBudget + WATER_SPLASH_RATE * dt);
    const water = this.ctx.elements.get('water');
    const waterLayer = this.ctx.layers.get('water');

    for (let i = 0; i < want; i++) {
      const speed = drop.speed[i];
      drop.x[i] += vx * dt;
      drop.z[i] += vz * dt;
      drop.y[i] -= speed * dt;

      if (drop.y[i] <= drop.ground[i]) {
        this._land(drop.x[i], drop.ground[i], drop.z[i], water, waterLayer);
        this._spawnDrop(i, false);
      }

      // The streak lies along the droplet's own velocity, so the whole curtain
      // shares one wind-given slant.
      const inv = 1 / Math.hypot(vx, speed, vz);
      const dx = vx * inv;
      const dy = -speed * inv;
      const dz = vz * inv;
      const len = drop.len[i];

      const o = i * 6;
      positions[o] = drop.x[i];
      positions[o + 1] = drop.y[i];
      positions[o + 2] = drop.z[i];
      positions[o + 3] = drop.x[i] - dx * len;
      positions[o + 4] = drop.y[i] - dy * len;
      positions[o + 5] = drop.z[i] - dz * len;

      const b = drop.bright[i];
      const head = b > 0.5 ? RAIN_BRIGHT_ALPHA : RAIN_ALPHA;
      const a = i * 2;
      alpha[a] = head;
      alpha[a + 1] = head * STREAK_TAPER;
      brightAttr[a] = b;
      brightAttr[a + 1] = b;
    }

    mesh.geometry.setDrawRange(0, want * 2);
    mesh.geometry.attributes.position.needsUpdate = true;
    mesh.geometry.attributes.aAlpha.needsUpdate = true;
    mesh.geometry.attributes.aBright.needsUpdate = true;
  }

  /**
   * @private Place droplet `i` under a random cloud.
   * @param {number} i
   * @param {boolean} scatter true to start it partway down instead of at the cloud
   */
  _spawnDrop(i, scatter) {
    const drop = this._drop;
    const clouds = this.clouds;
    const c = clouds[Math.floor(Math.random() * clouds.length)] || clouds[0];
    const radius = c.scale * this.params.cloudScale * 1.3;
    const a = Math.random() * TAU;
    const r = Math.sqrt(Math.random()) * radius;
    const x = c.x + Math.cos(a) * r;
    const z = c.z + Math.sin(a) * r;
    const top = this.params.altitude + c.alt - 0.8 - Math.random() * 1.2;
    const ground = this.ctx.terrain.heightAt(x, z);

    drop.x[i] = x;
    drop.z[i] = z;
    drop.ground[i] = ground;
    drop.y[i] = scatter ? ground + Math.random() * Math.max(0.5, top - ground) : top;
    drop.speed[i] = FALL_MIN + Math.random() * (FALL_MAX - FALL_MIN);
    drop.len[i] = STREAK_MIN + Math.random() * (STREAK_MAX - STREAK_MIN);
    drop.bright[i] = Math.random() < BRIGHT_FRACTION ? 1 : 0;
  }

  /**
   * @private A droplet reached the ground: a ring on water; on land a splash
   * crown plus a drop of volume for the water flow simulation.
   * @param {number} x
   * @param {number} y
   * @param {number} z
   * @param {object|undefined} water the water element, if registered
   * @param {import('../core/PaintLayers.js').PaintLayer|undefined} waterLayer
   */
  _land(x, y, z, water, waterLayer) {
    let onWater = false;
    if (water?.isWater) {
      onWater = Boolean(water.isWater(x, z));
    } else if (waterLayer) {
      const { u, v } = worldToUV(x, z);
      onWater = waterLayer.sample(u, v) > 0.5;
    }

    if (onWater) {
      if (this._waterBudget >= 1) {
        this._waterBudget -= 1;
        water?.splash?.(x, z, 0.25, 0.15);
      }
      return;
    }
    // Rain falling on land feeds the water flow simulation, so puddles and
    // runoff build up where it rains. A no-op until Water ships addVolume.
    if (this.params.rainVolume > 0) water?.addVolume?.(x, z, this.params.rainVolume);
    this._spawnSplash(x, y, z);
  }

  /**
   * @private
   * @param {number} x
   * @param {number} y
   * @param {number} z
   */
  _spawnSplash(x, y, z) {
    if (this._splashCount >= MAX_SPLASHES) return;
    const i = this._splashCount++;
    const s = this._splash;
    s.x[i] = x;
    s.y[i] = y;
    s.z[i] = z;
    s.age[i] = 0;
    s.size[i] = SPLASH_MIN + Math.random() * (SPLASH_MAX - SPLASH_MIN);
    s.angle[i] = Math.random() * TAU;
  }

  /**
   * @private Age the crowns and rewrite their three ticks.
   * @param {number} dt
   */
  _updateSplashes(dt) {
    const mesh = this._splashMesh;
    if (!mesh) return;
    const s = this._splash;

    for (let i = this._splashCount - 1; i >= 0; i--) {
      s.age[i] += dt;
      if (s.age[i] < SPLASH_LIFE) continue;
      const last = --this._splashCount;
      if (i !== last) {
        s.x[i] = s.x[last];
        s.y[i] = s.y[last];
        s.z[i] = s.z[last];
        s.age[i] = s.age[last];
        s.size[i] = s.size[last];
        s.angle[i] = s.angle[last];
      }
    }

    const count = this._splashCount;
    if (!count) {
      mesh.visible = false;
      mesh.geometry.setDrawRange(0, 0);
      return;
    }
    mesh.visible = true;

    const positions = mesh.geometry.attributes.position.array;
    const alpha = mesh.geometry.attributes.aAlpha.array;

    for (let i = 0; i < count; i++) {
      const t = s.age[i] / SPLASH_LIFE;
      const size = s.size[i];
      const spread = size * (0.35 + 1.7 * t);
      const rise = size * (1.1 - 0.35 * t);
      const a = (1 - t) * 0.85;
      const dx = Math.cos(s.angle[i]);
      const dz = Math.sin(s.angle[i]);
      const x = s.x[i];
      const y = s.y[i] + 0.02;
      const z = s.z[i];

      const o = i * 18;
      // Left tick, flicking outward and up.
      positions[o] = x - dx * spread;
      positions[o + 1] = y;
      positions[o + 2] = z - dz * spread;
      positions[o + 3] = x - dx * spread * 1.25;
      positions[o + 4] = y + rise * 0.7;
      positions[o + 5] = z - dz * spread * 1.25;
      // Right tick.
      positions[o + 6] = x + dx * spread;
      positions[o + 7] = y;
      positions[o + 8] = z + dz * spread;
      positions[o + 9] = x + dx * spread * 1.25;
      positions[o + 10] = y + rise * 0.7;
      positions[o + 11] = z + dz * spread * 1.25;
      // Centre spike.
      positions[o + 12] = x;
      positions[o + 13] = y;
      positions[o + 14] = z;
      positions[o + 15] = x;
      positions[o + 16] = y + rise;
      positions[o + 17] = z;

      const ao = i * 6;
      for (let k = 0; k < 6; k++) alpha[ao + k] = a;
    }

    mesh.geometry.setDrawRange(0, count * 6);
    mesh.geometry.attributes.position.needsUpdate = true;
    mesh.geometry.attributes.aAlpha.needsUpdate = true;
  }

  // ── lightning ────────────────────────────────────────────────────────────

  /**
   * @private Countdown, flash envelope and bolt lifetime.
   * @param {number} dt
   */
  _updateLightning(dt) {
    const p = this.params;

    if (p.lightning && this.clouds.length) {
      this._nextStrike -= dt;
      if (this._nextStrike <= 0) {
        this.lightningNow();
        this._nextStrike = (2 + Math.random() * 5) / Math.max(0.05, p.lightningFreq);
      }
    } else if (this._nextStrike <= 0) {
      this._nextStrike = 2 + Math.random() * 5;
    }

    if (this._flashT < FLASH_DUR) {
      this._flashT += dt;
      const t = Math.min(1, this._flashT / FLASH_DUR);
      // Falling envelope with two flickers on the way down.
      this._flash = Math.max(0, (1 - t) * (0.5 + 0.5 * Math.cos(t * Math.PI * 6)));
      const boltVisible = this._flashT < BOLT_LIFE;
      const boltAlpha = 0.35 + 0.6 * Math.max(0, 1 - this._flashT / BOLT_LIFE);
      this._setBolt(boltVisible, boltAlpha);
    } else {
      this._flash = 0;
      this._flashT = Infinity;
      this._setBolt(false, 0);
    }

    if (this._flashLight) this._flashLight.intensity = FLASH_LIGHT_INTENSITY * this._flash;
    const boost = 1 + 0.6 * this._flash;
    if (this._rainMesh) /** @type {any} */ (this._rainMesh.material).uniforms.uFlash.value = boost;
    if (this._splashMesh) /** @type {any} */ (this._splashMesh.material).uniforms.uFlash.value = boost;
  }

  /**
   * @private
   * @param {boolean} visible
   * @param {number} alpha core opacity; the halo runs at 60 % of it
   */
  _setBolt(visible, alpha) {
    if (this._boltMesh) {
      this._boltMesh.visible = visible;
      /** @type {THREE.MeshBasicMaterial} */ (this._boltMesh.material).opacity = alpha;
    }
    if (this._boltGlow) {
      this._boltGlow.visible = visible;
      /** @type {THREE.MeshBasicMaterial} */ (this._boltGlow.material).opacity = alpha * 0.6;
    }
  }

  /**
   * @private Random-walk a jagged ribbon from the cloud base down to the ground.
   * @param {number} x
   * @param {number} y
   * @param {number} z
   */
  _buildBolt(x, y, z) {
    const mesh = this._boltMesh;
    if (!mesh) return;

    const groundY = this.ctx.terrain.heightAt(x, z);
    const drop = Math.max(2, y - groundY);
    const step = drop / BOLT_SEGMENTS;

    /** @type {number[][]} pairs of [ax,ay,az,bx,by,bz] */
    const segments = [];
    let cx = x;
    let cy = y;
    let cz = z;
    const forkAt = 4 + Math.floor(Math.random() * 4);
    let forkOrigin = null;
    for (let i = 0; i < BOLT_SEGMENTS; i++) {
      const jitter = 0.55 * (1 - i / BOLT_SEGMENTS) + 0.25;
      const nx = cx + (Math.random() - 0.5) * 2 * jitter;
      const nz = cz + (Math.random() - 0.5) * 2 * jitter;
      const ny = cy - step;
      segments.push([cx, cy, cz, nx, ny, nz]);
      if (i === forkAt) forkOrigin = [nx, ny, nz];
      cx = nx;
      cy = ny;
      cz = nz;
    }
    if (forkOrigin) {
      let [fx, fy, fz] = forkOrigin;
      const bias = (Math.random() - 0.5) * 1.6;
      for (let i = 0; i < BOLT_FORK_SEGMENTS; i++) {
        const nx = fx + bias * 0.6 + (Math.random() - 0.5) * 0.5;
        const nz = fz + (Math.random() - 0.5) * 0.7;
        const ny = fy - step * 0.75;
        segments.push([fx, fy, fz, nx, ny, nz]);
        fx = nx;
        fy = ny;
        fz = nz;
      }
    }

    this._writeRibbon(mesh, segments, BOLT_CORE_WIDTH);
    if (this._boltGlow) this._writeRibbon(this._boltGlow, segments, BOLT_GLOW_WIDTH);
  }

  /**
   * @private Widen each segment across the view so the bolt reads as a ribbon,
   * not a hairline, and taper it toward the tip.
   * @param {THREE.Mesh} mesh
   * @param {number[][]} segments pairs of [ax,ay,az,bx,by,bz]
   * @param {number} width world units at the top of the bolt
   */
  _writeRibbon(mesh, segments, width) {
    const view = this.ctx.camera.getWorldDirection(this._tmpV2);
    const positions = mesh.geometry.attributes.position.array;
    const dir = this._tmpV;
    const side = this._tmpSide;
    let w = 0;
    for (let i = 0; i < BOLT_MAX_SEGMENTS; i++) {
      const seg = segments[i];
      if (!seg) {
        for (let k = 0; k < 18; k++) positions[w++] = 0;
        continue;
      }
      const [ax, ay, az, bx, by, bz] = seg;
      dir.set(bx - ax, by - ay, bz - az).normalize();
      side.crossVectors(dir, view);
      if (side.lengthSq() < 1e-6) side.set(1, 0, 0);
      const taper = 1 - (0.55 * i) / BOLT_MAX_SEGMENTS;
      side.normalize().multiplyScalar(width * 0.5 * taper);
      const sx = side.x;
      const sy = side.y;
      const sz = side.z;
      const quad = [
        ax - sx, ay - sy, az - sz,
        ax + sx, ay + sy, az + sz,
        bx + sx, by + sy, bz + sz,
        ax - sx, ay - sy, az - sz,
        bx + sx, by + sy, bz + sz,
        bx - sx, by - sy, bz - sz,
      ];
      for (const value of quad) positions[w++] = value;
    }
    mesh.geometry.attributes.position.needsUpdate = true;
  }

  // ── mood shift ───────────────────────────────────────────────────────────

  /**
   * Re-colour the puffs for a style. When it is raining the weather mood owns
   * the scene's sun/sky/fog colours, so the dry-scene baseline is re-taken
   * here — the Style has just written the new palette into those very values.
   * @param {{lit?:string, shade?:string}} [p]
   */
  applyPalette(p) {
    const u = this.mesh?.material?.uniforms;
    if (p && u) {
      if (p.lit != null) u.uCloudLit.value.set(p.lit);
      if (p.shade != null) u.uCloudShade.value.set(p.shade);
    }
    if (this._baseline) this._captureBaseline();
    return this;
  }

  /**
   * @private
   * @returns {{uSkyTop:{value:THREE.Color}, uSkyHorizon:{value:THREE.Color}}|null}
   * the App's gradient-sky uniforms, when it has one
   */
  _skyUniforms() {
    const u = /** @type {any} */ (this.ctx.app?.sky)?.material?.uniforms;
    return u?.uSkyTop && u?.uSkyHorizon ? u : null;
  }

  /** @private Snapshot the dry scene so it can be restored exactly. */
  _captureBaseline() {
    const { sun, scene } = this.ctx;
    const sky = this._skyUniforms();
    this._baseline = {
      skyTop: sky ? sky.uSkyTop.value.clone() : null,
      skyHorizon: sky ? sky.uSkyHorizon.value.clone() : null,
      sunIntensity: sun.light.intensity,
      sunColor: sun.light.color.clone(),
      hemiColor: sun.hemi ? sun.hemi.color.clone() : null,
      fogColor: scene.fog ? scene.fog.color.clone() : null,
      fogNear: scene.fog ? scene.fog.near : 0,
      fogFar: scene.fog ? scene.fog.far : 0,
      background: scene.background instanceof THREE.Color ? scene.background.clone() : null,
    };
  }

  /** @private Put every touched scene value back to its dry state. */
  _restoreBaseline() {
    const b = this._baseline;
    if (!b) return;
    const { sun, scene } = this.ctx;
    const sky = this._skyUniforms();
    if (sky && b.skyTop) {
      sky.uSkyTop.value.copy(b.skyTop);
      sky.uSkyHorizon.value.copy(b.skyHorizon);
    }
    sun.light.intensity = b.sunIntensity;
    sun.light.color.copy(b.sunColor);
    if (sun.hemi && b.hemiColor) sun.hemi.color.copy(b.hemiColor);
    if (scene.fog && b.fogColor) {
      scene.fog.color.copy(b.fogColor);
      scene.fog.near = b.fogNear;
      scene.fog.far = b.fogFar;
    }
    if (b.background && scene.background instanceof THREE.Color) {
      scene.background.copy(b.background);
    }
    this.ctx.terrain?.setWetness?.(0);
    this._baseline = null;
  }

  /** @private Cool and grey the whole scene by `wetness`, then add the flash on top. */
  _applyMood() {
    const w = this.wetness;
    const flash = this._flash;
    if (w <= 0 && flash <= 0) {
      this._restoreBaseline();
      return;
    }
    if (!this._baseline) this._captureBaseline();

    const b = this._baseline;
    const { sun, scene } = this.ctx;

    sun.light.intensity = b.sunIntensity * (1 - 0.45 * w) * (1 + 0.5 * flash);
    sun.light.color.copy(b.sunColor).lerp(WET_SUN_COLOR, w).multiplyScalar(1 + 0.55 * flash);
    if (sun.hemi && b.hemiColor) {
      sun.hemi.color.copy(b.hemiColor).lerp(WET_SKY_COLOR, w).multiplyScalar(1 + 0.7 * flash);
    }
    if (scene.fog && b.fogColor) {
      scene.fog.color.copy(b.fogColor).lerp(WET_GREY_COLOR, w);
      scene.fog.near = b.fogNear * (1 - 0.35 * w);
      scene.fog.far = b.fogFar * (1 - 0.35 * w);
    }
    if (b.background && scene.background instanceof THREE.Color) {
      scene.background.copy(b.background).lerp(WET_GREY_COLOR, w).multiplyScalar(1 + 0.15 * flash);
    }
    // The App draws a gradient sky over the clear colour, so grey that too.
    const sky = this._skyUniforms();
    if (sky && b.skyTop) {
      sky.uSkyTop.value.copy(b.skyTop).lerp(WET_SKY_TOP_COLOR, w).multiplyScalar(1 + 0.35 * flash);
      sky.uSkyHorizon.value.copy(b.skyHorizon).lerp(WET_GREY_COLOR, w).multiplyScalar(1 + 0.35 * flash);
    }
    this.ctx.terrain?.setWetness?.(w);
  }

  /**
   * @private Refresh the read-only wetness readout a few times a second.
   * @param {number} dt
   */
  _updateInfo(dt) {
    const info = this._controls?.wetInfo;
    if (!info?.setText) return;
    this._infoT += dt;
    if (this._infoT < 0.25) return;
    this._infoT = 0;
    info.setText(
      `Wetness ${this.wetness.toFixed(2)} · clouds ${this.clouds.length} · drops ${this._dropCount}`,
    );
  }
}
