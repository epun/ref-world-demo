import * as THREE from 'three';
import { HALF } from '../core/constants.js';

/** Default droplet particles per emitter. */
const DROPLETS = 400;
/** Droplets respawned per second, per 400 particles. */
const DROPLET_RATE = 220;
/** Share of the droplet budget that bursts up from the plunge pool. */
const BASE_SPRAY_SHARE = 0.4;
/** Big round foam puffs at the base of a fall. */
const BLOBS = 4;
/** Puff diameters in world units, cycled over the blobs. */
const PUFF_SIZES = [1.4, 1.0, 1.25, 0.85];
/** World-unit step used when tracing the fall downhill. */
const TRACE_STEP = 0.6;
/** Maximum trace steps before giving up on finding a drop. */
const TRACE_MAX = 12;
/** A trace this steep ends the fall. */
const TRACE_DROP = 1.5;
/** Below this total drop the ground counts as flat and we fake a 1-unit fall. */
const FLAT_DROP = 0.4;
/** Seconds between mist puffs. */
const MIST_INTERVAL = 0.35;
/** Seconds between the concentric rings the fall beats into its plunge pool. */
const RING_INTERVAL = 1.0;
/** Amplitude of one of those rings. */
const RING_STRENGTH = 0.12;
/** Rows across the falling ribbon. */
const SHEET_ACROSS = 7;
/** Rows down the falling ribbon. */
const SHEET_ROWS = 14;
/** Rows in the rounded cap that curls over the lip. */
const LIP_ROWS = 4;
/** Height of that cap in world units. */
const LIP_HEIGHT = 0.3;
/** Big rounded mist puffs bobbing at the foot of a fall. */
const MIST_PUFFS = 5;

const GRAVITY = -9.81;
const PARKED_Y = -1000;

/**
 * One Ghibli waterfall: the white sheet falling from a curling lip into a
 * plunge pool, cumulus mist at its foot, a thin veil of rising mist against the
 * cliff, spray arcing off both ends and rings beaten into the pool.
 *
 * Owned and driven by the Water element; it is not an Element itself.
 */
export class Waterfall {
  /**
   * @param {object} ctx shared app context
   * @param {object} opts
   * @param {number} opts.x world x of the top of the fall
   * @param {number} opts.z world z of the top of the fall
   * @param {number} opts.dirX downhill direction x
   * @param {number} opts.dirZ downhill direction z
   * @param {number} [opts.width] spray width in world units
   * @param {number} [opts.droplets] particle budget
   * @param {boolean} [opts.sheet] draw the sheet, lip and mist (brush-placed falls)
   * @param {number} [opts.fallWidth] ribbon width; defaults to `width`
   * @param {{x:number,y:number,z:number}} [opts.lip] explicit top of the sheet
   * @param {{x:number,y:number,z:number}} [opts.base] explicit foot of the sheet
   * @param {(x:number, z:number)=>boolean} [opts.isWet]
   * @param {object} [materials] shared, not owned
   */
  constructor(ctx, opts, materials) {
    /** @type {object} */
    this.ctx = ctx;
    /** @type {number} */
    this.x = opts.x;
    /** @type {number} */
    this.z = opts.z;
    /** @type {number} */
    this.dirX = opts.dirX;
    /** @type {number} */
    this.dirZ = opts.dirZ;
    /** @type {number} spray width in world units */
    this.width = opts.width ?? 1.6;
    /** @type {number} width of the falling ribbon in world units */
    this.fallWidth = opts.fallWidth ?? this.width;
    /** @type {number} */
    this.count = Math.max(20, Math.round(opts.droplets ?? DROPLETS));
    /** @type {object} */
    this.materials = materials;
    /** @type {((x:number, z:number) => boolean)|null} is there water here? */
    this.isWet = opts.isWet || null;
    /** @type {boolean} whether the base actually sits in water */
    this.wet = true;
    /** @type {boolean} whether this fall draws a sheet, a lip and mist */
    this.hasSheet = !!opts.sheet;
    /** @type {{x:number,y:number,z:number}|null} explicit top of the sheet */
    this.lip = opts.lip ? { ...opts.lip } : null;
    /** @type {{x:number, z:number, rate:number}|null} the spring feeding it */
    this.spring = null;
    /** @type {Array<{x:number, z:number, r:number}>} pools laid with it */
    this.pools = [];
    /** @type {{x:number, z:number}|null} the foam rim registered at its foot */
    this.rim = null;

    /** @type {THREE.Group} */
    this.group = new THREE.Group();
    this.group.name = 'waterfall';
    this.group.userData.__duiIgnore = true;

    /** @type {Array<{x:number,y:number,z:number}>} traced fall path, top first */
    this.path = [];
    /** @type {{x:number,y:number,z:number}} bottom of the fall */
    this.base = opts.base ? { ...opts.base } : { x: opts.x, y: 0, z: opts.z };

    this._pos = new Float32Array(this.count * 3);
    this._vel = new Float32Array(this.count * 3);
    this._age = new Float32Array(this.count);
    this._alive = new Uint8Array(this.count);
    this._spawnDebt = 0;
    this._mistTimer = Math.random() * MIST_INTERVAL;
    this._ringTimer = 0;
    this._tmp = new THREE.Vector3();

    this._buildPath();
    this._buildDroplets();
    this._buildFoam();
    if (this.hasSheet) {
      this._buildSheet();
      this._buildMist();
    }
  }

  /** @returns {number} vertical drop of the fall in world units */
  get drop() {
    if (this.path.length < 2) return 0;
    return this.path[0].y - this.path[this.path.length - 1].y;
  }

  /** Recompute the path and rebuild everything anchored to it. */
  rebuild() {
    this._buildPath();
    this._disposeFoam();
    this._buildFoam();
    if (this.hasSheet) {
      this._disposeSheet();
      this._disposeMist();
      this._buildSheet();
      this._buildMist();
    }
    return this;
  }

  /**
   * @param {number} dt seconds
   * @param {number} time seconds since start
   * @param {import('./Water.js').Water} water for splashes into the ripple sim
   */
  update(dt, time, water) {
    // Everything this emitter draws belongs at a real fall base.
    if (!this.wet) {
      this.points.visible = false;
      if (this.sheet) this.sheet.visible = false;
      if (this.mist) this.mist.visible = false;
      if (this.veil) this.veil.visible = false;
      return;
    }
    this.points.visible = true;
    if (this.sheet) this.sheet.visible = true;
    if (this.mist) this.mist.visible = true;
    if (this.veil) this.veil.visible = true;
    this._updateDroplets(dt, water);

    // Concentric rings beaten into the plunge pool, about one per second.
    this._ringTimer -= dt;
    if (this._ringTimer <= 0) {
      this._ringTimer = RING_INTERVAL;
      if (water) water.splash(this.base.x, this.base.z, this.fallWidth * 0.3, RING_STRENGTH);
    }

    this._mistTimer -= dt;
    if (this._mistTimer <= 0) {
      this._mistTimer = MIST_INTERVAL * (0.7 + Math.random() * 0.6);
      const smoke = this.ctx.elements.get('smoke');
      if (smoke && typeof smoke.puff === 'function') {
        smoke.puff(
          this.base.x + (Math.random() - 0.5) * this.width,
          this.base.y + 0.3 + Math.random() * 0.4,
          this.base.z + (Math.random() - 0.5) * this.width,
          { size: 1.2, life: 1.6, color: '#ffffff' },
        );
      }
      if (water) water.splash(this.base.x, this.base.z, 0.7, 0.035);
    }
  }

  /** @returns {object} everything needed to rebuild this fall on load */
  serialize() {
    return {
      x: this.x,
      z: this.z,
      dirX: this.dirX,
      dirZ: this.dirZ,
      width: this.width,
      fallWidth: this.fallWidth,
      sheet: this.hasSheet,
      lip: this.lip ? { ...this.lip } : null,
      base: { ...this.base },
      pools: this.pools.map((p) => ({ ...p })),
      rim: this.rim ? { ...this.rim } : null,
      spring: this.spring ? { x: this.spring.x, z: this.spring.z, rate: this.spring.rate } : null,
    };
  }

  dispose() {
    this._disposeFoam();
    this._disposeSheet();
    this._disposeMist();
    if (this.points) {
      this.group.remove(this.points);
      this.points.geometry.dispose();
      this.points = null;
    }
    this.group.parent?.remove(this.group);
  }

  // --- construction -------------------------------------------------------

  /** @private Walk downhill from the emitter, following the steepest slope. */
  _buildPath() {
    const terrain = this.ctx.terrain;
    let dx = this.dirX;
    let dz = this.dirZ;
    const dl = Math.hypot(dx, dz) || 1;
    dx /= dl;
    dz /= dl;

    // A brush-placed fall knows exactly where its lip and its pool are; only
    // auto-detected ones have to guess by tracing the ground.
    if (this.lip && this.hasSheet) {
      this.path = [{ ...this.lip }, { ...this.base }];
      this.wet = this.isWet ? this.isWet(this.base.x, this.base.z) : true;
      return;
    }

    const limit = HALF - 0.6;
    let cx = this.x;
    let cz = this.z;
    const topY = terrain.heightAt(cx, cz);
    const pts = [{ x: cx, y: topY, z: cz }];

    for (let i = 0; i < TRACE_MAX; i++) {
      const n = terrain.normalAt(cx, cz, this._tmp);
      const gl = Math.hypot(n.x, n.z);
      if (gl > 0.02) {
        // Downhill on a height field is the horizontal part of the normal.
        dx = dx * 0.35 + (n.x / gl) * 0.65;
        dz = dz * 0.35 + (n.z / gl) * 0.65;
        const l = Math.hypot(dx, dz) || 1;
        dx /= l;
        dz /= l;
      }
      cx = Math.max(-limit, Math.min(limit, cx + dx * TRACE_STEP));
      cz = Math.max(-limit, Math.min(limit, cz + dz * TRACE_STEP));
      const y = terrain.heightAt(cx, cz);
      // A fall ends where its water ends: never follow the slope out onto dry
      // ground, or the base foam lands in the middle of a meadow.
      if (this.isWet && !this.isWet(cx, cz)) break;
      pts.push({ x: cx, y, z: cz });
      if (topY - y >= TRACE_DROP) break;
    }

    if (topY - pts[pts.length - 1].y < FLAT_DROP) {
      // Flat ground: a short vertical fall so something visible still appears.
      pts.length = 0;
      pts.push({ x: this.x, y: topY + 1.0, z: this.z });
      pts.push({ x: this.x + dx * 0.15, y: topY + 0.5, z: this.z + dz * 0.15 });
      pts.push({ x: this.x + dx * 0.3, y: topY, z: this.z + dz * 0.3 });
    }

    this.path = pts;
    const last = pts[pts.length - 1];
    this.base = { x: last.x, y: last.y, z: last.z };
    this.lip = { ...pts[0] };
    this.wet = this.isWet ? this.isWet(this.base.x, this.base.z) : true;
  }

  /**
   * @private The fall's frame: unit downstream vector, its perpendicular, the
   * horizontal run and the vertical drop from lip to base.
   * @returns {{dx:number, dz:number, px:number, pz:number, run:number, drop:number}}
   */
  _frame() {
    const lip = this.lip || this.path[0];
    let dx = this.base.x - lip.x;
    let dz = this.base.z - lip.z;
    let run = Math.hypot(dx, dz);
    if (run < 1e-3) {
      dx = this.dirX;
      dz = this.dirZ;
      run = 0;
      const l = Math.hypot(dx, dz) || 1;
      dx /= l;
      dz /= l;
    } else {
      dx /= run;
      dz /= run;
    }
    return { dx, dz, px: -dz, pz: dx, run, drop: Math.max(0.4, lip.y - this.base.y) };
  }

  /** @private */
  _buildDroplets() {
    const geo = new THREE.BufferGeometry();
    this._pos.fill(PARKED_Y);
    geo.setAttribute('position', new THREE.BufferAttribute(this._pos, 3));
    /** @type {THREE.Points} */
    this.points = new THREE.Points(geo, this.materials.droplet);
    this.points.name = 'waterfallDroplets';
    this.points.frustumCulled = false;
    this.points.renderOrder = 7;
    this.points.userData.__duiIgnore = true;
    this.group.add(this.points);
  }

  /** @private Flat white blobs bobbing in the pool at the base. */
  _buildFoam() {
    const positions = new Float32Array(BLOBS * 4 * 3);
    const uvs = new Float32Array(BLOBS * 4 * 2);
    const phases = new Float32Array(BLOBS * 4);
    const indices = [];

    for (let b = 0; b < BLOBS; b++) {
      const a = (b / BLOBS) * Math.PI * 2 + 0.6;
      // Puffs sit close together so they overlap into one painted mass.
      const rad = 0.38 + 0.16 * (b % 2);
      const ox = Math.cos(a) * rad;
      const oz = Math.sin(a) * rad;
      // The blob shader's alpha edge sits at about 0.74 of the quad half-size.
      const s = PUFF_SIZES[b % PUFF_SIZES.length] * 0.5 / 0.74;
      const y = 0.02 * b;
      const corners = [
        [-s, -s],
        [s, -s],
        [-s, s],
        [s, s],
      ];
      for (let c = 0; c < 4; c++) {
        const i = b * 4 + c;
        positions[i * 3] = ox + corners[c][0];
        positions[i * 3 + 1] = y;
        positions[i * 3 + 2] = oz + corners[c][1];
        uvs[i * 2] = corners[c][0] > 0 ? 1 : 0;
        uvs[i * 2 + 1] = corners[c][1] > 0 ? 1 : 0;
        phases[i] = b * 0.37;
      }
      const base = b * 4;
      indices.push(base, base + 1, base + 2, base + 1, base + 3, base + 2);
    }

    const geo = new THREE.BufferGeometry();
    geo.setAttribute('position', new THREE.BufferAttribute(positions, 3));
    geo.setAttribute('uv', new THREE.BufferAttribute(uvs, 2));
    geo.setAttribute('aPhase', new THREE.BufferAttribute(phases, 1));
    geo.setIndex(indices);
    geo.computeBoundingSphere();

    /** @type {THREE.Mesh} */
    this.foam = new THREE.Mesh(geo, this.materials.foam);
    this.foam.name = 'waterfallFoam';
    this.foam.position.set(this.base.x, this.base.y + 0.16, this.base.z);
    this.foam.visible = this.wet;
    this.foam.renderOrder = 6;
    this.foam.userData.__duiIgnore = true;
    this.group.add(this.foam);
  }

  /**
   * @private The white column itself: a ribbon `fallWidth` wide bowed outward
   * from the lip to the plunge pool, capped by the rounded lip that curls over
   * the edge. Both live in one mesh; `aLip` tells them apart.
   */
  _buildSheet() {
    const lip = this.lip || this.path[0];
    const { dx, dz, px, pz, run, drop } = this._frame();
    const halfW = Math.max(0.35, this.fallWidth * 0.5);
    const len = Math.hypot(run, drop);
    // A tall fall bows further out from the rock than a short one.
    const bow = Math.min(0.55, len * 0.14);
    const rows = LIP_ROWS + SHEET_ROWS;
    const verts = rows * SHEET_ACROSS;

    const positions = new Float32Array(verts * 3);
    const along = new Float32Array(verts);
    const across = new Float32Array(verts);
    const lipFlag = new Float32Array(verts);
    const down = new Float32Array(verts);
    const indices = [];

    for (let r = 0; r < rows; r++) {
      let cx;
      let cy;
      let cz;
      let t;
      let isLip = 0;
      if (r < LIP_ROWS) {
        // Half-round nose: from behind the edge, over the crest, down to the lip.
        const phi = Math.PI * (1 - r / (LIP_ROWS - 1));
        const back = (Math.cos(phi) - 1) * 0.18;
        cx = lip.x + dx * back;
        cz = lip.z + dz * back;
        cy = lip.y + Math.sin(phi) * LIP_HEIGHT;
        t = -Math.sin(phi);
        isLip = 1;
      } else {
        t = (r - LIP_ROWS) / (SHEET_ROWS - 1);
        const forward = run * t + Math.sin(Math.PI * t) * bow;
        cx = lip.x + dx * forward;
        cz = lip.z + dz * forward;
        // Steep off the lip, easing out into the pool — but never sunk into
        // the hillside, so a fall down a natural slope rides its surface.
        cy = lip.y - drop * Math.pow(t, 0.8);
        const ground = this.ctx.terrain.heightAt(cx, cz) + 0.06;
        if (ground > cy) cy = ground;
      }

      for (let c = 0; c < SHEET_ACROSS; c++) {
        const a = (c / (SHEET_ACROSS - 1)) * 2 - 1;
        // The edges tuck back toward the rock, so the sheet reads as convex.
        const tuck = -0.16 * halfW * a * a;
        const i = r * SHEET_ACROSS + c;
        positions[i * 3] = cx + px * a * halfW + dx * tuck;
        positions[i * 3 + 1] = cy;
        positions[i * 3 + 2] = cz + pz * a * halfW + dz * tuck;
        along[i] = t;
        across[i] = a;
        lipFlag[i] = isLip;
        // World-unit distance travelled down the sheet: what the streaks scroll
        // along, so a tall fall is not striped more finely than a short one.
        down[i] = isLip ? t * LIP_HEIGHT : t * len;
      }
    }

    for (let r = 0; r < rows - 1; r++) {
      for (let c = 0; c < SHEET_ACROSS - 1; c++) {
        const i = r * SHEET_ACROSS + c;
        indices.push(i, i + 1, i + SHEET_ACROSS, i + 1, i + SHEET_ACROSS + 1, i + SHEET_ACROSS);
      }
    }

    const geo = new THREE.BufferGeometry();
    geo.setAttribute('position', new THREE.BufferAttribute(positions, 3));
    geo.setAttribute('aAlong', new THREE.BufferAttribute(along, 1));
    geo.setAttribute('aAcross', new THREE.BufferAttribute(across, 1));
    geo.setAttribute('aLip', new THREE.BufferAttribute(lipFlag, 1));
    geo.setAttribute('aDown', new THREE.BufferAttribute(down, 1));
    geo.setIndex(indices);
    geo.computeVertexNormals();
    geo.computeBoundingSphere();

    /** @type {THREE.Mesh} */
    this.sheet = new THREE.Mesh(geo, this.materials.sheet);
    this.sheet.name = 'waterfallSheet';
    this.sheet.castShadow = false;
    this.sheet.receiveShadow = true;
    this.sheet.renderOrder = 5;
    this.sheet.userData.__duiIgnore = true;
    this.group.add(this.sheet);
  }

  /**
   * @private Cumulus puffs bobbing at the foot of the fall, plus the thin veil
   * of mist rising against the cliff behind them.
   */
  _buildMist() {
    const { dx, dz, px, pz, drop } = this._frame();
    const halfW = Math.max(0.35, this.fallWidth * 0.5);

    const positions = new Float32Array(MIST_PUFFS * 4 * 3);
    const centers = new Float32Array(MIST_PUFFS * 4 * 3);
    const corners = new Float32Array(MIST_PUFFS * 4 * 2);
    const sizes = new Float32Array(MIST_PUFFS * 4);
    const phases = new Float32Array(MIST_PUFFS * 4);
    const indices = [];
    const quad = [
      [-1, -1],
      [1, -1],
      [-1, 1],
      [1, 1],
    ];

    for (let b = 0; b < MIST_PUFFS; b++) {
      // Deterministic spread: a reload must draw the same cloud.
      const k = b / MIST_PUFFS;
      const jitter = ((b * 2654435761) % 1000) / 1000;
      const size = 0.9 + jitter * 0.8;
      // Spread wide and sitting low, so the foot of the column stays visible
      // between the puffs instead of disappearing behind them.
      const side = (k * 2 - 0.8) * (halfW + 1.1);
      const fwd = -0.1 + jitter * 0.9;
      const cx = this.base.x + px * side + dx * fwd;
      const cz = this.base.z + pz * side + dz * fwd;
      const cy = this.base.y + size * 0.26 + jitter * 0.2;
      for (let c = 0; c < 4; c++) {
        const i = b * 4 + c;
        positions[i * 3] = cx;
        positions[i * 3 + 1] = cy;
        positions[i * 3 + 2] = cz;
        centers[i * 3] = cx;
        centers[i * 3 + 1] = cy;
        centers[i * 3 + 2] = cz;
        corners[i * 2] = quad[c][0];
        corners[i * 2 + 1] = quad[c][1];
        sizes[i] = size * 0.5;
        phases[i] = jitter + b * 0.19;
      }
      const base = b * 4;
      indices.push(base, base + 1, base + 2, base + 1, base + 3, base + 2);
    }

    const geo = new THREE.BufferGeometry();
    geo.setAttribute('position', new THREE.BufferAttribute(positions, 3));
    geo.setAttribute('aCenter', new THREE.BufferAttribute(centers, 3));
    geo.setAttribute('aCorner', new THREE.BufferAttribute(corners, 2));
    geo.setAttribute('aSize', new THREE.BufferAttribute(sizes, 1));
    geo.setAttribute('aPhase', new THREE.BufferAttribute(phases, 1));
    geo.setIndex(indices);
    geo.computeBoundingSphere();
    geo.boundingSphere.radius += 3;

    /** @type {THREE.Mesh} */
    this.mist = new THREE.Mesh(geo, this.materials.mistPuff);
    this.mist.name = 'waterfallMist';
    this.mist.renderOrder = 8;
    this.mist.frustumCulled = false;
    this.mist.userData.__duiIgnore = true;
    this.group.add(this.mist);

    // The veil: one upright quad across the fall, standing in front of the rock.
    const w = this.fallWidth * 1.8;
    const h = Math.max(0.8, drop * 0.85);
    const midX = this.base.x + dx * 0.3;
    const midZ = this.base.z + dz * 0.3;
    const vp = new Float32Array(12);
    const vuv = new Float32Array(8);
    const quadUv = [
      [0, 0],
      [1, 0],
      [0, 1],
      [1, 1],
    ];
    for (let c = 0; c < 4; c++) {
      const sx = quadUv[c][0] * 2 - 1;
      const sy = quadUv[c][1];
      vp[c * 3] = midX + px * sx * w * 0.5;
      vp[c * 3 + 1] = this.base.y + sy * h;
      vp[c * 3 + 2] = midZ + pz * sx * w * 0.5;
      vuv[c * 2] = quadUv[c][0];
      vuv[c * 2 + 1] = quadUv[c][1];
    }
    const vgeo = new THREE.BufferGeometry();
    vgeo.setAttribute('position', new THREE.BufferAttribute(vp, 3));
    vgeo.setAttribute('uv', new THREE.BufferAttribute(vuv, 2));
    vgeo.setIndex([0, 1, 2, 1, 3, 2]);
    vgeo.computeBoundingSphere();

    /** @type {THREE.Mesh} */
    this.veil = new THREE.Mesh(vgeo, this.materials.mistSheet);
    this.veil.name = 'waterfallVeil';
    this.veil.renderOrder = 4;
    this.veil.userData.__duiIgnore = true;
    this.group.add(this.veil);
  }

  // --- simulation ---------------------------------------------------------

  /** @private */
  _updateDroplets(dt, water) {
    const terrain = this.ctx.terrain;
    const wind = this.ctx.wind;
    const top = this.path[0];
    const next = this.path[Math.min(1, this.path.length - 1)];
    let tx = next.x - top.x;
    let tz = next.z - top.z;
    const tl = Math.hypot(tx, tz) || 1;
    tx /= tl;
    tz /= tl;
    const px = -tz;
    const pz = tx;

    this._spawnDebt += DROPLET_RATE * (this.count / DROPLETS) * dt;
    let toSpawn = Math.floor(this._spawnDebt);
    this._spawnDebt -= toSpawn;

    const pos = this._pos;
    const vel = this._vel;

    for (let i = 0; i < this.count; i++) {
      const o = i * 3;
      if (!this._alive[i]) {
        if (toSpawn <= 0) continue;
        toSpawn--;
        const across = (Math.random() - 0.5) * this.width;
        if (Math.random() < BASE_SPRAY_SHARE) {
          // Spray bursting back up out of the plunge pool.
          pos[o] = this.base.x + px * across * 0.8 + (Math.random() - 0.5) * 0.3;
          pos[o + 1] = this.base.y + 0.05;
          pos[o + 2] = this.base.z + pz * across * 0.8 + (Math.random() - 0.5) * 0.3;
          vel[o] = (Math.random() - 0.5) * 1.8 + tx * 0.6;
          vel[o + 1] = 2.4 + Math.random() * 1.6;
          vel[o + 2] = (Math.random() - 0.5) * 1.8 + tz * 0.6;
        } else {
          // Spray thrown clear of the lip.
          pos[o] = top.x + px * across;
          pos[o + 1] = top.y + 0.5 + Math.random() * 0.25;
          pos[o + 2] = top.z + pz * across;
          vel[o] = tx * 2.0 + (Math.random() - 0.5) * 0.7;
          vel[o + 1] = 1.5 + (Math.random() - 0.5) * 0.6;
          vel[o + 2] = tz * 2.0 + (Math.random() - 0.5) * 0.7;
        }
        this._age[i] = 0;
        this._alive[i] = 1;
        continue;
      }

      const w = wind.sampleAt(pos[o], pos[o + 2]);
      vel[o] += w.x * 0.6 * dt;
      vel[o + 2] += w.z * 0.6 * dt;
      vel[o + 1] += GRAVITY * dt;
      pos[o] += vel[o] * dt;
      pos[o + 1] += vel[o + 1] * dt;
      pos[o + 2] += vel[o + 2] * dt;
      this._age[i] += dt;

      const ground = terrain.heightAt(pos[o], pos[o + 2]);
      if (pos[o + 1] <= ground + 0.06 || this._age[i] > 3) {
        if (water && Math.random() < 0.1) {
          water.splash(pos[o], pos[o + 2], 0.35, 0.02);
        }
        this._alive[i] = 0;
        pos[o + 1] = PARKED_Y;
      }
    }

    this.points.geometry.attributes.position.needsUpdate = true;
  }

  /** @private */
  _disposeFoam() {
    if (!this.foam) return;
    this.group.remove(this.foam);
    this.foam.geometry.dispose();
    this.foam = null;
  }

  /** @private */
  _disposeSheet() {
    if (!this.sheet) return;
    this.group.remove(this.sheet);
    this.sheet.geometry.dispose();
    this.sheet = null;
  }

  /** @private */
  _disposeMist() {
    if (this.mist) {
      this.group.remove(this.mist);
      this.mist.geometry.dispose();
      this.mist = null;
    }
    if (this.veil) {
      this.group.remove(this.veil);
      this.veil.geometry.dispose();
      this.veil = null;
    }
  }
}
