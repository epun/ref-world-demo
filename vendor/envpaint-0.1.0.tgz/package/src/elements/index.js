import { Grass } from './Grass.js';
import { Flowers } from './Flowers.js';
import { Water } from './Water.js';
import { Rocks } from './Rocks.js';
import { Smoke } from './Smoke.js';
import { Fire } from './Fire.js';
import { Clouds } from './Clouds.js';
import { Trees } from './Trees.js';
import { Sword } from './Sword.js';

/**
 * Every environment element, in registration order. Elements are constructed
 * with `ctx` and `init()`ed in this order by `main.js`.
 * @type {Array<typeof import('../core/Element.js').Element>}
 */
export const ELEMENTS = [Grass, Flowers, Water, Rocks, Smoke, Fire, Clouds, Trees, Sword].sort((a, b) => a.order - b.order);
