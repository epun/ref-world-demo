import * as THREE from 'three';
import { Element } from '../core/Element.js';
import { PaintLayer } from '../core/PaintLayers.js';
import { WORLD_SIZE, uvToWorld, worldToUV } from '../core/constants.js';
import { noiseGLSL } from '../core/shaders/toon.glsl.js';

/** Hard cap on flame billboards derived from the layer. */
const MAX_FLAMES = 200;
/** Coarse rescan grid for the painted fire layer. */
const GRID = 64;
/** Layer value a cell needs to become a flame. */
const FIRE_THRESHOLD = 0.4;
/** Hard cap on live embers. */
const MAX_EMBERS = 120;
/** Hard cap on flickering point lights. */
const MAX_LIGHTS = 3;
/** Ceiling on smoke puffs spawned by fire, per second, across all flames. */
const MAX_PUFFS_PER_SECOND = 12;
/** Seconds between grass-consumption / scorch / burn-out ticks. */
const BURN_TICK = 0.25;
/** Seconds between emitter rescans, so burning cannot rescan every frame. */
const RESCAN_INTERVAL = 0.15;
/** Ember colours: hot centre, cooler edge. */
const EMBER_HOT = '#ffd24a';
const EMBER_COOL = '#ff8a2a';

const _drawSize = new THREE.Vector2();
const _matrix = new THREE.Matrix4();

const flameVertexShader = /* glsl */ `
#include <fog_pars_vertex>

attribute float aSeed;
attribute float aIntensity;
attribute vec2 aWind;

uniform float uTime;
uniform float uLean;

varying vec2 vUv;
varying float vSeed;
varying float vFlame;
varying float vAspect;

void main() {
  vUv = uv;
  vSeed = aSeed;
  vFlame = aIntensity;

  #ifdef USE_INSTANCING
    vec3 instPos = vec3(instanceMatrix[3][0], instanceMatrix[3][1], instanceMatrix[3][2]);
    float sx = length(vec3(instanceMatrix[0][0], instanceMatrix[0][1], instanceMatrix[0][2]));
    float sy = length(vec3(instanceMatrix[1][0], instanceMatrix[1][1], instanceMatrix[1][2]));
  #else
    vec3 instPos = vec3(0.0);
    float sx = 1.0;
    float sy = 1.0;
  #endif

  // Width over height of this quad, so the fragment shader can work in a
  // space where a circle is a circle whatever the two sliders say.
  vAspect = sx / max(sy, 0.001);

  // Slow breath, 1.2 Hz, +-6% of the height. No fast flicker: Ghibli fire
  // moves as one soft body.
  sy *= 1.0 + 0.06 * sin(uTime * 7.54 + aSeed * 11.0);

  // Cylindrical billboard: screen-right x world-up keeps flames upright and
  // rooted in the ground under the fixed isometric camera.
  vec3 right = normalize(vec3(viewMatrix[0][0], viewMatrix[1][0], viewMatrix[2][0]));
  vec3 up = vec3(0.0, 1.0, 0.0);

  float h = uv.y;
  vec3 local = right * (position.x * sx) + up * (h * sy);
  // The whole tongue sways together at 0.6 Hz, hinged at the base.
  local += right * (sin(uTime * 3.77 + aSeed * 6.28) * 0.10 * h * sx);
  local += vec3(aWind.x, 0.0, aWind.y) * (uLean * h * h * sy);

  vec4 worldPosition = modelMatrix * vec4(instPos + local, 1.0);
  vec4 mvPosition = viewMatrix * worldPosition;
  gl_Position = projectionMatrix * mvPosition;
  #include <fog_vertex>
}
`;

const flameFragmentShader = /* glsl */ `
#include <common>
#include <fog_pars_fragment>
${noiseGLSL}

uniform vec3 uColRim;
uniform vec3 uColOuter;
uniform vec3 uColMid;
uniform vec3 uColCore;
uniform vec3 uColHot;
uniform float uIntensity;
// 0 ghibli, 1 flat, 2 realistic, 3 painterly, 4 pixel. Left out of the
// material's own uniforms so Style.attach() can hand over the shared one.
uniform float uStyleId;

varying vec2 vUv;
varying float vSeed;
varying float vFlame;
varying float vAspect;

/** Half-width of the main tongue, the unit every band threshold is in. */
const float SPINE = 0.125;
/** Width of the rounded cel edge between two colour bands, in SPINE units.
 *  Much narrower than a band: the edges round, the fills stay flat. */
const float BAND_SOFT = 0.06;

/** Rounded union: tongues merge into one mass instead of crossing. */
float smax(float a, float b, float k) {
  float h = clamp(0.5 + 0.5 * (a - b) / k, 0.0, 1.0);
  return mix(b, a, h) + k * h * (1.0 - h);
}

// One rounded tongue, drawn the way a cel painter would: it tapers up the
// height, closes in a parabolic cap so the tip is blunt, and flares at the base
// into the dome all the tongues share. Returns how far inside the tongue the
// point is, in quad-height units -- 0 on the silhouette, negative outside.
float tongue(vec2 q, float cx, float w0, float top, float ph) {
  float t = max(q.y, 0.0) / top;
  float t2 = t * t;
  float t8 = t2 * t2 * t2 * t2;
  // Tapers gently up the height and then closes in a parabolic cap: a tongue
  // that narrows the way a painted flame does, with a blunt, rounded tip.
  float prof = sqrt(max(0.0, 1.0 - t8)) * (1.0 - 0.38 * t2);
  float flare = 1.0 + 0.26 * exp(-q.y * 5.0);
  float wob = (fbm(vec2(q.y * 2.2 - uTime * 0.30, ph * 9.0), 2) - 0.5) * 0.24;
  float halfw = w0 * prof * flare * (1.0 + wob);
  // Each tongue leans on its own slow sine on top of the whole-quad sway, and
  // curves as it rises so no two stand up like posts.
  float sway = 0.10 * t2 * sin(uTime * 1.05 + ph * 6.283);
  float curve = (fract(ph * 9.3) - 0.5) * 0.13 * t2;
  return halfw - abs(q.x - cx - curve - sway);
}

// A round blob shed off a tip: rises slowly on a loop and cools as it goes.
// It is narrower than the centre tongue, so the ramp alone keeps it amber --
// a shed blob can never read as hot as the heart of the fire.
float blob(vec2 q, float cx, float y0, float sd) {
  float t = fract(uTime * 0.11 + sd);
  float r = 0.075 * (1.0 - 0.40 * t);
  vec2 c = vec2(cx + 0.06 * sin(uTime * 0.8 + sd * 6.283), y0 + t * 0.30);
  return (r - length(q - c)) * (1.0 - 0.4 * t);
}

void main() {
  // Isotropic quad space: x measured in units of the quad's own height, so a
  // circle here is a circle in the world whatever the sliders say.
  vec2 q = vec2((vUv.x - 0.5) * vAspect, vUv.y);
  float s = vSeed;
  float grow = clamp(0.70 + 0.30 * uIntensity * vFlame, 0.60, 1.10);
  float top = min(0.78 * grow, 0.84);

  // ONE big tongue and one shoulder per quad. A campfire paints several
  // emitters over its patch, so three tongues per quad would stack into a
  // dozen and read as a mound; one each keeps the group at the two or three
  // fat hand-drawn tongues the look is built on.
  float side = fract(s * 3.7) < 0.5 ? -0.105 : 0.105;
  float d = tongue(q, (s - 0.5) * 0.04, SPINE, top, s);
  d = smax(d, tongue(q, side, 0.065, top * 0.55, s + 0.37), 0.030);
  // One blob rising clear of the tip, so it reads as shed rather than as a
  // bump -- a plain max keeps it detached.
  d = max(d, blob(q, mix(-0.10, 0.11, fract(s * 5.1)), top * 0.70, s));

  // Depth measured inward from the silhouette, in units of the centre tongue's
  // half-width. Absolute, not per-tongue: that is what makes the yellow heart
  // an inner flame inside the fat body while a thin shoulder or a shed blob
  // stays orange all the way through, instead of every tongue being a stripe
  // of the whole ramp.
  float fn = d / SPINE;

  // The outer edge stays hard, but it is a rounded edge: the field itself is
  // smooth, so nothing needs blurring to blunt it.
  if (fn < 0.015) discard;

  vec3 col;
  // Alpha drives the colour blend only: separate alpha blending forces the
  // framebuffer alpha to 0, which exempts fire from the ink pass in every
  // style. Hard-edged styles use alpha 1, which is a plain overwrite.
  float alpha = 1.0;

  if (uStyleId > 0.5 && uStyleId < 1.5) {
    // Flat: three saturated colours, hard edges, no rim.
    col = uColOuter;
    if (fn > 0.40) col = uColMid;
    if (fn > 0.74) col = uColCore;
  } else if (uStyleId > 1.5 && uStyleId < 2.5) {
    // Realistic: one smooth gradient into a bright core, soft alpha edge.
    float t = clamp(fn / 0.95, 0.0, 1.0);
    col = mix(uColOuter, uColCore, t);
    col = mix(col, uColHot, smoothstep(0.72, 1.0, t));
    col += uColHot * 0.3 * smoothstep(0.85, 1.0, t);
    alpha = smoothstep(0.015, 0.40, fn);
  } else if (uStyleId > 3.5) {
    // Pixel: four hard colours, nothing in between.
    col = uColRim;
    if (fn > 0.20) col = uColOuter;
    if (fn > 0.50) col = uColMid;
    if (fn > 0.82) col = uColHot;
  } else {
    // Ghibli, and painterly with the band edges bled wide open. A slim rim,
    // then thick flat bands: the amber and yellow together own most of the
    // body, which is what reads as anime fire rather than a gradient.
    float soft = uStyleId > 2.5 ? 0.30 : BAND_SOFT;
    col = uColRim;
    col = mix(col, uColOuter, smoothstep(0.0, soft, fn - 0.14));
    col = mix(col, uColMid, smoothstep(0.0, soft, fn - 0.50));
    col = mix(col, uColCore, smoothstep(0.0, soft, fn - 0.62));
    col = mix(col, uColHot, smoothstep(0.0, soft, fn - 0.95));
  }

  gl_FragColor = vec4(col, alpha);
  #include <fog_fragment>
  #include <colorspace_fragment>
}
`;

const poolVertexShader = /* glsl */ `
#include <fog_pars_vertex>

attribute float aSeed;

varying vec2 vUv;
varying float vSeed;

void main() {
  vUv = uv;
  vSeed = aSeed;
  #ifdef USE_INSTANCING
    vec4 worldPosition = modelMatrix * instanceMatrix * vec4(position, 1.0);
  #else
    vec4 worldPosition = modelMatrix * vec4(position, 1.0);
  #endif
  vec4 mvPosition = viewMatrix * worldPosition;
  gl_Position = projectionMatrix * mvPosition;
  #include <fog_vertex>
}
`;

const poolFragmentShader = /* glsl */ `
#include <common>
${noiseGLSL}

uniform vec3 uPoolColor;
uniform float uPoolAlpha;
// 0 ghibli, 1 flat, 2 realistic, 3 painterly, 4 pixel. Left out of the
// material's own uniforms so Style.attach() can hand over the shared one.
uniform float uStyleId;

varying vec2 vUv;
varying float vSeed;

void main() {
  vec2 p = vUv * 2.0 - 1.0;
  float r = length(p);
  float ang = atan(p.y, p.x);
  // Hard but wobbled edge: a cel-drawn pool of firelight, not a soft glow.
  float wob = fbm(vec2(cos(ang), sin(ang)) * 2.0 + vSeed * 13.0, 3);
  float edge = 0.74 + (wob - 0.5) * 0.30;
  float alpha = uPoolAlpha;

  if (uStyleId > 0.5 && uStyleId < 1.5) {
    // Flat: a printed disc -- perfect circle, one tone, no wobble.
    edge = 0.74;
  } else if (uStyleId > 1.5 && uStyleId < 2.5) {
    // Realistic: a soft glow that fades out instead of ending on a line.
    edge = 0.92;
    alpha *= smoothstep(0.92, 0.10, r);
  } else if (uStyleId > 2.5 && uStyleId < 3.5) {
    // Painterly: the same wobbled shape with a wet, bled rim.
    alpha *= smoothstep(edge, edge - 0.28, r);
  } else if (uStyleId > 3.5) {
    // Pixel: two concentric hard rings on the quantised grid.
    edge = floor(edge * 4.0) / 4.0;
    alpha *= r > edge * 0.62 ? 0.6 : 1.0;
  }
  if (r > edge) discard;
  // Alpha drives the colour blend; separate alpha blending writes 0 to the
  // framebuffer so the ink pass leaves the pool (and the grass under it) alone.
  gl_FragColor = vec4(uPoolColor, alpha);
  #include <colorspace_fragment>
}
`;

const emberVertexShader = /* glsl */ `
#include <fog_pars_vertex>

attribute float aSize;
attribute float aSeed;
attribute float aFade;

uniform float uFrustumHalfHeight;
uniform float uViewportHeight;
uniform float uStyleId;

varying float vSeed;
varying float vFade;

void main() {
  vSeed = aSeed;
  vFade = aFade;
  vec4 worldPosition = modelMatrix * vec4(position, 1.0);
  vec4 mvPosition = viewMatrix * worldPosition;
  gl_Position = projectionMatrix * mvPosition;
  // Pixel art draws a spark as one pixel of the low-res target.
  gl_PointSize = uStyleId > 3.5
    ? 1.0
    : max(2.0, aSize * (uViewportHeight / (2.0 * uFrustumHalfHeight)));
  #include <fog_vertex>
}
`;

const emberFragmentShader = /* glsl */ `
#include <common>
#include <fog_pars_fragment>

uniform vec3 uEmberCore;
uniform vec3 uEmberEdge;
// 0 ghibli, 1 flat, 2 realistic, 3 painterly, 4 pixel. Left out of the
// material's own uniforms so Style.attach() can hand over the shared one.
uniform float uStyleId;

varying float vSeed;
varying float vFade;

void main() {
  vec2 p = gl_PointCoord * 2.0 - 1.0;
  float r = length(p);
  // Round, two flat tones, shrinking as it cools.
  if (r > vFade) discard;
  vec3 col = r < vFade * 0.55 ? uEmberCore : uEmberEdge;
  float alpha = 1.0;

  if (uStyleId > 0.5 && uStyleId < 1.5) {
    // Flat: one printed ink, no inner tone.
    col = uEmberCore;
  } else if (uStyleId > 1.5 && uStyleId < 2.5) {
    // Realistic: a soft spark that glows out at the edge.
    col = mix(uEmberEdge, uEmberCore, smoothstep(vFade, 0.0, r));
    alpha = smoothstep(vFade, vFade * 0.25, r);
  } else if (uStyleId > 2.5 && uStyleId < 3.5) {
    // Painterly: the two tones with a bled rim.
    alpha = smoothstep(vFade, vFade * 0.75, r);
  } else if (uStyleId > 3.5) {
    // Pixel: the whole spark is one pixel of one ink.
    col = uEmberCore;
  }
  // Alpha 1 with the framebuffer alpha forced to 0: opaque, ink-exempt.
  gl_FragColor = vec4(col, alpha);
  #include <fog_fragment>
  #include <colorspace_fragment>
}
`;

/**
 * Ghibli fire: two or three rounded tongues with blunt tips, painted onto the
 * ground. Each emitter is a camera-facing quad whose silhouette comes from a
 * rounded gradient mask minus two slow upward-drifting Voronoi layers, pushed
 * through a five-step constant ramp. Flames sway as one, lean downwind, throw
 * embers, pool warm light on the grass and feed the shared smoke service.
 */
export class Fire extends Element {
  static id = 'fire';
  static label = 'Fire';
  static order = 50;

  /**
   * @param {object} ctx shared app context
   */
  constructor(ctx) {
    super(ctx);

    /** @type {object} */
    this.params = {
      intensity: 1,
      height: 2.2,
      width: 1.75,
      lean: 0.55,
      rim: '#d63a1a',
      outer: '#ff7a1c',
      mid: '#ffb128',
      core: '#ffe36b',
      hot: '#fff7cf',
      embers: true,
      emberRate: 1.4,
      light: true,
      lightIntensity: 12,
      lightColor: '#ff9a3a',
      pool: true,
      poolColor: '#ffb15a',
      poolAlpha: 0.35,
      smokeRate: 0.8,
      spread: true,
      spreadRate: 0.25,
      burnTime: 12,
    };

    /** @type {PaintLayer|null} */
    this.layer = null;
    /** @type {THREE.InstancedMesh|null} */
    this.flames = null;
    /** @type {THREE.InstancedMesh|null} */
    this.pools = null;
    /** @type {THREE.Points|null} */
    this.embers = null;
    /** @type {Array<{key:number, x:number, y:number, z:number, value:number, seed:number, width:number, height:number}>} */
    this.emitters = [];
    /** @type {THREE.PointLight[]} */
    this.lights = [];

    this._emberCount = 0;
    this._ex = new Float32Array(MAX_EMBERS);
    this._ey = new Float32Array(MAX_EMBERS);
    this._ez = new Float32Array(MAX_EMBERS);
    this._evy = new Float32Array(MAX_EMBERS);
    this._eang = new Float32Array(MAX_EMBERS);
    this._erad = new Float32Array(MAX_EMBERS);
    this._eage = new Float32Array(MAX_EMBERS);
    this._elife = new Float32Array(MAX_EMBERS);
    this._eseed = new Float32Array(MAX_EMBERS);
    this._esize = new Float32Array(MAX_EMBERS);
    this._emberAcc = 0;
    this._puffAcc = 0;
    this._burnTick = 0;
    this._rescanTimer = 0;
    this._needsRescan = false;
    /** @type {Map<number, number>} grid cell key -> seconds that cell has burned */
    this._burn = new Map();
  }

  /** Register the layers + tool, build the flames, pools, embers and lights. */
  async init() {
    const ctx = this.ctx;
    this.layer = ctx.layers.add(new PaintLayer('fire', { channels: 1, float: false, initial: 0 }));
    /** @type {PaintLayer} burn scars left behind by fire */
    this.scorchLayer = ctx.layers.add(
      new PaintLayer('scorch', { channels: 1, float: false, initial: 0 }),
    );
    ctx.terrain.setLayerTexture('scorch', this.scorchLayer.texture);

    ctx.brush.registerTool({
      id: 'fire',
      label: 'Fire',
      color: '#ff7a2a',
      key: 'f',
      layer: 'fire',
      mode: 'add',
      eraseMode: 'erase',
      strengthScale: 1,
    });

    /** @type {THREE.Group} everything this element puts in the scene */
    this.root = new THREE.Group();
    this.root.name = 'Fire';
    ctx.scene.add(this.root);

    const p = this.params;
    const geometry = new THREE.PlaneGeometry(1, 1);
    this._aSeed = new THREE.InstancedBufferAttribute(new Float32Array(MAX_FLAMES), 1);
    this._aIntensity = new THREE.InstancedBufferAttribute(new Float32Array(MAX_FLAMES), 1);
    this._aWind = new THREE.InstancedBufferAttribute(new Float32Array(MAX_FLAMES * 2), 2);
    this._aWind.setUsage(THREE.DynamicDrawUsage);
    geometry.setAttribute('aSeed', this._aSeed);
    geometry.setAttribute('aIntensity', this._aIntensity);
    geometry.setAttribute('aWind', this._aWind);

    const flameMaterial = new THREE.ShaderMaterial({
      lights: false,
      fog: true,
      transparent: false,
      // Colour blends by the fragment alpha (the realistic style wants soft
      // edges) while the framebuffer alpha is forced to 0, so fire stays
      // exempt from the ink pass in every style.
      blending: THREE.CustomBlending,
      blendEquation: THREE.AddEquation,
      blendSrc: THREE.SrcAlphaFactor,
      blendDst: THREE.OneMinusSrcAlphaFactor,
      blendEquationAlpha: THREE.AddEquation,
      blendSrcAlpha: THREE.ZeroFactor,
      blendDstAlpha: THREE.ZeroFactor,
      side: THREE.DoubleSide,
      depthWrite: false,
      uniforms: Object.assign(
        THREE.UniformsUtils.merge([THREE.UniformsLib.fog]),
        ctx.wind.uniforms,
        {
          uLean: { value: p.lean },
          uIntensity: { value: p.intensity },
          uColRim: { value: new THREE.Color(p.rim) },
          uColOuter: { value: new THREE.Color(p.outer) },
          uColMid: { value: new THREE.Color(p.mid) },
          uColCore: { value: new THREE.Color(p.core) },
          uColHot: { value: new THREE.Color(p.hot) },
        },
      ),
      vertexShader: flameVertexShader,
      fragmentShader: flameFragmentShader,
    });
    flameMaterial.toneMapped = false;

    flameMaterial.name = 'Fire';
    ctx.style?.attach?.(flameMaterial, { element: 'fire' });
    this.flameMaterial = flameMaterial;
    this.flameGeometry = geometry;
    flameMaterial.userData.uiProps = this._materialProps();
    flameMaterial.userData.swatch = [p.hot, p.mid, p.rim];
    this.flames = new THREE.InstancedMesh(geometry, flameMaterial, MAX_FLAMES);
    this.flames.name = 'fire-flames';
    this.flames.count = 0;
    this.flames.frustumCulled = false;
    this.flames.renderOrder = 20;
    this.root.add(this.flames);

    const poolGeometry = new THREE.PlaneGeometry(1, 1);
    poolGeometry.rotateX(-Math.PI / 2);
    this._aPoolSeed = new THREE.InstancedBufferAttribute(new Float32Array(MAX_FLAMES), 1);
    poolGeometry.setAttribute('aSeed', this._aPoolSeed);

    const poolMaterial = new THREE.ShaderMaterial({
      lights: false,
      fog: false,
      transparent: true,
      depthWrite: false,
      // The meadow's blades stand above the ground plane, so a depth-tested
      // decal would hide between them; a cel light pool is painted on top.
      depthTest: false,
      // Colour blends with the grass at uPoolAlpha, but the framebuffer alpha
      // is forced to 0 so the ink pass treats the pool as exempt.
      blending: THREE.CustomBlending,
      blendEquation: THREE.AddEquation,
      blendSrc: THREE.SrcAlphaFactor,
      blendDst: THREE.OneMinusSrcAlphaFactor,
      blendEquationAlpha: THREE.AddEquation,
      blendSrcAlpha: THREE.ZeroFactor,
      blendDstAlpha: THREE.ZeroFactor,
      uniforms: Object.assign({}, ctx.wind.uniforms, {
        uPoolColor: { value: new THREE.Color(p.poolColor) },
        uPoolAlpha: { value: p.poolAlpha },
      }),
      vertexShader: poolVertexShader,
      fragmentShader: poolFragmentShader,
    });
    poolMaterial.toneMapped = false;
    poolMaterial.name = 'fire-light-pool';
    ctx.style?.attach?.(poolMaterial, { element: 'fire' });

    this.poolMaterial = poolMaterial;
    this.poolGeometry = poolGeometry;
    this.pools = new THREE.InstancedMesh(poolGeometry, poolMaterial, MAX_FLAMES);
    this.pools.name = 'fire-light-pool';
    this.pools.userData.__duiIgnore = true;
    this.pools.count = 0;
    this.pools.frustumCulled = false;
    this.pools.renderOrder = 18;
    this.root.add(this.pools);

    const emberGeometry = new THREE.BufferGeometry();
    this._epos = new THREE.BufferAttribute(new Float32Array(MAX_EMBERS * 3), 3);
    this._eSizeAttr = new THREE.BufferAttribute(new Float32Array(MAX_EMBERS), 1);
    this._eSeedAttr = new THREE.BufferAttribute(new Float32Array(MAX_EMBERS), 1);
    this._eFadeAttr = new THREE.BufferAttribute(new Float32Array(MAX_EMBERS), 1);
    for (const a of [this._epos, this._eSizeAttr, this._eSeedAttr, this._eFadeAttr]) {
      a.setUsage(THREE.DynamicDrawUsage);
    }
    emberGeometry.setAttribute('position', this._epos);
    emberGeometry.setAttribute('aSize', this._eSizeAttr);
    emberGeometry.setAttribute('aSeed', this._eSeedAttr);
    emberGeometry.setAttribute('aFade', this._eFadeAttr);
    emberGeometry.setDrawRange(0, 0);
    emberGeometry.boundingSphere = new THREE.Sphere(new THREE.Vector3(), WORLD_SIZE);

    const emberMaterial = new THREE.ShaderMaterial({
      lights: false,
      fog: true,
      transparent: false,
      blending: THREE.CustomBlending,
      blendEquation: THREE.AddEquation,
      blendSrc: THREE.SrcAlphaFactor,
      blendDst: THREE.OneMinusSrcAlphaFactor,
      blendEquationAlpha: THREE.AddEquation,
      blendSrcAlpha: THREE.ZeroFactor,
      blendDstAlpha: THREE.ZeroFactor,
      uniforms: Object.assign(THREE.UniformsUtils.merge([THREE.UniformsLib.fog]), {
        uFrustumHalfHeight: { value: ctx.iso.frustumHalfHeight },
        uViewportHeight: { value: 800 },
        uEmberCore: { value: new THREE.Color(EMBER_HOT) },
        uEmberEdge: { value: new THREE.Color(EMBER_COOL) },
      }),
      vertexShader: emberVertexShader,
      fragmentShader: emberFragmentShader,
    });
    emberMaterial.toneMapped = false;
    emberMaterial.name = 'fire-embers';
    ctx.style?.attach?.(emberMaterial, { element: 'fire' });

    this.emberMaterial = emberMaterial;
    this.emberGeometry = emberGeometry;
    this.embers = new THREE.Points(emberGeometry, emberMaterial);
    this.embers.name = 'fire-embers';
    this.embers.userData.__duiIgnore = true;
    this.embers.frustumCulled = false;
    this.embers.renderOrder = 21;
    this.root.add(this.embers);

    // Created once and kept in the scene at zero intensity when unused: adding
    // or hiding lights later would recompile every lit material.
    for (let i = 0; i < MAX_LIGHTS; i++) {
      const light = new THREE.PointLight(new THREE.Color(p.lightColor), 0, 14, 2);
      light.name = `fire-light-${i}`;
      light.castShadow = false;
      this.root.add(light);
      this.lights.push(light);
    }

    this._rescan();
  }

  /**
   * @private Flame ramp and light pool, for the inspector's Material folder.
   * Setters write `params` as well as the uniform, so the Fire folder, save
   * files and this agree. See "Material descriptors" in ARCHITECTURE.md.
   * @returns {Array<object>}
   */
  _materialProps() {
    const p = this.params;
    const u = this.flameMaterial.uniforms;
    const swatch = (label, key, uniform, tooltip) => ({
      label,
      kind: 'color',
      tooltip,
      get: () => p[key],
      set: (v) => { p[key] = v; u[uniform].value.set(v); },
    });
    return [
      swatch('Rim', 'rim', 'uColRim', 'Outermost, coolest band of the flame'),
      swatch('Outer', 'outer', 'uColOuter', 'Second band of the flame ramp'),
      swatch('Mid', 'mid', 'uColMid', 'Middle band of the flame ramp'),
      swatch('Core', 'core', 'uColCore', 'Bright core of the flame'),
      swatch('Hot core', 'hot', 'uColHot', 'Hottest centre of the flame'),
      {
        label: 'Height', min: 0.5, max: 6, step: 0.05, tooltip: 'Flame height in metres',
        get: () => p.height, set: (v) => { p.height = v; },
      },
      {
        label: 'Light pool', kind: 'color', tooltip: 'Colour of the glow cast on the ground',
        get: () => p.poolColor,
        set: (v) => { p.poolColor = v; this.poolMaterial.uniforms.uPoolColor.value.set(v); },
      },
      {
        label: 'Pool strength', min: 0, max: 1, step: 0.01, tooltip: 'How strongly the light pool reads',
        get: () => p.poolAlpha,
        set: (v) => { p.poolAlpha = v; this.poolMaterial.uniforms.uPoolAlpha.value = v; },
      },
    ];
  }

  /** @private Rebuild the emitter list from the painted layer. */
  _rescan() {
    const { terrain, layers } = this.ctx;
    const mask = layers.get('mask');
    const cell = WORLD_SIZE / GRID;
    const emitters = [];
    for (let j = 0; j < GRID; j++) {
      const v = (j + 0.5) / GRID;
      for (let i = 0; i < GRID; i++) {
        const u = (i + 0.5) / GRID;
        const value = this.layer.sample(u, v);
        if (value <= FIRE_THRESHOLD) continue;
        if (mask && mask.sample(u, v) > 0.5) continue;
        const seed = fract(Math.sin(i * 12.9898 + j * 78.233) * 43758.5453);
        const seed2 = fract(Math.sin(i * 39.346 + j * 11.135) * 24634.6345);
        const world = uvToWorld(u, v);
        const x = world.x + (seed - 0.5) * cell * 0.7;
        const z = world.z + (seed2 - 0.5) * cell * 0.7;
        emitters.push({
          key: j * GRID + i,
          x,
          z,
          y: terrain ? terrain.heightAt(x, z) : 0,
          value,
          seed,
          width: 0.85 + seed2 * 0.35,
          // A campfire is wide and knee-high, not a column: the painted value
          // moves the height only a little, the Intensity slider does the rest.
          // The per-emitter spread is wide on purpose: a few tall tongues and
          // a few short ones read as one hand-drawn fire, four equal ones as a
          // fence.
          height: (0.95 + value * 0.55) * (0.78 + seed * 0.44),
        });
      }
    }
    emitters.sort((a, b) => b.value - a.value);
    if (emitters.length > MAX_FLAMES) emitters.length = MAX_FLAMES;
    this.emitters = emitters;

    // Forget burn timers of cells that are no longer alight.
    const live = new Set(emitters.map((e) => e.key));
    for (const key of this._burn.keys()) {
      if (!live.has(key)) this._burn.delete(key);
    }
    this._writeInstances();
  }

  /** @private Push emitter transforms and per-instance attributes to the GPU. */
  _writeInstances() {
    if (!this.flames) return;
    const p = this.params;
    const seeds = this._aSeed.array;
    const intens = this._aIntensity.array;
    const poolSeeds = this._aPoolSeed.array;
    for (let i = 0; i < this.emitters.length; i++) {
      const e = this.emitters[i];
      _matrix.makeScale(p.width * e.width, p.height * e.height, 1);
      _matrix.setPosition(e.x, e.y - 0.25, e.z);
      this.flames.setMatrixAt(i, _matrix);
      seeds[i] = e.seed;
      intens[i] = 0.85 + e.value * 0.25;

      // 0.74 of the half-scale survives the wobbled edge, so a ~1.2 u pool per
      // flame; the several emitters of one campfire overlap into the ~1.4 u
      // the design asks for instead of stacking into a wash.
      const d = 2.7 * p.intensity * (0.7 + e.value * 0.5);
      _matrix.makeScale(d, 1, d);
      _matrix.setPosition(e.x, e.y + 0.02, e.z);
      this.pools.setMatrixAt(i, _matrix);
      poolSeeds[i] = e.seed;
    }
    const count = this.emitters.length;
    this.flames.count = count;
    this.pools.count = p.pool ? count : 0;
    this.flames.instanceMatrix.needsUpdate = true;
    this.pools.instanceMatrix.needsUpdate = true;
    this._aSeed.needsUpdate = true;
    this._aIntensity.needsUpdate = true;
    this._aPoolSeed.needsUpdate = true;
  }

  /**
   * @param {import('../core/PaintLayers.js').PaintLayer} layer
   */
  onLayerChanged(layer) {
    if (layer.id === 'fire' || layer.id === 'mask') this._needsRescan = true;
  }

  /** Re-anchor flames when the ground moved under them. */
  onTerrainChanged() {
    const terrain = this.ctx.terrain;
    if (!terrain) return;
    for (const e of this.emitters) e.y = terrain.heightAt(e.x, e.z);
    this._writeInstances();
  }

  /**
   * @private Spawn one ember at the top of a flame.
   * @param {{x:number, y:number, z:number, height:number}} e
   */
  _spawnEmber(e) {
    if (this._emberCount >= MAX_EMBERS) return;
    const i = this._emberCount++;
    const h = this.params.height * e.height;
    this._ex[i] = e.x;
    this._ey[i] = e.y + h * (0.55 + Math.random() * 0.3);
    this._ez[i] = e.z;
    this._evy[i] = 0.7 + Math.random() * 0.5;
    this._eang[i] = Math.random() * Math.PI * 2;
    this._erad[i] = 0.12 + Math.random() * 0.22;
    this._eage[i] = 0;
    this._elife[i] = 0.9 + Math.random() * 0.9;
    this._eseed[i] = Math.random();
    // Two sizes only, like hand-drawn sparks.
    this._esize[i] = Math.random() < 0.5 ? 0.06 : 0.1;
  }

  /**
   * @private Swap-remove one ember.
   * @param {number} i
   */
  _killEmber(i) {
    const last = --this._emberCount;
    if (i === last) return;
    this._ex[i] = this._ex[last];
    this._ey[i] = this._ey[last];
    this._ez[i] = this._ez[last];
    this._evy[i] = this._evy[last];
    this._eang[i] = this._eang[last];
    this._erad[i] = this._erad[last];
    this._eage[i] = this._eage[last];
    this._elife[i] = this._elife[last];
    this._eseed[i] = this._eseed[last];
    this._esize[i] = this._esize[last];
  }

  /**
   * @param {number} dt seconds
   * @param {number} time seconds since start
   */
  update(dt, time) {
    if (!this.flames) return;
    const ctx = this.ctx;

    this._rescanTimer += dt;
    if (this._needsRescan && this._rescanTimer >= RESCAN_INTERVAL) {
      this._rescanTimer = 0;
      this._needsRescan = false;
      this._rescan();
    }
    const count = this.emitters.length;

    ctx.renderer.getDrawingBufferSize(_drawSize);
    this.emberMaterial.uniforms.uViewportHeight.value = _drawSize.y;
    this.emberMaterial.uniforms.uFrustumHalfHeight.value = ctx.iso.frustumHalfHeight;

    // Per-emitter wind shear.
    const winds = this._aWind.array;
    for (let i = 0; i < count; i++) {
      const e = this.emitters[i];
      const w = ctx.wind.sampleAt(e.x, e.z, time);
      winds[i * 2] = w.x;
      winds[i * 2 + 1] = w.z;
    }
    if (count > 0) this._aWind.needsUpdate = true;

    this._burnGround(dt, count);
    this._updateLights(count, time);
    this._updateEmbers(dt, time, count);
    this._updateSmoke(dt, count);
  }

  /**
   * @private Fire eats the grass under it, scorches the ground, spreads
   * downwind onto fuel and finally burns out. The fire layer stays the single
   * source of truth: burn-out erases it and the rescan drops the emitter.
   * @param {number} dt seconds
   * @param {number} count number of emitters
   */
  _burnGround(dt, count) {
    if (count === 0) return;
    const p = this.params;
    const { layers } = this.ctx;
    const grass = layers.get('grass');
    const mask = layers.get('mask');
    const cellUV = 1 / GRID;
    const cellWorld = WORLD_SIZE / GRID;
    const winds = this._aWind.array;

    this._burnTick += dt;
    const tick = this._burnTick >= BURN_TICK;
    if (tick) this._burnTick -= BURN_TICK;

    for (let i = 0; i < count; i++) {
      const e = this.emitters[i];
      const { u, v } = worldToUV(e.x, e.z);
      const burned = (this._burn.get(e.key) || 0) + dt;
      this._burn.set(e.key, burned);
      const fuel = grass ? grass.sample(u, v) : 0;

      if (tick) {
        if (grass) {
          grass.stamp({ u, v, radius: cellUV * 0.8, strength: 0.15, hardness: 0.5, mode: 'erase' });
        }
        this.scorchLayer.stamp({
          u, v, radius: cellUV * 0.8, strength: 0.5, hardness: 0.4, mode: 'add',
        });
        if (fuel < 0.05 && burned > p.burnTime) {
          this.layer.stamp({ u, v, radius: cellUV, strength: 1, hardness: 0.8, mode: 'erase' });
          this._burn.delete(e.key);
          continue;
        }
      }

      // Spread downwind onto whatever fuel is there.
      if (!p.spread || !grass || Math.random() >= p.spreadRate * dt) continue;
      const wx = winds[i * 2];
      const wz = winds[i * 2 + 1];
      const len = Math.hypot(wx, wz);
      if (len < 1e-4) continue;
      const target = worldToUV(e.x + (wx / len) * cellWorld, e.z + (wz / len) * cellWorld);
      if (target.u <= 0 || target.u >= 1 || target.v <= 0 || target.v >= 1) continue;
      if (grass.sample(target.u, target.v) <= 0.3) continue;
      if (mask && mask.sample(target.u, target.v) > 0.5) continue;
      this.layer.stamp({
        u: target.u, v: target.v, radius: cellUV, strength: 0.6, hardness: 0.5, mode: 'add',
      });
    }
  }

  /**
   * @private Park up to three flickering point lights on the strongest flames.
   * @param {number} count
   * @param {number} time
   */
  _updateLights(count, time) {
    const p = this.params;
    for (let i = 0; i < this.lights.length; i++) {
      const light = this.lights[i];
      if (!p.light || i >= count) {
        light.intensity = 0;
        continue;
      }
      const e = this.emitters[i];
      const flicker = 0.8 + 0.2 * Math.sin(time * 3.4 + i * 2.1);
      light.position.set(e.x, e.y + p.height * e.height * 0.45, e.z);
      light.color.set(p.lightColor);
      light.intensity = p.lightIntensity * e.value * flicker;
      light.distance = 6 + p.height * 4;
    }
  }

  /**
   * @private Spawn, integrate and upload embers.
   * @param {number} dt
   * @param {number} time
   * @param {number} count number of emitters
   */
  _updateEmbers(dt, time, count) {
    const p = this.params;
    if (p.embers && count > 0) {
      this._emberAcc += dt * Math.min(count * p.emberRate, 30);
      while (this._emberAcc >= 1) {
        this._emberAcc -= 1;
        this._spawnEmber(this.emitters[(Math.random() * count) | 0]);
      }
    } else {
      this._emberAcc = 0;
    }

    const wind = this.ctx.wind;
    const pos = this._epos.array;
    const sizes = this._eSizeAttr.array;
    const seeds = this._eSeedAttr.array;
    const fades = this._eFadeAttr.array;
    for (let i = this._emberCount - 1; i >= 0; i--) {
      this._eage[i] += dt;
      const t = this._eage[i] / this._elife[i];
      if (t >= 1) {
        this._killEmber(i);
        continue;
      }
      const w = wind.sampleAt(this._ex[i], this._ez[i], time);
      this._ex[i] += w.x * 0.8 * dt;
      this._ez[i] += w.z * 0.8 * dt;
      this._evy[i] -= 0.35 * dt;
      this._ey[i] += this._evy[i] * dt;
      // Slow spiral around the rising column.
      const a = this._eang[i] + time * 1.4;
      const o = i * 3;
      pos[o] = this._ex[i] + Math.cos(a) * this._erad[i];
      pos[o + 1] = this._ey[i];
      pos[o + 2] = this._ez[i] + Math.sin(a) * this._erad[i];
      sizes[i] = this._esize[i];
      seeds[i] = this._eseed[i];
      fades[i] = 1 - t * t;
    }
    this.emberGeometry.setDrawRange(0, this._emberCount);
    this._epos.needsUpdate = true;
    this._eSizeAttr.needsUpdate = true;
    this._eSeedAttr.needsUpdate = true;
    this._eFadeAttr.needsUpdate = true;
  }

  /**
   * @private Feed the shared smoke service from the flame tops.
   * @param {number} dt
   * @param {number} count number of emitters
   */
  _updateSmoke(dt, count) {
    const smoke = this.ctx.elements.get('smoke');
    if (!smoke || count === 0 || this.params.smokeRate <= 0) {
      this._puffAcc = 0;
      return;
    }
    const p = this.params;
    this._puffAcc += dt * Math.min(count * p.smokeRate, MAX_PUFFS_PER_SECOND);
    while (this._puffAcc >= 1) {
      this._puffAcc -= 1;
      const e = this.emitters[(Math.random() * count) | 0];
      smoke.puff(
        e.x + (Math.random() - 0.5) * 0.4,
        e.y + p.height * e.height * 1.15,
        e.z + (Math.random() - 0.5) * 0.4,
        // No `color`: a tint would flatten the puff to one grey, and Smoke's
        // own three-tone cumulus ramp is exactly the Ghibli palette we want.
        { size: 0.85 + e.value * 0.15, life: 3.2, rise: 0.6, drift: 1.2 },
      );
    }
  }

  /**
   * Repaint the flame ramp and the light pool from a style's palette. Writes
   * `params` as well as the uniforms, so the Fire folder, the Material folder
   * and `serialize()` all keep telling the truth.
   * @param {{rim?:string, outer?:string, mid?:string, core?:string, hot?:string,
   *   pool?:string, light?:string, ember?:string, emberEdge?:string}} [p]
   * @returns {Fire} this, for chaining
   */
  applyPalette(p) {
    if (!p || !this.flameMaterial) return this;
    const u = this.flameMaterial.uniforms;
    const ramp = [
      ['rim', 'uColRim'], ['outer', 'uColOuter'], ['mid', 'uColMid'],
      ['core', 'uColCore'], ['hot', 'uColHot'],
    ];
    for (const [key, uniform] of ramp) {
      if (p[key] != null) { this.params[key] = p[key]; u[uniform].value.set(p[key]); }
    }
    if (p.pool != null) {
      this.params.poolColor = p.pool;
      this.poolMaterial.uniforms.uPoolColor.value.set(p.pool);
    }
    if (p.light != null) this.params.lightColor = p.light;
    const eu = this.emberMaterial.uniforms;
    if (p.ember != null) eu.uEmberCore.value.set(p.ember);
    if (p.emberEdge != null) eu.uEmberEdge.value.set(p.emberEdge);
    this.flameMaterial.userData.swatch = [this.params.hot, this.params.mid, this.params.rim];
    return this;
  }

  /**
   * @param {object} ui ghost-panel root
   */
  buildPanel(ui) {
    const f = ui.addFolder('Fire');
    const p = this.params;
    const u = this.flameMaterial.uniforms;
    f.addSlider('Intensity', {
      min: 0.2, max: 2.5, step: 0.05, value: p.intensity,
      onChange: (v) => { p.intensity = v; u.uIntensity.value = v; this._writeInstances(); },
    });
    f.addSlider('Height', {
      min: 0.6, max: 5, step: 0.1, value: p.height,
      onChange: (v) => { p.height = v; this._writeInstances(); },
    });
    f.addSlider('Width', {
      min: 0.4, max: 3, step: 0.05, value: p.width,
      onChange: (v) => { p.width = v; this._writeInstances(); },
    });
    f.addSlider('Wind lean', {
      min: 0, max: 2, step: 0.05, value: p.lean,
      onChange: (v) => { p.lean = v; u.uLean.value = v; },
    });
    const colors = [
      ['Rim', 'rim', 'uColRim'],
      ['Outer', 'outer', 'uColOuter'],
      ['Mid', 'mid', 'uColMid'],
      ['Core', 'core', 'uColCore'],
      ['Hot core', 'hot', 'uColHot'],
    ];
    for (const [label, key, uniform] of colors) {
      f.addColor(label, {
        value: p[key],
        onChange: (hex) => { p[key] = hex; u[uniform].value.set(hex); },
      });
    }
    f.addCheckbox('Embers', {
      value: p.embers,
      onChange: (v) => { p.embers = v; },
    });
    f.addSlider('Ember rate', {
      min: 0, max: 8, step: 0.1, value: p.emberRate,
      onChange: (v) => { p.emberRate = v; },
    });
    f.addSlider('Smoke rate', {
      min: 0, max: 5, step: 0.1, value: p.smokeRate,
      onChange: (v) => { p.smokeRate = v; },
    });
    f.addCheckbox('Spread', {
      value: p.spread,
      onChange: (v) => { p.spread = v; },
    });
    f.addSlider('Spread rate', {
      min: 0, max: 1, step: 0.01, value: p.spreadRate,
      onChange: (v) => { p.spreadRate = v; },
    });
    f.addSlider('Burn time', {
      min: 1, max: 60, step: 1, value: p.burnTime,
      onChange: (v) => { p.burnTime = v; },
    });
    f.addCheckbox('Light', {
      value: p.light,
      onChange: (v) => { p.light = v; },
    });
    f.addSlider('Light intensity', {
      min: 0, max: 40, step: 0.5, value: p.lightIntensity,
      onChange: (v) => { p.lightIntensity = v; },
    });
    f.addColor('Light colour', {
      value: p.lightColor,
      onChange: (hex) => { p.lightColor = hex; },
    });
    f.addCheckbox('Light pool', {
      value: p.pool,
      onChange: (v) => { p.pool = v; this._writeInstances(); },
    });
    f.addColor('Pool colour', {
      value: p.poolColor,
      onChange: (hex) => { p.poolColor = hex; this.poolMaterial.uniforms.uPoolColor.value.set(hex); },
    });
    f.addSlider('Pool strength', {
      min: 0, max: 1, step: 0.01, value: p.poolAlpha,
      onChange: (v) => { p.poolAlpha = v; this.poolMaterial.uniforms.uPoolAlpha.value = v; },
    });
  }

  /** @returns {object} panel parameters (emitters come from the layer) */
  serialize() {
    return { ...this.params };
  }

  /**
   * @param {object} o output of `serialize()`
   */
  deserialize(o = {}) {
    Object.assign(this.params, o);
    if (!this.flames) return;
    const p = this.params;
    const u = this.flameMaterial.uniforms;
    u.uIntensity.value = p.intensity;
    u.uLean.value = p.lean;
    u.uColRim.value.set(p.rim);
    u.uColOuter.value.set(p.outer);
    u.uColMid.value.set(p.mid);
    u.uColCore.value.set(p.core);
    u.uColHot.value.set(p.hot);
    this.poolMaterial.uniforms.uPoolColor.value.set(p.poolColor);
    this.poolMaterial.uniforms.uPoolAlpha.value = p.poolAlpha;
    this._writeInstances();
  }

  /** Release GPU resources. */
  dispose() {
    if (!this.flames) return;
    const style = this.ctx.style;
    style?.detach?.(this.flameMaterial);
    style?.detach?.(this.poolMaterial);
    style?.detach?.(this.emberMaterial);
    this.ctx.scene.remove(this.root);
    this.root.clear();
    this.lights.length = 0;
    this.flameGeometry.dispose();
    this.flameMaterial.dispose();
    this.poolGeometry.dispose();
    this.poolMaterial.dispose();
    this.emberGeometry.dispose();
    this.emberMaterial.dispose();
    this.flames = null;
    this.pools = null;
    this.embers = null;
    this.root = null;
  }
}

/**
 * @param {number} x
 * @returns {number} fractional part, always in 0..1
 */
function fract(x) {
  return x - Math.floor(x);
}
