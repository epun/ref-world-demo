import * as THREE from 'three';
import RAPIER from '@dimforge/rapier3d-compat';
import { Element } from '../core/Element.js';
import { Physics } from '../core/Physics.js';
import { PaintLayer } from '../core/PaintLayers.js';
import { WORLD_SIZE, worldToUV } from '../core/constants.js';
import { toonParsVertex, toonShadowVertex, toonParsFragment } from '../core/shaders/toon.glsl.js';

/** Number of low-poly rock shapes. */
const VARIANTS = 6;
/** Instances each variant's InstancedMesh can hold. */
const PER_VARIANT = 100;
/** Hard cap on live rocks. */
const MAX_ROCKS = 400;
/** Ratio of the ball collider radius to the rock's visual scale. */
const COLLIDER_RATIO = 0.7;
/** Grass density at which moss starts / is fully grown. */
const MOSS_LO = 0.4;
const MOSS_HI = 0.8;
/** Resolution of the 'press' layer (rocks flattening grass). */
const PRESS_RES = 128;
/** Per-frame decay of the press layer back to neutral. */
const PRESS_DECAY = 0.88;
/** A rock slower than this leaves no press trail. */
const PRESS_MIN_SPEED = 0.15;
/** Below this speed a landed rock gets rolling resistance and beds down. */
const SETTLE_SPEED = 2.5;

const _v = new THREE.Vector3();
const _q = new THREE.Quaternion();
const _s = new THREE.Vector3();
const _m = new THREE.Matrix4();

/**
 * Deterministic 0..1 hash of three integers plus a seed.
 * @param {number} x
 * @param {number} y
 * @param {number} z
 * @param {number} seed
 * @returns {number}
 */
function hash3(x, y, z, seed) {
  let h = x * 374761393 + y * 668265263 + z * 2147483647 + seed * 1442695040;
  h = (h ^ (h >>> 13)) * 1274126177;
  h = h ^ (h >>> 16);
  return ((h >>> 0) % 100003) / 100003;
}

/**
 * One faceted boulder: an icosahedron whose vertices are pushed in and out by
 * a hash of their (quantised) direction, then flattened in Y. Quantising the
 * direction keeps duplicated vertices of the non-indexed geometry watertight.
 * Flat normals give the hard toon facets.
 *
 * @param {number} seed variant seed
 * @returns {THREE.BufferGeometry} non-indexed, flat-shaded
 */
export function makeRockGeometry(seed) {
  const source = new THREE.IcosahedronGeometry(1, 1);
  const geometry = source.index ? source.toNonIndexed() : source;
  if (geometry !== source) source.dispose();

  const pos = geometry.attributes.position;
  for (let i = 0; i < pos.count; i++) {
    _v.fromBufferAttribute(pos, i).normalize();
    const fine = hash3(
      Math.round(_v.x * 64),
      Math.round(_v.y * 64),
      Math.round(_v.z * 64),
      seed * 17 + 1,
    );
    const lobe = hash3(Math.round(_v.x * 2), Math.round(_v.y * 2), Math.round(_v.z * 2), seed * 31 + 7);
    const r = 1 + 0.35 * (fine - 0.5) + 0.28 * (lobe - 0.5);
    pos.setXYZ(i, _v.x * r, _v.y * r * 0.75, _v.z * r);
  }
  pos.needsUpdate = true;
  geometry.computeVertexNormals();
  geometry.computeBoundingSphere();
  return geometry;
}

/**
 * The unique vertices of a rock geometry, for its convex-hull collider.
 * @param {THREE.BufferGeometry} geometry
 * @returns {Float32Array} xyz triplets
 */
function hullPoints(geometry) {
  const pos = geometry.attributes.position.array;
  const seen = new Set();
  const out = [];
  for (let i = 0; i < pos.length; i += 3) {
    const key = `${pos[i].toFixed(4)},${pos[i + 1].toFixed(4)},${pos[i + 2].toFixed(4)}`;
    if (seen.has(key)) continue;
    seen.add(key);
    out.push(pos[i], pos[i + 1], pos[i + 2]);
  }
  return new Float32Array(out);
}

/**
 * Painted rocks: faceted toon boulders dropped from above and settled by
 * Rapier, mossy on top where they sit in grass, splashing when they land in
 * water.
 *
 * This element also owns the lazy creation of `ctx.physics` (App does not build
 * it): the first Rocks instance constructs the Physics wrapper, marks itself as
 * its `owner`, and is therefore the one element that calls `physics.step(dt)`
 * each frame. Any other element that needs physics can just use `ctx.physics`.
 */
export class Rocks extends Element {
  static id = 'rocks';
  static label = 'Rocks';
  static order = 30;

  /**
   * @param {object} ctx shared app context
   */
  constructor(ctx) {
    super(ctx);
    /** @type {Array<object>} live rocks */
    this.rocks = [];
    /** @type {Array<{mesh: THREE.InstancedMesh, moss: THREE.InstancedBufferAttribute, seed: THREE.InstancedBufferAttribute, rocks: Array<object>}>} */
    this.variants = [];
    /** @type {import('../core/Physics.js').Physics|null} */
    this.physics = null;
    /** @type {THREE.Group|null} scene parent, what the Outliner lists */
    this.root = null;

    /** @type {{sizeMin:number, sizeMax:number, spawnRate:number, speckle:number}} */
    this.params = { sizeMin: 0.3, sizeMax: 1.0, spawnRate: 0.35, speckle: 0.6 };
    /** @private moss needs re-sampling from the grass layer */
    this._mossDirty = true;
    /** @private seconds since the last moss refresh */
    this._sinceMoss = 0;
    /** @private the press layer holds non-neutral texels that still need decaying */
    this._pressActive = false;
    /**
     * Where rocks are currently pressing on what grows below: RGBA byte layer,
     * RG = push direction, B = strength. Grass reads it.
     * @type {PaintLayer|null}
     */
    this.pressLayer = null;
  }

  /** Build geometry, material, instanced meshes, the tool and the physics world. */
  async init() {
    const ctx = this.ctx;

    if (!ctx.physics) {
      ctx.physics = new Physics(ctx);
      await ctx.physics.init();
      ctx.physics.owner = this;
    }
    this.physics = ctx.physics;
    this.pressLayer = this._buildPressLayer();

    this.material = this._buildMaterial();
    this.material.userData.uiProps = this._materialProps();
    this.material.userData.swatch = ['#bfb8ab', '#8f8c88', '#5f7396'];
    this.ctx.style?.attach?.(this.material, { element: 'rocks' });

    // One parent for every variant mesh: the panel's Outliner lists elements by
    // `sceneObjects()`, which picks up `this.root`. Left at the origin, so the
    // instance matrices stay world-space.
    this.root = new THREE.Group();
    this.root.name = 'Rocks';
    ctx.scene.add(this.root);

    for (let i = 0; i < VARIANTS; i++) {
      const geometry = makeRockGeometry(i);
      const moss = new THREE.InstancedBufferAttribute(new Float32Array(PER_VARIANT), 1);
      const seed = new THREE.InstancedBufferAttribute(new Float32Array(PER_VARIANT), 1);
      for (let k = 0; k < PER_VARIANT; k++) seed.setX(k, hash3(i, k, 3, 11) * 40);
      geometry.setAttribute('aMoss', moss);
      geometry.setAttribute('aSeed', seed);

      const mesh = new THREE.InstancedMesh(geometry, this.material, PER_VARIANT);
      mesh.name = `rocks:${i}`;
      mesh.count = 0;
      mesh.castShadow = true;
      mesh.receiveShadow = true;
      mesh.frustumCulled = false;
      mesh.instanceMatrix.setUsage(THREE.DynamicDrawUsage);
      this.root.add(mesh);
      this.variants.push({ mesh, moss, seed, rocks: [], hull: hullPoints(geometry) });
    }

    ctx.brush.registerTool({
      id: 'rocks',
      label: 'Rocks',
      color: '#9a9a9a',
      key: '6',
      element: 'rocks',   // History snapshots this element around the stroke
      mode: 'add',
      eraseMode: 'erase',
      strengthScale: 4,
      onStamp: (_ctx, op, hit) => this._onStamp(op, hit),
    });
  }

  /**
   * @private The 'press' layer other elements read to know where something
   * heavy is rolling over them: RG = push direction (dir * 0.5 + 0.5 in layer
   * UV space), B = strength 0..1, A unused. `PaintLayer`'s `initial` is a
   * single scalar, so the neutral RGBA (128, 128, 0, 255) is written here.
   * @returns {PaintLayer}
   */
  _buildPressLayer() {
    const existing = this.ctx.layers.get('press');
    if (existing) return existing;

    // Simulated every frame, never painted directly — kept out of undo.
    const layer = this.ctx.layers.add(
      new PaintLayer('press', { res: PRESS_RES, channels: 4, history: false }),
    );
    const data = layer.data;
    for (let i = 0; i < data.length; i += 4) {
      data[i] = 128;
      data[i + 1] = 128;
      data[i + 2] = 0;
      data[i + 3] = 255;
    }
    layer.texture.needsUpdate = true;
    return layer;
  }

  /**
   * Re-colour the rocks for a style; only the keys present are written.
   * @param {{rock?:string, warm?:string, cool?:string, moss?:string}} [p]
   */
  applyPalette(p) {
    if (!p || !this.material) return this;
    const u = this.material.uniforms;
    if (p.rock != null) u.uRock.value.set(p.rock);
    if (p.warm != null) u.uWarm.value.set(p.warm);
    if (p.cool != null) u.uCool.value.set(p.cool);
    if (p.moss != null) u.uMoss.value.set(p.moss);
    return this;
  }

  /**
   * @private Rock colours, for the inspector's Material folder. Colours go
   * through `applyPalette`, the same path a style switch takes.
   * See "Material descriptors" in ARCHITECTURE.md.
   * @returns {Array<object>}
   */
  _materialProps() {
    const u = this.material.uniforms;
    const hex = (name) => `#${u[name].value.getHexString()}`;
    const swatch = (label, key, name, tooltip) => ({
      label,
      kind: 'color',
      tooltip,
      get: () => hex(name),
      set: (v) => this.applyPalette({ [key]: v }),
    });
    return [
      swatch('Base', 'rock', 'uRock', 'Overall stone colour'),
      swatch('Sunlit top', 'warm', 'uWarm', 'Warm light catching the upper faces'),
      swatch('Shadow side', 'cool', 'uCool', 'Cool bounce on the shaded faces'),
      swatch('Moss', 'moss', 'uMoss', 'Moss that creeps in where grass is thick'),
      {
        label: 'Speckle',
        min: 0,
        max: 1,
        step: 0.01,
        tooltip: 'Mineral fleck across the surface',
        get: () => this.params.speckle,
        set: (v) => { this.params.speckle = v; u.uSpeckle.value = v; },
      },
    ];
  }

  /** @private @returns {THREE.ShaderMaterial} */
  _buildMaterial() {
    const { sun, wind } = this.ctx;
    const color = (hex) => ({ value: new THREE.Color(hex) });

    const uniforms = Object.assign(
      THREE.UniformsUtils.clone(THREE.UniformsLib.lights),
      sun.uniforms,
      wind.uniforms,
      {
        uRock: color('#8f8c88'),
        uWarm: color('#bfb8ab'),
        uCool: color('#5f7396'),
        uMoss: color('#6fa04a'),
        uSpeckle: { value: this.params.speckle },
      },
    );

    const vertexShader = /* glsl */ `
      ${toonParsVertex}
      attribute float aMoss;
      attribute float aSeed;
      varying float vMoss;
      varying float vSeed;
      varying vec3 vObjPos;

      void main() {
        vMoss = aMoss;
        vSeed = aSeed;
        vObjPos = position;

        mat4 instance = mat4(1.0);
        #ifdef USE_INSTANCING
          instance = instanceMatrix;
        #endif

        vec4 worldPosition = modelMatrix * instance * vec4(position, 1.0);
        vec3 objectNormal = mat3(instance) * normal;
        vec3 transformedNormal = normalMatrix * objectNormal;
        ${toonShadowVertex}
      }
    `;

    const fragmentShader = /* glsl */ `
      ${toonParsFragment}

      uniform float uStyleId;
      uniform vec3 uRock;
      uniform vec3 uWarm;
      uniform vec3 uCool;
      uniform vec3 uMoss;
      uniform float uSpeckle;

      varying float vMoss;
      varying float vSeed;
      varying vec3 vObjPos;

      // Distance to the nearest feature point of a jittered grid: the speckle
      // of the reference rock's Voronoi layer.
      float voronoiF1(vec2 p) {
        vec2 cell = floor(p);
        vec2 f = fract(p);
        float best = 1.0;
        for (int j = -1; j <= 1; j++) {
          for (int i = -1; i <= 1; i++) {
            vec2 g = vec2(float(i), float(j));
            vec2 o = vec2(hash21(cell + g), hash21(cell + g + 91.7));
            best = min(best, length(g + o - f));
          }
        }
        return clamp(best, 0.0, 1.0);
      }

      void main() {
        vec3 n = normalize(vNormalW);

        // Warm, sun-bleached top; cool blue-grey on the faces turned away.
        float up = smoothstep(0.0, 0.85, n.y);
        vec3 albedo = mix(uRock, uWarm, up * 0.7);
        float away = 1.0 - smoothstep(-0.25, 0.30, dot(n, uSunDir));
        albedo = mix(albedo, uCool, away * 0.7);

        // Cellular speckle, hard-stepped so it reads as painted flecks.
        float cell = voronoiF1(vObjPos.xz * 4.5 + vObjPos.y * 3.0 + vSeed);
        float fleck = step(0.42, cell);
        float speckle = uSpeckle;

        // --- style branches (see "Style branches" in ARCHITECTURE.md) ---
        if (uStyleId > 0.5 && uStyleId < 1.5) {
          // Flat: one printed grey, one printed top. No weathering at all.
          albedo = mix(uRock, uWarm, step(0.5, up));
          speckle = 0.0;
        } else if (uStyleId > 1.5 && uStyleId < 2.5) {
          // Realistic: smooth weathering, no hard flecks, no blue side.
          albedo = mix(uRock, uWarm, up * 0.55);
          albedo = mix(albedo, uCool, away * 0.25);
          albedo *= mix(1.0, 0.86 + 0.28 * cell, uSpeckle * 0.7);
          speckle = 0.0;
        } else if (uStyleId > 3.5) {
          // Pixel: three inks, chosen by facet, nothing blended.
          albedo = away > 0.5 ? uCool : (up > 0.5 ? uWarm : uRock);
          speckle = 0.0;
        }
        albedo *= mix(1.0, 0.90 + 0.20 * fleck + 0.06 * cell, speckle);

        // Moss caps the up-facing part of rocks standing in grass, with a
        // broken, hand-painted edge.
        float mossEdge = fbm(vWorldPos.xz * 2.5, 3);
        float moss = step(0.5, vMoss * smoothstep(0.2, 0.7, n.y) * (0.55 + 0.95 * mossEdge));
        // Realistic moss creeps rather than snapping on at a painted edge.
        if (uStyleId > 1.5 && uStyleId < 2.5) {
          moss = smoothstep(0.35, 0.75, vMoss * smoothstep(0.1, 0.8, n.y) * (0.55 + 0.95 * mossEdge));
        }
        albedo = mix(albedo, uMoss, moss * 0.9);

        vec3 col = toonLight(albedo, n, toonShadow(), 3.0);
        // Rock keeps its original flat cel texture (two tones and painted
        // flecks) with an outline only: the ink pass never hatches it.
        gl_FragColor = vec4(col, 0.75);
        #include <colorspace_fragment>
      }
    `;

    return new THREE.ShaderMaterial({
      name: 'Rock',
      uniforms,
      vertexShader,
      fragmentShader,
      lights: true,
      toneMapped: false,
    });
  }

  // --- spawning -----------------------------------------------------------

  /**
   * @private Brush callback: scatter or erase rocks inside the brush disc.
   * @param {object} op stamp op (UV space)
   * @param {object} hit terrain hit
   */
  _onStamp(op, hit) {
    const radius = op.radius * WORLD_SIZE;
    if (op.mode === 'erase' || op.mode === 'lower') {
      this.removeNear(hit.x, hit.z, radius);
      return;
    }
    if (Math.random() > this.params.spawnRate * Math.min(1, op.strength)) return;

    const a = Math.random() * Math.PI * 2;
    const d = Math.sqrt(Math.random()) * radius;
    this.spawn(hit.x + Math.cos(a) * d, hit.z + Math.sin(a) * d);
  }

  /**
   * Drop one rock from a couple of units above the terrain.
   * @param {number} x world X
   * @param {number} z world Z
   * @param {number} [scale] visual radius; random in [sizeMin, sizeMax] otherwise
   * @returns {object|null} the rock record, or null when capped / masked out
   */
  spawn(x, z, scale) {
    if (this.rocks.length >= MAX_ROCKS || !this.physics?.ready) return null;
    const half = WORLD_SIZE / 2 - 0.5;
    if (x < -half || x > half || z < -half || z > half) return null;

    const { u, v } = worldToUV(x, z);
    if ((this.ctx.layers.get('mask')?.sample(u, v) ?? 0) > 0.5) return null;

    const { sizeMin, sizeMax } = this.params;
    const s = scale ?? sizeMin + Math.random() * Math.max(0.01, sizeMax - sizeMin);

    // Refuse to drop a rock inside another one: overlapping colliders are
    // resolved with violent impulses that scatter the whole cluster.
    for (const other of this.rocks) {
      const t = other.body.translation();
      const dx = t.x - x;
      const dz = t.z - z;
      const min = (s + other.scale) * 0.75;
      if (dx * dx + dz * dz < min * min) return null;
    }

    const y = this.ctx.terrain.heightAt(x, z) + 2 + Math.random() * 2;

    const vi = this._pickVariant();
    if (vi < 0) return null;

    const rot = new THREE.Quaternion().setFromEuler(
      new THREE.Euler(Math.random() * Math.PI * 2, Math.random() * Math.PI * 2, Math.random() * Math.PI * 2),
    );
    const body = this._createBody(x, y, z, rot, s, vi);
    if (!body) return null;
    body.setAngvel({ x: (Math.random() - 0.5) * 3, y: (Math.random() - 0.5) * 3, z: (Math.random() - 0.5) * 3 }, true);

    return this._register(body, s, vi);
  }

  /**
   * @private The variant mesh a new rock should go into: random, falling back
   * to the least-full one.
   * @param {number} [preferred]
   * @returns {number} variant index, or -1 when every mesh is full
   */
  _pickVariant(preferred) {
    let vi = preferred ?? Math.floor(Math.random() * VARIANTS);
    if (vi < 0 || vi >= VARIANTS || this.variants[vi].rocks.length >= PER_VARIANT) {
      vi = this.variants.reduce(
        (best, cur, i) => (cur.rocks.length < this.variants[best].rocks.length ? i : best),
        0,
      );
    }
    return this.variants[vi].rocks.length >= PER_VARIANT ? -1 : vi;
  }

  /**
   * @private Rapier body for a rock. The collider is the convex hull of the
   * rock's own facets, so it beds down on a face instead of rolling forever
   * like a ball would; a ball is the fallback if the hull can't be built.
   * @param {number} x
   * @param {number} y
   * @param {number} z
   * @param {THREE.Quaternion} rot
   * @param {number} s scale
   * @param {number} vi variant index
   */
  _createBody(x, y, z, rot, s, vi) {
    // Damping and friction: rocks thud and stop instead of rolling like
    // marbles — which also keeps them from skating across height-field cell
    // edges fast enough to be pushed through the ground.
    const desc = RAPIER.RigidBodyDesc.dynamic()
      .setTranslation(x, y, z)
      .setRotation({ x: rot.x, y: rot.y, z: rot.z, w: rot.w })
      .setLinearDamping(0.4)
      .setAngularDamping(2.5);

    const hull = this.variants[vi]?.hull;
    let collider = null;
    if (hull) {
      const pts = new Float32Array(hull.length);
      for (let i = 0; i < hull.length; i++) pts[i] = hull[i] * s;
      collider = RAPIER.ColliderDesc.convexHull(pts);
    }
    if (!collider) collider = RAPIER.ColliderDesc.ball(s * COLLIDER_RATIO);
    collider.setRestitution(0.05).setFriction(1.4).setDensity(2.5);
    return this.physics.addRigidBody(desc, collider);
  }

  /**
   * @private Slot a body into a variant mesh (see `_pickVariant`).
   * @param {object} body
   * @param {number} s
   * @param {number} vi variant index
   */
  _register(body, s, vi) {
    const variant = this.variants[vi];
    const rock = {
      body,
      variant: vi,
      slot: variant.rocks.length,
      scale: s,
      landed: false,
      inWater: false,
      obstacle: false,
      awake: true,
      damped: false,
    };
    variant.rocks.push(rock);
    variant.mesh.count = variant.rocks.length;
    this.rocks.push(rock);
    this._writeMatrix(rock);
    this._updateMoss(rock);
    return rock;
  }

  /**
   * Remove every rock whose centre is within `radius` of (x, z).
   * @param {number} x
   * @param {number} z
   * @param {number} radius world units
   * @returns {number} how many were removed
   */
  removeNear(x, z, radius) {
    const r2 = radius * radius;
    const doomed = this.rocks.filter((rock) => {
      const t = rock.body.translation();
      const dx = t.x - x;
      const dz = t.z - z;
      return dx * dx + dz * dz <= r2;
    });
    for (const rock of doomed) this._destroy(rock);
    return doomed.length;
  }

  /** Remove every rock. */
  clear() {
    for (const rock of [...this.rocks]) this._destroy(rock);
    return this;
  }

  /**
   * @private Free a rock's body and compact its variant's instance list.
   * @param {object} rock
   */
  _destroy(rock) {
    const variant = this.variants[rock.variant];
    const last = variant.rocks[variant.rocks.length - 1];
    variant.rocks[rock.slot] = last;
    last.slot = rock.slot;
    variant.rocks.pop();
    variant.mesh.count = variant.rocks.length;
    if (last !== rock) {
      this._writeMatrix(last);
      this._updateMoss(last);
    }
    variant.mesh.instanceMatrix.needsUpdate = true;

    const i = this.rocks.indexOf(rock);
    if (i >= 0) this.rocks.splice(i, 1);
    this.physics.remove(rock.body);
    rock.body = null;
  }

  // --- per-frame ----------------------------------------------------------

  /**
   * Step the world (when this element owns it) and sync instance matrices.
   * @param {number} dt
   */
  update(dt) {
    const physics = this.physics;
    if (!physics?.ready) return;
    // Exactly one element drives the world: whoever created it, unless that
    // instance is no longer the registered element (a replaced element would
    // otherwise leave the simulation frozen).
    if (physics.owner !== this && this.ctx.elements.get(Rocks.id) === this) physics.owner = this;
    if (physics.owner === this) physics.step(dt);

    this._sinceMoss += dt;
    if (this._mossDirty && this._sinceMoss > 0.25) {
      this._sinceMoss = 0;
      this._mossDirty = false;
      for (const rock of this.rocks) this._updateMoss(rock);
    }

    const water = this.ctx.elements.get('water');
    const gust = this.ctx.wind.uniforms.uGust.value;
    let pressWrote = this._decayPress();

    for (const rock of this.rocks) {
      const sleeping = rock.body.isSleeping();
      if (sleeping && !rock.awake) continue;
      rock.awake = !sleeping;

      const t = rock.body.translation();

      // Safety net: a body that ended up under the ground (a solver escape, or
      // terrain sculpted up from under it) is put back on the surface.
      if (t.y < this.ctx.terrain.heightAt(t.x, t.z) - 1.5) {
        this._resurface(rock);
        continue;
      }
      this._writeMatrix(rock);

      // A moving rock flattens whatever grows under it and shoves it aside.
      const vel = rock.body.linvel();
      const speed = Math.sqrt(vel.x * vel.x + vel.y * vel.y + vel.z * vel.z);
      if (speed > PRESS_MIN_SPEED) {
        this._pressSplat(t.x, t.z, rock.scale * 1.4, vel.x, vel.z, speed);
        pressWrote = true;
      }

      // Small rocks skitter in strong gusts (never wakes a settled rock).
      if (rock.scale < 0.35 && gust > 0.8) {
        const w = this.ctx.wind.sampleAt(t.x, t.z, this.ctx.time);
        const m = rock.body.mass() * 0.02;
        rock.body.applyImpulse({ x: w.x * m, y: 0, z: w.z * m }, false);
      }

      // Rolling resistance: real rocks bed into the ground instead of rolling
      // on forever. Once one has slowed down, damp it hard so it stops where
      // it was painted (Rapier has no rolling friction of its own).
      if (!rock.damped && rock.landed && speed < SETTLE_SPEED) {
        rock.damped = true;
        rock.body.setLinearDamping(4);
        rock.body.setAngularDamping(9);
      }

      if (!rock.landed) {
        const ground = this.ctx.terrain.heightAt(t.x, t.z);
        if (t.y - ground < rock.scale * COLLIDER_RATIO + 0.35) {
          rock.landed = true;
          rock.inWater = this._isWater(t.x, t.z);
          if (rock.inWater) {
            const impact = Math.min(12, Math.abs(vel.y));
            water?.splash?.(t.x, t.z, 0.8 + rock.scale, 0.35 + impact * 0.06);
            rock.body.setLinearDamping(3);
          }
        }
      } else if (rock.inWater && !rock.obstacle && (sleeping || speed < 0.05)) {
        rock.obstacle = true;
        water?.addObstacle?.(t.x, t.z, rock.scale);
      }
    }

    if (pressWrote) {
      const layer = this.pressLayer;
      layer.version++;
      layer.dirtyRect = { x0: 0, y0: 0, x1: layer.res - 1, y1: layer.res - 1 };
    }
  }

  /**
   * @private Relax the whole press layer back toward neutral. Costs nothing
   * once every texel is neutral again.
   * @returns {boolean} whether anything was written
   */
  _decayPress() {
    if (!this._pressActive) return false;
    const data = this.pressLayer.data;
    let active = false;
    for (let i = 0; i < data.length; i += 4) {
      const r = data[i];
      const g = data[i + 1];
      const b = data[i + 2];
      if (b === 0 && r === 128 && g === 128) continue;
      const nr = 128 + (((r - 128) * PRESS_DECAY) | 0);
      const ng = 128 + (((g - 128) * PRESS_DECAY) | 0);
      const nb = (b * PRESS_DECAY) | 0;
      data[i] = nr;
      data[i + 1] = ng;
      data[i + 2] = nb;
      if (nb !== 0 || nr !== 128 || ng !== 128) active = true;
    }
    this._pressActive = active;
    return true;
  }

  /**
   * @private Stamp a push disc into the press layer.
   * @param {number} x world X
   * @param {number} z world Z
   * @param {number} radius world units
   * @param {number} vx world X velocity
   * @param {number} vz world Z velocity
   * @param {number} speed |velocity|
   */
  _pressSplat(x, z, radius, vx, vz, speed) {
    const layer = this.pressLayer;
    const res = layer.res;
    const data = layer.data;
    const u = x / WORLD_SIZE + 0.5;
    const v = z / WORLD_SIZE + 0.5;
    const rt = (radius / WORLD_SIZE) * res;
    if (rt <= 0) return;

    const cx = u * res;
    const cy = v * res;
    let x0 = Math.floor(cx - rt);
    let x1 = Math.ceil(cx + rt);
    let y0 = Math.floor(cy - rt);
    let y1 = Math.ceil(cy + rt);
    x0 = x0 < 0 ? 0 : x0;
    y0 = y0 < 0 ? 0 : y0;
    x1 = x1 > res - 1 ? res - 1 : x1;
    y1 = y1 > res - 1 ? res - 1 : y1;
    if (x1 < x0 || y1 < y0) return;

    // Push direction in layer UV space; a rock falling straight down (no
    // horizontal motion) just presses, without a direction.
    const h = Math.sqrt(vx * vx + vz * vz);
    const dirR = h > 1e-4 ? ((vx / h) * 0.5 + 0.5) * 255 : 128;
    const dirG = h > 1e-4 ? ((vz / h) * 0.5 + 0.5) * 255 : 128;
    const strength = Math.max(0.3, Math.min(1, speed / 3)) * 255;
    const inv = 1 / rt;

    for (let py = y0; py <= y1; py++) {
      const dy = py + 0.5 - cy;
      for (let px = x0; px <= x1; px++) {
        const dx = px + 0.5 - cx;
        const d = Math.sqrt(dx * dx + dy * dy) * inv;
        if (d >= 1) continue;
        const f = 1 - d * d;
        const i = (py * res + px) * 4;
        data[i] += (dirR - data[i]) * f;
        data[i + 1] += (dirG - data[i + 1]) * f;
        const s = strength * f;
        if (s > data[i + 2]) data[i + 2] = s;
      }
    }
    this._pressActive = true;
  }

  /**
   * @private Drop a rock back onto the terrain surface, at rest.
   * @param {object} rock
   */
  _resurface(rock) {
    const t = rock.body.translation();
    const y = this.ctx.terrain.heightAt(t.x, t.z) + rock.scale * COLLIDER_RATIO;
    rock.body.setTranslation({ x: t.x, y, z: t.z }, true);
    rock.body.setLinvel({ x: 0, y: 0, z: 0 }, true);
    rock.body.setAngvel({ x: 0, y: 0, z: 0 }, true);
    rock.awake = true;
    this._writeMatrix(rock);
  }

  /**
   * @private Copy a body's transform into its instance matrix.
   * @param {object} rock
   */
  _writeMatrix(rock) {
    const variant = this.variants[rock.variant];
    const t = rock.body.translation();
    const r = rock.body.rotation();
    _v.set(t.x, t.y, t.z);
    _q.set(r.x, r.y, r.z, r.w);
    _s.setScalar(rock.scale);
    variant.mesh.setMatrixAt(rock.slot, _m.compose(_v, _q, _s));
    variant.mesh.instanceMatrix.needsUpdate = true;
  }

  /**
   * @private Re-sample the grass layer under a rock into its moss attribute.
   * @param {object} rock
   */
  _updateMoss(rock) {
    const t = rock.body.translation();
    const { u, v } = worldToUV(t.x, t.z);
    const grass = this.ctx.layers.get('grass')?.sample(u, v) ?? 0;
    const moss = Math.max(0, Math.min(1, (grass - MOSS_LO) / (MOSS_HI - MOSS_LO)));
    const variant = this.variants[rock.variant];
    variant.moss.setX(rock.slot, moss);
    variant.moss.needsUpdate = true;
  }

  /**
   * @private Is this spot water? Asks the Water element, falls back to the layer.
   * @param {number} x
   * @param {number} z
   * @returns {boolean}
   */
  _isWater(x, z) {
    const water = this.ctx.elements.get('water');
    if (water?.isWater) return Boolean(water.isWater(x, z));
    const { u, v } = worldToUV(x, z);
    return (this.ctx.layers.get('water')?.sample(u, v) ?? 0) > 0.5;
  }

  // --- reactions ----------------------------------------------------------

  /**
   * @param {import('../core/PaintLayers.js').PaintLayer} layer
   */
  onLayerChanged(layer) {
    if (layer.id === 'grass') this._mossDirty = true;
  }

  /** Sculpting moved the ground: rebuild the collider and let rocks re-settle. */
  onTerrainChanged() {
    this.physics?.requestTerrainRebuild();
    for (const rock of this.rocks) {
      rock.body.wakeUp();
      rock.awake = true;
      // Drop the rolling resistance so a rock the ground was raised under can
      // actually slide off it again.
      if (rock.damped) {
        rock.damped = false;
        rock.body.setLinearDamping(rock.inWater ? 3 : 0.4);
        rock.body.setAngularDamping(2.5);
      }
    }
  }

  // --- UI -----------------------------------------------------------------

  /**
   * @param {object} ui ghost-panel handle
   */
  buildPanel(ui) {
    const f = ui.addFolder('Rocks');
    const u = this.material.uniforms;

    f.addSlider('Size min', {
      min: 0.15, max: 1.2, step: 0.05, value: this.params.sizeMin,
      onChange: (v) => {
        this.params.sizeMin = Math.min(v, this.params.sizeMax);
      },
    });
    f.addSlider('Size max', {
      min: 0.2, max: 2.0, step: 0.05, value: this.params.sizeMax,
      onChange: (v) => {
        this.params.sizeMax = Math.max(v, this.params.sizeMin);
      },
    });
    f.addSlider('Spawn rate', {
      min: 0, max: 1, step: 0.01, value: this.params.spawnRate,
      onChange: (v) => {
        this.params.spawnRate = v;
      },
    });
    f.addColor('Rock colour', { value: '#8f8c88', onChange: (hex) => u.uRock.value.set(hex) });
    f.addColor('Sunlit top', { value: '#bfb8ab', onChange: (hex) => u.uWarm.value.set(hex) });
    f.addColor('Shadow side', { value: '#5f7396', onChange: (hex) => u.uCool.value.set(hex) });
    f.addColor('Moss', { value: '#6fa04a', onChange: (hex) => u.uMoss.value.set(hex) });
    f.addSlider('Speckle', {
      min: 0, max: 1, step: 0.01, value: this.params.speckle,
      onChange: (v) => {
        this.params.speckle = v;
        u.uSpeckle.value = v;
      },
    });
    f.addButton('Clear rocks', () => this.ctx.history.wrap('Clear rocks', () => this.clear(), { element: 'rocks' }));
    return f;
  }

  // --- save / load --------------------------------------------------------

  /** @returns {object} params plus every rock's resting transform */
  serialize() {
    const u = this.material.uniforms;
    return {
      ...this.params,
      colors: {
        rock: `#${u.uRock.value.getHexString()}`,
        warm: `#${u.uWarm.value.getHexString()}`,
        cool: `#${u.uCool.value.getHexString()}`,
        moss: `#${u.uMoss.value.getHexString()}`,
      },
      rocks: this.rocks.map((rock) => {
        const t = rock.body.translation();
        const r = rock.body.rotation();
        return {
          x: t.x, y: t.y, z: t.z,
          qx: r.x, qy: r.y, qz: r.z, qw: r.w,
          scale: rock.scale,
          variant: rock.variant,
        };
      }),
    };
  }

  /**
   * @param {object} o output of `serialize()`
   */
  deserialize(o = {}) {
    if (typeof o.sizeMin === 'number') this.params.sizeMin = o.sizeMin;
    if (typeof o.sizeMax === 'number') this.params.sizeMax = o.sizeMax;
    if (typeof o.spawnRate === 'number') this.params.spawnRate = o.spawnRate;
    if (typeof o.speckle === 'number') {
      this.params.speckle = o.speckle;
      this.material.uniforms.uSpeckle.value = o.speckle;
    }
    const u = this.material.uniforms;
    if (o.colors) {
      if (o.colors.rock) u.uRock.value.set(o.colors.rock);
      if (o.colors.warm) u.uWarm.value.set(o.colors.warm);
      if (o.colors.cool) u.uCool.value.set(o.colors.cool);
      if (o.colors.moss) u.uMoss.value.set(o.colors.moss);
    }

    this.clear();
    if (!this.physics?.ready || !Array.isArray(o.rocks)) return;
    for (const r of o.rocks) {
      const vi = this._pickVariant(r.variant);
      if (vi < 0) break;
      _q.set(r.qx ?? 0, r.qy ?? 0, r.qz ?? 0, r.qw ?? 1);
      const body = this._createBody(r.x, r.y, r.z, _q, r.scale ?? 0.5, vi);
      if (body) this._register(body, r.scale ?? 0.5, vi);
    }
  }

  /** Drop meshes, bodies and — when this element created it — the world. */
  dispose() {
    this.clear();
    for (const variant of this.variants) {
      variant.mesh.removeFromParent();
      variant.mesh.geometry.dispose();
    }
    this.variants.length = 0;
    this.root?.removeFromParent();
    this.root = null;
    this.material?.dispose();
    if (this.physics && this.physics.owner === this) {
      this.physics.dispose();
      if (this.ctx.physics === this.physics) this.ctx.physics = null;
    }
    this.physics = null;
  }
}
