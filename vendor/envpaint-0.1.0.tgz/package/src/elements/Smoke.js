import * as THREE from 'three';
import { Element } from '../core/Element.js';
import { WORLD_SIZE } from '../core/constants.js';
import { noiseGLSL } from '../core/shaders/toon.glsl.js';

/** Hard cap on live puffs. */
const MAX_PUFFS = 3000;
/** Value of `params.rate` at which every requested puff is made. */
const RATE_FULL = 5;
/** Fraction of the life over which a puff dissolves. */
const FADE_FRACTION = 0.4;

const _drawSize = new THREE.Vector2();

const vertexShader = /* glsl */ `
#include <fog_pars_vertex>

attribute float aSize;
attribute float aSeed;
attribute float aFade;
attribute vec3 aTint;

uniform float uFrustumHalfHeight;
uniform float uViewportHeight;

varying float vSeed;
varying float vFade;
varying vec3 vTint;

void main() {
  vSeed = aSeed;
  vFade = aFade;
  vTint = aTint;
  vec4 worldPosition = modelMatrix * vec4(position, 1.0);
  vec4 mvPosition = viewMatrix * worldPosition;
  gl_Position = projectionMatrix * mvPosition;
  // Orthographic: pixels per world unit is constant, so derive the sprite size
  // from the current zoom instead of from the view depth.
  gl_PointSize = aSize * (uViewportHeight / (2.0 * uFrustumHalfHeight));
  #include <fog_vertex>
}
`;

const fragmentShader = /* glsl */ `
#include <common>
#include <fog_pars_fragment>
${noiseGLSL}

uniform vec3 uDark;
uniform vec3 uMid;
uniform vec3 uLight;
uniform vec3 uSunColor;
// 0 ghibli, 1 flat, 2 realistic, 3 painterly, 4 pixel. Left out of the
// material's own uniforms so Style.attach() can hand over the shared one.
uniform float uStyleId;

varying float vSeed;
varying float vFade;
varying vec3 vTint;

void main() {
  vec2 p = gl_PointCoord * 2.0 - 1.0;
  p.y = -p.y;

  // Cumulus silhouette: four big overlapping discs. Built as a union of
  // circles rather than a wobbled radius, so every lobe is round and the
  // joins between them can never pinch into a notch.
  float d = 4.0;
  for (int k = 0; k < 4; k++) {
    float fk = float(k);
    float a0 = vSeed * 6.283 + fk * 1.571;
    vec2 c = vec2(cos(a0), sin(a0)) * (0.28 + 0.11 * sin(vSeed * 17.0 + fk * 2.1));
    float r = 0.55 + 0.15 * sin(vSeed * 11.0 + fk * 1.7);
    d = min(d, length(p - c) / r);
  }
  if (d > 1.0) discard;

  float n = vnoise(p * 2.2 + vec2(vSeed * 31.0, vSeed * 17.0));

  // Dissolve into flat chunks over the last part of the life.
  float survive = n * 0.7 + (1.0 - d) * 0.5;
  if (survive < (1.0 - vFade) * 1.2) discard;

  // Flat three-step ramp: light toward the sky side, dark toward the rim.
  float g = dot(normalize(vec2(-0.55, 0.83)), p) * 0.5 + 0.5;
  float f = g * 0.62 + n * 0.5 - d * 0.24;

  // The lit side picks up a little of the sun's warmth.
  vec3 lit = uLight * mix(vec3(1.0), uSunColor, 0.35);
  float mul = f > 0.58 ? 1.8 : (f > 0.30 ? 1.0 : 0.66);
  vec3 col;
  float alpha = 1.0;

  if (uStyleId > 0.5 && uStyleId < 1.5) {
    // Flat: one grey, no shading at all.
    col = uMid;
  } else if (uStyleId > 1.5 && uStyleId < 2.5) {
    // Realistic: smooth grey gradient with a soft alpha falloff at the rim.
    col = mix(uDark, lit, clamp(f * 1.3, 0.0, 1.0));
    alpha = smoothstep(1.0, 0.55, d) * vFade;
  } else if (uStyleId > 2.5 && uStyleId < 3.5) {
    // Painterly: the same three tones, edges bled soft.
    col = mix(uDark, uMid, smoothstep(0.18, 0.42, f));
    col = mix(col, lit, smoothstep(0.46, 0.70, f));
  } else {
    // Ghibli and pixel: three flat tones, hard edges.
    col = uDark;
    if (f > 0.30) col = uMid;
    if (f > 0.58) col = lit;
  }
  if (dot(vTint, vec3(1.0)) > 0.0001) col = vTint * mul;

  gl_FragColor = vec4(col, alpha);
  #include <fog_fragment>
  #include <colorspace_fragment>
}
`;

/**
 * Toon smoke: hard-edged flat-grey blobs that grow, rise and drift downwind.
 * Also the shared "puff" service other elements call (fire, waterfall mist,
 * rain splashes) through `ctx.elements.get('smoke').puff(...)`.
 */
export class Smoke extends Element {
  static id = 'smoke';
  static label = 'Smoke';
  static order = 45;

  /**
   * @param {object} ctx shared app context
   */
  constructor(ctx) {
    super(ctx);

    /** @type {{rate:number, size:number, life:number, dark:string, mid:string, light:string}} */
    this.params = {
      rate: 5,
      size: 1,
      life: 3.5,
      dark: '#8c8fa3',
      mid: '#b0b2c2',
      light: '#dcdde6',
    };

    /** @type {THREE.Points|null} */
    this.points = null;
    /** @type {number} live puff count */
    this.count = 0;

    this._tintCache = new Map();
    this._n = MAX_PUFFS;
    this._px = new Float32Array(MAX_PUFFS);
    this._py = new Float32Array(MAX_PUFFS);
    this._pz = new Float32Array(MAX_PUFFS);
    this._age = new Float32Array(MAX_PUFFS);
    this._life = new Float32Array(MAX_PUFFS);
    this._size0 = new Float32Array(MAX_PUFFS);
    this._size1 = new Float32Array(MAX_PUFFS);
    this._seed = new Float32Array(MAX_PUFFS);
    this._rise = new Float32Array(MAX_PUFFS);
    this._drift = new Float32Array(MAX_PUFFS);
    this._tint = new Float32Array(MAX_PUFFS * 3);
  }

  /**
   * Build the point cloud. Smoke has no brush and no layer: every puff comes
   * from another element calling `puff()`.
   */
  async init() {
    const ctx = this.ctx;
    const geometry = new THREE.BufferGeometry();
    this._aPos = new THREE.BufferAttribute(new Float32Array(MAX_PUFFS * 3), 3);
    this._aSize = new THREE.BufferAttribute(new Float32Array(MAX_PUFFS), 1);
    this._aSeed = new THREE.BufferAttribute(new Float32Array(MAX_PUFFS), 1);
    this._aFade = new THREE.BufferAttribute(new Float32Array(MAX_PUFFS), 1);
    this._aTint = new THREE.BufferAttribute(new Float32Array(MAX_PUFFS * 3), 3);
    for (const a of [this._aPos, this._aSize, this._aSeed, this._aFade, this._aTint]) {
      a.setUsage(THREE.DynamicDrawUsage);
    }
    geometry.setAttribute('position', this._aPos);
    geometry.setAttribute('aSize', this._aSize);
    geometry.setAttribute('aSeed', this._aSeed);
    geometry.setAttribute('aFade', this._aFade);
    geometry.setAttribute('aTint', this._aTint);
    geometry.setDrawRange(0, 0);
    geometry.boundingSphere = new THREE.Sphere(new THREE.Vector3(), WORLD_SIZE);

    const material = new THREE.ShaderMaterial({
      lights: false,
      fog: true,
      transparent: false,
      depthWrite: true,
      // Colour blends by the fragment alpha (the realistic style wants a soft
      // rim) and the framebuffer keeps that alpha, so the ink pass still
      // outlines smoke in the styles that draw it opaque.
      blending: THREE.CustomBlending,
      blendEquation: THREE.AddEquation,
      blendSrc: THREE.SrcAlphaFactor,
      blendDst: THREE.OneMinusSrcAlphaFactor,
      blendEquationAlpha: THREE.AddEquation,
      blendSrcAlpha: THREE.OneFactor,
      blendDstAlpha: THREE.ZeroFactor,
      uniforms: Object.assign(
        THREE.UniformsUtils.merge([THREE.UniformsLib.fog]),
        this.ctx.wind.uniforms,
        this.ctx.sun.uniforms,
        {
          uFrustumHalfHeight: { value: ctx.iso.frustumHalfHeight },
          uViewportHeight: { value: 800 },
          uDark: { value: new THREE.Color(this.params.dark) },
          uMid: { value: new THREE.Color(this.params.mid) },
          uLight: { value: new THREE.Color(this.params.light) },
        },
      ),
      vertexShader,
      fragmentShader,
    });
    material.toneMapped = false;
    material.name = 'Smoke';
    ctx.style?.attach?.(material, { element: 'smoke' });

    this.material = material;
    material.userData.uiProps = this._materialProps();
    material.userData.swatch = [this.params.light, this.params.mid, this.params.dark];
    this.geometry = geometry;
    this.points = new THREE.Points(geometry, material);
    this.points.name = 'smoke';
    this.points.frustumCulled = false;
    this.points.renderOrder = 15;

    /** @type {THREE.Group} everything this element puts in the scene */
    this.root = new THREE.Group();
    this.root.name = 'Smoke';
    this.root.add(this.points);
    ctx.scene.add(this.root);
  }

  /**
   * @private Puff greys and size, for the inspector's Material folder.
   * See "Material descriptors" in ARCHITECTURE.md.
   * @returns {Array<object>}
   */
  _materialProps() {
    const p = this.params;
    const u = this.material.uniforms;
    const swatch = (label, key, uniform, tooltip) => ({
      label,
      kind: 'color',
      tooltip,
      get: () => p[key],
      set: (v) => { p[key] = v; u[uniform].value.set(v); },
    });
    return [
      swatch('Dark', 'dark', 'uDark', 'Shadowed underside of a puff'),
      swatch('Mid', 'mid', 'uMid', 'Body of a puff'),
      swatch('Light', 'light', 'uLight', 'Sunlit top of a puff'),
      {
        label: 'Size', min: 0.2, max: 3, step: 0.05, tooltip: 'Puff size multiplier',
        get: () => p.size, set: (v) => { p.size = v; },
      },
    ];
  }

  /**
   * Spawn one smoke puff.
   * @param {number} x world x
   * @param {number} y world y
   * @param {number} z world z
   * @param {{size?:number, life?:number, color?:string, rise?:number, drift?:number}} [opts]
   * @returns {boolean} false when the pool is full
   */
  puff(x, y, z, opts = {}) {
    if (this.count >= this._n) return false;
    // With the vents gone, `rate` is the world's smoke density: it decides how
    // many of the requested puffs are actually made. RATE_FULL and above keeps
    // every one.
    if (this.params.rate < RATE_FULL && Math.random() >= this.params.rate / RATE_FULL) return false;
    const { size = 1, life = 3, color = null, rise = 0.8, drift = 1 } = opts;
    const i = this.count++;
    const s = size * this.params.size;

    this._px[i] = x;
    this._py[i] = y;
    this._pz[i] = z;
    this._age[i] = 0;
    this._life[i] = Math.max(0.05, life);
    this._size0[i] = 0.6 * s;
    this._size1[i] = 2.4 * s * (0.85 + Math.random() * 0.3);
    this._seed[i] = Math.random();
    this._rise[i] = rise;
    this._drift[i] = drift;

    const o = i * 3;
    if (color) {
      const c = this._color(color);
      this._tint[o] = c.r;
      this._tint[o + 1] = c.g;
      this._tint[o + 2] = c.b;
    } else {
      this._tint[o] = 0;
      this._tint[o + 1] = 0;
      this._tint[o + 2] = 0;
    }
    return true;
  }

  /**
   * @private Cached sRGB hex -> linear THREE.Color.
   * @param {string} hex
   * @returns {THREE.Color}
   */
  _color(hex) {
    let c = this._tintCache.get(hex);
    if (!c) {
      c = new THREE.Color(hex);
      this._tintCache.set(hex, c);
    }
    return c;
  }

  /**
   * @private Move the last live particle into slot `i`.
   * @param {number} i
   */
  _kill(i) {
    const last = --this.count;
    if (i === last) return;
    this._px[i] = this._px[last];
    this._py[i] = this._py[last];
    this._pz[i] = this._pz[last];
    this._age[i] = this._age[last];
    this._life[i] = this._life[last];
    this._size0[i] = this._size0[last];
    this._size1[i] = this._size1[last];
    this._seed[i] = this._seed[last];
    this._rise[i] = this._rise[last];
    this._drift[i] = this._drift[last];
    const a = i * 3;
    const b = last * 3;
    this._tint[a] = this._tint[b];
    this._tint[a + 1] = this._tint[b + 1];
    this._tint[a + 2] = this._tint[b + 2];
  }

  /**
   * @param {number} dt seconds
   * @param {number} time seconds since start
   */
  update(dt, time) {
    if (!this.points) return;
    const ctx = this.ctx;

    ctx.renderer.getDrawingBufferSize(_drawSize);
    this.material.uniforms.uViewportHeight.value = _drawSize.y;
    this.material.uniforms.uFrustumHalfHeight.value = ctx.iso.frustumHalfHeight;

    const wind = ctx.wind;
    const pos = this._aPos.array;
    const sizes = this._aSize.array;
    const seeds = this._aSeed.array;
    const fades = this._aFade.array;
    const tints = this._aTint.array;

    for (let i = this.count - 1; i >= 0; i--) {
      this._age[i] += dt;
      const t = this._age[i] / this._life[i];
      if (t >= 1) {
        this._kill(i);
        continue;
      }
      const seed = this._seed[i];
      const w = wind.sampleAt(this._px[i], this._pz[i], time);
      const drift = this._drift[i] * 1.4;
      const turb = 0.35 * (1 - t);
      this._px[i] += (w.x * drift + Math.sin(time * 1.3 + seed * 39.0) * turb) * dt;
      this._pz[i] += (w.z * drift + Math.cos(time * 1.1 + seed * 27.0) * turb) * dt;
      this._py[i] += this._rise[i] * (1.2 - 0.5 * t) * dt;

      const o = i * 3;
      pos[o] = this._px[i];
      pos[o + 1] = this._py[i];
      pos[o + 2] = this._pz[i];
      sizes[i] = this._size0[i] + (this._size1[i] - this._size0[i]) * Math.pow(t, 0.6);
      seeds[i] = seed;
      fades[i] = t < 1 - FADE_FRACTION ? 1 : Math.max(0, (1 - t) / FADE_FRACTION);
      tints[o] = this._tint[o];
      tints[o + 1] = this._tint[o + 1];
      tints[o + 2] = this._tint[o + 2];
    }

    this.geometry.setDrawRange(0, this.count);
    this._aPos.needsUpdate = true;
    this._aSize.needsUpdate = true;
    this._aSeed.needsUpdate = true;
    this._aFade.needsUpdate = true;
    this._aTint.needsUpdate = true;
  }

  /**
   * Repaint the three puff greys from a style's palette. Writes `params` too,
   * so the Smoke folder, the Material folder and `serialize()` agree.
   * @param {{dark?:string, mid?:string, light?:string}} [p]
   * @returns {Smoke} this, for chaining
   */
  applyPalette(p) {
    if (!p || !this.material) return this;
    const u = this.material.uniforms;
    for (const key of ['dark', 'mid', 'light']) {
      if (p[key] != null) { this.params[key] = p[key]; u[`u${key[0].toUpperCase()}${key.slice(1)}`].value.set(p[key]); }
    }
    this.material.userData.swatch = [this.params.light, this.params.mid, this.params.dark];
    return this;
  }

  /**
   * @param {object} ui ghost-panel root
   */
  buildPanel(ui) {
    const f = ui.addFolder('Smoke');
    const p = this.params;
    f.addSlider('Rate', {
      min: 0, max: RATE_FULL, step: 0.1, value: p.rate,
      onChange: (v) => { p.rate = v; },
    });
    f.addSlider('Size', {
      min: 0.2, max: 3, step: 0.05, value: p.size,
      onChange: (v) => { p.size = v; },
    });
    f.addSlider('Lifetime', {
      min: 0.5, max: 10, step: 0.1, value: p.life,
      onChange: (v) => { p.life = v; },
    });
    f.addColor('Shadow', {
      value: p.dark,
      onChange: (hex) => { p.dark = hex; this.material.uniforms.uDark.value.set(hex); },
    });
    f.addColor('Mid', {
      value: p.mid,
      onChange: (hex) => { p.mid = hex; this.material.uniforms.uMid.value.set(hex); },
    });
    f.addColor('Light', {
      value: p.light,
      onChange: (hex) => { p.light = hex; this.material.uniforms.uLight.value.set(hex); },
    });
  }

  /** @returns {object} panel parameters; puffs are transient, nothing else to save */
  serialize() {
    return { ...this.params };
  }

  /**
   * @param {object} o output of `serialize()`
   */
  deserialize(o = {}) {
    Object.assign(this.params, o);
    if (!this.material) return;
    this.material.uniforms.uDark.value.set(this.params.dark);
    this.material.uniforms.uMid.value.set(this.params.mid);
    this.material.uniforms.uLight.value.set(this.params.light);
  }

  /** Release GPU resources. */
  dispose() {
    if (!this.points) return;
    this.ctx.style?.detach?.(this.material);
    this.ctx.scene.remove(this.root);
    this.root.clear();
    this.geometry.dispose();
    this.material.dispose();
    this.points = null;
    this.root = null;
  }
}
