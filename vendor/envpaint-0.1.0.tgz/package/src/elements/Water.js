import * as THREE from 'three';
import { makeFalloff } from '../core/BrushShape.js';
import { Element } from '../core/Element.js';
import { PaintLayer } from '../core/PaintLayers.js';
import { WORLD_SIZE, HALF, LAYER_RES, worldToUV, uvToWorld } from '../core/constants.js';
import { toonParsVertex, toonShadowVertex, toonParsFragment } from '../core/shaders/toon.glsl.js';
import {
  waterCommonGLSL,
  fullscreenVertex,
  rippleSimFragment,
  dropletVertex,
  dropletFragment,
  foamBlobVertex,
  foamBlobFragment,
  sheetVertex,
  sheetFragment,
  mistPuffVertex,
  mistPuffFragment,
  mistSheetVertex,
  mistSheetFragment,
} from '../core/shaders/water.glsl.js';
import { Waterfall } from './Waterfall.js';

/** Sentinel level meaning "no water here". */
const DRY = -1000;
/** A texel counts as water above this depth. */
const WET_DEPTH = 0.02;
/** Depth at which the derived presence layer saturates. */
const PRESENCE_DEPTH = 0.35;
/** Surface subdivisions per side: one quad per layer texel. */
const SEGMENTS = LAYER_RES - 1;
/** World units per layer texel. */
const TEXEL_WORLD = WORLD_SIZE / LAYER_RES;
/** Ripple simulation resolution. */
const SIM_RES = 256;
/** Simulation substep length, seconds. */
const SIM_STEP = 1 / 60;
/** Substeps per frame at most. */
const SIM_MAX_STEPS = 2;
/** Impacts uploaded per simulation step; extras are dropped. */
const MAX_IMPACTS = 16;
/** Foam-ring obstacles the surface shader can draw. */
const MAX_OBSTACLES = 32;
/** Manual waterfall emitters kept alive at once. */
const MAX_WATERFALLS = 4;
/** Depth of the bowl the waterfall brush carves for its plunge pool. */
const PLUNGE_DEPTH = 0.5;
/** Height of the water in the source pool above the ground at the lip. */
const SOURCE_RISE = 0.15;
/** Volume per second of the spring the waterfall brush leaves at the top. */
const FALL_SPRING_RATE = 0.6;
/** Texels the sculpted cliff face is allowed to run over. */
const CLIFF_TEXELS = 2.5;
/** An auto-detected fall this close to a painted one is the same fall. */
const AUTO_FALL_MERGE = 2.5;
/** Samples down the live preview ribbon while the stroke is dragged. */
const PREVIEW_STEPS = 20;
/** Auto-detected waterfall emitters kept alive at once. */
const MAX_AUTO_FALLS = 6;
/** Rows re-derived per frame during a full pass (4 slices over 512 rows). */
const DERIVE_SLICE = LAYER_RES / 4;
/** Downsample factor of the fall-detection grid (512 / 4 = 128). */
const FALL_STEP = 4;
/** Surface drop that counts as a waterfall. */
const FALL_DROP = 1.2;
/** Shortest gap between fall-detection passes, ms. */
const FALL_INTERVAL_MS = 150;
/** Flood-fill texel budget. */
const FLOOD_CAP = 200000;
/** How far above the seed a basin fill may rise on its own, world units. */
const MAX_BASIN_RISE = 12;
/** Thinnest film of water a river stamp leaves over its own bed. */
const MIN_RIVER_FILM = 0.06;
/** How far under the rim a pond's surface sits, so it never floats above it. */
const POND_RIM_DROP = 0.06;
/** How far from water a fall's base may sit before the emitter is dropped. */
const FALL_WATER_RADIUS = 1.0;
/** Floating leaves drifting on the flow. */
const LEAF_COUNT = 90;
/** Painted flow strength a texel needs before a leaf will spawn on it. */
const LEAF_MIN_FLOW = 0.25;
/** Flow-simulation grid resolution; one cell covers a 4x4 block of texels. */
const FLOW_RES = 128;
/** Texels per flow cell per side. */
const FLOW_BLOCK = LAYER_RES / FLOW_RES;
/** Ground area of one flow cell, world units squared. */
const FLOW_CELL_AREA = (WORLD_SIZE / FLOW_RES) * (WORLD_SIZE / FLOW_RES);
/** Flow simulation substep, seconds. */
const FLOW_STEP = 1 / 30;
/** Substeps per frame at most. */
const FLOW_MAX_STEPS = 2;
/** Pipe conductivity. `K * dt` is clamped to 0.25 to keep the scheme stable. */
const FLOW_K = 12;
/** Largest share of a cell's depth that may leave it in one step. */
const FLOW_MAX_TRANSFER = 0.25;
/** Evaporation, world units of depth per second. */
const FLOW_EVAPORATION = 0.02;
/** Depth change below which a cell is not written back. */
const FLOW_EPSILON = 1e-4;
/**
 * Normal colour blending, but the destination alpha is forced to 0. The PostFX
 * ink pass treats scene alpha as its mask, so particles drawn with this are
 * exempt: droplets and foam blobs must not each get their own outline.
 */
const INK_EXEMPT_BLEND = {
  blending: THREE.CustomBlending,
  blendEquation: THREE.AddEquation,
  blendSrc: THREE.SrcAlphaFactor,
  blendDst: THREE.OneMinusSrcAlphaFactor,
  blendEquationAlpha: THREE.AddEquation,
  blendSrcAlpha: THREE.ZeroFactor,
  blendDstAlpha: THREE.ZeroFactor,
};
/**
 * Panel colour swatches: [label, params key, uniform name, target material].
 * The target defaults to the water surface; 'sheet' and 'mist' address the
 * waterfall materials instead.
 */
const COLOR_CONTROLS = [
  ['Deep', 'deep', 'uDeep'],
  ['Mid', 'mid', 'uMid'],
  ['Shallow', 'shallow', 'uShallow'],
  ['Foam', 'foam', 'uFoam'],
  ['Wet line', 'wet', 'uWet'],
  ['Highlight', 'highlight', 'uHighlight'],
  ['Fall body', 'sheetBody', 'uBody', 'sheet'],
  ['Fall streak', 'sheetStreak', 'uStreak', 'sheet'],
  ['Fall line', 'sheetLine', 'uLine', 'sheet'],
  ['Mist', 'mist', 'uMist', 'mist'],
];

/**
 * Landscape-reactive water: ponds fill basins, rivers run downhill and carve a
 * channel, a sea level floods everything below it, and water going over a cliff
 * renders as a waterfall sheet.
 *
 * The source of truth is the `waterLevel` float layer (absolute surface Y per
 * texel, `DRY` where there is none). The `water` byte layer other elements read
 * is derived from `waterLevel - terrainHeight`.
 */
export class Water extends Element {
  static id = 'water';
  static label = 'Water';
  static order = 20;

  /**
   * @param {object} ctx shared app context
   */
  constructor(ctx) {
    super(ctx);

    /** @type {object} panel-editable parameters */
    this.params = {
      seaLevel: -3,
      pondDepth: 0.8,
      riverDepth: 0.6,
      carvePressure: 0.6,
      riverSurface: 0.15,
      carve: true,
      highlightStyle: 'lines',
      highlightAmount: 0.55,
      flowSpeed: 1.0,
      rippleStrength: 1.0,
      windWaves: 1.0,
      flowSim: false,
      sourceRate: 0.4,
      fallHeight: 3,
      fallWidth: 2.5,
      deep: '#2b6ec2',
      mid: '#3d8fe0',
      shallow: '#79c6f4',
      foam: '#f7ffff',
      wet: '#2a62b0',
      highlight: '#f6fdff',
      sheetBody: '#f2fbff',
      sheetStreak: '#a9d8ff',
      sheetLine: '#5fa8e8',
      mist: '#ffffff',
    };

    /** @type {Waterfall[]} manual emitters, placed with the waterfall tool */
    this.waterfalls = [];
    /** @type {Waterfall[]} emitters auto-detected where water goes over a cliff */
    this.autoFalls = [];
    /** @type {Array<{x:number, z:number, r:number}>} */
    this.obstacles = [];
    /** @type {Array<{x:number, z:number, rate:number}>} river springs */
    this.springs = [];
    /** @type {number} rolling cost of one flow substep, milliseconds */
    this.flowStepMs = 0;

    this._impacts = [];
    this._simAccum = 0;
    this._tmpVec = new THREE.Vector3();
    this._tmpSize = new THREE.Vector2();
    this._panel = null;
    this._leafSeed = 1;
    this._deriveRow = LAYER_RES; // >= LAYER_RES means "no full pass pending"
    this._fallsAt = 0;
    this._fallsDirty = true;
    this._pondLevel = 0;
    this._pondRim = 0;
    this._riverLevel = 0;
    this._isWet = (x, z) => this._isWetAt(x, z);
    this._flowAccum = 0;
    this._flowLevelVersion = -1;
  }

  /** Register layers and tools, build the sim, the surface and the emitters. */
  async init() {
    const ctx = this.ctx;

    /** @type {PaintLayer} absolute water surface height, `DRY` where dry */
    this.levelLayer = ctx.layers.add(
      new PaintLayer('waterLevel', { channels: 1, float: true, initial: DRY, history: false }),
    );
    // The level field is a step function with a DRY sentinel: bilinear filtering
    // would smear -1000 across the shore, so sample it per texel.
    this.levelLayer.texture.minFilter = THREE.NearestFilter;
    this.levelLayer.texture.magFilter = THREE.NearestFilter;

    /** @type {PaintLayer} derived presence 0..1, read by grass/rocks/terrain/… */
    this.layer = ctx.layers.add(new PaintLayer('water', { channels: 1, float: false, initial: 0 }));
    /** @type {PaintLayer} painted flow direction, RG = dir * 0.5 + 0.5 */
    this.flowLayer = ctx.layers.add(new PaintLayer('flow', { channels: 2, float: false, initial: 0.5 }));
    ctx.terrain.setLayerTexture('water', this.layer.texture);

    this._buildSim();
    this._buildSurface();
    this._buildWaterfallMaterials();
    this._buildLeaves();

    this._wfStroke = [];
    this._wfErase = false;
    this._registerTools();

    this._onStrokeStart = (payload) => this._beginStroke(payload);
    this._onStrokeEnd = (payload) => this._finishWaterfallStroke(payload);
    ctx.brush.on('strokestart', this._onStrokeStart);
    ctx.brush.on('strokeend', this._onStrokeEnd);

    this._buildFlow();
    this._deriveRect(0, 0, LAYER_RES - 1, LAYER_RES - 1);
  }

  // --- public API ---------------------------------------------------------

  /**
   * Drop a ripple source into the height field. Safe to call ~60x/s; impacts
   * are accumulated and the first `MAX_IMPACTS` of a step are applied.
   * @param {number} x world x
   * @param {number} z world z
   * @param {number} radius world units
   * @param {number} strength wave amplitude (0.02 rain … 0.25 boulder)
   */
  splash(x, z, radius, strength) {
    if (this._impacts.length >= MAX_IMPACTS) return;
    const { u, v } = worldToUV(x, z);
    if (u < 0 || u > 1 || v < 0 || v > 1) return;
    this._impacts.push({ u, v, r: Math.max(0.002, radius / WORLD_SIZE), s: strength });
  }

  /**
   * Register a solid standing in the water so the surface draws a foam ring
   * around it.
   * @param {number} x world x
   * @param {number} z world z
   * @param {number} r radius in world units
   */
  addObstacle(x, z, r) {
    if (this.obstacles.length >= MAX_OBSTACLES) return;
    this.obstacles.push({ x, z, r });
    this._syncObstacles();
  }

  /**
   * Drop the obstacle nearest to (x, z) within 1.5 world units.
   * @param {number} x world x
   * @param {number} z world z
   */
  removeObstacle(x, z) {
    let best = -1;
    let bestD = 1.5;
    for (let i = 0; i < this.obstacles.length; i++) {
      const o = this.obstacles[i];
      const d = Math.hypot(o.x - x, o.z - z);
      if (d < bestD) {
        bestD = d;
        best = i;
      }
    }
    if (best < 0) return;
    this.obstacles.splice(best, 1);
    this._syncObstacles();
  }

  /**
   * @param {number} x world x
   * @param {number} z world z
   * @returns {boolean} whether water covers this point (presence > 0.5)
   */
  isWater(x, z) {
    const { u, v } = worldToUV(x, z);
    return this.layer.sample(u, v) > 0.5;
  }

  /**
   * @param {number} x world x
   * @param {number} z world z
   * @returns {number} water depth in world units, 0 where dry
   */
  depthAt(x, z) {
    const { u, v } = worldToUV(x, z);
    const level = Math.max(this.levelLayer.sample(u, v), this.params.seaLevel);
    return Math.max(0, level - this.ctx.terrain.heightAt(x, z));
  }

  /**
   * @param {number} x world x
   * @param {number} z world z
   * @returns {number|null} world Y of the water surface, or null where dry
   */
  surfaceHeightAt(x, z) {
    const { u, v } = worldToUV(x, z);
    const level = Math.max(this.levelLayer.sample(u, v), this.params.seaLevel);
    return level - this.ctx.terrain.heightAt(x, z) > WET_DEPTH ? level : null;
  }

  /**
   * Fill the basin containing (x, z). `level` is a *minimum* surface height:
   * when the basin can hold more, the water rises to the point where it would
   * spill out of the valley, so the button fills the valley rather than leaving
   * a puddle in the deepest dent. Every connected texel whose ground is below
   * the final level becomes water at exactly that height.
   * @param {number} x world x
   * @param {number} z world z
   * @param {number} level minimum absolute surface height
   * @returns {number} texels filled
   */
  floodFillAt(x, z, level) {
    const res = LAYER_RES;
    const ground = this.ctx.terrain.heightLayer.data;
    const lvl = this.levelLayer.data;
    const { u, v } = worldToUV(x, z);
    const sx = Math.max(0, Math.min(res - 1, Math.floor(u * res)));
    const sy = Math.max(0, Math.min(res - 1, Math.floor(v * res)));
    const start = sy * res + sx;
    const spill = this._spillLevel(start);
    if (spill > level) level = Math.min(spill, ground[start] + MAX_BASIN_RISE);
    if (ground[start] >= level) return 0;

    const seen = new Uint8Array(res * res);
    const queue = new Int32Array(FLOOD_CAP);
    let head = 0;
    let tail = 0;
    queue[tail++] = start;
    seen[start] = 1;
    let x0 = sx;
    let x1 = sx;
    let y0 = sy;
    let y1 = sy;
    let filled = 0;

    while (head < tail) {
      const i = queue[head++];
      const cy = (i / res) | 0;
      const cx = i - cy * res;
      if (lvl[i] < level) lvl[i] = level;
      filled++;
      if (cx < x0) x0 = cx;
      if (cx > x1) x1 = cx;
      if (cy < y0) y0 = cy;
      if (cy > y1) y1 = cy;

      for (let k = 0; k < 4; k++) {
        const nx = cx + (k === 0 ? -1 : k === 1 ? 1 : 0);
        const ny = cy + (k === 2 ? -1 : k === 3 ? 1 : 0);
        if (nx < 0 || ny < 0 || nx >= res || ny >= res) continue;
        const ni = ny * res + nx;
        if (seen[ni] || ground[ni] >= level) continue;
        if (tail >= FLOOD_CAP) break;
        seen[ni] = 1;
        queue[tail++] = ni;
      }
    }

    this._markDirty(this.levelLayer, x0, y0, x1, y1);
    this._deriveRect(x0, y0, x1, y1);
    return filled;
  }

  /**
   * Pour water into the flow simulation. Rain calls this per drop that lands on
   * ground. A no-op while `params.flowSim` is off, when painted water is meant
   * to stay exactly as painted.
   * @param {number} x world x
   * @param {number} z world z
   * @param {number} amount volume in cubic world units
   * @returns {boolean} whether the volume was accepted
   */
  addVolume(x, z, amount) {
    if (!this.params.flowSim || !(amount > 0)) return false;
    const i = this._flowIndexAt(x, z);
    if (i < 0) return false;
    this._flowD[i] += amount / FLOW_CELL_AREA;
    return true;
  }

  /**
   * Add a spring that keeps pouring water while the flow simulation runs.
   * @param {number} x world x
   * @param {number} z world z
   * @param {number} [rate] volume per second; defaults to `params.sourceRate`
   * @returns {{x:number, z:number, rate:number}|null}
   */
  addSpring(x, z, rate = this.params.sourceRate) {
    if (this._flowIndexAt(x, z) < 0) return null;
    const spring = { x, z, rate };
    this.springs.push(spring);
    this._syncPanel();
    return spring;
  }

  /** Forget every spring. */
  clearSprings() {
    this.springs.length = 0;
    this._syncPanel();
    return this;
  }

  /**
   * @private Highest level the basin around `start` holds before the water
   * would run off the edge of the world (Meyer's priority flood: grow the
   * region from its lowest border cell, tracking the running maximum height).
   * @param {number} start texel index of the seed
   * @returns {number} spill height in world units
   */
  _spillLevel(start) {
    const res = LAYER_RES;
    const ground = this.ctx.terrain.heightLayer.data;
    const seen = new Uint8Array(res * res);
    const heapIdx = new Int32Array(FLOOD_CAP);
    const heapKey = new Float32Array(FLOOD_CAP);
    let size = 0;

    const push = (i, key) => {
      if (size >= FLOOD_CAP) return;
      let c = size++;
      heapIdx[c] = i;
      heapKey[c] = key;
      while (c > 0) {
        const parent = (c - 1) >> 1;
        if (heapKey[parent] <= heapKey[c]) break;
        const ti = heapIdx[parent];
        const tk = heapKey[parent];
        heapIdx[parent] = heapIdx[c];
        heapKey[parent] = heapKey[c];
        heapIdx[c] = ti;
        heapKey[c] = tk;
        c = parent;
      }
    };

    const pop = () => {
      const top = heapIdx[0];
      size--;
      if (size > 0) {
        heapIdx[0] = heapIdx[size];
        heapKey[0] = heapKey[size];
        let c = 0;
        for (;;) {
          const l = c * 2 + 1;
          const r = l + 1;
          let m = c;
          if (l < size && heapKey[l] < heapKey[m]) m = l;
          if (r < size && heapKey[r] < heapKey[m]) m = r;
          if (m === c) break;
          const ti = heapIdx[m];
          const tk = heapKey[m];
          heapIdx[m] = heapIdx[c];
          heapKey[m] = heapKey[c];
          heapIdx[c] = ti;
          heapKey[c] = tk;
          c = m;
        }
      }
      return top;
    };

    const cap = ground[start] + MAX_BASIN_RISE;
    let level = ground[start];
    seen[start] = 1;
    push(start, level);

    while (size > 0) {
      const i = pop();
      const h = ground[i];
      if (h > level) level = h;
      if (level >= cap) return cap;
      const y = (i / res) | 0;
      const x = i - y * res;
      // Reaching the edge of the world means the basin drains off the map.
      if (x === 0 || y === 0 || x === res - 1 || y === res - 1) return level;
      for (let k = 0; k < 4; k++) {
        const nx = x + (k === 0 ? -1 : k === 1 ? 1 : 0);
        const ny = y + (k === 2 ? -1 : k === 3 ? 1 : 0);
        const ni = ny * res + nx;
        if (seen[ni]) continue;
        seen[ni] = 1;
        push(ni, ground[ni]);
      }
    }
    return level;
  }

  /** Remove every drop of water (the sea level is left alone). */
  drainAll() {
    this.levelLayer.clear(DRY);
    if (this._flowD) {
      this._flowD.fill(0);
      this._flowFlux.fill(0);
      this._flowLevelVersion = this.levelLayer.version;
    }
    this._deriveRect(0, 0, LAYER_RES - 1, LAYER_RES - 1);
    return this;
  }

  /**
   * Add a manual waterfall emitter running downhill from (x, z).
   * @param {number} x world x
   * @param {number} z world z
   * @param {{x:number, y:number}|null} [strokeDir] fallback direction on flat ground (y = world z)
   * @returns {Waterfall}
   */
  spawnWaterfall(x, z, strokeDir = null) {
    const n = this.ctx.terrain.normalAt(x, z, this._tmpVec);
    let dx = n.x;
    let dz = n.z;
    const gl = Math.hypot(dx, dz);
    if (n.y > 0.995 || gl < 1e-3) {
      dx = strokeDir ? strokeDir.x : 0;
      dz = strokeDir ? strokeDir.y : 1;
    }
    const l = Math.hypot(dx, dz) || 1;
    const width = Math.max(0.8, this.ctx.brush.settings.radius * 0.7);
    const fall = this._addWaterfall({
      x,
      z,
      dirX: dx / l,
      dirZ: dz / l,
      width,
      fallWidth: width,
      sheet: true,
    });

    // Lay water down the traced path so the surface mesh forms the falling
    // sheet: on a steep slope the level field inherits the slope's gradient.
    const radius = Math.max(0.4, fall.width * 0.5) / WORLD_SIZE;
    for (const point of fall.path) {
      const uv = worldToUV(point.x, point.z);
      this._writeLevelDisc(uv.u, uv.v, radius, 0.55, 'fill', point.y + 0.12, 0.5);
    }
    fall.rebuild();
    return fall;
  }

  /**
   * Remove the manual waterfall emitter nearest to (x, z).
   * @param {number} x world x
   * @param {number} z world z
   * @param {number} radius search radius in world units
   * @returns {boolean} whether one was removed
   */
  removeWaterfallNear(x, z, radius) {
    let best = -1;
    let bestD = radius;
    for (let i = 0; i < this.waterfalls.length; i++) {
      const w = this.waterfalls[i];
      // Either end of the fall counts: the pointer may be at the lip or in
      // the plunge pool.
      const d = Math.min(
        Math.hypot(w.x - x, w.z - z),
        Math.hypot(w.base.x - x, w.base.z - z),
      );
      if (d <= bestD) {
        bestD = d;
        best = i;
      }
    }
    if (best < 0) return false;
    const fall = this.waterfalls[best];

    // A waterfall is its emitter, its spring and the water it laid down.
    if (fall.spring) {
      const i = this.springs.indexOf(fall.spring);
      if (i >= 0) this.springs.splice(i, 1);
    }
    for (const pool of fall.pools) {
      const uv = worldToUV(pool.x, pool.z);
      this._writeLevelDisc(uv.u, uv.v, (pool.r * 1.15) / WORLD_SIZE, 0.6, 'drain', 0);
    }
    if (fall.rim) this.removeObstacle(fall.rim.x, fall.rim.z);

    fall.dispose();
    this.waterfalls.splice(best, 1);
    this._syncPanel();
    return true;
  }

  /** Drain everything and forget the flow field and every manual emitter. */
  clearWater() {
    this.drainAll();
    this.flowLayer.clear(0.5);
    while (this.waterfalls.length) this.waterfalls.pop().dispose();
    this.obstacles.length = 0;
    this.springs.length = 0;
    this._syncObstacles();
    this._syncPanel();
    return this;
  }

  /**
   * @param {number} v absolute sea level in world units
   */
  setSeaLevel(v) {
    this.params.seaLevel = v;
    this.surface.material.uniforms.uSeaLevel.value = v;
    this._queueFullDerive();
    return this;
  }

  // --- element hooks ------------------------------------------------------

  /**
   * @param {object} ui ghost-panel root
   */
  buildPanel(ui) {
    const f = ui.addFolder('Water');
    const u = this.surface.material.uniforms;

    f.addSlider('Sea level', {
      min: -6,
      max: 8,
      step: 0.05,
      value: this.params.seaLevel,
      onChange: (v) => this.setSeaLevel(v),
    });
    f.addSlider('Pond depth', {
      min: 0.2,
      max: 4,
      step: 0.05,
      value: this.params.pondDepth,
      onChange: (v) => {
        this.params.pondDepth = v;
      },
    });
    f.addSlider('River depth', {
      min: 0,
      max: 2,
      step: 0.05,
      value: this.params.riverDepth,
      onChange: (v) => {
        this.params.riverDepth = v;
      },
    });
    f.addSlider('River surface', {
      min: 0,
      max: 1,
      step: 0.01,
      value: this.params.riverSurface,
      onChange: (v) => {
        this.params.riverSurface = v;
      },
    });
    f.addSlider('Carve pressure', {
      min: 0.1,
      max: 1.5,
      step: 0.01,
      value: this.params.carvePressure,
      onChange: (v) => {
        this.params.carvePressure = v;
      },
    });
    f.addCheckbox('Carve rivers', {
      value: this.params.carve,
      onChange: (v) => {
        this.params.carve = !!v;
      },
    });

    f.addCheckbox('Flow simulation', {
      value: this.params.flowSim,
      onChange: (v) => {
        this.params.flowSim = !!v;
        if (this.params.flowSim) this._flowLevelVersion = -1;
      },
    });
    f.addSlider('Source rate', {
      min: 0,
      max: 2,
      step: 0.01,
      value: this.params.sourceRate,
      onChange: (v) => {
        this.params.sourceRate = v;
      },
    });
    f.addSlider('Fall height', {
      min: 0.5,
      max: 12,
      step: 0.1,
      value: this.params.fallHeight,
      onChange: (v) => {
        this.params.fallHeight = v;
      },
    });
    f.addSlider('Fall width', {
      min: 0.4,
      max: 8,
      step: 0.1,
      value: this.params.fallWidth,
      onChange: (v) => {
        this.params.fallWidth = v;
      },
    });

    f.addSelect('Highlights', {
      options: [
        { value: 'lines', label: 'Wave lines' },
        { value: 'cells', label: 'Cell web' },
      ],
      value: this.params.highlightStyle,
      onChange: (v) => {
        this.params.highlightStyle = v === 'cells' ? 'cells' : 'lines';
        u.uHighlightStyle.value = this.params.highlightStyle === 'cells' ? 1 : 0;
      },
    });
    f.addSlider('Highlight amount', {
      min: 0,
      max: 1,
      step: 0.01,
      value: this.params.highlightAmount,
      onChange: (v) => {
        this.params.highlightAmount = v;
        u.uHighlightAmount.value = v;
      },
    });
    f.addSlider('Flow speed', {
      min: 0,
      max: 3,
      step: 0.01,
      value: this.params.flowSpeed,
      onChange: (v) => {
        this.params.flowSpeed = v;
        u.uFlowSpeed.value = v;
      },
    });
    f.addSlider('Ripple strength', {
      min: 0,
      max: 2,
      step: 0.01,
      value: this.params.rippleStrength,
      onChange: (v) => {
        this.params.rippleStrength = v;
        u.uRippleStrength.value = v;
      },
    });
    f.addSlider('Wind waves', {
      min: 0,
      max: 2,
      step: 0.01,
      value: this.params.windWaves,
      onChange: (v) => {
        this.params.windWaves = v;
        this._simMaterial.uniforms.uWindWaves.value = v;
      },
    });

    for (const [label, key] of COLOR_CONTROLS) {
      f.addColor(label, {
        id: `water-${key}`,
        value: this.params[key],
        onChange: (hex) => this.setColor(key, hex),
      });
    }

    f.addInfo(this._waterfallInfo(), 'water-waterfalls');
    f.addButtonRow([
      { label: 'Flood fill basin', onClick: () => this._floodFillAtCursor() },
      { label: 'Raise sea to cursor', onClick: () => this._seaToCursor() },
      { label: 'Drain all', onClick: () => this._undoable('Drain all', () => this.drainAll()) },
    ]);
    f.addButton('Clear springs', () => this._undoable('Clear springs', () => this.clearSprings()));
    f.addButton('Clear water', () => this._undoable('Clear water', () => this.clearWater()));
    this._panel = f;
  }

  /**
   * @param {number} dt seconds
   * @param {number} time seconds since start
   */
  update(dt, time) {
    this._processFullDerive();
    // The throttle can swallow the last detection of a stroke, so give any
    // pending one a chance every frame.
    this._maybeDetectFalls();
    this._stepFlow(dt);
    this._stepRipples(dt);
    this._updatePointScale();
    this._updateLeaves(dt);

    for (const w of this.waterfalls) w.update(dt, time, this);
    for (const w of this.autoFalls) w.update(dt, time, this);
  }

  /** Reconform the sheet and every emitter to the new ground. */
  onTerrainChanged() {
    this._applyGround();
    this._flowRebuildGround();
    this._queueFullDerive();
    for (const w of this.waterfalls) w.rebuild();
  }

  /**
   * Adopt a style's water colours. Only the keys present are written.
   * @param {{deep?:string, mid?:string, shallow?:string, foam?:string, wet?:string, highlight?:string}} [p]
   * @returns {this}
   */
  applyPalette(p) {
    if (!p || !this.surface) return this;
    for (const [, key] of COLOR_CONTROLS) {
      if (p[key] != null) this.setColor(key, p[key]);
    }
    return this;
  }

  /**
   * Set one water colour everywhere it is read: params, shader uniform and the
   * panel swatch. The Materials palette and the Water folder both go through it.
   * @param {'deep'|'mid'|'shallow'|'foam'|'wet'|'highlight'} key
   * @param {string} hex sRGB hex string
   * @returns {this}
   */
  setColor(key, hex) {
    const entry = COLOR_CONTROLS.find((c) => c[1] === key);
    if (!entry || !this.surface) return this;
    this.params[key] = hex;
    for (const uniform of this._colorUniforms(entry)) uniform.value.set(hex);

    // The Materials palette chips: deep / mid / foam for the surface, and the
    // three sheet inks for the fall.
    this.surface.material.userData.swatch = [this.params.deep, this.params.mid, this.params.foam];
    const sheet = this._wfMaterials?.sheet;
    if (sheet) {
      sheet.userData.swatch = [this.params.sheetBody, this.params.sheetStreak, this.params.sheetLine];
    }
    this._syncPanelColors();
    return this;
  }

  /**
   * @private Every uniform one colour control drives. Sheet and mist colours
   * live on the waterfall materials, which may not exist yet during `init()`.
   * @param {Array} entry a COLOR_CONTROLS row
   * @returns {Array<{value: THREE.Color}>}
   */
  _colorUniforms(entry) {
    const [, , name, target] = entry;
    const mats = this._wfMaterials;
    if (target === 'sheet') {
      if (!mats?.sheet) return [];
      const out = [mats.sheet.uniforms[name]];
      // The curling lip, and the sheet the surface mesh forms where the level
      // field goes over an edge, are the same lighter blue as the streaks.
      if (name === 'uStreak') {
        out.push(mats.sheet.uniforms.uLipColor, this.surface.material.uniforms.uSheetBase);
      }
      return out;
    }
    if (target === 'mist') {
      if (!mats?.mistPuff) return [];
      return [mats.mistPuff.uniforms[name], mats.mistSheet.uniforms[name]];
    }
    return [this.surface.material.uniforms[name]];
  }

  /**
   * @private Descriptors for ghost-panel's Materials palette, wired to the same
   * params the Water folder and the style palettes use.
   * @returns {Array<object>}
   */
  _buildUiProps() {
    // The surface mesh is assigned after this runs, so dereference it lazily.
    const uni = () => this.surface.material.uniforms;
    const props = COLOR_CONTROLS.filter((c) => !c[3]).map(([label, key]) => ({
      label,
      kind: 'color',
      get: () => this.params[key],
      set: (v) => this.setColor(key, v),
    }));
    props.push({
      label: 'Highlight amount',
      kind: 'number',
      min: 0,
      max: 1,
      step: 0.01,
      get: () => this.params.highlightAmount,
      set: (v) => {
        this.params.highlightAmount = v;
        uni().uHighlightAmount.value = v;
      },
    });
    props.push({
      label: 'Highlight style',
      kind: 'select',
      options: [
        { value: 'lines', label: 'Wave lines' },
        { value: 'cells', label: 'Cell web' },
      ],
      get: () => this.params.highlightStyle,
      set: (v) => {
        this.params.highlightStyle = v === 'cells' ? 'cells' : 'lines';
        uni().uHighlightStyle.value = this.params.highlightStyle === 'cells' ? 1 : 0;
      },
    });
    props.push({
      label: 'Flow speed',
      kind: 'number',
      min: 0,
      max: 3,
      step: 0.01,
      get: () => this.params.flowSpeed,
      set: (v) => {
        this.params.flowSpeed = v;
        uni().uFlowSpeed.value = v;
      },
    });
    props.push({
      label: 'Wind waves',
      kind: 'number',
      min: 0,
      max: 2,
      step: 0.01,
      get: () => this.params.windWaves,
      set: (v) => {
        this.params.windWaves = v;
        this._simMaterial.uniforms.uWindWaves.value = v;
      },
    });
    return props;
  }

  /** @returns {object} panel params plus every manual emitter */
  serialize() {
    return {
      ...this.params,
      springs: this.springs.map((sp) => ({ x: sp.x, z: sp.z, rate: sp.rate })),
      waterfalls: this.waterfalls.map((w) => w.serialize()),
    };
  }

  /**
   * @param {object} o output of `serialize()`
   */
  deserialize(o = {}) {
    const u = this.surface.material.uniforms;
    if (o.highlightStyle) this.params.highlightStyle = o.highlightStyle === 'cells' ? 'cells' : 'lines';
    for (const key of [
      'seaLevel',
      'pondDepth',
      'riverDepth',
      'riverSurface',
      'highlightAmount',
      'flowSpeed',
      'rippleStrength',
      'windWaves',
      'sourceRate',
      'carvePressure',
      'fallHeight',
      'fallWidth',
    ]) {
      if (typeof o[key] === 'number') this.params[key] = o[key];
    }
    if (typeof o.carve === 'boolean') this.params.carve = o.carve;
    if (typeof o.flowSim === 'boolean') this.params.flowSim = o.flowSim;
    this.springs = (o.springs || []).map((sp) => ({ x: sp.x, z: sp.z, rate: sp.rate ?? this.params.sourceRate }));
    for (const [, key] of COLOR_CONTROLS) {
      if (typeof o[key] === 'string') this.params[key] = o[key];
    }
    u.uHighlightStyle.value = this.params.highlightStyle === 'cells' ? 1 : 0;
    u.uHighlightAmount.value = this.params.highlightAmount;
    u.uFlowSpeed.value = this.params.flowSpeed;
    u.uRippleStrength.value = this.params.rippleStrength;
    u.uSeaLevel.value = this.params.seaLevel;
    this._simMaterial.uniforms.uWindWaves.value = this.params.windWaves;
    for (const [, key] of COLOR_CONTROLS) this.setColor(key, this.params[key]);
    this._syncPanelColors();

    while (this.waterfalls.length) this.waterfalls.pop().dispose();
    for (const w of o.waterfalls || []) {
      const fall = this._addWaterfall(w);
      fall.pools = (w.pools || []).map((pool) => ({ ...pool }));
      fall.rim = w.rim ? { ...w.rim } : null;
      // Re-link the spring this fall owns, which `springs` above restored.
      fall.spring =
        (w.spring &&
          this.springs.find(
            (sp) => Math.abs(sp.x - w.spring.x) < 1e-3 && Math.abs(sp.z - w.spring.z) < 1e-3,
          )) ||
        null;
    }
    this._queueFullDerive();
    this._syncPanel();
  }

  /**
   * History snapshot. `waterLevel` opts out of the per-layer shadow because the
   * flow simulation rewrites it every frame, so the field travels here instead
   * and pond/river strokes still undo.
   * @returns {object}
   */
  captureHistory() {
    return {
      ...this.serialize(),
      level: Float32Array.from(this.levelLayer.data),
    };
  }

  /**
   * @param {object} state output of `captureHistory()`
   */
  restoreHistory(state) {
    if (!state) return;
    this.deserialize(state);
    if (state.level && state.level.length === this.levelLayer.data.length) {
      this.levelLayer.data.set(state.level);
      this._markDirty(this.levelLayer, 0, 0, LAYER_RES - 1, LAYER_RES - 1);
      this._flowLevelVersion = -1;
      this._queueFullDerive();
    }
  }

  dispose() {
    this.ctx.brush.off('strokestart', this._onStrokeStart);
    this.ctx.brush.off('strokeend', this._onStrokeEnd);
    while (this.waterfalls.length) this.waterfalls.pop().dispose();
    while (this.autoFalls.length) this.autoFalls.pop().dispose();

    this.ctx.style?.detach?.(this.surface.material);
    this.ctx.style?.detach?.(this._wfMaterials.sheet);
    this.ctx.style?.detach?.(this._wfMaterials.mistPuff);
    if (this.preview) {
      this.preview.geometry.dispose();
      this.preview = null;
    }
    this.surface.geometry.dispose();
    this.surface.material.dispose();
    this.leaves.geometry.dispose();
    this._leafMaterial.dispose();
    for (const m of Object.values(this._wfMaterials)) m.dispose();
    this.ctx.scene.remove(this.root);

    this._simScene.children[0].geometry.dispose();
    this._simMaterial.dispose();
    this._rtA.dispose();
    this._rtB.dispose();
  }

  // --- level field --------------------------------------------------------

  /**
   * @private Write a disc of the level field and derive presence for it in the
   * same call, so a drag shows water appearing under the cursor immediately.
   * @param {number} u
   * @param {number} v
   * @param {number} radius UV radius
   * @param {number} hardness
   * @param {'fill'|'drain'} op
   * @param {number} level absolute surface height for 'fill'
   * @param {number} [maxDepth=Infinity] cap the water depth per texel, so a
   *   flowing body hugs the ground on a slope instead of hanging in the air as
   *   a block of water where the terrain falls away inside the brush
   * @param {object} [shape] the brush op carrying edge-shape settings
   *   (edgeNoise, edgeScale, spatter, aspect, seed, dir); omitted = clean disc
   */
  _writeLevelDisc(u, v, radius, hardness, op, level, maxDepth = Infinity, shape = null) {
    const res = LAYER_RES;
    const data = this.levelLayer.data;
    const ground = this.ctx.terrain.heightLayer.data;
    const fall = makeFalloff({ ...(shape || {}), radius, hardness });
    const rt = fall.bound * res;
    const cx = u * res;
    const cy = v * res;
    const x0 = Math.max(0, Math.floor(cx - rt));
    const x1 = Math.min(res - 1, Math.ceil(cx + rt));
    const y0 = Math.max(0, Math.floor(cy - rt));
    const y1 = Math.min(res - 1, Math.ceil(cy + rt));
    if (x1 < x0 || y1 < y0) return;

    for (let y = y0; y <= y1; y++) {
      const dv = (y + 0.5) / res - v;
      for (let x = x0; x <= x1; x++) {
        const du = (x + 0.5) / res - u;
        // Same falloff as PaintLayer.stamp; the level write itself is binary.
        const f = fall.f(du, dv, x, y);
        if (f <= 0.05) continue;
        const i = y * res + x;
        if (op === 'drain') {
          data[i] = DRY;
          continue;
        }
        // Taper the depth toward the disc's edge so overlapping dabs blend into
        // a channel instead of a chain of flat-topped beads.
        const cap = ground[i] + maxDepth * (0.35 + 0.65 * f);
        const target = level < cap ? level : cap;
        if (data[i] < target) data[i] = target;
      }
    }

    this._markDirty(this.levelLayer, x0, y0, x1, y1);
    this._deriveRect(x0, y0, x1, y1);
  }

  /**
   * @private Freeze the ground a carving stroke measures its cut against, so
   * overlapping dabs cannot ratchet the reference down as they go.
   */
  _snapshotCarve() {
    const height = this.ctx.terrain.heightLayer.data;
    if (!this._carveFrom || this._carveFrom.length !== height.length) {
      this._carveFrom = new Float32Array(height.length);
    }
    this._carveFrom.set(height);
  }

  /**
   * @private Mean terrain height on a ring around a point: the banks a river
   * channel is cut relative to.
   * @param {number} x world x
   * @param {number} z world z
   * @param {number} r ring radius in world units
   * @param {{x:number, y:number}} [dir] stroke direction; when given the banks
   *   are sampled across the stroke only, where the neighbouring dabs of the
   *   same stroke have not already cut the ground away
   * @returns {number}
   */
  _bankHeight(x, z, r, dir) {
    const terrain = this.ctx.terrain;
    let sum = 0;
    if (dir) {
      const px = -dir.y;
      const pz = dir.x;
      for (const d of [r, -r, r * 1.4, -r * 1.4]) {
        sum += terrain.heightAt(x + px * d, z + pz * d);
      }
      return sum / 4;
    }
    for (let i = 0; i < 8; i++) {
      const a = (i / 8) * Math.PI * 2;
      sum += terrain.heightAt(x + Math.cos(a) * r, z + Math.sin(a) * r);
    }
    return sum / 8;
  }

  /**
   * @private Cut a channel into the height layer, lowering only. A 'flatten'
   * stamp would raise the ground wherever it sits below the bed, and the river
   * would build itself an embankment as the stroke ran downhill.
   * @param {number} u
   * @param {number} v
   * @param {number} radius UV radius
   * @param {number} hardness
   * @param {number} bed absolute bed height to cut down to
   * @param {number} pressure blend toward the bed per stamp, 0..1
   * @param {number} maxCut deepest a texel may be cut below its own height
   * @param {number} [rim] when given, the bed is a bowl: the full depth at the
   *   centre easing back up to `rim` at the edge of the disc
   * @param {object} [shape] the brush op carrying edge-shape settings; omitted
   *   = clean disc
   */
  _carveDisc(u, v, radius, hardness, bed, pressure, maxCut, rim, shape = null) {
    const res = LAYER_RES;
    const height = this.ctx.terrain.heightLayer;
    const data = height.data;
    const fall = makeFalloff({ ...(shape || {}), radius, hardness });
    const rt = fall.bound * res;
    const cx = u * res;
    const cy = v * res;
    const x0 = Math.max(0, Math.floor(cx - rt));
    const x1 = Math.min(res - 1, Math.ceil(cx + rt));
    const y0 = Math.max(0, Math.floor(cy - rt));
    const y1 = Math.min(res - 1, Math.ceil(cy + rt));
    if (x1 < x0 || y1 < y0) return;

    for (let y = y0; y <= y1; y++) {
      const dv = (y + 0.5) / res - v;
      for (let x = x0; x <= x1; x++) {
        const du = (x + 0.5) / res - u;
        const f = fall.f(du, dv, x, y);
        if (f <= 0.02) continue;
        const i = y * res + x;
        // A texel is never cut more than one river-depth below where it stood at
        // the start of the stroke, so crossing a ridge notches it instead of
        // trenching through it.
        const from = this._carveFrom ? this._carveFrom[i] : data[i];
        const localBed = rim === undefined ? bed : rim - (rim - bed) * f;
        const target = Math.max(localBed, from - maxCut);
        if (data[i] <= target) continue;
        data[i] += (target - data[i]) * pressure * f;
      }
    }
    this._markDirty(height, x0, y0, x1, y1);
  }

  /**
   * @private Recompute the derived presence layer over a texel rect.
   * @param {number} x0
   * @param {number} y0
   * @param {number} x1
   * @param {number} y1
   */
  _deriveRect(x0, y0, x1, y1) {
    const res = LAYER_RES;
    const lvl = this.levelLayer.data;
    const ground = this.ctx.terrain.heightLayer.data;
    const presence = this.layer.data;
    const sea = this.params.seaLevel;

    for (let y = y0; y <= y1; y++) {
      const row = y * res;
      for (let x = x0; x <= x1; x++) {
        const i = row + x;
        const level = lvl[i] > sea ? lvl[i] : sea;
        const depth = level - ground[i];
        const p = depth <= 0 ? 0 : depth >= PRESENCE_DEPTH ? 1 : depth / PRESENCE_DEPTH;
        presence[i] = (p * 255) | 0;
      }
    }
    this._markDirty(this.layer, x0, y0, x1, y1);
    this._fallsDirty = true;
    this._maybeDetectFalls();
  }

  /** @private Re-derive the whole layer over the next four frames. */
  _queueFullDerive() {
    this._deriveRow = 0;
  }

  /** @private One slice of a queued full re-derive. */
  _processFullDerive() {
    if (this._deriveRow >= LAYER_RES) return;
    const y0 = this._deriveRow;
    const y1 = Math.min(LAYER_RES - 1, y0 + DERIVE_SLICE - 1);
    this._deriveRect(0, y0, LAYER_RES - 1, y1);
    this._deriveRow = y1 + 1;
  }

  /**
   * @private Bump a layer's version and dirty rect after a direct data write.
   * @param {PaintLayer} layer
   * @param {number} x0
   * @param {number} y0
   * @param {number} x1
   * @param {number} y1
   */
  _markDirty(layer, x0, y0, x1, y1) {
    if (layer.markDirtyRect) {
      layer.markDirtyRect(x0, y0, x1, y1);
      return;
    }
    layer.version++;
    const r = layer.dirtyRect;
    if (!r) {
      layer.dirtyRect = { x0, y0, x1, y1 };
      return;
    }
    if (x0 < r.x0) r.x0 = x0;
    if (y0 < r.y0) r.y0 = y0;
    if (x1 > r.x1) r.x1 = x1;
    if (y1 > r.y1) r.y1 = y1;
  }

  // --- auto waterfall detection -------------------------------------------

  /** @private Throttled so even a fast drag refreshes emitters ~7x/s. */
  _maybeDetectFalls() {
    const now = typeof performance !== 'undefined' ? performance.now() : Date.now();
    if (!this._fallsDirty || now - this._fallsAt < FALL_INTERVAL_MS) return;
    this._fallsAt = now;
    this._fallsDirty = false;
    this._syncAutoFalls(this._detectFalls());
  }

  /**
   * @private Scan a 128² downsample for cells whose surface drops by
   * `FALL_DROP` into a neighbour, and group the adjacent ones.
   * @returns {Array<{x:number, z:number, dirX:number, dirZ:number, size:number}>}
   */
  _detectFalls() {
    const res = LAYER_RES;
    const n = res / FALL_STEP;
    const lvl = this.levelLayer.data;
    const ground = this.ctx.terrain.heightLayer.data;
    const sea = this.params.seaLevel;

    const surf = new Float32Array(n * n);
    const wet = new Uint8Array(n * n);
    // Reduce each 4x4 block rather than point-sampling it, so a river only a
    // few texels wide is never missed.
    for (let gy = 0; gy < n; gy++) {
      for (let gx = 0; gx < n; gx++) {
        let top = -Infinity;
        let low = Infinity;
        let anyWet = false;
        for (let oy = 0; oy < FALL_STEP; oy++) {
          const row = (gy * FALL_STEP + oy) * res + gx * FALL_STEP;
          for (let ox = 0; ox < FALL_STEP; ox++) {
            const i = row + ox;
            const g = ground[i];
            if (g < low) low = g;
            const level = lvl[i] > sea ? lvl[i] : sea;
            if (level - g > WET_DEPTH) {
              anyWet = true;
              if (level > top) top = level;
            }
          }
        }
        wet[gy * n + gx] = anyWet ? 1 : 0;
        surf[gy * n + gx] = anyWet ? top : low;
      }
    }

    const fall = new Uint8Array(n * n);
    const fx = new Float32Array(n * n);
    const fz = new Float32Array(n * n);
    for (let gy = 0; gy < n; gy++) {
      for (let gx = 0; gx < n; gx++) {
        const i = gy * n + gx;
        if (!wet[i]) continue;
        let bx = 0;
        let bz = 0;
        let drop = FALL_DROP;
        for (let k = 0; k < 4; k++) {
          const nx = gx + (k === 0 ? -1 : k === 1 ? 1 : 0);
          const ny = gy + (k === 2 ? -1 : k === 3 ? 1 : 0);
          if (nx < 0 || ny < 0 || nx >= n || ny >= n) continue;
          const d = surf[i] - surf[ny * n + nx];
          if (d >= drop) {
            drop = d;
            bx = nx - gx;
            bz = ny - gy;
          }
        }
        if (bx !== 0 || bz !== 0) {
          fall[i] = 1;
          fx[i] = bx;
          fz[i] = bz;
        }
      }
    }

    // Group adjacent fall cells (8-connected) and keep the biggest.
    const seen = new Uint8Array(n * n);
    const stack = [];
    const groups = [];
    for (let i = 0; i < n * n; i++) {
      if (!fall[i] || seen[i]) continue;
      seen[i] = 1;
      stack.length = 0;
      stack.push(i);
      let sx = 0;
      let sy = 0;
      let sdx = 0;
      let sdz = 0;
      let size = 0;
      while (stack.length) {
        const c = stack.pop();
        const cy = (c / n) | 0;
        const cx = c - cy * n;
        sx += cx;
        sy += cy;
        sdx += fx[c];
        sdz += fz[c];
        size++;
        for (let oy = -1; oy <= 1; oy++) {
          for (let ox = -1; ox <= 1; ox++) {
            const nx = cx + ox;
            const ny = cy + oy;
            if (nx < 0 || ny < 0 || nx >= n || ny >= n) continue;
            const ni = ny * n + nx;
            if (!fall[ni] || seen[ni]) continue;
            seen[ni] = 1;
            stack.push(ni);
          }
        }
      }
      const l = Math.hypot(sdx, sdz) || 1;
      const { x, z } = uvToWorld((sx / size + 0.5) / n, (sy / size + 0.5) / n);
      groups.push({ x, z, dirX: sdx / l, dirZ: sdz / l, size });
    }

    groups.sort((a, b) => b.size - a.size);
    return groups.slice(0, MAX_AUTO_FALLS);
  }

  /**
   * @private Keep emitters whose group is still there, drop the rest, add new.
   * @param {Array<{x:number, z:number, dirX:number, dirZ:number}>} groups
   */
  _syncAutoFalls(groups) {
    const keep = new Set();
    for (const g of groups) {
      // A painted fall already draws its own sheet, mist and spray there; the
      // step it cut into the level field must not raise a second emitter.
      const painted = this.waterfalls.some(
        (w) =>
          Math.hypot(w.x - g.x, w.z - g.z) < AUTO_FALL_MERGE ||
          Math.hypot(w.base.x - g.x, w.base.z - g.z) < AUTO_FALL_MERGE,
      );
      if (painted) continue;
      const match = this.autoFalls.find(
        (w) => !keep.has(w) && Math.hypot(w.x - g.x, w.z - g.z) < 1.5,
      );
      if (match) {
        keep.add(match);
        continue;
      }
      const added = this._addAutoFall(g);
      if (added) keep.add(added);
    }
    for (let i = this.autoFalls.length - 1; i >= 0; i--) {
      const w = this.autoFalls[i];
      if (keep.has(w) && this._waterNear(w.base.x, w.base.z, FALL_WATER_RADIUS)) continue;
      w.dispose();
      this.autoFalls.splice(i, 1);
    }
    this._syncPanel();
  }

  /**
   * @private
   * @param {{x:number, z:number, dirX:number, dirZ:number}} g
   * @returns {Waterfall}
   */
  _addAutoFall(g) {
    const fall = new Waterfall(
      this.ctx,
      {
        x: g.x,
        z: g.z,
        dirX: g.dirX,
        dirZ: g.dirZ,
        width: 1.4,
        droplets: 140,
        isWet: this._isWet,
      },
      this._wfMaterials,
    );
    // Spray and foam belong at a real fall base. A group whose base ended up on
    // dry ground was a false positive of the 128-grid scan.
    if (!this._waterNear(fall.base.x, fall.base.z, FALL_WATER_RADIUS)) {
      fall.dispose();
      return null;
    }
    this._wfGroup.add(fall.group);
    this.autoFalls.push(fall);
    return fall;
  }

  /**
   * @private
   * @param {number} x world x
   * @param {number} z world z
   * @returns {boolean} whether painted water covers this exact point
   */
  _isWetAt(x, z) {
    const u = x / WORLD_SIZE + 0.5;
    const v = z / WORLD_SIZE + 0.5;
    if (u < 0 || u > 1 || v < 0 || v > 1) return false;
    return this.layer.sample(u, v) > 0.5;
  }

  /**
   * @private Is there water within `r` of (x, z)? Centre plus an eight-point
   * ring, which is enough for a metre-scale test on a 512 grid.
   * @param {number} x world x
   * @param {number} z world z
   * @param {number} r radius in world units
   * @returns {boolean}
   */
  _waterNear(x, z, r) {
    if (this._isWetAt(x, z)) return true;
    for (let i = 0; i < 8; i++) {
      const a = (i / 8) * Math.PI * 2;
      if (this._isWetAt(x + Math.cos(a) * r, z + Math.sin(a) * r)) return true;
    }
    return false;
  }

  // --- flow simulation ----------------------------------------------------

  /** @private Allocate the virtual-pipes grid. */
  _buildFlow() {
    const n = FLOW_RES * FLOW_RES;
    /** @private @type {Float32Array} mean terrain height per cell */
    this._flowG = new Float32Array(n);
    /** @private @type {Float32Array} water depth per cell */
    this._flowD = new Float32Array(n);
    /** @private @type {Float32Array} depth at the start of the step */
    this._flowPrev = new Float32Array(n);
    /** @private @type {Float32Array} outflow per cell per direction: L,R,U,D */
    this._flowFlux = new Float32Array(n * 4);
    this._flowRebuildGround();
  }

  /** @private Mean terrain height of every 4x4 block. */
  _flowRebuildGround() {
    if (!this._flowG) return;
    const ground = this.ctx.terrain.heightLayer.data;
    const g = this._flowG;
    for (let cy = 0; cy < FLOW_RES; cy++) {
      for (let cx = 0; cx < FLOW_RES; cx++) {
        let sum = 0;
        for (let oy = 0; oy < FLOW_BLOCK; oy++) {
          const row = (cy * FLOW_BLOCK + oy) * LAYER_RES + cx * FLOW_BLOCK;
          for (let ox = 0; ox < FLOW_BLOCK; ox++) sum += ground[row + ox];
        }
        g[cy * FLOW_RES + cx] = sum / (FLOW_BLOCK * FLOW_BLOCK);
      }
    }
    this._flowLevelVersion = -1;
  }

  /**
   * @private
   * @param {number} x world x
   * @param {number} z world z
   * @returns {number} flow cell index, or -1 outside the world
   */
  _flowIndexAt(x, z) {
    const { u, v } = worldToUV(x, z);
    if (u < 0 || u >= 1 || v < 0 || v >= 1) return -1;
    const cx = Math.min(FLOW_RES - 1, Math.floor(u * FLOW_RES));
    const cy = Math.min(FLOW_RES - 1, Math.floor(v * FLOW_RES));
    return cy * FLOW_RES + cx;
  }

  /** @private Take the depths from the painted level field: one shared truth. */
  _flowReadDepths() {
    const lvl = this.levelLayer.data;
    const g = this._flowG;
    const d = this._flowD;
    const sea = this.params.seaLevel;
    for (let cy = 0; cy < FLOW_RES; cy++) {
      for (let cx = 0; cx < FLOW_RES; cx++) {
        let top = -Infinity;
        for (let oy = 0; oy < FLOW_BLOCK; oy++) {
          const row = (cy * FLOW_BLOCK + oy) * LAYER_RES + cx * FLOW_BLOCK;
          for (let ox = 0; ox < FLOW_BLOCK; ox++) {
            const l = lvl[row + ox];
            if (l > top) top = l;
          }
        }
        if (top < sea) top = sea;
        const i = cy * FLOW_RES + cx;
        const depth = top - g[i];
        d[i] = depth > 0 ? depth : 0;
      }
    }
    this._flowLevelVersion = this.levelLayer.version;
  }

  /** @private Fixed-step the flow simulation. */
  _stepFlow(dt) {
    if (!this.params.flowSim) {
      this._flowAccum = 0;
      return;
    }
    this._flowAccum = Math.min(this._flowAccum + dt, FLOW_STEP * FLOW_MAX_STEPS);
    let steps = 0;
    while (this._flowAccum >= FLOW_STEP && steps < FLOW_MAX_STEPS) {
      this._flowAccum -= FLOW_STEP;
      const t0 = typeof performance !== 'undefined' ? performance.now() : 0;
      this._flowStep(FLOW_STEP);
      if (t0) {
        const ms = performance.now() - t0;
        this.flowStepMs = this.flowStepMs * 0.9 + ms * 0.1;
      }
      steps++;
    }
  }

  /**
   * @private One virtual-pipes substep: accumulate outflow per direction from
   * the surface slope, cap it so no cell can go negative, move the water, then
   * write the changed cells back into the level field.
   * @param {number} dt
   */
  _flowStep(dt) {
    if (this.levelLayer.version !== this._flowLevelVersion) this._flowReadDepths();

    const n = FLOW_RES;
    const g = this._flowG;
    const d = this._flowD;
    const prev = this._flowPrev;
    const flux = this._flowFlux;
    const sea = this.params.seaLevel;
    const kdt = Math.min(FLOW_K * dt, FLOW_MAX_TRANSFER);
    prev.set(d);

    // Springs pour in before the transport pass.
    for (const spring of this.springs) {
      const i = this._flowIndexAt(spring.x, spring.z);
      if (i >= 0) d[i] += (spring.rate * dt) / FLOW_CELL_AREA;
    }

    // Outflow per direction from the surface difference, capped as a group.
    for (let i = 0; i < n * n; i++) {
      const o = i * 4;
      const depth = d[i];
      if (depth <= 0) {
        flux[o] = 0;
        flux[o + 1] = 0;
        flux[o + 2] = 0;
        flux[o + 3] = 0;
        continue;
      }
      const y = (i / n) | 0;
      const x = i - y * n;
      const s = g[i] + depth;
      let sum = 0;
      for (let k = 0; k < 4; k++) {
        const nx = x + (k === 0 ? -1 : k === 1 ? 1 : 0);
        const ny = y + (k === 2 ? -1 : k === 3 ? 1 : 0);
        let f = flux[o + k];
        if (nx < 0 || ny < 0 || nx >= n || ny >= n) {
          flux[o + k] = 0;
          continue;
        }
        const j = ny * n + nx;
        f += (s - (g[j] + d[j])) * kdt;
        if (f < 0) f = 0;
        flux[o + k] = f;
        sum += f;
      }
      const cap = depth * FLOW_MAX_TRANSFER;
      if (sum > cap && sum > 0) {
        const scale = cap / sum;
        flux[o] *= scale;
        flux[o + 1] *= scale;
        flux[o + 2] *= scale;
        flux[o + 3] *= scale;
      }
    }

    // Move the water: gather each cell's inflow from its neighbours' outflow.
    for (let y = 0; y < n; y++) {
      for (let x = 0; x < n; x++) {
        const i = y * n + x;
        const o = i * 4;
        let change = -(flux[o] + flux[o + 1] + flux[o + 2] + flux[o + 3]);
        if (x > 0) change += flux[(i - 1) * 4 + 1];
        if (x < n - 1) change += flux[(i + 1) * 4];
        if (y > 0) change += flux[(i - n) * 4 + 3];
        if (y < n - 1) change += flux[(i + n) * 4 + 2];
        d[i] += change;
      }
    }

    // Evaporation, the sea's infinite reservoir, and draining world edges.
    const evap = FLOW_EVAPORATION * dt;
    for (let i = 0; i < n * n; i++) {
      let depth = d[i] - evap;
      if (depth < 0) depth = 0;
      if (g[i] < sea) depth = sea - g[i];
      d[i] = depth;
    }
    for (let x = 0; x < n; x++) {
      d[x] = g[x] < sea ? sea - g[x] : 0;
      const last = (n - 1) * n + x;
      d[last] = g[last] < sea ? sea - g[last] : 0;
    }
    for (let y = 0; y < n; y++) {
      const left = y * n;
      const right = left + n - 1;
      d[left] = g[left] < sea ? sea - g[left] : 0;
      d[right] = g[right] < sea ? sea - g[right] : 0;
    }

    this._flowWriteBack(prev);
  }

  /**
   * @private Push every changed cell back into the level and presence layers,
   * so the surface mesh and everything reading `water` update the same frame.
   * @param {Float32Array} prev depths at the start of the step
   */
  _flowWriteBack(prev) {
    const n = FLOW_RES;
    const g = this._flowG;
    const d = this._flowD;
    const lvl = this.levelLayer.data;
    const ground = this.ctx.terrain.heightLayer.data;
    const presence = this.layer.data;
    const sea = this.params.seaLevel;
    let x0 = LAYER_RES;
    let y0 = LAYER_RES;
    let x1 = -1;
    let y1 = -1;

    for (let cy = 0; cy < n; cy++) {
      for (let cx = 0; cx < n; cx++) {
        const i = cy * n + cx;
        const depth = d[i];
        if (Math.abs(depth - prev[i]) <= FLOW_EPSILON) continue;
        const surface = g[i] + depth;
        const tx = cx * FLOW_BLOCK;
        const ty = cy * FLOW_BLOCK;
        for (let oy = 0; oy < FLOW_BLOCK; oy++) {
          const row = (ty + oy) * LAYER_RES + tx;
          for (let ox = 0; ox < FLOW_BLOCK; ox++) {
            const t = row + ox;
            const gt = ground[t];
            const wet = depth > 0 && surface > gt + 0.01;
            lvl[t] = wet ? surface : DRY;
            const level = wet && surface > sea ? surface : sea;
            const dep = level - gt;
            presence[t] =
              dep <= 0 ? 0 : dep >= PRESENCE_DEPTH ? 255 : ((dep / PRESENCE_DEPTH) * 255) | 0;
          }
        }
        if (tx < x0) x0 = tx;
        if (ty < y0) y0 = ty;
        if (tx + FLOW_BLOCK - 1 > x1) x1 = tx + FLOW_BLOCK - 1;
        if (ty + FLOW_BLOCK - 1 > y1) y1 = ty + FLOW_BLOCK - 1;
      }
    }

    if (x1 < 0) return;
    this._markDirty(this.levelLayer, x0, y0, x1, y1);
    this._markDirty(this.layer, x0, y0, x1, y1);
    this._flowLevelVersion = this.levelLayer.version;
    this._fallsDirty = true;
  }

  // --- ripple simulation --------------------------------------------------

  /** @private Ping-pong render targets plus the full-screen sim pass. */
  _buildSim() {
    const renderer = this.ctx.renderer;
    const options = {
      type: THREE.HalfFloatType,
      format: THREE.RGBAFormat,
      minFilter: THREE.LinearFilter,
      magFilter: THREE.LinearFilter,
      wrapS: THREE.ClampToEdgeWrapping,
      wrapT: THREE.ClampToEdgeWrapping,
      depthBuffer: false,
      stencilBuffer: false,
      generateMipmaps: false,
    };
    this._rtA = new THREE.WebGLRenderTarget(SIM_RES, SIM_RES, options);
    this._rtB = new THREE.WebGLRenderTarget(SIM_RES, SIM_RES, options);

    const impacts = [];
    for (let i = 0; i < MAX_IMPACTS; i++) impacts.push(new THREE.Vector4(0, 0, 0.01, 0));

    this._simMaterial = new THREE.ShaderMaterial({
      name: 'WaterRippleSim',
      uniforms: Object.assign({}, this.ctx.wind.uniforms, {
        uPrev: { value: this._rtA.texture },
        uWaterTex: { value: this.layer.texture },
        uTexel: { value: new THREE.Vector2(1 / SIM_RES, 1 / SIM_RES) },
        uStiffness: { value: 0.5 },
        uDamping: { value: 0.985 },
        uWindWaves: { value: this.params.windWaves },
        uImpactCount: { value: 0 },
        uImpacts: { value: impacts },
      }),
      vertexShader: fullscreenVertex,
      fragmentShader: rippleSimFragment,
      depthTest: false,
      depthWrite: false,
    });

    this._simMaterial.userData.__duiIgnore = true;
    this._simScene = new THREE.Scene();
    this._simScene.userData.__duiIgnore = true;
    const simQuad = new THREE.Mesh(new THREE.PlaneGeometry(2, 2), this._simMaterial);
    simQuad.userData.__duiIgnore = true;
    this._simScene.add(simQuad);
    this._simCamera = new THREE.OrthographicCamera(-1, 1, 1, -1, 0, 1);

    // Start from a flat, still surface whatever the renderer's clear colour is.
    const prevColor = new THREE.Color();
    renderer.getClearColor(prevColor);
    const prevAlpha = renderer.getClearAlpha();
    renderer.setClearColor(0x000000, 0);
    for (const rt of [this._rtA, this._rtB]) {
      renderer.setRenderTarget(rt);
      renderer.clear(true, false, false);
    }
    renderer.setRenderTarget(null);
    renderer.setClearColor(prevColor, prevAlpha);
  }

  /** @private Fixed-step the height field and swap the targets. */
  _stepRipples(dt) {
    this._simAccum = Math.min(this._simAccum + dt, SIM_STEP * SIM_MAX_STEPS);
    let steps = 0;
    while (this._simAccum >= SIM_STEP && steps < SIM_MAX_STEPS) {
      this._simAccum -= SIM_STEP;
      this._simStep(steps === 0);
      steps++;
    }
    if (steps === 0) return;
    this._impacts.length = 0;
    this.ctx.renderer.setRenderTarget(null);
  }

  /**
   * @private One substep. Impacts go in on the first substep only so a frame's
   * splashes are not injected twice.
   * @param {boolean} withImpacts
   */
  _simStep(withImpacts) {
    const renderer = this.ctx.renderer;
    const u = this._simMaterial.uniforms;
    u.uPrev.value = this._rtA.texture;

    if (withImpacts) {
      const list = this._impacts;
      const count = Math.min(list.length, MAX_IMPACTS);
      for (let i = 0; i < count; i++) {
        const im = list[i];
        u.uImpacts.value[i].set(im.u, im.v, im.r, im.s);
      }
      u.uImpactCount.value = count;
    } else {
      u.uImpactCount.value = 0;
    }

    renderer.setRenderTarget(this._rtB);
    renderer.render(this._simScene, this._simCamera);

    const swap = this._rtA;
    this._rtA = this._rtB;
    this._rtB = swap;
    this.surface.material.uniforms.uRipple.value = this._rtA.texture;
  }

  // --- surface ------------------------------------------------------------

  /** @private One mesh for every water body, shorelines and waterfall sheets. */
  _buildSurface() {
    const ctx = this.ctx;

    /** @type {THREE.Group} everything Water draws, listed by the Outliner */
    this.root = new THREE.Group();
    this.root.name = 'Water';
    this.root.matrixAutoUpdate = false;
    this.root.updateMatrix();
    ctx.scene.add(this.root);

    const geometry = new THREE.PlaneGeometry(WORLD_SIZE, WORLD_SIZE, SEGMENTS, SEGMENTS);
    geometry.rotateX(-Math.PI / 2);

    // Ground height per vertex. The vertex grid is 512x512 in the same row-major
    // order as the layer texels, so this is a straight copy of the height layer.
    this._ground = new Float32Array(LAYER_RES * LAYER_RES);
    geometry.setAttribute('aGround', new THREE.BufferAttribute(this._ground, 1));

    const obstacles = [];
    for (let i = 0; i < MAX_OBSTACLES; i++) obstacles.push(new THREE.Vector3(0, 0, 0));

    const color = (hex) => ({ value: new THREE.Color(hex) });
    const uniforms = Object.assign(
      THREE.UniformsUtils.merge([THREE.UniformsLib.lights, THREE.UniformsLib.fog]),
      ctx.sun.uniforms,
      ctx.wind.uniforms,
      {
        uWaterLevel: { value: this.levelLayer.texture },
        uFlowTex: { value: this.flowLayer.texture },
        uRipple: { value: this._rtA.texture },
        uWorldSize: { value: WORLD_SIZE },
        uTexel: { value: new THREE.Vector2(1 / LAYER_RES, 1 / LAYER_RES) },
        uTexelWorld: { value: TEXEL_WORLD },
        uSeaLevel: { value: this.params.seaLevel },
        uDeep: color(this.params.deep),
        uMid: color(this.params.mid),
        uShallow: color(this.params.shallow),
        uFoam: color(this.params.foam),
        uWet: color(this.params.wet),
        uHighlight: color(this.params.highlight),
        uSheetBase: color('#9fd6ff'),
        uStyleId: { value: 0 },
        uHighlightAmount: { value: this.params.highlightAmount },
        uHighlightStyle: { value: this.params.highlightStyle === 'cells' ? 1 : 0 },
        uFlowSpeed: { value: this.params.flowSpeed },
        uRippleStrength: { value: this.params.rippleStrength },
        uRippleVis: { value: 5.0 },
        uOpacity: { value: 0.6 },
        uObstacles: { value: obstacles },
        uObstacleCount: { value: 0 },
      },
    );

    const vertexShader = /* glsl */ `
      ${toonParsVertex}
      #include <fog_pars_vertex>

      attribute float aGround;

      uniform sampler2D uWaterLevel;
      uniform sampler2D uRipple;
      uniform vec2 uTexel;
      uniform float uTexelWorld;
      uniform float uSeaLevel;
      uniform float uWorldSize;
      uniform float uRippleStrength;

      varying float vDepth;
      varying vec2 vGrad;

      // A dry neighbour must not read as a cliff, or every shoreline would look
      // like a waterfall: treat it as level with the centre instead.
      float nbLevel(vec2 uv, float center) {
        float raw = texture2D(uWaterLevel, uv).r;
        float lvl = max(raw, uSeaLevel);
        return (raw < -900.0 && lvl < center) ? center : lvl;
      }

      void main() {
        vec4 worldPosition = modelMatrix * vec4(position, 1.0);
        vec2 uv = worldPosition.xz / uWorldSize + 0.5;

        float level = max(texture2D(uWaterLevel, uv).r, uSeaLevel);
        vDepth = level - aGround;

        float lx0 = nbLevel(uv - vec2(uTexel.x, 0.0), level);
        float lx1 = nbLevel(uv + vec2(uTexel.x, 0.0), level);
        float lz0 = nbLevel(uv - vec2(0.0, uTexel.y), level);
        float lz1 = nbLevel(uv + vec2(0.0, uTexel.y), level);
        vGrad = clamp(
          vec2(lx1 - lx0, lz1 - lz0) / (2.0 * uTexelWorld),
          vec2(-20.0),
          vec2(20.0)
        );

        // Dry vertices sit just under the ground instead of at the sentinel.
        float y = max(level, aGround - 0.05);
        y += texture2D(uRipple, uv).r * uRippleStrength * 0.5;
        worldPosition.y = y;

        vec3 transformedNormal = normalMatrix * vec3(0.0, 1.0, 0.0);
        ${toonShadowVertex}
        #include <fog_vertex>
      }
    `;

    const fragmentShader = /* glsl */ `
      ${toonParsFragment}
      ${waterCommonGLSL}
      #include <fog_pars_fragment>

      uniform sampler2D uFlowTex;
      uniform sampler2D uRipple;
      uniform float uWorldSize;
      uniform vec3 uDeep;
      uniform vec3 uMid;
      uniform vec3 uShallow;
      uniform vec3 uFoam;
      uniform vec3 uWet;
      uniform vec3 uHighlight;
      uniform vec3 uSheetBase;
      uniform float uStyleId;
      uniform float uHighlightAmount;
      uniform float uHighlightStyle;
      uniform float uFlowSpeed;
      uniform float uRippleVis;
      uniform float uOpacity;
      uniform vec3 uObstacles[${MAX_OBSTACLES}];
      uniform int uObstacleCount;

      varying float vDepth;
      varying vec2 vGrad;

      void main() {
        if (vDepth < 0.01) discard;

        vec2 uv = vWorldPos.xz / uWorldSize + 0.5;
        vec2 p = vWorldPos.xz;
        vec3 surfN = normalize(vec3(-vGrad.x, 1.0, -vGrad.y));

        vec3 albedo;
        // Shading normal: flat for every style but 'realistic', which perturbs
        // it with the ripple field below.
        vec3 n = surfN;
        float alpha = uOpacity;

        // Low-frequency wobble: every edge below is hard, but not a clean arc.
        float wob = fbm(p * 0.9, 2) - 0.5;

        if (surfN.y < 0.6) {
          // WATERFALL — a few broad white stripes over one pale blue, scrolling
          // down the sheet. Two tones, nothing else.
          vec2 g = vGrad / max(length(vGrad), 1e-4);
          float down = dot(p, -g);
          float across = dot(p, vec2(-g.y, g.x));
          float edge = fbm(vec2((down + uTime * 2.0) * 0.6, across * 0.5), 2) - 0.5;
          float stripe = fract((across + edge * 0.35) * 2.2);
          albedo = mix(uSheetBase, vec3(1.0), step(stripe, 0.45));
          // A cel waterfall is a bright painted shape: it must not go grey
          // just because the rock it hangs on faces away from the sun. Only
          // the realistic style keeps the true surface normal.
          if (uStyleId < 1.5 || uStyleId > 2.5) n = vec3(0.0, 1.0, 0.0);
          if (uStyleId > 0.5 && uStyleId < 1.5) {
            // FLAT — two printed tones, no wobble in the stripe edges.
            albedo = mix(uSheetBase, vec3(1.0), step(fract(across * 2.2), 0.45));
          } else if (uStyleId < 2.5 && uStyleId > 1.5) {
            // REALISTIC — a smooth wash of white over blue, no hard stripes.
            float sm = 0.5 + 0.5 * sin((across + edge * 0.35) * 6.9);
            albedo = mix(uSheetBase, vec3(1.0), smoothstep(0.25, 0.85, sm));
          } else if (uStyleId < 3.5 && uStyleId > 2.5) {
            // PAINTERLY — the same stripes with a wet, soft edge.
            albedo = mix(uSheetBase, vec3(1.0), smoothstep(0.55, 0.35, stripe));
          } else if (uStyleId > 3.5) {
            // PIXEL — a few hard columns of two inks.
            float col2 = floor(across * 3.0 + down * 0.5);
            albedo = mix(uSheetBase, vec3(1.0), step(0.45, hash21(vec2(col2, 4.0))));
          }
          alpha = 0.85;
        } else {
          // LAKE / RIVER — three flat blues, a foam rim and a thin wet line.
          vec2 flow = texture2D(uFlowTex, uv).rg * 2.0 - 1.0;
          vec2 downhill = -vGrad;
          vec2 flowVec = length(flow) > 0.06
            ? flow
            : (length(downhill) > 0.02 ? downhill : windAt(p) * 0.4);
          float flowLen = length(flowVec);
          vec2 dir = flowLen > 1e-4 ? flowVec / flowLen : vec2(1.0, 0.0);
          vec2 perp = vec2(-dir.y, dir.x);

          // How fast this water is going somewhere: a painted river is 1, a
          // still pond drifting on the wind is 0.
          float moving = smoothstep(0.06, 0.45, max(length(flow), min(length(downhill), 1.0)));
          // Glyphs are carried downstream at river speed and merely nudged by
          // the wind on still water, stretch 3:1 with the current, and breathe
          // four times faster where the water moves.
          float advect = mix(0.10, 0.85, moving);
          float stretch = mix(1.0, 3.0, moving);
          float breatheRate = mix(0.12, 0.5, moving);
          // The shore foam wobbles along the flow, so its edge crawls downstream.
          float wobF = fbm(p * 0.9 - dir * (uTime * advect * 0.5), 2) - 0.5;

          // Distance to the shoreline along the surface, not depth: a pond
          // bowl shelves so gently that a depth band would paint half the
          // pond white. depth / |grad depth| is the horizontal run back to
          // depth 0; flat-bottomed water (tiny gradient) counts as far out.
          vec2 dDepth = vec2(dFdx(vDepth), dFdy(vDepth));
          float pxWorld = 0.5 * (length(dFdx(vWorldPos.xz)) + length(dFdy(vWorldPos.xz)));
          float bedSlope = length(dDepth) / max(pxWorld, 1e-5);
          float shore = vDepth / max(bedSlope, 0.12);

          albedo = uMid;
          albedo = mix(albedo, uDeep, step(1.2 + wob * 0.35, vDepth));
          float shallowBand = step(0.30 + wob * 0.05, shore) * (1.0 - step(0.75 + wob * 0.12, shore));
          albedo = mix(albedo, uShallow, shallowBand);
          float wetBand = step(0.22 + wobF * 0.05, shore) * (1.0 - step(0.30 + wobF * 0.05, shore));
          albedo = mix(albedo, uWet, wetBand);
          float foam = 1.0 - step(0.22 + wobF * 0.07, shore);

          // Rain and rock impacts: one flat lighter ring, no shading at all —
          // and a white core ring for the heavy beat of a waterfall.
          float rip = texture2D(uRipple, uv).r * uRippleVis;
          albedo = mix(albedo, uShallow, step(0.30, rip));
          albedo = mix(albedo, uFoam, step(0.62, rip));

          // Hand-drawn wave glyphs: sparse, big, rounded, slowly breathing.
          float hl;
          float hlSoft;
          if (uHighlightStyle < 0.5) {
            float along = (dot(p, dir) - uTime * advect * uFlowSpeed) * (0.35 / stretch);
            float across = dot(p, perp) * 2.4;
            // fbm() sums to at most 0.75 over two octaves; normalise so the
            // glyph window sits where the spec puts it.
            float gl = fbm(vec2(along, across), 2) * 1.3333;
            float breathe = fbm(vec2(along * 0.24 + uTime * breatheRate, across * 0.05), 2) * 1.3333 - 0.5;
            float lo = 0.75 - 0.12 * uHighlightAmount + breathe * 0.05;
            hl = step(lo, gl) * (1.0 - step(lo + 0.06, gl));
            hlSoft = smoothstep(lo - 0.05, lo + 0.02, gl) * (1.0 - smoothstep(lo + 0.04, lo + 0.11, gl));
          } else {
            float th = 0.10 + 0.04 * uHighlightAmount;
            hl = voronoiWeb(uv * 22.0 - dir * (uTime * advect * uFlowSpeed * 22.0 / uWorldSize), th);
            hlSoft = hl;
          }
          hl *= step(0.20, vDepth) * step(0.45, shore);
          hlSoft *= step(0.20, vDepth) * step(0.45, shore);

          // Foam rings around solids, thicker on the side the flow comes from,
          // with a faint broken trail streaming away downstream.
          float trail = 0.0;
          for (int i = 0; i < ${MAX_OBSTACLES}; i++) {
            if (i >= uObstacleCount) break;
            vec3 o = uObstacles[i];
            vec2 rel = p - o.xy;
            float d = length(rel);
            float up = max(0.0, dot(rel / max(d, 1e-4), -dir));
            float w = 0.13 + 0.09 * up * step(0.06, flowLen);
            foam = max(foam, 1.0 - step(w, abs(d - o.z * 1.1 - wob * 0.12)));

            float dn = dot(rel, dir);
            float sd = abs(dot(rel, perp));
            float wake = step(o.z * 0.8, dn)
              * (1.0 - smoothstep(o.z * 0.8, o.z * 5.0, dn))
              * (1.0 - smoothstep(o.z * 0.45, o.z * 1.15, sd))
              * step(0.06, flowLen);
            // Broken up and drifting, so it reads as painted foam, not a cone.
            wake *= step(0.44, fbm(vec2(dn * 1.1 - uTime * advect, sd * 3.0), 2) * 1.3333);
            trail = max(trail, wake * 0.45);
          }

          if (uStyleId < 0.5) {
            // GHIBLI — flat fills, hard glyphs.
            foam = max(foam, trail);
            albedo = mix(albedo, uHighlight, hl);
          } else if (uStyleId < 1.5) {
            // FLAT — one blue and a white rim, nothing else.
            albedo = uMid;
          } else if (uStyleId < 2.5) {
            // REALISTIC — smooth blue, ripple normal shading, sky fresnel and a
            // specular glint; no glyphs, no wet line, only a thin soft rim.
            float t = 1.0 / ${SIM_RES}.0;
            float hx = texture2D(uRipple, uv + vec2(t, 0.0)).r - texture2D(uRipple, uv - vec2(t, 0.0)).r;
            float hz = texture2D(uRipple, uv + vec2(0.0, t)).r - texture2D(uRipple, uv - vec2(0.0, t)).r;
            n = normalize(surfN + vec3(-hx * 12.0, 0.0, -hz * 12.0));
            albedo = mix(uDeep, uShallow, smoothstep(0.0, 1.6, vDepth));
            vec3 viewDir = normalize(cameraPosition - vWorldPos);
            float fres = pow(1.0 - max(dot(n, viewDir), 0.0), 3.0);
            albedo = mix(albedo, uSkyColor, fres * 0.55);
            float spec = pow(max(dot(n, normalize(uSunDir + viewDir)), 0.0), 64.0);
            albedo += uSunColor * spec * 0.8;
            foam = (1.0 - smoothstep(0.06, 0.16, shore)) * 0.7;
          } else if (uStyleId < 3.5) {
            // PAINTERLY — the same glyphs, but as soft dabs.
            foam = max(foam, trail * 0.8);
            albedo = mix(albedo, uHighlight, smoothstep(0.0, 1.0, hlSoft));
          } else {
            // PIXEL — two blues plus white, highlights as thin dashes.
            albedo = mix(uMid, uDeep, step(0.9, vDepth));
            float dashRow = floor(p.y * 8.0);
            float dash = step(0.72, hash21(vec2(floor(p.x * 3.0), dashRow)))
              * step(fract(p.y * 8.0), 0.3)
              * step(0.3, vDepth);
            albedo = mix(albedo, vec3(1.0), dash);
          }
          albedo = mix(albedo, uFoam, clamp(foam, 0.0, 1.0));
        }

        // Flat fills only: one 2-band ramp on the surface normal, no per-pixel
        // normal shading, no glint.
        vec3 col = toonLight(albedo, n, toonShadow(), 2.0);

        gl_FragColor = vec4(col, clamp(alpha, 0.0, 1.0));
        #include <fog_fragment>
        #include <colorspace_fragment>
      }
    `;

    const material = new THREE.ShaderMaterial({
      name: 'Water',
      uniforms,
      vertexShader,
      fragmentShader,
      lights: true,
      fog: true,
      transparent: true,
      depthWrite: true,
      side: THREE.DoubleSide,
      toneMapped: false,
      // Flat opaque colour, but 0.6 lands in the alpha channel: PostFX reads
      // that as "outline this, do not hatch or pool it".
      blending: THREE.CustomBlending,
      blendEquation: THREE.AddEquation,
      blendSrc: THREE.OneFactor,
      blendDst: THREE.ZeroFactor,
      blendEquationAlpha: THREE.AddEquation,
      blendSrcAlpha: THREE.OneFactor,
      blendDstAlpha: THREE.ZeroFactor,
    });

    material.userData.uiProps = this._buildUiProps();
    material.userData.swatch = [this.params.deep, this.params.mid, this.params.foam];
    ctx.style?.attach?.(material, { element: Water.id });

    /** @type {THREE.Mesh} */
    this.surface = new THREE.Mesh(geometry, material);
    this.surface.name = 'waterSurface';
    this.surface.receiveShadow = true;
    this.surface.castShadow = false;
    this.surface.renderOrder = 5;
    this.surface.frustumCulled = false;
    this.surface.matrixAutoUpdate = false;
    this.surface.updateMatrix();
    this.root.add(this.surface);

    this._applyGround();

    /** @type {THREE.Group} */
    this._wfGroup = new THREE.Group();
    this._wfGroup.name = 'waterfalls';
    this._wfGroup.userData.__duiIgnore = true;
    this.root.add(this._wfGroup);
  }

  /** @private Copy the height layer into the surface's ground attribute. */
  _applyGround() {
    this._ground.set(this.ctx.terrain.heightLayer.data);
    this.surface.geometry.attributes.aGround.needsUpdate = true;
  }

  /** @private Push the obstacle list into the surface shader. */
  _syncObstacles() {
    const u = this.surface.material.uniforms;
    const count = Math.min(this.obstacles.length, MAX_OBSTACLES);
    for (let i = 0; i < count; i++) {
      const o = this.obstacles[i];
      u.uObstacles.value[i].set(o.x, o.z, o.r);
    }
    u.uObstacleCount.value = count;
  }

  // --- tools --------------------------------------------------------------

  /** @private */
  _registerTools() {
    const brush = this.ctx.brush;

    brush.registerTool({
      id: 'pond',
      element: Water.id,
      label: 'Pond',
      color: '#5fb7ff',
      key: '3',
      eraseMode: 'erase',
      // Same mapping as the river: Strength 0.6 -> a 0.4 carve blend per stamp
      // (the default 0.26 carves at about 0.17; raise Strength to dig faster).
      strengthScale: 2.2,
      onStamp: (ctx, op) => {
        if (op.mode === 'erase') {
          this._writeLevelDisc(op.u, op.v, op.radius, op.hardness, 'drain', 0, Infinity, op);
          return;
        }
        if (this.params.carve) {
          // Dig the basin the water sits in: a bowl one pond-depth below the
          // rim at the centre, easing back to the rim at the brush edge.
          const base = Math.min(1.0, Math.max(0.1, op.strength * 1.2));
          const pressure = Math.min(1, base * (this.params.carvePressure / 0.6));
          const depth = this.params.pondDepth;
          this._carveDisc(
            op.u,
            op.v,
            op.radius,
            0.3,
            this._pondRim - depth,
            pressure,
            depth,
            this._pondRim,
            op,
          );
        }
        this._writeLevelDisc(op.u, op.v, op.radius, op.hardness, 'fill', this._pondLevel, Infinity, op);
      },
    });

    brush.registerTool({
      id: 'river',
      element: Water.id,
      label: 'River',
      color: '#3d8fe0',
      key: '4',
      eraseMode: 'erase',
      // Brush Strength 0.6 -> op.strength 0.33 -> a 0.4 carve blend per stamp;
      // the default 0.26 gives about 0.17, so a river needs a few passes.
      strengthScale: 2.2,
      onStamp: (ctx, op, hit) => {
        if (op.mode === 'erase') {
          this._writeLevelDisc(op.u, op.v, op.radius, op.hardness, 'drain', 0, Infinity, op);
          return;
        }
        const ground = ctx.terrain.heightAt(hit.x, hit.z);
        const depth = this.params.riverDepth;
        // The running level never rises, so the river descends over bumps — but
        // it never sits more than one river-depth below the local ground, so a
        // rise is stepped over instead of tunnelled through.
        this._riverLevel = Math.min(this._riverLevel, ground + this.params.riverSurface);
        this._riverLevel = Math.max(this._riverLevel, ground - depth + this.params.riverSurface);
        if (this.params.carve) {
          // The bed is measured from the untouched banks, not from the channel
          // floor: overlapping stamps would otherwise ratchet the reference down
          // with every dab and dig a canyon. Painting the same line again then
          // converges on a channel one river-depth below its banks.
          const bank = this._bankHeight(hit.x, hit.z, op.radius * WORLD_SIZE * 1.6, op.dir);
          const bed = bank - depth;
          // Blend per stamp; the slider multiplies, 0.6 being neutral.
          const base = Math.min(1.0, Math.max(0.1, op.strength * 1.2));
          const pressure = Math.min(1, base * (this.params.carvePressure / 0.6));
          this._carveDisc(op.u, op.v, op.radius * 0.9, 0.35, bed, pressure, depth, undefined, op);
        }
        // Whatever the running level says, the water must still cover the bed
        // that was just cut, or a river stepping over a rise would go dry.
        this._riverLevel = Math.max(
          this._riverLevel,
          ctx.terrain.heightAt(hit.x, hit.z) + MIN_RIVER_FILM,
        );
        this._writeLevelDisc(
          op.u,
          op.v,
          op.radius,
          op.hardness,
          'fill',
          this._riverLevel,
          this.params.riverSurface + this.params.riverDepth + 0.35,
          op,
        );
        if (op.dir) {
          ctx.layers.get('flow').stamp({
            u: op.u,
            v: op.v,
            radius: op.radius,
            strength: Math.min(0.8, op.strength * 3),
            hardness: op.hardness,
            mode: 'direction',
            dir: op.dir,
          });
        }
      },
    });

    brush.registerTool({
      id: 'waterfall',
      element: Water.id,
      label: 'Waterfall',
      color: '#dff6ff',
      key: '5',
      eraseMode: 'erase',
      onStamp: (ctx, op, hit) => {
        this._wfErase = op.mode === 'erase';
        this._wfStroke.push({ x: hit.x, z: hit.z });
        // Nothing is committed until the pointer lifts — this tool needs both
        // ends of the drag — so the drag shows the fall it is about to build.
        if (!this._wfErase) this._showPreview(this._wfStroke[0], hit);
      },
    });
  }

  /**
   * Build a whole waterfall between two points: sculpt the ledge if the ground
   * is not already high enough, lay the source pool, the sheet of water down
   * the cliff and the plunge pool, and leave a spring and an emitter behind.
   *
   * @param {{x:number, z:number}} start top of the intended fall
   * @param {{x:number, z:number}} end bottom of it
   * @returns {import('./Waterfall.js').Waterfall|null}
   */
  paintWaterfall(start, end) {
    const terrain = this.ctx.terrain;
    const radius = Math.max(0.5, this.ctx.brush.settings.radius);
    const width = Math.max(0.4, this.params.fallWidth || radius);

    let dx = end.x - start.x;
    let dz = end.z - start.z;
    let len = Math.hypot(dx, dz);
    if (len < 0.35) {
      // A tap rather than a drag: fall downhill, or south on flat ground.
      const n = terrain.normalAt(start.x, start.z, this._tmpVec);
      const gl = Math.hypot(n.x, n.z);
      dx = gl > 1e-3 ? n.x / gl : 0;
      dz = gl > 1e-3 ? n.z / gl : 1;
      len = radius * 2;
      end = { x: start.x + dx * len, z: start.z + dz * len };
    } else {
      dx /= len;
      dz /= len;
    }

    // A Ghibli fall is a column, not a ramp: the lip stands directly over the
    // plunge pool, so the sheet is steep however long the drag was.
    const face = TEXEL_WORLD * CLIFF_TEXELS;
    const fallRun = Math.min(len * 0.45, Math.max(0.9, width * 0.7));
    let lipT = Math.max(0.05, len - fallRun);
    const cliffT = lipT + face * 0.6;

    // The pool's rim is the untouched ground it will sit in, read across the
    // stroke and BEFORE the ledge goes up — a ring that reached back over the
    // new plateau would float the pool half-way up the cliff.
    const rim = this._bankHeight(end.x, end.z, radius * 1.15, { x: dx, y: dz });

    const drop = terrain.heightAt(start.x, start.z) - terrain.heightAt(end.x, end.z);
    const rise = this.params.fallHeight - drop;
    if (rise > 0.05) {
      this._sculptLedge(start, dx, dz, cliffT, len, rise, width, radius);
    } else {
      // Down an existing cliff there is nothing to sculpt: the landscape
      // already falls further than the slider asks for, so the fall starts
      // where the ground itself starts dropping.
      lipT = this._naturalLip(start, dx, dz, len);
    }

    const lipX = start.x + dx * lipT;
    const lipZ = start.z + dz * lipT;
    const topGround = terrain.heightAt(lipX, lipZ);
    const topLevel = topGround + SOURCE_RISE;

    // The plunge pool: a bowl one half-unit deep, filled to its rim.
    this._snapshotCarve();
    const endUV = worldToUV(end.x, end.z);
    this._carveDisc(
      endUV.u,
      endUV.v,
      radius / WORLD_SIZE,
      0.25,
      rim - PLUNGE_DEPTH,
      1,
      PLUNGE_DEPTH,
      rim,
    );
    this._writeLevelDisc(endUV.u, endUV.v, radius / WORLD_SIZE, 0.45, 'fill', rim);

    // The source pool feeding the lip.
    const startUV = worldToUV(start.x, start.z);
    const srcLevel = terrain.heightAt(start.x, start.z) + SOURCE_RISE;
    this._writeLevelDisc(startUV.u, startUV.v, radius / WORLD_SIZE, 0.45, 'fill', srcLevel);

    // The strip of level running from the lip down the face into the pool, so
    // the surface mesh carries water all the way rather than in two puddles.
    const pools = [
      { x: start.x, z: start.z, r: radius },
      { x: end.x, z: end.z, r: radius },
    ];
    const steps = Math.max(4, Math.min(48, Math.round(len / (TEXEL_WORLD * 2))));
    const lipFrac = lipT / len;
    for (let i = 0; i <= steps; i++) {
      const t = i / steps;
      const px = start.x + dx * len * t;
      const pz = start.z + dz * len * t;
      // Flat along the plateau, then descending to the pool past the lip.
      const over = Math.min(1, Math.max(0, (t - lipFrac) / Math.max(1e-3, 1 - lipFrac)));
      const level = topLevel + (rim - topLevel) * over;
      const uv = worldToUV(px, pz);
      this._writeLevelDisc(uv.u, uv.v, width * 0.5 / WORLD_SIZE, 0.5, 'fill', level, 0.3);
      if (i % 4 === 0) pools.push({ x: px, z: pz, r: width * 0.5 });
    }

    const fall = this._addWaterfall({
      x: lipX,
      z: lipZ,
      dirX: dx,
      dirZ: dz,
      width,
      fallWidth: width,
      droplets: 320,
      sheet: true,
      lip: { x: lipX, y: topLevel, z: lipZ },
      base: { x: end.x, y: rim, z: end.z },
    });
    fall.pools = pools;
    fall.spring = this.addSpring(start.x, start.z, FALL_SPRING_RATE);
    // A foam rim where the column hits the pool.
    this.addObstacle(end.x, end.z, Math.max(0.35, width * 0.45));
    fall.rim = { x: end.x, z: end.z };
    return fall;
  }

  /**
   * @private Where an existing slope begins to fall away: the last point along
   * the stroke still within a fifth of the drop of the top.
   * @param {{x:number, z:number}} start
   * @param {number} dx unit stroke direction x
   * @param {number} dz unit stroke direction z
   * @param {number} len stroke length in world units
   * @returns {number} distance along the stroke
   */
  _naturalLip(start, dx, dz, len) {
    const terrain = this.ctx.terrain;
    const steps = 24;
    const top = terrain.heightAt(start.x, start.z);
    const bottom = terrain.heightAt(start.x + dx * len, start.z + dz * len);
    const drop = top - bottom;
    if (drop <= 0.05) return Math.max(0.05, len * 0.5);
    const edge = bottom + drop * 0.8;
    let best = 0;
    for (let i = 1; i <= steps; i++) {
      const t = (i / steps) * len;
      if (terrain.heightAt(start.x + dx * t, start.z + dz * t) >= edge) best = t;
    }
    return Math.min(Math.max(best, 0.05), Math.max(0.05, len - 0.4));
  }

  /**
   * @private Raise the upstream half of the stroke until the start stands
   * `rise` above the end, with a near-vertical face across the stroke midline
   * and a soft blend out to the sides. Downstream ground is never lowered.
   * @param {{x:number, z:number}} start
   * @param {number} dx unit stroke direction x
   * @param {number} dz unit stroke direction z
   * @param {number} cliffT distance along the stroke where the face drops
   * @param {number} len stroke length in world units
   * @param {number} rise how much higher the top must sit
   * @param {number} width fall width in world units
   * @param {number} radius brush radius in world units
   */
  _sculptLedge(start, dx, dz, cliffT, len, rise, width, radius) {
    const res = LAYER_RES;
    const height = this.ctx.terrain.heightLayer;
    const data = height.data;
    const px = -dz;
    const pz = dx;
    const face = TEXEL_WORLD * CLIFF_TEXELS;
    const blend = radius * 1.5;
    // Full height out to here across the stroke, and back to here behind it.
    const keepSide = Math.max(width, radius) * 0.75;
    const keepBack = radius * 0.8;
    const reach = blend + keepSide + keepBack + 1;

    const tipX = start.x + dx * len;
    const tipZ = start.z + dz * len;
    const minX = Math.min(start.x, tipX) - reach;
    const maxX = Math.max(start.x, tipX) + reach;
    const minZ = Math.min(start.z, tipZ) - reach;
    const maxZ = Math.max(start.z, tipZ) + reach;
    const a0 = worldToUV(minX, minZ);
    const a1 = worldToUV(maxX, maxZ);
    const x0 = Math.max(0, Math.floor(a0.u * res));
    const x1 = Math.min(res - 1, Math.ceil(a1.u * res));
    const y0 = Math.max(0, Math.floor(a0.v * res));
    const y1 = Math.min(res - 1, Math.ceil(a1.v * res));
    if (x1 < x0 || y1 < y0) return;

    const ramp = (v) => {
      const c = v < 0 ? 0 : v > 1 ? 1 : v;
      return 1 - c * c * (3 - 2 * c);
    };

    for (let y = y0; y <= y1; y++) {
      const wz = (((y + 0.5) / res) - 0.5) * WORLD_SIZE;
      for (let x = x0; x <= x1; x++) {
        const wx = (((x + 0.5) / res) - 0.5) * WORLD_SIZE;
        const rx = wx - start.x;
        const rz = wz - start.z;
        const t = rx * dx + rz * dz;
        const side = Math.abs(rx * px + rz * pz);
        // The cliff face: 2-3 texels from plateau to valley floor.
        const along = ramp((t - (cliffT - face * 0.5)) / face);
        if (along <= 0.002) continue;
        const back = ramp((-t - keepBack) / blend);
        const lateral = ramp((side - keepSide) / blend);
        const f = along * back * lateral;
        if (f <= 0.002) continue;
        data[y * res + x] += rise * f;
      }
    }
    this._markDirty(height, x0, y0, x1, y1);
  }

  /**
   * @private Show the fall the current drag would build: a ribbon standing on
   * the plateau the ledge sculpt will raise, falling to the pointer.
   * @param {{x:number, z:number}} start
   * @param {{x:number, z:number}} end
   */
  _showPreview(start, end) {
    if (!start || !end) return;
    if (!this.preview) this._buildPreview();
    const terrain = this.ctx.terrain;
    const radius = Math.max(0.5, this.ctx.brush.settings.radius);
    const width = Math.max(0.4, this.params.fallWidth || radius);
    let dx = end.x - start.x;
    let dz = end.z - start.z;
    const len = Math.hypot(dx, dz);
    if (len < 0.3) {
      this.preview.visible = false;
      return;
    }
    dx /= len;
    dz /= len;
    const px = -dz;
    const pz = dx;
    const gEnd = terrain.heightAt(end.x, end.z);
    const drop = terrain.heightAt(start.x, start.z) - gEnd;
    const top = gEnd + Math.max(drop, this.params.fallHeight) + SOURCE_RISE;
    const half = width * 0.5;
    const pos = this._previewPos;
    const down = this._previewDown;
    // Where the lip will end up, as a fraction of the stroke.
    const lipAt = Math.max(0.05, len - Math.min(len * 0.45, Math.max(0.9, width * 0.7))) / len;
    const fallLen = Math.hypot(len * (1 - lipAt), top - gEnd);

    for (let r = 0; r < PREVIEW_STEPS; r++) {
      const t = r / (PREVIEW_STEPS - 1);
      const cx = start.x + dx * len * t;
      const cz = start.z + dz * len * t;
      // Flat along the plateau, then over the edge just above the pool.
      const fall = t <= lipAt ? 0 : Math.pow((t - lipAt) / (1 - lipAt), 0.8);
      const cy = top - (top - gEnd) * fall;
      for (let c = 0; c < 3; c++) {
        const a = c - 1;
        const i = (r * 3 + c) * 3;
        pos[i] = cx + px * a * half;
        pos[i + 1] = cy + 0.02;
        pos[i + 2] = cz + pz * a * half;
        down[r * 3 + c] = t * fallLen;
      }
    }
    this.preview.geometry.attributes.position.needsUpdate = true;
    this.preview.geometry.attributes.aDown.needsUpdate = true;
    this.preview.geometry.computeVertexNormals();
    this.preview.visible = true;
  }

  /** @private The ribbon drawn while a waterfall stroke is being dragged. */
  _buildPreview() {
    const rows = PREVIEW_STEPS;
    const cols = 3;
    const n = rows * cols;
    this._previewPos = new Float32Array(n * 3);
    this._previewDown = new Float32Array(n);
    const along = new Float32Array(n);
    const across = new Float32Array(n);
    const lip = new Float32Array(n);
    const indices = [];
    for (let r = 0; r < rows; r++) {
      for (let c = 0; c < cols; c++) {
        const i = r * cols + c;
        along[i] = r / (rows - 1);
        across[i] = c - 1;
        lip[i] = 0;
      }
    }
    for (let r = 0; r < rows - 1; r++) {
      for (let c = 0; c < cols - 1; c++) {
        const i = r * cols + c;
        indices.push(i, i + 1, i + cols, i + 1, i + cols + 1, i + cols);
      }
    }
    const geo = new THREE.BufferGeometry();
    geo.setAttribute('position', new THREE.BufferAttribute(this._previewPos, 3));
    geo.setAttribute('aAlong', new THREE.BufferAttribute(along, 1));
    geo.setAttribute('aAcross', new THREE.BufferAttribute(across, 1));
    geo.setAttribute('aLip', new THREE.BufferAttribute(lip, 1));
    geo.setAttribute('aDown', new THREE.BufferAttribute(this._previewDown, 1));
    geo.setIndex(indices);
    geo.computeVertexNormals();

    /** @type {THREE.Mesh} the live waterfall-stroke preview */
    this.preview = new THREE.Mesh(geo, this._wfMaterials.sheet);
    this.preview.name = 'waterfallPreview';
    this.preview.frustumCulled = false;
    this.preview.renderOrder = 8;
    this.preview.visible = false;
    this.preview.userData.__duiIgnore = true;
    this._wfGroup.add(this.preview);
  }

  /** @private Hide the drag preview. */
  _hidePreview() {
    if (this.preview) this.preview.visible = false;
  }

  /**
   * @private Capture the level a pond or river stroke works at.
   * @param {{tool: object, hit: object}} payload
   */
  _beginStroke(payload) {
    const id = payload?.tool?.id;
    const hit = payload?.hit;
    if (!hit) return;
    const ground = this.ctx.terrain.heightAt(hit.x, hit.z);
    if (id === 'waterfall') {
      this._hidePreview();
      return;
    }
    if (id === 'pond') {
      // The rim is the untouched ground just outside the brush, not the ground
      // under it: re-reading a carved centre would ratchet the bowl deeper on
      // every pass. The water sits just under the rim, so the sheet is flush
      // with the meadow instead of floating above it.
      this._pondRim = this._bankHeight(hit.x, hit.z, this.ctx.brush.settings.radius * 1.3);
      this._pondLevel = this._pondRim - POND_RIM_DROP;
      if (this.params.carve) this._snapshotCarve();
    } else if (id === 'river') {
      this._riverLevel = ground + this.params.riverSurface;
      if (this.params.carve) this._snapshotCarve();
      // A carved river needs a source, or the flow simulation drains it.
      if (this.params.flowSim) this.addSpring(hit.x, hit.z);
    }
  }

  /**
   * @private End of a stroke: place or remove a manual waterfall emitter. This
   * is the only stroke-end-gated action; everything else lands per stamp.
   * @param {{tool: object}} payload
   */
  _finishWaterfallStroke(payload) {
    if (payload?.tool?.id !== 'waterfall') return;
    const path = this._wfStroke;
    this._wfStroke = [];
    this._hidePreview();
    if (!path.length) return;

    const start = path[0];
    const end = path[path.length - 1];

    if (this._wfErase) {
      const radius = Math.max(2, this.ctx.brush.settings.radius * 1.5);
      this._undoable('Erase waterfall', () => this.removeWaterfallNear(end.x, end.z, radius));
      return;
    }
    // The ledge, the pools and the emitter are one undo entry. `wrap` closes
    // the brush's own (empty) stroke scope first, so this is the only one.
    this._undoable('Waterfall', () => this.paintWaterfall(start, end));
  }

  /**
   * @private
   * @param {{x:number, z:number, dirX:number, dirZ:number, width?:number}} opts
   * @returns {Waterfall}
   */
  _addWaterfall(opts) {
    while (this.waterfalls.length >= MAX_WATERFALLS) this.waterfalls.shift().dispose();
    const fall = new Waterfall(this.ctx, { ...opts, isWet: this._isWet }, this._wfMaterials);
    this._wfGroup.add(fall.group);
    this.waterfalls.push(fall);
    this._syncPanel();
    return fall;
  }

  /** @private */
  _floodFillAtCursor() {
    const hit = this.ctx.brush.hit;
    if (!hit) return;
    const run = () =>
      this.floodFillAt(hit.x, hit.z, this.ctx.terrain.heightAt(hit.x, hit.z) + this.params.pondDepth);
    if (this.ctx.history?.wrap) this.ctx.history.wrap('Flood fill basin', run, { element: 'water' });
    else run();
  }

  /** @private */
  _seaToCursor() {
    const hit = this.ctx.brush.hit;
    if (!hit) return;
    const run = () => this.setSeaLevel(this.ctx.terrain.heightAt(hit.x, hit.z));
    if (this.ctx.history?.wrap) this.ctx.history.wrap('Raise sea to cursor', run, { element: 'water' });
    else run();
  }

  /**
   * @private Run a one-shot mutation as a single undo entry.
   * @param {string} label
   * @param {() => void} fn
   */
  _undoable(label, fn) {
    if (this.ctx.history?.wrap) this.ctx.history.wrap(label, fn, { element: 'water' });
    else fn();
  }

  /** @private @returns {string} */
  _waterfallInfo() {
    return (
      `Waterfalls: ${this.waterfalls.length} manual / ${this.autoFalls.length} auto` +
      ` · springs: ${this.springs.length}`
    );
  }

  /** @private Push palette changes back into the panel's colour swatches. */
  _syncPanelColors() {
    const controls = this._panel?.controls;
    if (!controls) return;
    for (const [, key] of COLOR_CONTROLS) {
      controls[`water-${key}`]?.setValue?.(this.params[key]);
    }
  }

  /** @private */
  _syncPanel() {
    const info = this._panel?.controls?.['water-waterfalls'];
    if (info?.setText) info.setText(this._waterfallInfo());
  }

  // --- waterfall + leaf materials ----------------------------------------

  /** @private Shared across every emitter so shaders compile once. */
  _buildWaterfallMaterials() {
    const ctx = this.ctx;
    const wind = ctx.wind.uniforms;
    const color = (hex) => ({ value: new THREE.Color(hex) });

    const droplet = new THREE.ShaderMaterial({
      name: 'WaterfallDroplets',
      ...INK_EXEMPT_BLEND,
      uniforms: Object.assign({}, THREE.UniformsUtils.clone(THREE.UniformsLib.fog), {
        uColor: { value: new THREE.Color('#eaf8ff') },
        uOpacity: { value: 0.9 },
        uSize: { value: 0.16 },
        uPointScale: { value: 12 },
      }),
      vertexShader: dropletVertex,
      fragmentShader: dropletFragment,
      transparent: true,
      depthWrite: false,
      fog: true,
      toneMapped: false,
    });

    const foam = new THREE.ShaderMaterial({
      name: 'WaterfallFoam',
      ...INK_EXEMPT_BLEND,
      uniforms: Object.assign({}, THREE.UniformsUtils.clone(THREE.UniformsLib.fog), wind, {
        uFoamColor: { value: new THREE.Color('#ffffff') },
        uFoamShade: { value: new THREE.Color('#cfe9fb') },
        uOpacity: { value: 0.95 },
      }),
      vertexShader: foamBlobVertex,
      fragmentShader: foamBlobFragment,
      transparent: true,
      depthWrite: false,
      side: THREE.DoubleSide,
      fog: true,
      toneMapped: false,
    });

    // The falling sheet itself: lit like every other painted surface, so a
    // style switch repaints it with the rest of the scene.
    const sheet = new THREE.ShaderMaterial({
      name: 'Waterfall',
      uniforms: Object.assign(
        THREE.UniformsUtils.merge([THREE.UniformsLib.lights, THREE.UniformsLib.fog]),
        ctx.sun.uniforms,
        wind,
        {
          uBody: color(this.params.sheetBody),
          uStreak: color(this.params.sheetStreak),
          uLine: color(this.params.sheetLine),
          uLipColor: color(this.params.sheetStreak),
          uScroll: { value: 2.5 },
          uStreaks: { value: 5 },
        },
      ),
      vertexShader: sheetVertex,
      fragmentShader: sheetFragment,
      lights: true,
      fog: true,
      side: THREE.DoubleSide,
      depthWrite: true,
      toneMapped: false,
    });
    sheet.userData.swatch = [this.params.sheetBody, this.params.sheetStreak, this.params.sheetLine];
    sheet.userData.uiProps = this._buildSheetUiProps(sheet);
    ctx.style?.attach?.(sheet, { element: Water.id });

    // Cumulus mist at the foot. Opaque and depth-writing, so the ink pass
    // outlines each puff the way it outlines a cloud.
    const mistPuff = new THREE.ShaderMaterial({
      name: 'Waterfall mist',
      uniforms: Object.assign({}, THREE.UniformsUtils.clone(THREE.UniformsLib.fog), wind, {
        uMist: color(this.params.mist),
        uMistShade: color('#c3ccdb'),
      }),
      vertexShader: mistPuffVertex,
      fragmentShader: mistPuffFragment,
      fog: true,
      side: THREE.DoubleSide,
      toneMapped: false,
    });
    mistPuff.userData.swatch = ['#ffffff', '#c3ccdb'];
    ctx.style?.attach?.(mistPuff, { element: Water.id });

    // The veil of rising mist: faint, and exempt from the ink pass.
    const mistSheet = new THREE.ShaderMaterial({
      name: 'WaterfallVeil',
      ...INK_EXEMPT_BLEND,
      uniforms: Object.assign({}, THREE.UniformsUtils.clone(THREE.UniformsLib.fog), wind, {
        uMist: color(this.params.mist),
        uOpacity: { value: 0.25 },
      }),
      vertexShader: mistSheetVertex,
      fragmentShader: mistSheetFragment,
      transparent: true,
      depthWrite: false,
      side: THREE.DoubleSide,
      fog: true,
      toneMapped: false,
    });

    droplet.userData.__duiIgnore = true;
    foam.userData.__duiIgnore = true;
    mistSheet.userData.__duiIgnore = true;

    /** @type {Record<string, THREE.ShaderMaterial>} */
    this._wfMaterials = { droplet, foam, sheet, mistPuff, mistSheet };
  }

  /**
   * @private Materials-palette rows for the falling sheet.
   * @param {THREE.ShaderMaterial} sheet
   * @returns {Array<object>}
   */
  _buildSheetUiProps(sheet) {
    const props = COLOR_CONTROLS.filter((c) => c[3] === 'sheet' || c[3] === 'mist').map(
      ([label, key]) => ({
        label,
        kind: 'color',
        get: () => this.params[key],
        set: (v) => this.setColor(key, v),
      }),
    );
    props.push({
      label: 'Scroll speed',
      kind: 'number',
      min: 0,
      max: 8,
      step: 0.1,
      get: () => sheet.uniforms.uScroll.value,
      set: (v) => {
        sheet.uniforms.uScroll.value = v;
      },
    });
    return props;
  }

  /** @private Points are sized in framebuffer pixels under an ortho camera. */
  _updatePointScale() {
    const renderer = this.ctx.renderer;
    renderer.getDrawingBufferSize(this._tmpSize);
    const half = this.ctx.iso?.frustumHalfHeight || 14;
    const scale = this._tmpSize.y / (2 * half);
    this._wfMaterials.droplet.uniforms.uPointScale.value = scale;
    this._leafMaterial.uniforms.uPointScale.value = scale;
  }

  // --- floating leaves ----------------------------------------------------

  /** @private Petals and leaves carried by the flow. */
  _buildLeaves() {
    this._leafPos = new Float32Array(LEAF_COUNT * 3);
    this._leafAlive = new Uint8Array(LEAF_COUNT);
    this._leafAge = new Float32Array(LEAF_COUNT);
    this._leafPos.fill(-1000);

    const geometry = new THREE.BufferGeometry();
    geometry.setAttribute('position', new THREE.BufferAttribute(this._leafPos, 3));

    this._leafMaterial = new THREE.ShaderMaterial({
      name: 'WaterLeaves',
      userData: { __duiIgnore: true },
      ...INK_EXEMPT_BLEND,
      uniforms: Object.assign({}, THREE.UniformsUtils.clone(THREE.UniformsLib.fog), {
        uColor: { value: new THREE.Color('#e8cf86') },
        uOpacity: { value: 0.95 },
        uSize: { value: 0.14 },
        uPointScale: { value: 12 },
      }),
      vertexShader: dropletVertex,
      fragmentShader: dropletFragment,
      transparent: true,
      depthWrite: false,
      fog: true,
      toneMapped: false,
    });

    /** @type {THREE.Points} */
    this.leaves = new THREE.Points(geometry, this._leafMaterial);
    this.leaves.name = 'waterLeaves';
    this.leaves.frustumCulled = false;
    this.leaves.renderOrder = 6;
    this.leaves.userData.__duiIgnore = true;
    this.root.add(this.leaves);
  }

  /** @private */
  _updateLeaves(dt) {
    const pos = this._leafPos;
    const flow = this.flowLayer;
    const wind = this.ctx.wind;
    let spawned = 0;

    for (let i = 0; i < LEAF_COUNT; i++) {
      const o = i * 3;
      if (!this._leafAlive[i]) {
        if (spawned >= 3) continue;
        spawned++;
        if (!this._spawnLeaf(i)) continue;
      }

      const x = pos[o];
      const z = pos[o + 2];
      const u = x / WORLD_SIZE + 0.5;
      const v = z / WORLD_SIZE + 0.5;
      const w = this.layer.sample(u, v);
      this._leafAge[i] += dt;
      if (w < 0.4 || this._leafAge[i] > 40 || Math.abs(x) > HALF || Math.abs(z) > HALF) {
        this._leafAlive[i] = 0;
        pos[o + 1] = -1000;
        continue;
      }

      const fx = flow.sample(u, v, 0) * 2 - 1;
      const fz = flow.sample(u, v, 1) * 2 - 1;
      const fl = Math.hypot(fx, fz);
      const gust = wind.sampleAt(x, z);
      let vx = gust.x * 0.12;
      let vz = gust.z * 0.12;
      if (fl > 0.06) {
        vx += (fx / fl) * 1.5 * Math.min(1, fl) * this.params.flowSpeed;
        vz += (fz / fl) * 1.5 * Math.min(1, fl) * this.params.flowSpeed;
      }
      pos[o] = x + vx * dt;
      pos[o + 2] = z + vz * dt;
      pos[o + 1] = (this.surfaceHeightAt(pos[o], pos[o + 2]) ?? pos[o + 1]) + 0.06;
    }

    this.leaves.geometry.attributes.position.needsUpdate = true;
  }

  /**
   * @private Place leaf `i` on a random patch of open water.
   * @param {number} i
   * @returns {boolean} whether a spot was found
   */
  _spawnLeaf(i) {
    for (let tries = 0; tries < 12; tries++) {
      const u = this._random();
      const v = this._random();
      if (this.layer.sample(u, v) < 0.6) continue;
      // Leaves ride rivers; still ponds stay clean rather than speckled.
      const fx = this.flowLayer.sample(u, v, 0) * 2 - 1;
      const fz = this.flowLayer.sample(u, v, 1) * 2 - 1;
      if (Math.hypot(fx, fz) < LEAF_MIN_FLOW) continue;
      const { x, z } = uvToWorld(u, v);
      const o = i * 3;
      this._leafPos[o] = x;
      this._leafPos[o + 1] = (this.surfaceHeightAt(x, z) ?? 0) + 0.06;
      this._leafPos[o + 2] = z;
      this._leafAlive[i] = 1;
      this._leafAge[i] = 0;
      return true;
    }
    return false;
  }

  /** @private Deterministic 0..1 sequence so reloads look the same. */
  _random() {
    this._leafSeed = (this._leafSeed * 1664525 + 1013904223) % 4294967296;
    return this._leafSeed / 4294967296;
  }
}
