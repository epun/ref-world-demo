import * as THREE from 'three';
import { mergeGeometries } from 'three/examples/jsm/utils/BufferGeometryUtils.js';
import { Element } from '../core/Element.js';
import { HALF, worldToUV } from '../core/constants.js';
import { noiseGLSL, toonParsVertex, toonShadowVertex, toonParsFragment } from '../core/shaders/toon.glsl.js';

/** Hard cap on planted trees. */
const MAX_TREES = 500;
/** Per-InstancedMesh capacity — the global cap, so any variant mix fits. */
const VARIANT_CAPACITY = MAX_TREES;
/** Minimum distance between two trunks, world units. */
const MIN_SPACING = 1.2;
/** Spawn probability per stamp, multiplied by the stamp strength. */
const SPAWN_CHANCE = 0.12;
/** Trees refuse ground steeper than this (world normal Y). */
const MIN_NORMAL_Y = 0.7;
/** Largest lean the sway spring may reach, radians. */
const MAX_LEAN = 0.45;
/** Reused Y axis for the per-instance yaw. */
const UP = new THREE.Vector3(0, 1, 0);

/**
 * Blueprint for one tree shape: a tapered trunk plus overlapping canopy blobs.
 * `y` values are in "unit tree" space, scaled per instance by `aScale`.
 */
const VARIANTS = [
  {
    name: 'broadleaf',
    trunk: { top: 0.11, bottom: 0.2, height: 1.5, sides: 7 },
    blobs: [
      { x: 0, y: 2.05, z: 0, rx: 1.05, ry: 0.85, rz: 1.05 },
      { x: 0.62, y: 1.75, z: 0.28, rx: 0.72, ry: 0.6, rz: 0.72 },
      { x: -0.55, y: 1.85, z: -0.35, rx: 0.66, ry: 0.56, rz: 0.66 },
      { x: 0.15, y: 2.62, z: -0.2, rx: 0.62, ry: 0.55, rz: 0.62 },
      { x: -0.22, y: 2.4, z: 0.5, rx: 0.55, ry: 0.5, rz: 0.55 },
    ],
  },
  {
    name: 'camphor',
    trunk: { top: 0.16, bottom: 0.3, height: 1.0, sides: 7 },
    blobs: [
      { x: 0, y: 1.5, z: 0, rx: 1.35, ry: 0.85, rz: 1.25 },
      { x: 0.95, y: 1.25, z: 0.2, rx: 0.8, ry: 0.6, rz: 0.8 },
      { x: -0.9, y: 1.3, z: -0.25, rx: 0.85, ry: 0.62, rz: 0.8 },
      { x: 0.1, y: 2.0, z: -0.15, rx: 0.8, ry: 0.65, rz: 0.8 },
    ],
  },
  {
    name: 'cypress',
    trunk: { top: 0.09, bottom: 0.16, height: 1.4, sides: 6 },
    blobs: [
      { x: 0, y: 1.9, z: 0, rx: 0.62, ry: 0.95, rz: 0.62 },
      { x: 0, y: 2.75, z: 0, rx: 0.52, ry: 0.8, rz: 0.52 },
      { x: 0.05, y: 3.45, z: 0, rx: 0.36, ry: 0.6, rz: 0.36 },
    ],
  },
];

/**
 * Deterministic 0..1 hash of three numbers, used to rough up the canopy blobs.
 * @param {number} x
 * @param {number} y
 * @param {number} z
 * @returns {number} 0..1
 */
function hash3(x, y, z) {
  const s = Math.sin(x * 127.1 + y * 311.7 + z * 74.7) * 43758.5453;
  return s - Math.floor(s);
}

/**
 * Ghibli-style toon trees painted onto the ground. Each tree is an instance of
 * one of three geometry variants; wind sway is a per-tree damped angular spring
 * simulated on the CPU and handed to the vertex shader as `aBend`.
 */
export class Trees extends Element {
  static id = 'trees';
  static label = 'Trees';
  static order = 40;

  /**
   * @param {object} ctx shared app context
   */
  constructor(ctx) {
    super(ctx);

    /** @type {Array<object>} every planted tree, newest last */
    this.trees = [];
    /** @type {Array<{mesh: THREE.InstancedMesh, geometry: THREE.BufferGeometry, trees: Array<object>, bend: THREE.InstancedBufferAttribute, variation: THREE.InstancedBufferAttribute, phase: THREE.InstancedBufferAttribute}>} */
    this.variants = [];
    /** @type {{stiffness:number, swayAmount:number, flutter:number, canopyShade:string, canopyLight:string, highlight:string, trunk:string}} */
    this.params = {
      stiffness: 6,
      swayAmount: 0.28,
      flutter: 0.035,
      canopyShade: '#3f7d34',
      canopyLight: '#9ad35a',
      highlight: '#d8f08a',
      trunk: '#7a5a3a',
    };

    /** @type {THREE.Group|null} everything this element draws, for the Outliner */
    this.root = null;
    this._material = null;
    this._matrix = new THREE.Matrix4();
    this._pos = new THREE.Vector3();
    this._quat = new THREE.Quaternion();
    this._scaleVec = new THREE.Vector3();
    this._normal = new THREE.Vector3();
    this._rapier = null;
    this._physicsPending = false;
  }

  // --- lifecycle ----------------------------------------------------------

  /** Build the three instanced meshes, the toon material and the brush tool. */
  async init() {
    const ctx = this.ctx;

    this._material = this._buildMaterial();
    this._material.userData.uiProps = this._materialProps();
    this._material.userData.swatch = [this.params.canopyLight, this.params.canopyShade, this.params.trunk];
    ctx.style?.attach?.(this._material, { element: Trees.id });

    // One group holds all three variant meshes so the inspector's Outliner
    // shows a single 'Trees' node. Left at the origin: instances are placed in
    // world space, so the group's transform must stay identity.
    this.root = new THREE.Group();
    this.root.name = 'Trees';
    ctx.scene.add(this.root);

    for (let v = 0; v < VARIANTS.length; v++) {
      const geometry = this._buildVariantGeometry(v);
      const mesh = new THREE.InstancedMesh(geometry, this._material, VARIANT_CAPACITY);
      mesh.name = `trees:${VARIANTS[v].name}`;
      mesh.count = 0;
      mesh.castShadow = true;
      mesh.receiveShadow = true;
      mesh.frustumCulled = false; // instances span the whole world; bend leaves the bounds
      mesh.instanceMatrix.setUsage(THREE.DynamicDrawUsage);
      this.root.add(mesh);

      this.variants.push({
        mesh,
        geometry,
        trees: [],
        bend: geometry.getAttribute('aBend'),
        variation: geometry.getAttribute('aVar'),
        phase: geometry.getAttribute('aPhase'),
      });
    }

    ctx.brush.registerTool({
      id: 'trees',
      label: 'Trees',
      color: '#2e8b57',
      key: '7',
      element: 'trees',   // History snapshots this element around the stroke
      mode: 'add',
      eraseMode: 'erase',
      strengthScale: 8,
      onStamp: (_ctx, op, hit) => this._onStamp(op, hit),
    });
  }

  /**
   * @param {object} ui ghost-panel root
   */
  buildPanel(ui) {
    const f = ui.addFolder('Trees');
    const u = this._material.uniforms;

    f.addSlider('Sway stiffness', {
      min: 1,
      max: 20,
      step: 0.5,
      value: this.params.stiffness,
      onChange: (v) => {
        this.params.stiffness = v;
      },
    });
    f.addSlider('Sway amount', {
      min: 0,
      max: 0.8,
      step: 0.01,
      value: this.params.swayAmount,
      onChange: (v) => {
        this.params.swayAmount = v;
      },
    });
    f.addSlider('Flutter', {
      min: 0,
      max: 0.12,
      step: 0.005,
      value: this.params.flutter,
      onChange: (v) => {
        this.params.flutter = v;
        u.uFlutter.value = v;
      },
    });
    f.addColor('Canopy shade', {
      value: this.params.canopyShade,
      onChange: (hex) => {
        this.params.canopyShade = hex;
        u.uCanopyDark.value.set(hex);
      },
    });
    f.addColor('Canopy light', {
      value: this.params.canopyLight,
      onChange: (hex) => {
        this.params.canopyLight = hex;
        u.uCanopyLight.value.set(hex);
      },
    });
    f.addColor('Canopy highlight', {
      value: this.params.highlight,
      onChange: (hex) => {
        this.params.highlight = hex;
        u.uHighlight.value.set(hex);
      },
    });
    f.addColor('Trunk', {
      value: this.params.trunk,
      onChange: (hex) => {
        this.params.trunk = hex;
        u.uTrunk.value.set(hex);
      },
    });
    f.addButton('Clear trees', () => this.ctx.history.wrap('Clear trees', () => this.clear(), { element: 'trees' }));
  }

  // --- public API ---------------------------------------------------------

  /**
   * Plant one tree at a world position, if the ground allows it.
   * @param {number} x world x
   * @param {number} z world z
   * @param {{variant?:number, scale?:number, hue?:number, rot?:number, force?:boolean}} [opts]
   * @returns {object|null} the tree record, or null when the spot was rejected
   */
  spawnAt(x, z, opts = {}) {
    if (!opts.force && !this.canPlant(x, z)) return null;
    if (this.trees.length >= MAX_TREES) return null;

    const variant = opts.variant ?? (Math.random() * VARIANTS.length) | 0;
    const slot = this.variants[variant];
    if (!slot || slot.trees.length >= VARIANT_CAPACITY) return null;

    const tree = {
      x,
      z,
      y: this.ctx.terrain.heightAt(x, z),
      variant,
      scale: opts.scale ?? 0.7 + Math.random() * 0.7,
      hue: opts.hue ?? Math.random(),
      rot: opts.rot ?? Math.random() * Math.PI * 2,
      phase: Math.random(),
      ang: { x: 0, z: 0 },
      vel: { x: 0, z: 0 },
      index: slot.trees.length,
      body: null,
    };

    slot.trees.push(tree);
    this.trees.push(tree);
    slot.mesh.count = slot.trees.length;
    this._writeInstance(slot, tree);
    this._addBody(tree);
    return tree;
  }

  /**
   * Is this spot plantable? Checks the cap, the world bounds, the water / path
   * / mask layers, the slope and the minimum spacing.
   * @param {number} x world x
   * @param {number} z world z
   * @returns {boolean}
   */
  canPlant(x, z) {
    if (this.trees.length >= MAX_TREES) return false;
    if (Math.abs(x) > HALF - 0.5 || Math.abs(z) > HALF - 0.5) return false;

    const layers = this.ctx.layers;
    const { u, v } = worldToUV(x, z);
    if ((layers.get('water')?.sample(u, v) ?? 0) > 0.3) return false;
    if ((layers.get('path')?.sample(u, v) ?? 0) > 0.35) return false;
    if ((layers.get('mask')?.sample(u, v) ?? 0) > 0.1) return false;

    if (this.ctx.terrain.normalAt(x, z, this._normal).y < MIN_NORMAL_Y) return false;

    const minSq = MIN_SPACING * MIN_SPACING;
    for (const t of this.trees) {
      const dx = t.x - x;
      const dz = t.z - z;
      if (dx * dx + dz * dz < minSq) return false;
    }
    return true;
  }

  /**
   * Remove every tree whose trunk falls inside a world-space disc.
   * @param {number} x world x
   * @param {number} z world z
   * @param {number} radius world units
   * @returns {number} how many trees were removed
   */
  eraseAt(x, z, radius) {
    const rSq = radius * radius;
    let removed = 0;
    for (let i = this.trees.length - 1; i >= 0; i--) {
      const t = this.trees[i];
      const dx = t.x - x;
      const dz = t.z - z;
      if (dx * dx + dz * dz <= rSq) {
        this._removeTree(t);
        removed++;
      }
    }
    return removed;
  }

  /** Remove every tree. */
  clear() {
    for (const tree of this.trees) this._removeBody(tree);
    this.trees.length = 0;
    for (const slot of this.variants) {
      slot.trees.length = 0;
      slot.mesh.count = 0;
    }
  }

  // --- per frame ----------------------------------------------------------

  /**
   * Integrate every tree's sway spring and upload the bend attribute.
   * @param {number} dt seconds
   * @param {number} time seconds since start
   */
  update(dt, time) {
    if (!this._rapier && !this._physicsPending && this.ctx.physics?.ready) this._initPhysics();
    if (!this.trees.length) return;

    const wind = this.ctx.wind;
    const amount = this.params.swayAmount;

    for (const slot of this.variants) {
      if (!slot.trees.length) continue;
      const bend = slot.bend.array;

      for (const tree of slot.trees) {
        const w = wind.sampleAt(tree.x, tree.z, time);
        // Per-tree phase noise so a stand of trees never moves in lockstep.
        const wobble = Math.sin(time * 1.7 + tree.phase * 6.283) * 0.1;
        const mag = Math.hypot(w.x, w.z);
        const tx = (w.x * 0.9 + wobble * mag) * amount;
        const tz = (w.z * 0.9 + wobble * mag) * amount;

        // Under-damped angular spring; big trees are stiffer, so they lean less
        // and recover faster than saplings.
        const k = this.params.stiffness / tree.scale;
        const c = 2 * Math.sqrt(k) * 0.35;
        tree.vel.x += (k * (tx - tree.ang.x) - c * tree.vel.x) * dt;
        tree.vel.z += (k * (tz - tree.ang.z) - c * tree.vel.z) * dt;
        tree.ang.x = Math.max(-MAX_LEAN, Math.min(MAX_LEAN, tree.ang.x + tree.vel.x * dt));
        tree.ang.z = Math.max(-MAX_LEAN, Math.min(MAX_LEAN, tree.ang.z + tree.vel.z * dt));

        bend[tree.index * 2] = tree.ang.x;
        bend[tree.index * 2 + 1] = tree.ang.z;
      }
      slot.bend.needsUpdate = true;
    }
  }

  /** Re-seat every trunk after the ground was sculpted. */
  onTerrainChanged() {
    if (!this.trees.length) return;
    for (const slot of this.variants) {
      for (const tree of slot.trees) {
        tree.y = this.ctx.terrain.heightAt(tree.x, tree.z);
        this._writeInstance(slot, tree);
        if (tree.body) tree.body.setTranslation({ x: tree.x, y: tree.y + this._halfHeight(tree), z: tree.z }, true);
      }
    }
  }

  /**
   * Recolour for the active style. Only the keys present are written.
   * @param {{canopyShade?:string, canopyLight?:string, highlight?:string, trunk?:string}} [p]
   * @returns {Trees}
   */
  applyPalette(p) {
    if (!p || !this._material) return this;
    const u = this._material.uniforms;
    if (p.canopyShade != null) {
      this.params.canopyShade = p.canopyShade;
      u.uCanopyDark.value.set(p.canopyShade);
    }
    if (p.canopyLight != null) {
      this.params.canopyLight = p.canopyLight;
      u.uCanopyLight.value.set(p.canopyLight);
    }
    if (p.highlight != null) {
      this.params.highlight = p.highlight;
      u.uHighlight.value.set(p.highlight);
    }
    if (p.trunk != null) {
      this.params.trunk = p.trunk;
      u.uTrunk.value.set(p.trunk);
    }
    return this;
  }

  // --- save / load --------------------------------------------------------

  /** @returns {object} the sway/colour params plus every tree as [x, z, variant, scale, hue, rot] */
  serialize() {
    return {
      trees: this.trees.map((t) => [
        Number(t.x.toFixed(3)),
        Number(t.z.toFixed(3)),
        t.variant,
        Number(t.scale.toFixed(3)),
        Number(t.hue.toFixed(3)),
        Number(t.rot.toFixed(3)),
      ]),
      ...this.params,
    };
  }

  /**
   * @param {object} o output of `serialize()`
   */
  deserialize(o = {}) {
    for (const key of Object.keys(this.params)) {
      if (o[key] !== undefined) this.params[key] = o[key];
    }
    this._material.uniforms.uFlutter.value = this.params.flutter;
    this.applyPalette(this.params);
    if (!Array.isArray(o.trees)) return;

    this.clear();
    for (const t of o.trees) {
      const [x, z, variant, scale, hue, rot] = t;
      this.spawnAt(x, z, { variant, scale, hue, rot, force: true });
    }
  }

  dispose() {
    this.clear();
    for (const slot of this.variants) {
      slot.mesh.removeFromParent();
      slot.mesh.dispose();
      slot.geometry.dispose();
    }
    this.variants.length = 0;
    this.ctx.style?.detach?.(this._material);
    this._material.dispose();
    this.root?.removeFromParent();
    this.root = null;
  }

  // --- internals ----------------------------------------------------------

  /**
   * @private Brush callback: plant or erase inside the stamp disc.
   * @param {object} op stamp op (UV space)
   * @param {{x:number, z:number}} hit world-space brush centre
   */
  _onStamp(op, hit) {
    const radius = this.ctx.brush.settings.radius;
    if (op.mode === 'erase') {
      this.eraseAt(hit.x, hit.z, radius);
      return;
    }
    if (Math.random() > SPAWN_CHANCE * op.strength) return;
    const a = Math.random() * Math.PI * 2;
    const r = Math.sqrt(Math.random()) * radius;
    this.spawnAt(hit.x + Math.cos(a) * r, hit.z + Math.sin(a) * r);
  }

  /**
   * @private Drop a tree out of its variant, swapping the last instance into
   * the freed slot so the instance buffer stays dense.
   * @param {object} tree
   */
  _removeTree(tree) {
    const slot = this.variants[tree.variant];
    const last = slot.trees[slot.trees.length - 1];
    slot.trees[tree.index] = last;
    last.index = tree.index;
    slot.trees.pop();
    slot.mesh.count = slot.trees.length;
    if (last !== tree) this._writeInstance(slot, last);

    const i = this.trees.indexOf(tree);
    if (i >= 0) this.trees.splice(i, 1);
    this._removeBody(tree);
  }

  /**
   * @private Write one tree's matrix and static per-instance attributes.
   * @param {object} slot variant record
   * @param {object} tree
   */
  _writeInstance(slot, tree) {
    this._pos.set(tree.x, tree.y, tree.z);
    this._quat.setFromAxisAngle(UP, tree.rot);
    this._scaleVec.setScalar(tree.scale);
    this._matrix.compose(this._pos, this._quat, this._scaleVec);
    slot.mesh.setMatrixAt(tree.index, this._matrix);
    slot.mesh.instanceMatrix.needsUpdate = true;
    slot.variation.array[tree.index] = tree.hue;
    slot.phase.array[tree.index] = tree.phase;
    slot.variation.needsUpdate = true;
    slot.phase.needsUpdate = true;
  }

  /**
   * @private Half the trunk height in world units, for the cylinder collider.
   * @param {object} tree
   * @returns {number}
   */
  _halfHeight(tree) {
    return VARIANTS[tree.variant].trunk.height * tree.scale * 0.5;
  }

  /** @private Load Rapier lazily and give every existing tree a trunk collider. */
  _initPhysics() {
    this._physicsPending = true;
    import('@dimforge/rapier3d-compat')
      .then((mod) => {
        this._rapier = mod.default ?? mod;
        for (const tree of this.trees) this._addBody(tree);
      })
      .catch(() => {
        this._rapier = null; // Rapier unavailable: trees stay decorative
      });
  }

  /**
   * @private Fixed cylinder collider at the trunk so rocks bounce off.
   * @param {object} tree
   */
  _addBody(tree) {
    const physics = this.ctx.physics;
    if (!this._rapier || !physics?.ready || tree.body) return;
    const RAPIER = this._rapier;
    const half = this._halfHeight(tree);
    const radius = VARIANTS[tree.variant].trunk.bottom * tree.scale * 1.4;
    const rb = RAPIER.RigidBodyDesc.fixed().setTranslation(tree.x, tree.y + half, tree.z);
    const col = RAPIER.ColliderDesc.cylinder(half, radius).setFriction(0.9).setRestitution(0.2);
    tree.body = physics.addRigidBody(rb, col);
  }

  /**
   * @private
   * @param {object} tree
   */
  _removeBody(tree) {
    if (!tree.body) return;
    this.ctx.physics?.remove(tree.body);
    tree.body = null;
  }

  /**
   * @private Build one variant's merged geometry with the per-vertex
   * attributes the shader needs, plus empty per-instance attributes.
   * @param {number} index into VARIANTS
   * @returns {THREE.BufferGeometry}
   */
  _buildVariantGeometry(index) {
    const spec = VARIANTS[index];
    let height = spec.trunk.height;
    for (const b of spec.blobs) height = Math.max(height, b.y + b.ry);

    const parts = [];

    const trunk = new THREE.CylinderGeometry(
      spec.trunk.top,
      spec.trunk.bottom,
      spec.trunk.height,
      spec.trunk.sides,
      1,
    );
    trunk.translate(0, spec.trunk.height * 0.5, 0);
    parts.push(this._prepPart(trunk, 0, height, null));

    for (let i = 0; i < spec.blobs.length; i++) {
      const b = spec.blobs[i];
      const blob = new THREE.IcosahedronGeometry(1, 1);
      const pos = blob.attributes.position.array;
      for (let p = 0; p < pos.length; p += 3) {
        // Rough the sphere up so canopies read as clumps of leaves, not balls.
        const d = 0.86 + 0.28 * hash3(pos[p] + i * 3.7, pos[p + 1], pos[p + 2]);
        pos[p] *= b.rx * d;
        pos[p + 1] *= b.ry * d;
        pos[p + 2] *= b.rz * d;
      }
      blob.translate(b.x, b.y, b.z);
      parts.push(this._prepPart(blob, 1, height, b));
    }

    const geometry = mergeGeometries(parts, false);
    for (const part of parts) part.dispose();
    geometry.computeBoundingSphere();

    geometry.setAttribute(
      'aBend',
      new THREE.InstancedBufferAttribute(new Float32Array(VARIANT_CAPACITY * 2), 2).setUsage(
        THREE.DynamicDrawUsage,
      ),
    );
    geometry.setAttribute(
      'aVar',
      new THREE.InstancedBufferAttribute(new Float32Array(VARIANT_CAPACITY), 1),
    );
    geometry.setAttribute(
      'aPhase',
      new THREE.InstancedBufferAttribute(new Float32Array(VARIANT_CAPACITY), 1),
    );
    return geometry;
  }

  /**
   * @private Flatten a sub-geometry and tag it with aCanopy / aH / aBlobN.
   * `aBlobN` is the smooth outward direction of the blob a vertex belongs to —
   * flutter displaces along it so co-located flat-shaded vertices stay welded.
   * @param {THREE.BufferGeometry} source
   * @param {number} canopy 1 for canopy, 0 for trunk
   * @param {number} height full tree height in unit-tree space
   * @param {{x:number,y:number,z:number}|null} centre blob centre, or null for the trunk
   * @returns {THREE.BufferGeometry}
   */
  _prepPart(source, canopy, height, centre) {
    const g = source.index ? source.toNonIndexed() : source;
    if (g !== source) source.dispose();
    g.deleteAttribute('uv');
    g.computeVertexNormals(); // non-indexed -> flat, faceted toon normals

    const pos = g.attributes.position.array;
    const count = pos.length / 3;
    const blobN = new Float32Array(pos.length);
    const isCanopy = new Float32Array(count);
    const h = new Float32Array(count);

    for (let i = 0; i < count; i++) {
      const o = i * 3;
      isCanopy[i] = canopy;
      h[i] = Math.min(1, Math.max(0, pos[o + 1] / height));
      if (centre) {
        const dx = pos[o] - centre.x;
        const dy = pos[o + 1] - centre.y;
        const dz = pos[o + 2] - centre.z;
        const len = Math.hypot(dx, dy, dz) || 1;
        blobN[o] = dx / len;
        blobN[o + 1] = dy / len;
        blobN[o + 2] = dz / len;
      }
    }

    g.setAttribute('aBlobN', new THREE.BufferAttribute(blobN, 3));
    g.setAttribute('aCanopy', new THREE.BufferAttribute(isCanopy, 1));
    g.setAttribute('aH', new THREE.BufferAttribute(h, 1));
    return g;
  }

  /**
   * @private Canopy and trunk colours, for the inspector's Material folder.
   * Every setter goes through `applyPalette`, so a style switch and a hand
   * edit write the same place. See "Material descriptors" in ARCHITECTURE.md.
   * @returns {Array<object>}
   */
  _materialProps() {
    const p = this.params;
    const swatch = (label, key, tooltip) => ({
      label,
      kind: 'color',
      tooltip,
      get: () => p[key],
      set: (v) => this.applyPalette({ [key]: v }),
    });
    return [
      swatch('Canopy shade', 'canopyShade', 'Deep leaf colour, away from the sun'),
      swatch('Canopy light', 'canopyLight', 'Leaf colour facing the sun'),
      swatch('Highlight', 'highlight', 'Warm rim on the topmost leaves'),
      swatch('Trunk', 'trunk', 'Trunk and branch colour'),
    ];
  }

  /**
   * @private The shared toon material: height-banded canopy, warm sun facets,
   * shadow receive, GPU bend + flutter.
   * @returns {THREE.ShaderMaterial}
   */
  _buildMaterial() {
    const { sun, wind } = this.ctx;
    const color = (hex) => ({ value: new THREE.Color(hex) });

    const uniforms = Object.assign(
      THREE.UniformsUtils.clone(THREE.UniformsLib.lights),
      THREE.UniformsUtils.clone(THREE.UniformsLib.fog),
      sun.uniforms,
      wind.uniforms,
      {
        uTrunk: color(this.params.trunk),
        uCanopyDark: color(this.params.canopyShade),
        uCanopyLight: color(this.params.canopyLight),
        uHighlight: color(this.params.highlight),
        uFlutter: { value: this.params.flutter },
      },
    );

    const vertexShader = /* glsl */ `
      ${toonParsVertex}
      ${noiseGLSL}
      #include <fog_pars_vertex>

      attribute vec3 aBlobN;
      attribute float aCanopy;
      attribute float aH;
      attribute vec2 aBend;
      attribute float aVar;
      attribute float aPhase;

      uniform float uFlutter;

      varying float vCanopy;
      varying float vH;
      varying float vVar;

      void main() {
        vCanopy = aCanopy;
        vH = aH;
        vVar = aVar;

        vec3 pos = position;
        // Shade the canopy mostly by the blob's smooth outward direction so the
        // cel bands land as big coherent lit / shadow areas instead of one
        // speckle per facet; keep a little facet normal for leafy break-up.
        vec3 nrm = mix(normal, normalize(mix(normal, aBlobN, 0.72)), aCanopy);
        vec3 blobN = aBlobN;
        float instScale = 1.0;
        #ifdef USE_INSTANCING
          pos = (instanceMatrix * vec4(pos, 1.0)).xyz;
          nrm = mat3(instanceMatrix) * nrm;
          blobN = mat3(instanceMatrix) * blobN;
          instScale = length(instanceMatrix[1].xyz);
        #endif

        // Height-weighted lean: the crown swings, the trunk barely moves.
        float wy = position.y * instScale;
        float lean = wy * aH;
        pos.xz += aBend * lean * 0.9;
        pos.y -= length(aBend) * lean * 0.2;

        // Canopy flutter along the blob's smooth outward direction.
        float gust = uWindStrength * (0.35 + 0.65 * uGust);
        float flutter = uFlutter * aCanopy * (0.3 + gust)
          * sin(uTime * 4.0 + aPhase * 6.2831 + wy * 3.0);
        pos += blobN / max(length(blobN), 1e-4) * flutter;

        vec4 worldPosition = modelMatrix * vec4(pos, 1.0);
        vec3 transformedNormal = normalMatrix * normalize(nrm);
        ${toonShadowVertex}
        #include <fog_vertex>
      }
    `;

    const fragmentShader = /* glsl */ `
      ${toonParsFragment}
      #include <fog_pars_fragment>

      uniform float uStyleId;
      uniform vec3 uTrunk;
      uniform vec3 uCanopyDark;
      uniform vec3 uCanopyLight;
      uniform vec3 uHighlight;

      varying float vCanopy;
      varying float vH;
      varying float vVar;

      void main() {
        vec3 n = normalize(vNormalW);

        // Vertical canopy gradient, broken up by noise then quantised into
        // three flat colour bands the way cel painters block in foliage.
        float t = smoothstep(0.35, 1.0, vH) + (fbm(vWorldPos.xz * 1.6, 2) - 0.5) * 0.35;
        float q = clamp(floor(clamp(t, 0.0, 1.0) * 3.0) / 2.0, 0.0, 1.0);

        // --- style branches (see "Style branches" in ARCHITECTURE.md) ---
        if (uStyleId > 0.5 && uStyleId < 1.5) {
          q = step(0.5, smoothstep(0.35, 1.0, vH));          // flat: two inks
        } else if (uStyleId > 1.5 && uStyleId < 2.5) {
          q = clamp(smoothstep(0.2, 1.0, vH), 0.0, 1.0);      // realistic: smooth canopy
        } else if (uStyleId > 2.5 && uStyleId < 3.5) {
          q = clamp(t, 0.0, 1.0);                             // painterly: washed gradient
        } else if (uStyleId > 3.5) {
          q = step(0.5, t);                                   // pixel: two inks, hard edge
        }
        vec3 canopy = mix(uCanopyDark, uCanopyLight, q);

        // Per-tree hue drift: cool blue-green through warm yellow-green.
        canopy *= mix(vec3(0.86, 1.02, 0.94), vec3(1.12, 0.99, 0.78), vVar);

        vec3 albedo = mix(uTrunk * (0.85 + 0.3 * vVar), canopy, vCanopy);

        // Hard warm dab where a facet points straight at the sun — smoothed
        // for the realistic style, dropped entirely for flat.
        float hi = step(0.82, dot(n, uSunDir)) * vCanopy;
        if (uStyleId > 0.5 && uStyleId < 1.5) hi = 0.0;
        else if (uStyleId > 1.5 && uStyleId < 2.5) hi = smoothstep(0.7, 1.0, dot(n, uSunDir)) * vCanopy;
        albedo = mix(albedo, uHighlight, hi * 0.5);

        vec3 col = toonLight(albedo, n, toonShadow(), 3.0);

        gl_FragColor = vec4(col, toonInkAlpha());
        #include <fog_fragment>
        #include <colorspace_fragment>
      }
    `;

    return new THREE.ShaderMaterial({
      name: 'Tree',
      uniforms,
      vertexShader,
      fragmentShader,
      lights: true,
      fog: true,
      toneMapped: false,
    });
  }
}
