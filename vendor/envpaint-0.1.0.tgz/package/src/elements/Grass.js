import * as THREE from 'three';
import { Element } from '../core/Element.js';
import { Cutouts } from '../core/Cutouts.js';
import { PaintLayer } from '../core/PaintLayers.js';
import { WORLD_SIZE, HALF, LAYER_RES } from '../core/constants.js';
import { noiseGLSL, toonParsVertex, toonShadowVertex, toonParsFragment } from '../core/shaders/toon.glsl.js';

const DEG = Math.PI / 180;

/** Segments along a blade; (SEG + 1) * 2 vertices per blade. */
const SEG = 4;

/** Layer uniforms that other modules own and may register after Grass. */
const EXTERNAL_LAYERS = [
  ['uHeight', 'height'],
  ['uMask', 'mask'],
  ['uPath', 'path'],
  ['uWater', 'water'],
  ['uPress', 'press'],
];

/**
 * 1x1 stand-in for a layer that has no owner yet.
 * @param {number[]} rgba four bytes
 * @param {string} name
 * @returns {THREE.DataTexture}
 */
function placeholderTexture(rgba, name) {
  const tex = new THREE.DataTexture(new Uint8Array(rgba), 1, 1);
  tex.name = name;
  tex.minFilter = THREE.NearestFilter;
  tex.magFilter = THREE.NearestFilter;
  tex.generateMipmaps = false;
  tex.needsUpdate = true;
  return tex;
}

/**
 * Deterministic 32-bit PRNG so a reload lays out identical blades.
 * @param {number} seed
 * @returns {() => number} generator of floats in [0, 1)
 */
function mulberry32(seed) {
  let a = seed >>> 0;
  return function next() {
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

const vertexShader = /* glsl */ `
#define WORLD_SIZE ${WORLD_SIZE.toFixed(1)}
#define TEXEL ${(1 / LAYER_RES).toFixed(8)}
#define TAU 6.2831853

${toonParsVertex}
${noiseGLSL}
#include <fog_pars_vertex>

uniform sampler2D uGrass;
uniform sampler2D uMask;
uniform sampler2D uComb;
uniform sampler2D uHeight;
uniform sampler2D uPath;
uniform sampler2D uWater;
uniform sampler2D uPress;

uniform float uDensity;
uniform float uNoiseScale;
uniform float uNoiseStrength;
uniform float uBladeHeight;
uniform float uBladeWidth;
uniform float uLean;
uniform float uDirection;
uniform float uDirectionJitter;
uniform float uCombStrength;
uniform float uWindResponse;
uniform float uStyleId;   // 0 ghibli · 1 flat · 2 realistic · 3 painterly · 4 pixel
uniform float uZoom;      // camera frustum half-height: how far away we are
#define MAX_CUTOUTS 8
uniform vec3 uCutouts[MAX_CUTOUTS]; // x, z, radius of bare discs under props
uniform int uCutoutCount;
uniform vec3 uSunDir;

attribute vec2 aOffset;
attribute vec4 aRand;
attribute vec2 aBlade;

varying float vT;
varying vec4 vRand;
varying float vNoise;

const vec2 NOISE_SEED = vec2(17.3, 41.7);

void main() {
  vec2 luv = aOffset / WORLD_SIZE + 0.5;

  float density = texture2D(uGrass, luv).r;
  float maskV = texture2D(uMask, luv).r;
  float waterV = texture2D(uWater, luv).r;
  float pathV = texture2D(uPath, luv).r;
  float h = texture2D(uHeight, luv).r;

  // Terrain normal from central differences of the height layer: grass thins out on cliffs.
  float hx0 = texture2D(uHeight, luv - vec2(TEXEL, 0.0)).r;
  float hx1 = texture2D(uHeight, luv + vec2(TEXEL, 0.0)).r;
  float hz0 = texture2D(uHeight, luv - vec2(0.0, TEXEL)).r;
  float hz1 = texture2D(uHeight, luv + vec2(0.0, TEXEL)).r;
  float span = 2.0 * TEXEL * WORLD_SIZE;
  vec3 groundN = normalize(vec3(-(hx1 - hx0) / span, 1.0, -(hz1 - hz0) / span));

  // Everything but the patchiness noise, which can only lower the survival odds.
  // The mask is a hard cutoff so one brush pass clears grass outright.
  float base = density * uDensity * step(maskV, 0.35)
    * step(pathV, 0.5) * step(waterV, 0.15) * smoothstep(0.45, 0.7, groundN.y);

  float n = 0.0;
  float p = 0.0;
  if (base > aRand.x) {
    n = fbm(luv * uNoiseScale * 40.0 + NOISE_SEED, 4);
    p = base * mix(1.0, smoothstep(0.25, 0.75, n), uNoiseStrength);
  }

  vT = 0.0;
  vRand = vec4(0.0);
  vNoise = 0.0;
  vWorldPos = vec3(0.0);
  vNormalW = vec3(0.0, 1.0, 0.0);
  #ifdef USE_FOG
    vFogDepth = 0.0;
  #endif

  if (p <= aRand.x) {
    gl_Position = vec4(2.0, 2.0, 2.0, 1.0);
    return;
  }
  // Bare discs under props (see core/Cutouts.js): nothing grows inside one.
  for (int i = 0; i < MAX_CUTOUTS; i++) {
    if (i >= uCutoutCount) break;
    if (distance(aOffset, uCutouts[i].xy) < uCutouts[i].z) {
      gl_Position = vec4(2.0, 2.0, 2.0, 1.0);
      return;
    }
  }

  float t = aBlade.y;
  float sideS = aBlade.x;

  float heightNoise = mix(0.65, 1.35, fbm(luv * 25.0 + 7.3, 3));
  float bh = uBladeHeight * heightNoise * mix(0.7, 1.3, aRand.z);
  float width = uBladeWidth * (1.0 - pow(t, 1.3));

  // --- style branches (see "Style branches" in ARCHITECTURE.md) ---
  if (uStyleId > 2.5 && uStyleId < 3.5) {
    // Painterly: soft dabs — wider, shorter, blunt-tipped.
    width = uBladeWidth * 1.6 * (1.0 - pow(t, 2.6));
    bh *= 0.8;
  } else if (uStyleId > 3.5) {
    // Pixel: far fewer, far fatter blades, so each one covers whole pixels.
    if (aRand.z > 0.4) {
      gl_Position = vec4(2.0, 2.0, 2.0, 1.0);
      return;
    }
    width = uBladeWidth * 2.0 * (1.0 - pow(t, 2.0));
    bh *= 1.1;
  }

  // Where the comb layer is painted it replaces the global lean entirely, and
  // damps the per-blade jitter so the patch reads as parted rather than wild.
  vec2 comb = texture2D(uComb, luv).rg * 2.0 - 1.0;
  float combMag = clamp(length(comb) * 1.4, 0.0, 1.0);
  float ang = uDirection + (aRand.y - 0.5) * uDirectionJitter * (1.0 - combMag * 0.7);
  vec2 lean = mix(
    vec2(cos(ang), sin(ang)) * uLean,
    normalize(comb + 1e-5) * uCombStrength,
    combMag
  );

  // Wind now, plus how fast it is changing: a blade leads into an arriving
  // gust and springs back past neutral as it leaves, instead of following
  // the field like a cork on a swell. Fast tip flutter only where it blows.
  float tw = uTime * uWindSpeed;
  vec2 wNow = windAtT(aOffset, tw);
  vec2 wPast = windAtT(aOffset, tw - 0.12);
  vec2 windV = (wNow + (wNow - wPast) * 1.8) * uWindResponse;
  float wm = length(wNow);
  windV += uWindDir * wm * 0.22 * sin(tw * 6.5 + aRand.w * TAU + aOffset.y * 1.3) * uWindResponse;

  vec2 bend2 = lean + windV;

  // Anything heavy rolling over the ground (Rocks) presses blades flat and
  // shoves them aside. RG is a direction in layer UV, whose axes are world XZ.
  vec4 pr = texture2D(uPress, luv);
  vec2 pushDir = pr.rg * 2.0 - 1.0;
  float push = pr.b;
  bend2 += pushDir * push * 2.2;
  bh *= 1.0 - 0.55 * push;

  float bendAmt = length(bend2);

  // Quadratic curve in t; the tip sinks as it bends so the blade keeps its length.
  vec3 pos = vec3(
    bend2.x * bh * t * t,
    bh * t * (1.0 - 0.3 * bendAmt * t * t),
    bend2.y * bh * t * t
  );

  float r = aRand.y * TAU;
  vec3 sideDir = vec3(cos(r), 0.0, sin(r));
  pos += sideDir * width * sideS * 0.5;

  vec3 world = vec3(aOffset.x, h, aOffset.y) + pos;

  // One flat normal for the whole blade (tangent taken at mid-height) so each
  // blade lands wholly in one cel band; the per-blade nudge toward the sun
  // breaks up band alignment between neighbours.
  vec3 tangent = normalize(vec3(
    bend2.x * bh,
    bh * (1.0 - 0.225 * bendAmt),
    bend2.y * bh
  ));
  vec3 nrm = normalize(cross(sideDir, tangent));
  // Per-blade nudge toward the sun breaks up band alignment between
  // neighbours — but zoomed out a blade is a pixel wide and the nudge reads as
  // salt-and-pepper speckle, so it fades away with distance.
  float far = smoothstep(9.0, 22.0, uZoom);
  // Flat, realistic and pixel all want blades that agree with each other: the
  // band-breaking jitter is a cel-painting trick and belongs to the toon and
  // painterly looks only.
  float jitter = (uStyleId > 0.5 && uStyleId < 3.5) ? 0.0 : 0.35;
  nrm = normalize(nrm + uSunDir * (aRand.w - 0.5) * jitter * (1.0 - 0.85 * far));

  vT = t;
  vRand = aRand;
  vNoise = n;

  vec4 worldPosition = vec4(world, 1.0);
  vec3 transformedNormal = normalize(mat3(viewMatrix) * nrm);
${toonShadowVertex}
  #include <fog_vertex>
}
`;

const fragmentShader = /* glsl */ `
${toonParsFragment}
#include <fog_pars_fragment>

uniform float uStyleId;   // 0 ghibli · 1 flat · 2 realistic · 3 painterly · 4 pixel
uniform vec3 uColorBase;
uniform vec3 uColorTip;
uniform vec3 uColorDry;
uniform float uZoom;

varying float vT;
varying vec4 vRand;
varying float vNoise;

void main() {
  vec3 n = normalize(vNormalW) * (gl_FrontFacing ? 1.0 : -1.0);

  vec3 col = mix(uColorBase, uColorTip, pow(vT, 0.7));
  col = mix(col, uColorDry, smoothstep(0.55, 0.9, vNoise) * 0.55);
  col *= mix(0.95, 1.05, vRand.w);
  float rootDark = mix(0.72, 1.0, smoothstep(0.0, 0.5, vT));

  // --- style branches (see "Style branches" in ARCHITECTURE.md) ---
  if (uStyleId > 0.5 && uStyleId < 1.5) {
    // Flat: one printed colour per patch — no tip gradient, no root shading.
    col = mix(uColorBase, uColorTip, 0.5);
    col = mix(col, uColorDry, step(0.72, vNoise));
    rootDark = 1.0;
  } else if (uStyleId > 1.5 && uStyleId < 2.5) {
    // Realistic: smooth gradient plus a deeper occlusion at the root.
    col = mix(uColorBase, uColorTip, vT);
    rootDark = mix(0.64, 1.0, smoothstep(0.0, 0.6, vT));
  } else if (uStyleId > 3.5) {
    // Pixel: two inks per blade, hard split, nothing in between.
    col = mix(uColorBase, uColorTip, step(0.55, vT));
    col = mix(col, uColorDry, step(0.75, vNoise));
    rootDark = 1.0;
  }
  col *= rootDark;

  // Zoomed out, root darkening and tip contrast turn into per-pixel noise:
  // collapse them toward one painted mid green so the meadow reads as a fill.
  float far = smoothstep(9.0, 22.0, uZoom);
  col = mix(col, mix(uColorBase, uColorTip, 0.55), far * 0.6);

  float shadow = toonShadow();
  vec3 lit = toonLight(col, n, shadow, 2.0);

  // Tip highlight: a hard cel dab by default, a soft specular sheen for the
  // realistic style, and nothing at all for flat and pixel.
  if (uStyleId < 0.5 || (uStyleId > 2.5 && uStyleId < 3.5)) {
    lit += uSunColor * 0.2
      * smoothstep(0.6, 1.0, vT)
      * smoothstep(0.4, 0.9, dot(n, uSunDir))
      * shadow;
  } else if (uStyleId > 1.5 && uStyleId < 2.5) {
    vec3 viewDir = normalize(cameraPosition - vWorldPos);
    vec3 halfDir = normalize(viewDir + uSunDir);
    lit += uSunColor * 0.35
      * pow(max(dot(n, halfDir), 0.0), 24.0)
      * smoothstep(0.35, 1.0, vT)
      * shadow;
  }

  // Alpha is the PostFX ink mask, not opacity: 0 keeps the ink pass from
  // outlining every single blade (the meadow's outer silhouette against the
  // sky is still drawn, that test does not use the mask).
  gl_FragColor = vec4(lit, 0.0);
  #include <fog_fragment>
  #include <colorspace_fragment>
}
`;

/**
 * Painted grass: one instanced blade mesh covering the whole world, culled and
 * shaped entirely in the vertex shader from the painted `grass` and `comb`
 * layers. Painting never touches an instance buffer.
 */
export class Grass extends Element {
  static id = 'grass';
  static label = 'Grass';
  static order = 10;

  /**
   * @param {object} ctx shared app context
   */
  constructor(ctx) {
    super(ctx);
    /** @type {Cutouts} bare discs under props, culled in the vertex shader */
    this.cutouts = new Cutouts();

    /** @type {object} panel-editable parameters */
    this.params = {
      count: 300000,
      density: 1,
      noiseScale: 0.25,
      noiseStrength: 0.6,
      height: 0.8,
      width: 0.11,
      lean: 0.45,
      direction: 30,
      directionJitter: 0.9,
      combStrength: 0.9,
      windResponse: 0.9,
      colorBase: '#5aa845',
      colorTip: '#cfe872',
      colorDry: '#e2d977',
    };

    /** @type {THREE.Mesh|null} */
    this.mesh = null;
    /** @type {THREE.ShaderMaterial|null} */
    this.material = null;
    /** @type {THREE.InstancedBufferGeometry|null} */
    this.geometry = null;
    /** @type {PaintLayer|null} */
    this.layer = null;
    /** @type {PaintLayer|null} */
    this.combLayer = null;

    /** @private @type {THREE.DataTexture|null} 1x1 black stand-in */
    this._placeholder = null;
    /** @private @type {THREE.DataTexture|null} 1x1 press-layer rest state */
    this._pressPlaceholder = null;
    /** @private @type {Array<[string, string]>} uniform/layer pairs still unresolved */
    this._pending = EXTERNAL_LAYERS.slice();
  }

  /** Register layers and tools, build the blade mesh. */
  async init() {
    const ctx = this.ctx;

    this.layer = ctx.layers.add(new PaintLayer('grass', { channels: 1, float: false, initial: 0 }));
    this.combLayer = ctx.layers.add(
      new PaintLayer('comb', { channels: 2, float: false, initial: 0.5 }),
    );

    ctx.brush.registerTool({
      id: 'grass',
      label: 'Grass',
      color: '#7ad24a',
      excludes: ['path'],   // grass grows back over a road
      key: '1',
      layer: 'grass',
      mode: 'add',
      channel: 0,
      eraseMode: 'erase',
    });
    ctx.brush.registerTool({
      id: 'comb',
      label: 'Comb',
      color: '#c5f07a',
      key: '2',
      layer: 'comb',
      mode: 'direction',
      channel: 0,
      eraseMode: 'set',
      strengthScale: 4,
      onStamp: (c, op) => {
        const comb = c.layers.get('comb');
        if (!comb) return;
        if (op.mode === 'direction') {
          comb.stamp(op);
          return;
        }
        // Erasing a comb means "no lean offset", i.e. 0.5 in both channels.
        comb.stamp({ ...op, mode: 'set', value: 0.5, channel: 0 });
        comb.stamp({ ...op, mode: 'set', value: 0.5, channel: 1 });
      },
    });

    // Lets the ground shader green up under dense grass.
    ctx.terrain?.setLayerTexture?.('grass', this.layer.texture);

    this._placeholder = placeholderTexture([0, 0, 0, 255], 'grass:placeholder');
    this._pressPlaceholder = placeholderTexture([128, 128, 0, 255], 'grass:pressPlaceholder');

    this.material = this._buildMaterial();
    this.material.userData.uiProps = this._materialProps();
    this.material.userData.swatch = [this.params.colorTip, this.params.colorBase];
    ctx.style?.attach?.(this.material, { element: 'grass' });
    this.geometry = this._buildGeometry(this.params.count);

    this.mesh = new THREE.Mesh(this.geometry, this.material);
    this.mesh.name = 'grass';
    this.mesh.frustumCulled = false;
    this.mesh.receiveShadow = true;
    this.mesh.matrixAutoUpdate = false;
    ctx.scene.add(this.mesh);

    this._resolveLayerTextures();
  }

  /**
   * Rebuild the instance buffers for a new blade count. Never called by painting.
   * @param {number} count number of blades
   */
  rebuild(count) {
    const n = Math.max(1, Math.round(count));
    this.params.count = n;
    if (!this.mesh || !this.geometry || this.geometry.instanceCount === n) return;
    const old = this.geometry;
    this.geometry = this._buildGeometry(n);
    this.mesh.geometry = this.geometry;
    old.dispose();
  }

  /** Grow grass over the whole world (the shader still respects mask, path and water). */
  fillMeadow() {
    this.layer?.clear(1);
  }

  /** Reset every combed direction back to neutral. */
  resetComb() {
    this.combLayer?.clear(0.5);
  }

  /** Remove all painted grass. */
  clearGrass() {
    this.layer?.clear(0);
  }

  /**
   * @param {object} ui ghost-panel root or folder
   */
  buildPanel(ui) {
    const f = ui.addFolder('Grass');
    const p = this.params;
    const u = this.material.uniforms;

    f.addSlider('Count', {
      min: 100000,
      max: 600000,
      step: 50000,
      value: p.count,
      onChange: (v) => this.rebuild(v),
    });
    f.addSlider('Density', {
      min: 0,
      max: 2,
      step: 0.01,
      value: p.density,
      onChange: (v) => {
        p.density = v;
        u.uDensity.value = v;
      },
    });
    f.addSlider('Noise scale', {
      min: 0.02,
      max: 1,
      step: 0.01,
      value: p.noiseScale,
      onChange: (v) => {
        p.noiseScale = v;
        u.uNoiseScale.value = v;
      },
    });
    f.addSlider('Noise strength', {
      min: 0,
      max: 1,
      step: 0.01,
      value: p.noiseStrength,
      onChange: (v) => {
        p.noiseStrength = v;
        u.uNoiseStrength.value = v;
      },
    });
    f.addSlider('Height', {
      min: 0.2,
      max: 2.5,
      step: 0.01,
      value: p.height,
      onChange: (v) => {
        p.height = v;
        u.uBladeHeight.value = v;
      },
    });
    f.addSlider('Width', {
      min: 0.02,
      max: 0.25,
      step: 0.005,
      value: p.width,
      onChange: (v) => {
        p.width = v;
        u.uBladeWidth.value = v;
      },
    });
    f.addSlider('Lean', {
      min: 0,
      max: 1,
      step: 0.01,
      value: p.lean,
      onChange: (v) => {
        p.lean = v;
        u.uLean.value = v;
      },
    });
    f.addSlider('Direction', {
      min: -180,
      max: 180,
      step: 1,
      value: p.direction,
      onChange: (v) => {
        p.direction = v;
        u.uDirection.value = v * DEG;
      },
    });
    f.addSlider('Direction jitter', {
      min: 0,
      max: 3,
      step: 0.01,
      value: p.directionJitter,
      onChange: (v) => {
        p.directionJitter = v;
        u.uDirectionJitter.value = v;
      },
    });
    f.addSlider('Comb strength', {
      min: 0,
      max: 1.5,
      step: 0.01,
      value: p.combStrength,
      onChange: (v) => {
        p.combStrength = v;
        u.uCombStrength.value = v;
      },
    });
    f.addSlider('Wind response', {
      min: 0,
      max: 2,
      step: 0.01,
      value: p.windResponse,
      onChange: (v) => {
        p.windResponse = v;
        u.uWindResponse.value = v;
      },
    });
    f.addColor('Base colour', {
      value: p.colorBase,
      onChange: (hex) => {
        p.colorBase = hex;
        u.uColorBase.value.set(hex);
      },
    });
    f.addColor('Tip colour', {
      value: p.colorTip,
      onChange: (hex) => {
        p.colorTip = hex;
        u.uColorTip.value.set(hex);
      },
    });
    f.addColor('Dry colour', {
      value: p.colorDry,
      onChange: (hex) => {
        p.colorDry = hex;
        u.uColorDry.value.set(hex);
      },
    });
    const history = this.ctx.history;
    f.addButtonRow([
      { label: 'Fill meadow', onClick: () => history.wrap('Fill meadow', () => this.fillMeadow()) },
      { label: 'Clear grass', onClick: () => history.wrap('Clear grass', () => this.clearGrass()) },
      { label: 'Comb reset', onClick: () => history.wrap('Comb reset', () => this.resetComb()) },
    ]);
    return f;
  }

  /** Per frame: layer textures registered by later elements, and the zoom. */
  update() {
    if (this._pending.length) this._resolveLayerTextures();
    // The blade shading flattens with distance; the camera's frustum height is
    // the only "how far away are we" the shader can see.
    const zoom = this.ctx.iso?.frustumHalfHeight;
    if (this.material && typeof zoom === 'number') this.material.uniforms.uZoom.value = zoom;
  }

  /**
   * @param {import('../core/PaintLayers.js').PaintLayer} layer the layer that changed
   */
  onLayerChanged(layer) {
    if (this._pending.length && this._pending.some(([, id]) => id === layer.id)) {
      this._resolveLayerTextures();
    }
  }

  /** @returns {object} panel parameters */
  serialize() {
    return { ...this.params };
  }

  /**
   * @param {object} o output of `serialize()`
   */
  deserialize(o = {}) {
    const p = this.params;
    for (const key of Object.keys(p)) {
      if (o[key] !== undefined) p[key] = o[key];
    }
    this._applyParams();
    this.rebuild(p.count);
  }

  dispose() {
    if (this.mesh) this.ctx.scene.remove(this.mesh);
    this.geometry?.dispose();
    this.material?.dispose();
    this._placeholder?.dispose();
    this._pressPlaceholder?.dispose();
    this.mesh = null;
    this.geometry = null;
    this.material = null;
    this._placeholder = null;
    this._pressPlaceholder = null;
  }

  /**
   * Re-colour the blades for a style. Writes `params` as well as the uniforms
   * so the panel and `serialize()` keep telling the truth.
   * @param {{base?:string, tip?:string, dry?:string}} [p]
   */
  applyPalette(p) {
    if (!p || !this.material) return this;
    const u = this.material.uniforms;
    if (p.base != null) { this.params.colorBase = p.base; u.uColorBase.value.set(p.base); }
    if (p.tip != null) { this.params.colorTip = p.tip; u.uColorTip.value.set(p.tip); }
    if (p.dry != null) { this.params.colorDry = p.dry; u.uColorDry.value.set(p.dry); }
    return this;
  }

  /**
   * @private Blade colours and shape, for the inspector's Material folder.
   * Colours go through `applyPalette` so `params` stays in step with the
   * uniforms. See "Material descriptors" in ARCHITECTURE.md.
   * @returns {Array<object>}
   */
  _materialProps() {
    const p = this.params;
    const u = this.material.uniforms;
    return [
      {
        label: 'Base', kind: 'color', tooltip: 'Colour at the root of a blade',
        get: () => p.colorBase, set: (v) => this.applyPalette({ base: v }),
      },
      {
        label: 'Tip', kind: 'color', tooltip: 'Colour at the tip of a blade',
        get: () => p.colorTip, set: (v) => this.applyPalette({ tip: v }),
      },
      {
        label: 'Dry', kind: 'color', tooltip: 'Colour of sun-bleached patches',
        get: () => p.colorDry, set: (v) => this.applyPalette({ dry: v }),
      },
      {
        label: 'Height', min: 0.2, max: 2.5, step: 0.01, tooltip: 'Blade length in metres',
        get: () => p.height, set: (v) => { p.height = v; u.uBladeHeight.value = v; },
      },
      {
        label: 'Width', min: 0.02, max: 0.25, step: 0.005, tooltip: 'Blade width at the root',
        get: () => p.width, set: (v) => { p.width = v; u.uBladeWidth.value = v; },
      },
      {
        label: 'Lean', min: 0, max: 1, step: 0.01, tooltip: 'How far blades tip away from vertical',
        get: () => p.lean, set: (v) => { p.lean = v; u.uLean.value = v; },
      },
    ];
  }

  /**
   * @private
   * @returns {THREE.ShaderMaterial}
   */
  _buildMaterial() {
    const ctx = this.ctx;
    const p = this.params;
    const uniforms = THREE.UniformsUtils.merge([THREE.UniformsLib.lights, THREE.UniformsLib.fog]);
    // Same objects, by reference, so Sun/Wind updates reach this material.
    Object.assign(uniforms, ctx.sun.uniforms, ctx.wind.uniforms);

    Object.assign(uniforms, {
      uGrass: { value: this.layer.texture },
      uComb: { value: this.combLayer.texture },
      uMask: { value: this._placeholder },
      uPath: { value: this._placeholder },
      uWater: { value: this._placeholder },
      uHeight: { value: this._placeholder },
      uPress: { value: this._pressPlaceholder },
      uDensity: { value: p.density },
      uNoiseScale: { value: p.noiseScale },
      uNoiseStrength: { value: p.noiseStrength },
      uBladeHeight: { value: p.height },
      uBladeWidth: { value: p.width },
      uLean: { value: p.lean },
      uDirection: { value: p.direction * DEG },
      uDirectionJitter: { value: p.directionJitter },
      uCombStrength: { value: p.combStrength },
      uWindResponse: { value: p.windResponse },
      uZoom: { value: ctx.iso?.frustumHalfHeight ?? 14 },
      uCutouts: this.cutouts.uniforms.uCutouts,
      uCutoutCount: this.cutouts.uniforms.uCutoutCount,
      uColorBase: { value: new THREE.Color(p.colorBase) },
      uColorTip: { value: new THREE.Color(p.colorTip) },
      uColorDry: { value: new THREE.Color(p.colorDry) },
    });

    return new THREE.ShaderMaterial({
      name: 'Grass',
      uniforms,
      vertexShader,
      fragmentShader,
      lights: true,
      fog: true,
      side: THREE.DoubleSide,
      toneMapped: false,
    });
  }

  /**
   * @private Base blade strip plus the jittered-grid instance attributes.
   * @param {number} count
   * @returns {THREE.InstancedBufferGeometry}
   */
  _buildGeometry(count) {
    const geo = new THREE.InstancedBufferGeometry();
    geo.name = 'grassBlade';

    const rows = SEG + 1;
    const blade = new Float32Array(rows * 2 * 2);
    for (let row = 0; row < rows; row++) {
      const t = row / SEG;
      blade[(row * 2) * 2] = -1;
      blade[(row * 2) * 2 + 1] = t;
      blade[(row * 2 + 1) * 2] = 1;
      blade[(row * 2 + 1) * 2 + 1] = t;
    }
    geo.setAttribute('aBlade', new THREE.BufferAttribute(blade, 2));

    const index = new Uint16Array(SEG * 6);
    for (let s = 0; s < SEG; s++) {
      const a = s * 2;
      index.set([a, a + 2, a + 1, a + 1, a + 2, a + 3], s * 6);
    }
    geo.setIndex(new THREE.BufferAttribute(index, 1));

    const offsets = new Float32Array(count * 2);
    const rands = new Float32Array(count * 4);
    const k = Math.ceil(Math.sqrt(count));
    const cell = WORLD_SIZE / k;
    const rand = mulberry32(0x9e3779b9);
    for (let i = 0; i < count; i++) {
      const gx = i % k;
      const gz = (i / k) | 0;
      offsets[i * 2] = -HALF + (gx + 0.5 + (rand() - 0.5) * 0.95) * cell;
      offsets[i * 2 + 1] = -HALF + (gz + 0.5 + (rand() - 0.5) * 0.95) * cell;
      rands[i * 4] = rand();
      rands[i * 4 + 1] = rand();
      rands[i * 4 + 2] = rand();
      rands[i * 4 + 3] = rand();
    }
    geo.setAttribute('aOffset', new THREE.InstancedBufferAttribute(offsets, 2));
    geo.setAttribute('aRand', new THREE.InstancedBufferAttribute(rands, 4));
    geo.instanceCount = count;
    return geo;
  }

  /** @private Push every parameter into its uniform. */
  _applyParams() {
    if (!this.material) return;
    const p = this.params;
    const u = this.material.uniforms;
    u.uDensity.value = p.density;
    u.uNoiseScale.value = p.noiseScale;
    u.uNoiseStrength.value = p.noiseStrength;
    u.uBladeHeight.value = p.height;
    u.uBladeWidth.value = p.width;
    u.uLean.value = p.lean;
    u.uDirection.value = p.direction * DEG;
    u.uDirectionJitter.value = p.directionJitter;
    u.uCombStrength.value = p.combStrength;
    u.uWindResponse.value = p.windResponse;
    u.uColorBase.value.set(p.colorBase);
    u.uColorTip.value.set(p.colorTip);
    u.uColorDry.value.set(p.colorDry);
  }

  /** @private Swap placeholders for real layer textures once their owners exist. */
  _resolveLayerTextures() {
    if (!this.material) return;
    const u = this.material.uniforms;
    for (let i = this._pending.length - 1; i >= 0; i--) {
      const [name, id] = this._pending[i];
      const layer = this.ctx.layers.get(id);
      if (!layer) continue;
      u[name].value = layer.texture;
      this._pending.splice(i, 1);
    }
  }
}
