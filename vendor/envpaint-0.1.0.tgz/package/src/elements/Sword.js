import * as THREE from 'three';
import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js';
import { Element } from '../core/Element.js';
import { PaintLayer } from '../core/PaintLayers.js';
import { WORLD_SIZE } from '../core/constants.js';
import { toonParsVertex, toonShadowVertex, toonParsFragment } from '../core/shaders/toon.glsl.js';

/** Where the converted asset lives (see `scratch/sword-convert.mjs`). */
const MODEL_URL = '/models/master-sword.glb';
const TEXTURE_DIR = '/models/master-sword';

/**
 * The five parts of the model. `Blade` leads on purpose: `Panel.js` takes the
 * first material it finds under the group, so the one carrying `uiProps` and
 * `swatch` has to be first in the group's child order. It is also the only one
 * the Materials palette lists, which is why it is called plainly `Sword` — a
 * swatch label is read by a person, and there is only ever one of them.
 * @type {Array<{mesh: string, part: string, name: string, glint: number, gem: number}>}
 */
const PARTS = [
  { mesh: 'Blade_low', part: 'blade', name: 'Sword', glint: 1, gem: 0 },
  { mesh: 'Handle_low', part: 'handle', name: 'SwordHandle', glint: 0, gem: 0 },
  { mesh: 'Hilt_low', part: 'hilt', name: 'SwordHilt', glint: 0, gem: 0 },
  { mesh: 'Wings_low', part: 'wings', name: 'SwordWings', glint: 0, gem: 0 },
  { mesh: 'Diamond_low', part: 'diamond', name: 'SwordDiamond', glint: 1, gem: 1 },
];

/**
 * Vertical extent of the source model in its own units, measured once at
 * conversion time: blade tip at `minY`, pommel at `maxY`, Y up. The live
 * bounds are re-measured from the GLB; these are the defaults the pure pose
 * maths (and its unit test) work against.
 */
export const MODEL_BOUNDS = {
  minY: -2052.9808076799695,
  maxY: 2042.5956837983397,
  height: 4095.5764914783094,
};

/** Sword length in world units at scale 1 — a tree trunk is 1.6 u. */
export const BASE_LENGTH = 1.6;

/** The blade may not be sunk past this fraction of the whole sword. */
export const MAX_BURIED = 0.6;

/** Sword scale, as a multiple of `BASE_LENGTH`. */
const MIN_SCALE = 0.15;
const MAX_SCALE = 6;

/** Resolution of the 'press' layer, matching the one Rocks registers. */
const PRESS_RES = 128;
/** Press disc radius as a fraction of the sword's length. */
const PRESS_RADIUS = 0.3;
/** How hard the sword flattens what grows under it, 0..1. */
const PRESS_STRENGTH = 0.7;
/** Key under which the sword registers its bare disc with grass and flowers. */
const CUTOUT_KEY = 'sword';

/**
 * @param {number} v
 * @param {number} lo
 * @param {number} hi
 * @returns {number}
 */
function clamp(v, lo, hi) {
  return v < lo ? lo : v > hi ? hi : v;
}

/**
 * Where a blade-down prop's group sits and how it leans, from its pose
 * parameters alone. Pure: no THREE objects, no scene, no terrain.
 *
 * The group's origin is the point on the blade that meets the ground, so the
 * tilt pivots at the surface and the buried depth stays put as it leans. The
 * model hangs under an inner node offset by `pivotY` **model units**, which is
 * what puts that origin `buried` of the way up from the tip.
 *
 * @param {object} [opts]
 * @param {number} [opts.x] world X
 * @param {number} [opts.z] world Z
 * @param {number} [opts.groundY] terrain height under (x, z)
 * @param {number} [opts.tilt] lean from vertical, degrees
 * @param {number} [opts.buried] fraction of the total length below ground
 * @param {number} [opts.yaw] spin about Y, radians
 * @param {number} [opts.scale] multiplier on `length`
 * @param {number} [opts.length] world length at scale 1
 * @param {{minY:number, maxY:number, height:number}} [opts.bounds] model extent
 * @returns {{unit:number, pivotY:number, length:number, tipDepth:number,
 *            position:{x:number,y:number,z:number},
 *            rotation:{x:number,y:number,z:number}}}
 */
export function swordPose({
  x = 0,
  z = 0,
  groundY = 0,
  tilt = 6,
  buried = 0.35,
  yaw = 0,
  scale = 1,
  length = BASE_LENGTH,
  bounds = MODEL_BOUNDS,
} = {}) {
  const worldLength = length * clamp(scale, MIN_SCALE, MAX_SCALE);
  const buriedFrac = clamp(buried, 0, MAX_BURIED);
  const tiltRad = (tilt * Math.PI) / 180;
  return {
    // Model units → world units: the group's uniform scale.
    unit: worldLength / bounds.height,
    // Model-space Y offset of the inner node: minY + buried·height lands at 0.
    pivotY: -(bounds.minY + buriedFrac * bounds.height),
    length: worldLength,
    // How deep the tip actually ends up once the sword leans.
    tipDepth: buriedFrac * worldLength * Math.cos(tiltRad),
    position: { x, y: groundY, z },
    rotation: { x: tiltRad, y: yaw, z: 0 },
  };
}

/**
 * The Master Sword: a **prop element**. Unlike the painted elements it owns one
 * asset-loaded object rather than a scatter, and that object is an ordinary
 * scene citizen — selectable in the Outliner, movable with the gizmo, and
 * deletable. Its Y is always derived from the terrain under it, so the blade
 * stays buried at the same fraction of its length however the ground is
 * sculpted and wherever it is dragged.
 */
export class Sword extends Element {
  static id = 'sword';
  static label = 'Master Sword';
  static order = 35;

  /**
   * @param {object} ctx shared app context
   */
  constructor(ctx) {
    super(ctx);

    /** @type {THREE.Group|null} what the Outliner lists and the gizmo drags */
    this.root = null;
    /** @private @type {THREE.Object3D|null} the model, offset to the ground point */
    this.pivot = null;
    /** @type {THREE.ShaderMaterial[]} one per part, sharing most uniform objects */
    this.materials = [];
    /** @type {THREE.Texture[]} */
    this.textures = [];
    /** @private @type {Record<string, {map: THREE.Texture, ao: THREE.Texture}>} */
    this.maps = {};
    /** @private @type {ArrayBuffer|null} the raw GLB, kept so a delete can be undone */
    this._glb = null;
    /** @private @type {import('../core/PaintLayers.js').PaintLayer|null} */
    this.pressLayer = null;
    /** @private @type {{x0:number,y0:number,x1:number,y1:number}|null} */
    this._splatRect = null;
    /** @private @type {{cx:number,cy:number,rt:number}|null} where it was stamped */
    this._splatCentre = null;
    /** @private the sword was deleted from the Outliner and is not in the scene */
    this.removed = false;
    /** @private guards the undo entry a scripted remove() would otherwise push */
    this._quiet = false;
    /** @private a restore() is mid-parse; a second one must not plant a twin */
    this._restoring = false;
    /** @private @type {object|null} the panel handle, for the undo stack */
    this._ui = null;
    /** @private @type {{x:number,z:number,yaw:number,unit:number}|null} */
    this._lastApplied = null;

    /**
     * @type {{x:number, z:number, yaw:number, scale:number, tilt:number,
     *         buried:number, detail:number, bands:number, glint:number,
     *         gemGlow:number, glintTint:string, gemTint:string}}
     */
    this.params = {
      x: 0,
      z: 0,
      yaw: 0,
      // A hero prop: 3 x the real 1.6 u (about 4.8 u long, 3 u showing) so
      // it reads as a landmark from the working zoom.
      scale: 3,
      tilt: 6,
      buried: 0.35,
      /** radius of bare ground around the blade, world units (metres) */
      clearing: 0.5,
      detail: 0.35,
      bands: 4,
      glint: 1,
      gemGlow: 0.6,
      glintTint: '#fff6da',
      gemTint: '#ffd257',
    };
    /** @private the pose a "Reset pose" button restores */
    this._defaults = { ...this.params };

    /** Live model extent, re-measured from the GLB on load. */
    this.bounds = { ...MODEL_BOUNDS };

    /** @private the uniform objects every part material shares by reference */
    this.shared = null;
  }

  // --- lifecycle ----------------------------------------------------------

  /**
   * Build the shared uniforms and the press layer, then start the asset load.
   * The load is deliberately **not** awaited: a slow or missing model must not
   * hold the app's boot up, and every other entry point copes with the sword
   * not being there yet.
   */
  async init() {
    const p = this.params;
    this.shared = {
      uDetail: { value: p.detail },
      uBands: { value: p.bands },
      uGlint: { value: p.glint },
      uGemGlow: { value: p.gemGlow },
      uGlintTint: { value: new THREE.Color(p.glintTint) },
      uGemTint: { value: new THREE.Color(p.gemTint) },
    };
    this.pressLayer = this._buildPressLayer();

    /** @type {Promise<void>} resolves once the sword is in the scene */
    this.ready = this._load().catch((err) => {
      console.warn('[EnvPaint] Master Sword failed to load:', err);
    });
    return this;
  }

  /** @private Fetch the GLB once (the bytes are kept so a delete can be undone). */
  async _load() {
    const res = await fetch(MODEL_URL);
    if (!res.ok) throw new Error(`${MODEL_URL} → HTTP ${res.status}`);
    this._glb = await res.arrayBuffer();
    await this._loadTextures();
    await this.restore();
  }

  /** @private BaseColor + AO for all five parts. */
  async _loadTextures() {
    const loader = new THREE.TextureLoader();
    await Promise.all(PARTS.map(async ({ part }) => {
      const [map, ao] = await Promise.all([
        loader.loadAsync(`${TEXTURE_DIR}/${part}-basecolor.png`),
        loader.loadAsync(`${TEXTURE_DIR}/${part}-ao.png`),
      ]);
      // The albedo is authored in sRGB; the AO map is data, not colour.
      map.colorSpace = THREE.SRGBColorSpace;
      ao.colorSpace = THREE.NoColorSpace;
      for (const t of [map, ao]) {
        t.wrapS = THREE.ClampToEdgeWrapping;
        t.wrapT = THREE.ClampToEdgeWrapping;
        t.anisotropy = 4;
      }
      this.textures.push(map, ao);
      this.maps[part] = { map, ao };
    }));
  }

  /**
   * Parse the kept GLB bytes into a fresh group and plant it. Also the undo of
   * a delete: the Outliner disposes the geometry and materials of whatever it
   * removes, so both really do have to be rebuilt.
   * @returns {Promise<THREE.Group|null>}
   */
  async restore() {
    if (this.root || !this._glb || this._restoring) return this.root;
    // The parse is an await away, so two callers (the initial load and a
    // fromJSON, say) could otherwise plant two swords.
    this._restoring = true;
    try {
      return await this._plant();
    } finally {
      this._restoring = false;
    }
  }

  /** @private The body of `restore()`, minus the re-entry guard. */
  async _plant() {
    const ctx = this.ctx;
    const model = await new Promise((resolve, reject) => {
      // A copy: GLTFLoader takes ownership of the buffer it is handed.
      new GLTFLoader().parse(this._glb.slice(0), '', (gltf) => resolve(gltf.scene), reject);
    });
    model.updateMatrixWorld(true);

    this._buildMaterials();

    const pivot = new THREE.Object3D();
    pivot.name = 'MasterSwordModel';
    PARTS.forEach((def, i) => {
      const mesh = model.getObjectByName(def.mesh);
      if (!mesh) return;
      // Re-parenting in PARTS order: the flattened world matrix keeps the
      // part where the artist put it, and Blade ends up first.
      mesh.matrixWorld.decompose(mesh.position, mesh.quaternion, mesh.scale);
      mesh.material = this.materials[i];
      mesh.castShadow = true;
      mesh.receiveShadow = true;
      // Only the Blade's material becomes a palette swatch; the other four
      // are the same object under the hood and would just be noise.
      if (i > 0) mesh.userData.__duiIgnore = true;
      pivot.add(mesh);
    });

    // Model extent, measured with the pivot still at the origin.
    const box = new THREE.Box3().setFromObject(pivot);
    if (box.isEmpty()) throw new Error('Master Sword GLB has no geometry');
    this.bounds = { minY: box.min.y, maxY: box.max.y, height: box.max.y - box.min.y };

    const root = new THREE.Group();
    root.name = 'Master Sword';
    root.rotation.order = 'YXZ';
    // Not locked: a prop is selected, dragged and deleted like any object the
    // user put in the scene (see `registerElementObjects` in Panel.js).
    root.userData.envpaintProp = true;
    root.add(pivot);

    this.root = root;
    this.pivot = pivot;
    this.removed = false;
    this._applyPose();
    ctx.scene.add(root);
    // Panel.js marks everything added to the scene while the transform gizmo
    // is still landing, which would drop the sword from the Outliner and its
    // material from the palette. This one is a real object; opt back in.
    delete root.userData.__duiIgnore;
    return root;
  }

  /** @private Build the five cel materials and register them with the Style. */
  _buildMaterials() {
    this.materials = PARTS.map((def) => {
      const material = this._buildMaterial(def);
      this.ctx.style?.attach?.(material, { element: Sword.id });
      return material;
    });
    const blade = this.materials[0];
    blade.userData.uiProps = this._materialProps();
    blade.userData.swatch = ['#c8c8c8', '#1e2e91', '#3a4a90'];
    for (let i = 1; i < this.materials.length; i++) {
      this.materials[i].userData.__duiIgnore = true;
    }
  }

  /**
   * Take the sword out of the scene, exactly as the Outliner's trash button
   * does. Undoable when the panel is up.
   */
  remove() {
    if (!this.root) return this;
    const om = this._ui?.objectManager;
    const name = om?.getNames?.().find((n) => om.getObject(n) === this.root);
    if (name) om.remove(name);          // disposes, then fires 'remove' → _onRemoved
    else this._onRemoved();
    return this;
  }

  /**
   * @private The object left the scene: drop our references, lift the press
   * mark, and offer the delete back on the undo stack.
   */
  _onRemoved() {
    if (!this.root) return;
    this.root.removeFromParent();
    for (const m of this.materials) this.ctx.style?.detach?.(m);
    this.materials = [];
    this.root = null;
    this.pivot = null;
    this._lastApplied = null;
    this.removed = true;
    this._clearSplat();
    this._clearCutout();
    if (this._quiet) return;
    this._ui?._undo?.push?.({
      label: 'delete Master Sword',
      undo: () => { this.restore(); },
      redo: () => { this._quiet = true; try { this.remove(); } finally { this._quiet = false; } },
    });
  }

  /**
   * The Outliner row for this element. Empty once the sword has been deleted,
   * so the panel's per-frame re-scan does not resurrect a dead row.
   * @returns {THREE.Object3D[]}
   */
  sceneObjects() {
    return this.root && this.root.parent ? [this.root] : [];
  }

  // --- pose ---------------------------------------------------------------

  /**
   * @private Push `params` onto the group. Y, tilt and the pivot offset are
   * always derived, so the blade keeps the same buried fraction of its length.
   */
  _applyPose() {
    const root = this.root;
    if (!root) return;
    const p = this.params;
    const groundY = this.ctx.terrain?.heightAt?.(p.x, p.z) ?? 0;
    const pose = swordPose({
      x: p.x, z: p.z, groundY, tilt: p.tilt, buried: p.buried,
      yaw: p.yaw, scale: p.scale, bounds: this.bounds,
    });
    root.position.set(pose.position.x, pose.position.y, pose.position.z);
    root.rotation.set(pose.rotation.x, pose.rotation.y, pose.rotation.z);
    root.scale.setScalar(pose.unit);
    this._applyCutout();
    if (this.pivot) this.pivot.position.y = pose.pivotY;
    this._lastApplied = { x: p.x, z: p.z, yaw: p.yaw, unit: pose.unit };
    return pose;
  }

  /**
   * @private Anything the gizmo changed on the group is read back into
   * `params` before the pose is re-derived, so a drag sticks. Y and the tilt
   * belong to the terrain and the panel and are simply re-imposed.
   */
  _readGizmo() {
    const root = this.root;
    const last = this._lastApplied;
    if (!root || !last) return;
    const p = this.params;
    if (Math.abs(root.position.x - last.x) > 1e-6) p.x = root.position.x;
    if (Math.abs(root.position.z - last.z) > 1e-6) p.z = root.position.z;
    if (Math.abs(root.rotation.y - last.yaw) > 1e-6) p.yaw = root.rotation.y;
    if (Math.abs(root.scale.x - last.unit) > 1e-9) {
      p.scale = clamp((root.scale.x * this.bounds.height) / BASE_LENGTH, MIN_SCALE, MAX_SCALE);
    }
  }

  /**
   * @param {number} dt
   * @param {number} time
   */
  // eslint-disable-next-line no-unused-vars
  update(dt, time) {
    if (!this.root) return;
    this._readGizmo();
    this._applyPose();
    this._writeSplat();
  }

  /** The ground moved under the sword; the pose is re-derived next frame. */
  onTerrainChanged() {
    this._applyPose();
  }

  // --- press layer --------------------------------------------------------

  /**
   * @private The shared 'press' layer (Rocks registers the same one): RG =
   * push direction, B = strength. Grass reads it and parts.
   * @returns {import('../core/PaintLayers.js').PaintLayer}
   */
  _buildPressLayer() {
    const existing = this.ctx.layers.get('press');
    if (existing) return existing;
    const layer = this.ctx.layers.add(
      new PaintLayer('press', { res: PRESS_RES, channels: 4, history: false }),
    );
    const data = layer.data;
    for (let i = 0; i < data.length; i += 4) {
      data[i] = 128;
      data[i + 1] = 128;
      data[i + 2] = 0;
      data[i + 3] = 255;
    }
    layer.texture.needsUpdate = true;
    return layer;
  }

  /**
   * @private Hold a flattened disc in the press layer under the blade. Rocks
   * decays the whole layer every frame, so this is re-stamped every frame; it
   * only marks the layer dirty when a byte actually changed.
   */
  _writeSplat() {
    const layer = this.pressLayer;
    const root = this.root;
    if (!layer || !root) return;
    const p = this.params;
    const radius = PRESS_RADIUS * BASE_LENGTH * clamp(p.scale, MIN_SCALE, MAX_SCALE);
    const res = layer.res;
    const data = layer.data;
    const cx = (p.x / WORLD_SIZE + 0.5) * res;
    const cy = (p.z / WORLD_SIZE + 0.5) * res;
    const rt = (radius / WORLD_SIZE) * res;
    if (rt <= 0) return;

    const rect = {
      x0: Math.max(0, Math.floor(cx - rt)),
      y0: Math.max(0, Math.floor(cy - rt)),
      x1: Math.min(res - 1, Math.ceil(cx + rt)),
      y1: Math.min(res - 1, Math.ceil(cy + rt)),
    };
    // Moved: lift the old mark before laying the new one down. Sub-texel
    // drags never change the rect, so the centre is what is compared — the
    // disc is written with max(), and a smear is what you get otherwise.
    const from = this._splatCentre;
    if (from && (Math.abs(from.cx - cx) > 0.25 || Math.abs(from.cy - cy) > 0.25 || from.rt !== rt)) {
      this._clearSplat();
    }
    this._splatRect = rect;
    this._splatCentre = { cx, cy, rt };

    let changed = false;
    const inv = 1 / rt;
    const peak = PRESS_STRENGTH * 255;
    for (let py = rect.y0; py <= rect.y1; py++) {
      const dy = py + 0.5 - cy;
      for (let px = rect.x0; px <= rect.x1; px++) {
        const dx = px + 0.5 - cx;
        const len = Math.sqrt(dx * dx + dy * dy);
        const d = len * inv;
        if (d >= 1) continue;
        // Grass lies down AWAY from the blade, as if trampled around a
        // pedestal: without a direction the blades only shorten in place and
        // the sword vanishes into the meadow from the isometric view. Rounded
        // to a byte before the compare, or the float would read as "greater"
        // every frame and the layer would upload forever.
        const s = Math.round(peak * (1 - d * d));
        const i = (py * res + px) * 4;
        if (s > data[i + 2]) {
          const nx = len > 1e-4 ? dx / len : 0;
          const ny = len > 1e-4 ? dy / len : 0;
          data[i] = Math.round((nx * 0.5 + 0.5) * 255);
          data[i + 1] = Math.round((ny * 0.5 + 0.5) * 255);
          data[i + 2] = s;
          changed = true;
        }
      }
    }
    if (changed) layer.markDirtyRect(rect.x0, rect.y0, rect.x1, rect.y1);
  }

  /** @private Bare ground under the blade: grass and flowers skip the disc. */
  _applyCutout() {
    const p = this.params;
    for (const id of ['grass', 'flowers']) {
      this.ctx.elements?.get(id)?.cutouts?.set(CUTOUT_KEY, p.x, p.z, p.clearing);
    }
  }

  /** @private */
  _clearCutout() {
    for (const id of ['grass', 'flowers']) this.ctx.elements?.get(id)?.cutouts?.remove(CUTOUT_KEY);
  }

  /** @private Return the sword's press mark to the layer's rest state. */
  _clearSplat() {
    const layer = this.pressLayer;
    const rect = this._splatRect;
    if (!layer || !rect) return;
    const data = layer.data;
    for (let py = rect.y0; py <= rect.y1; py++) {
      for (let px = rect.x0; px <= rect.x1; px++) {
        const i = (py * layer.res + px) * 4;
        data[i] = 128;
        data[i + 1] = 128;
        data[i + 2] = 0;
      }
    }
    layer.markDirtyRect(rect.x0, rect.y0, rect.x1, rect.y1);
    this._splatRect = null;
    this._splatCentre = null;
  }

  // --- material -----------------------------------------------------------

  /**
   * Re-colour the sword for a style; only the keys present are written.
   * @param {{glintTint?:string, gemTint?:string}} [p]
   */
  applyPalette(p) {
    if (!p || !this.shared) return this;
    if (p.glintTint != null) {
      this.params.glintTint = p.glintTint;
      this.shared.uGlintTint.value.set(p.glintTint);
    }
    if (p.gemTint != null) {
      this.params.gemTint = p.gemTint;
      this.shared.uGemTint.value.set(p.gemTint);
    }
    return this;
  }

  /**
   * @private Write one look value to `params` and to all five materials — the
   * uniform objects are shared, but the loop keeps that an optimisation rather
   * than a requirement.
   * @param {string} key `params` key
   * @param {string} uniform uniform name
   * @param {number} value
   */
  _setLook(key, uniform, value) {
    this.params[key] = value;
    if (this.shared?.[uniform]) this.shared[uniform].value = value;
    for (const m of this.materials) {
      if (m.uniforms[uniform]) m.uniforms[uniform].value = value;
    }
  }

  /**
   * @private The sword's look controls, for the inspector's Material folder.
   * See "Material descriptors" in ARCHITECTURE.md.
   * @returns {Array<object>}
   */
  _materialProps() {
    const row = (label, key, uniform, min, max, step, tooltip) => ({
      label,
      min,
      max,
      step,
      tooltip,
      get: () => this.params[key],
      set: (v) => this._setLook(key, uniform, v),
    });
    return [
      row('Detail', 'detail', 'uDetail', 0, 1, 0.01,
        'How much of the raw scan survives the posterise — engraving as a hint'),
      row('Bands', 'bands', 'uBands', 2, 6, 1,
        'Levels the texture brightness is cut into'),
      row('Glint', 'glint', 'uGlint', 0, 2, 0.01,
        'The anime highlight that creeps along the blade'),
      row('Gem glow', 'gemGlow', 'uGemGlow', 0, 2, 0.01,
        'How brightly the pommel stone breathes'),
    ];
  }

  /**
   * @private One cel material per part. All five share the same uniform
   * *objects* for the look controls, so one slider moves the whole sword; only
   * the two maps and the two per-part switches differ.
   * @param {{part:string, name:string, glint:number, gem:number}} part
   * @returns {THREE.ShaderMaterial}
   */
  _buildMaterial(part) {
    const { sun, wind } = this.ctx;
    const maps = this.maps[part.part] || {};

    const uniforms = Object.assign(
      THREE.UniformsUtils.clone(THREE.UniformsLib.lights),
      THREE.UniformsUtils.clone(THREE.UniformsLib.fog),
      sun.uniforms,
      wind.uniforms,
      this.shared,
      {
        uMap: { value: maps.map || null },
        uAO: { value: maps.ao || null },
        uIsBlade: { value: part.glint },
        uIsGem: { value: part.gem },
      },
    );

    const vertexShader = /* glsl */ `
      ${toonParsVertex}
      #include <fog_pars_vertex>

      varying vec2 vUv;

      void main() {
        vUv = uv;
        vec4 worldPosition = modelMatrix * vec4(position, 1.0);
        vec3 transformedNormal = normalMatrix * normal;
        ${toonShadowVertex}
        #include <fog_vertex>
      }
    `;

    const fragmentShader = /* glsl */ `
      ${toonParsFragment}
      #include <fog_pars_fragment>

      uniform float uStyleId;
      uniform sampler2D uMap;
      uniform sampler2D uAO;
      uniform float uDetail;    // 0 = pure poster, 1 = the raw scan
      uniform float uBands;     // brightness levels the poster is cut into
      uniform float uGlint;     // anime specular stripe, blade and gem only
      uniform float uGemGlow;   // emissive pulse, gem only
      uniform vec3  uGlintTint;
      uniform vec3  uGemTint;
      uniform float uIsBlade;
      uniform float uIsGem;

      varying vec2 vUv;

      // One soft-edged step of a bands-level staircase, spread between a
      // painted floor and near-white. A wider soft edge is what turns a hard
      // posterise into a painted one; the floor is why a cel ramp has no pure
      // black level, however dark the scan underneath it is.
      float bandStep(float x, float bands, float soft) {
        float n = max(bands, 2.0);
        float s = x * n;
        float f = floor(s);
        float e = smoothstep(0.5 - soft, 0.5 + soft, s - f);
        float idx = clamp(f + e, 0.0, n - 1.0);
        return mix(0.22, 0.92, idx / (n - 1.0));
      }

      // Posterise the way a cel painter would: keep the hue and the saturation
      // of the scanned texture, quantise only how bright it is. Brightness
      // here is the HSV value rather than the luminance — scaling a saturated
      // dark blue (the hilt) by its luminance either crushes it to black or
      // drives a channel past white; scaling by its value does neither.
      vec3 poster(vec3 c, float bands, float soft) {
        float v = max(max(c.r, c.g), c.b);
        return c * (bandStep(v, bands, soft) / max(v, 1e-4));
      }

      void main() {
        vec3 n = normalize(vNormalW);
        vec3 tex = texture2D(uMap, vUv).rgb;
        float ao = texture2D(uAO, vUv).r;

        float bands = max(uBands, 1.0);
        float soft = 0.16;
        float detail = uDetail;
        float aoMix = 0.35;
        float glint = uGlint;
        float posterFinal = 0.0;   // pixel style: quantise the finished colour

        // --- style branches (see "Style branches" in ARCHITECTURE.md) ---
        if (uStyleId > 0.5 && uStyleId < 1.5) {
          // Flat: two printed tones, no engraving, no contact shade.
          bands = 2.0;
          soft = 0.04;
          detail = 0.0;
          aoMix = 0.0;
          glint = 0.0;
        } else if (uStyleId > 1.5 && uStyleId < 2.5) {
          // Realistic: the scan itself, smoothly occluded.
          detail = 1.0;
          aoMix = 0.0;
        } else if (uStyleId > 2.5 && uStyleId < 3.5) {
          // Painterly: a wide, wobbling band edge — a wet brush, not a knife.
          soft = 0.34 + 0.20 * (fbm(vWorldPos.xz * 5.0 + vWorldPos.y * 2.0, 3) - 0.5);
        } else if (uStyleId > 3.5) {
          // Pixel: hard steps, and the finished colour quantised again.
          soft = 0.02;
          posterFinal = 1.0;
        }

        vec3 albedo = mix(poster(tex, bands, soft), tex, clamp(detail, 0.0, 1.0));

        // Ambient occlusion as ONE hard darker band, never a gradient: the
        // painted equivalent of a crease filled with a second wash.
        if (uStyleId > 1.5 && uStyleId < 2.5) {
          albedo *= mix(1.0, ao, 0.6);              // realistic: the smooth map
        } else {
          albedo *= mix(1.0, step(0.55, ao), aoMix);
        }

        vec3 col = toonLight(albedo, n, toonShadow(), 3.0);

        // Anime glint: a hard Blinn stripe whose half-vector creeps along the
        // edge, so the highlight travels instead of sitting still.
        if (glint > 0.001 && uIsBlade > 0.5) {
          float a = sin(uTime * 0.754) * 0.14;      // 0.12 Hz, small amplitude
          float ca = cos(a);
          float sa = sin(a);
          vec3 sd = normalize(vec3(
            uSunDir.x * ca - uSunDir.z * sa,
            uSunDir.y,
            uSunDir.x * sa + uSunDir.z * ca
          ));
          vec3 viewDir = normalize(cameraPosition - vWorldPos);
          vec3 halfVec = normalize(sd + viewDir);
          // Anime licence: the glint is a shape drawn on the blade, not a
          // physical reflection. A sun 50 deg up and a camera 35 deg up put
          // the half-vector well above the horizon, where a pow-48 lobe would
          // never once meet the near-vertical face of a planted blade — so
          // both vectors are laid down into the blade's own plane first.
          vec3 hFlat = normalize(vec3(halfVec.x, halfVec.y * 0.15, halfVec.z));
          vec3 nFlat = normalize(vec3(n.x, n.y * 0.15, n.z));
          float spec = pow(max(dot(nFlat, hFlat), 0.0), 48.0);
          float stripe = step(0.82, spec);
          if (uStyleId > 1.5 && uStyleId < 2.5) {
            stripe = spec * 0.8;                     // realistic: a smooth blinn
          } else if (uStyleId > 3.5) {
            stripe = step(0.5, spec);                // pixel: one hard stripe
          }
          col += uSunColor * uGlintTint * stripe * glint;
        }

        // The gem breathes its own colour.
        if (uIsGem > 0.5) {
          float pulse = 1.0 + 0.15 * sin(uTime * 3.14159);   // 0.5 Hz, +/-15 %
          col += uGemTint * uGemGlow * 0.25 * pulse;
        }

        if (posterFinal > 0.5) col = floor(clamp(col, 0.0, 1.0) * 4.0 + 0.5) / 4.0;

        gl_FragColor = vec4(col, toonInkAlpha());
        #include <fog_fragment>
        #include <colorspace_fragment>
      }
    `;

    return new THREE.ShaderMaterial({
      name: part.name,
      uniforms,
      vertexShader,
      fragmentShader,
      lights: true,
      fog: true,
      toneMapped: false,
    });
  }

  // --- UI -----------------------------------------------------------------

  /**
   * @param {object} ui ghost-panel handle
   */
  buildPanel(ui) {
    this._ui = ui;
    // The Outliner disposes what it deletes, so the element has to hear about
    // it: lift the press mark and offer the delete back on the undo stack.
    ui.objectManager?.on?.('remove', (_name, object) => {
      if (object === this.root) this._onRemoved();
    });

    const f = ui.addFolder('Sword');
    const p = this.params;

    f.addSlider('Scale', {
      min: 0.3, max: 3, step: 0.01, value: p.scale,
      tooltip: 'Length as a multiple of 1.6 world units',
      onChange: (v) => { p.scale = v; this._applyPose(); },
    });
    f.addSlider('Tilt', {
      min: -30, max: 30, step: 0.5, value: p.tilt,
      tooltip: 'Lean from vertical, degrees',
      onChange: (v) => { p.tilt = v; this._applyPose(); },
    });
    f.addSlider('Buried', {
      min: 0, max: MAX_BURIED, step: 0.01, value: p.buried,
      tooltip: 'Fraction of the whole sword below the ground',
      onChange: (v) => { p.buried = v; this._applyPose(); },
    });
    f.addSlider('Clearing', {
      min: 0, max: 2, step: 0.05, value: p.clearing, suffix: ' m',
      tooltip: 'Bare ground around the blade: no grass or flowers inside',
      onChange: (v) => { p.clearing = v; this._applyCutout(); },
    });
    f.addButton('Reset pose', () => {
      this.ctx.history?.wrap?.('Reset sword pose', () => {
        for (const key of ['x', 'z', 'yaw', 'scale', 'tilt', 'buried', 'clearing']) {
          this.params[key] = this._defaults[key];
        }
        this._applyPose();
      }, { element: Sword.id });
      this._syncFolder(f);
    });
    /** @private @type {object} kept so "Reset pose" can push the sliders back */
    this._folder = f;
    return f;
  }

  /**
   * @private Push `params` back into the folder's sliders after a change the
   * user did not make with them (Reset pose, undo, a gizmo drag).
   * @param {object} f
   */
  _syncFolder(f = this._folder) {
    if (!f) return;
    f.get('Scale')?.setValue(this.params.scale);
    f.get('Tilt')?.setValue(this.params.tilt);
    f.get('Buried')?.setValue(this.params.buried);
    f.get('Clearing')?.setValue(this.params.clearing);
  }

  // --- save / load --------------------------------------------------------

  /** @returns {object} transform plus every pose and look parameter */
  serialize() {
    const root = this.root;
    return {
      present: !this.removed,
      position: root ? root.position.toArray() : null,
      rotation: root ? [root.rotation.x, root.rotation.y, root.rotation.z] : null,
      scale: root ? root.scale.toArray() : null,
      params: { ...this.params },
    };
  }

  /**
   * @param {object} o output of `serialize()`
   */
  deserialize(o = {}) {
    if (!o) return;
    if (o.params) {
      for (const [key, value] of Object.entries(o.params)) {
        if (key in this.params) this.params[key] = value;
      }
    } else {
      // A transform-only save (or a hand-written one): derive what we can.
      if (Array.isArray(o.position)) { this.params.x = o.position[0]; this.params.z = o.position[2]; }
      if (Array.isArray(o.rotation)) this.params.yaw = o.rotation[1];
      if (Array.isArray(o.scale) && o.scale[0] > 0) {
        this.params.scale = clamp((o.scale[0] * this.bounds.height) / BASE_LENGTH, MIN_SCALE, MAX_SCALE);
      }
    }
    this.applyPalette({ glintTint: this.params.glintTint, gemTint: this.params.gemTint });
    for (const [key, uniform] of [['detail', 'uDetail'], ['bands', 'uBands'], ['glint', 'uGlint'], ['gemGlow', 'uGemGlow']]) {
      this._setLook(key, uniform, this.params[key]);
    }

    const present = o.present !== false;
    if (present && !this.root && this._glb) this.restore();
    else if (!present && this.root) { this._quiet = true; try { this.remove(); } finally { this._quiet = false; } }
    this._applyPose();
    this._syncFolder();
  }

  /** Drop the object, the materials and the textures. */
  dispose() {
    this._quiet = true;
    this._clearSplat();
    this.root?.removeFromParent();
    for (const m of this.materials) {
      this.ctx.style?.detach?.(m);
      m.dispose();
    }
    for (const t of this.textures) t.dispose();
    this.root?.traverse?.((o) => o.geometry?.dispose?.());
    this.materials = [];
    this.textures = [];
    this.root = null;
    this.pivot = null;
  }
}

export default Sword;
