/**
 * `envpaint/core` — the portable painting core.
 *
 * Everything re-exported here is free of EnvPaint's app wiring: no module
 * touches `document` or `window` while it is being evaluated, three is the
 * only runtime dependency (a peer), and the pieces that need a world — the
 * Brush — take it by injection rather than importing the app's constants.
 *
 * The app-specific halves (App, IsoCamera, Terrain, Physics, Style, PostFX,
 * the elements and the ghost-panel UI) are deliberately NOT here; import them
 * from their own paths if you want them.
 */

export { Brush } from './Brush.js';
export { PaintLayer, PaintLayers, toBase64, fromBase64 } from './PaintLayers.js';
export { History, stringifyState, parseState } from './History.js';
export { Cutouts, MAX_CUTOUTS } from './Cutouts.js';
export { makeFalloff, edgeRadius, smoothstep, SHAPE_DEFAULTS } from './BrushShape.js';
export { fbm, vnoise, hash21, hash11, hash31 } from './noise.js';
export { Wind } from './Wind.js';
export {
  DRY, PRESENCE_DEPTH, writeLevelDisc, carveDisc, floodFill, derivePresence, bankHeight,
} from './WaterOps.js';

// The world <-> layer-UV mapping EnvPaint itself uses. `WORLD_SIZE` and
// `LAYER_RES` are defaults, never requirements: a Brush takes its world size
// from `opts.worldSize`, and a PaintLayer its resolution from `opts.res`.
export { WORLD_SIZE, HALF, LAYER_RES, worldToUV, uvToWorld, clamp01 } from './constants.js';

// The core's only DOM helper, exported so a host can share the "a text field
// owns the keyboard" rule with its own hotkeys.
export { isTyping } from './dom.js';
