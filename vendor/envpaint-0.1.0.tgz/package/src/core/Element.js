/**
 * Base class for every environment element (grass, water, rocks, …).
 * All methods are no-ops so subclasses only override what they need.
 */
export class Element {
  /** @type {string} unique id, also the key in `ctx.elements` */
  static id = 'element';
  /** @type {string} human label for the UI */
  static label = 'Element';
  /** @type {number} update/draw order, low first */
  static order = 100;

  /**
   * @param {object} ctx the shared app context
   */
  constructor(ctx) {
    /** @type {object} */
    this.ctx = ctx;
  }

  /** Register layers and tools, build meshes. */
  async init() {}

  /**
   * Add ghost-panel folders for this element.
   * @param {object} ui
   */
  // eslint-disable-next-line no-unused-vars
  buildPanel(ui) {}

  /**
   * The objects this element owns that belong in the inspector's Outliner.
   * Elements whose root is neither `this.root` nor `this.mesh` should override.
   * @returns {import('three').Object3D[]}
   */
  sceneObjects() {
    if (this.root) return [this.root];
    return this.mesh ? [this.mesh] : [];
  }

  /**
   * @param {number} dt seconds since the last frame
   * @param {number} time seconds since start
   */
  // eslint-disable-next-line no-unused-vars
  update(dt, time) {}

  /**
   * A paint layer changed since the last frame.
   * @param {import('./PaintLayers.js').PaintLayer} layer
   */
  // eslint-disable-next-line no-unused-vars
  onLayerChanged(layer) {}

  /** The terrain height geometry was rebuilt. */
  onTerrainChanged() {}

  /** @returns {object|null} element parameters for save/load */
  serialize() {
    return null;
  }

  /**
   * Snapshot taken by History around a stroke whose tool names this element
   * (`tool.element`). Override when undo needs more or less than a full save.
   * @returns {object|null}
   */
  captureHistory() {
    return this.serialize();
  }

  /**
   * Restore a `captureHistory()` snapshot. Must leave the element in a clean
   * state — spawners recreate their bodies and meshes from scratch.
   * @param {object|null} state
   */
  restoreHistory(state) {
    this.deserialize(state);
  }

  /**
   * @param {object} o output of `serialize()`
   */
  // eslint-disable-next-line no-unused-vars
  deserialize(o) {}

  /** Release GPU resources. */
  dispose() {}
}
