/**
 * World and paint-layer constants plus the world <-> layer-UV mapping.
 * Every shader derives layer UVs from world position with the same formula.
 */

/** Ground extent in world units (square, centred on the origin). */
export const WORLD_SIZE = 48;

/** Half extent: x, z are in [-HALF, HALF]. */
export const HALF = WORLD_SIZE / 2;

/** Resolution of every paint layer, in texels per side. */
export const LAYER_RES = 512;

/**
 * World position -> layer UV.
 * @param {number} x
 * @param {number} z
 * @returns {{u: number, v: number}} UV in 0..1 (unclamped outside the world)
 */
export function worldToUV(x, z) {
  return { u: x / WORLD_SIZE + 0.5, v: z / WORLD_SIZE + 0.5 };
}

/**
 * Layer UV -> world position on the ground plane.
 * @param {number} u
 * @param {number} v
 * @returns {{x: number, z: number}}
 */
export function uvToWorld(u, v) {
  return { x: (u - 0.5) * WORLD_SIZE, z: (v - 0.5) * WORLD_SIZE };
}

/**
 * @param {number} x
 * @returns {number} x clamped to 0..1
 */
export function clamp01(x) {
  return x < 0 ? 0 : x > 1 ? 1 : x;
}
