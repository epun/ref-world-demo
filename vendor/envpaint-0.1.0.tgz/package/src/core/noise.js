/**
 * CPU mirror of the noise helpers in `shaders/toon.glsl.js`.
 * Naming follows `hash<inputDims><outputDims>`; results match the GLSL versions
 * to within float32/float64 precision, which is plenty for wind sampling.
 */

const fract = (x) => x - Math.floor(x);

/**
 * @param {number} p
 * @returns {number} pseudo-random 0..1
 */
export function hash11(p) {
  let v = fract(p * 0.1031);
  v *= v + 33.33;
  v *= v + v;
  return fract(v);
}

/**
 * @param {number} x
 * @param {number} y
 * @returns {number} pseudo-random 0..1
 */
export function hash21(x, y) {
  let px = fract(x * 0.1031);
  let py = fract(y * 0.1031);
  let pz = fract(x * 0.1031);
  const d = px * (py + 33.33) + py * (pz + 33.33) + pz * (px + 33.33);
  px += d;
  py += d;
  pz += d;
  return fract((px + py) * pz);
}

/**
 * @param {number} x
 * @param {number} y
 * @param {number} z
 * @returns {number} pseudo-random 0..1
 */
export function hash31(x, y, z) {
  let px = fract(x * 0.1031);
  let py = fract(y * 0.1031);
  let pz = fract(z * 0.1031);
  const d = px * (pz + 31.32) + py * (py + 31.32) + pz * (px + 31.32);
  px += d;
  py += d;
  pz += d;
  return fract((px + py) * pz);
}

/**
 * Value noise with quintic-ish (smoothstep) interpolation.
 * @param {number} x
 * @param {number} y
 * @returns {number} 0..1
 */
export function vnoise(x, y) {
  const ix = Math.floor(x);
  const iy = Math.floor(y);
  const fx = x - ix;
  const fy = y - iy;
  const ux = fx * fx * (3 - 2 * fx);
  const uy = fy * fy * (3 - 2 * fy);
  const a = hash21(ix, iy);
  const b = hash21(ix + 1, iy);
  const c = hash21(ix, iy + 1);
  const d = hash21(ix + 1, iy + 1);
  const top = a + (b - a) * ux;
  const bottom = c + (d - c) * ux;
  return top + (bottom - top) * uy;
}

/**
 * Fractal brownian motion over `vnoise`, up to 5 octaves.
 * @param {number} x
 * @param {number} y
 * @param {number} [octaves=3]
 * @returns {number} roughly 0..1
 */
export function fbm(x, y, octaves = 3) {
  let v = 0;
  let amp = 0.5;
  let px = x;
  let py = y;
  const n = Math.min(5, Math.max(1, octaves | 0));
  for (let i = 0; i < n; i++) {
    v += amp * vnoise(px, py);
    px = px * 2.02 + 17.0;
    py = py * 2.02 + 17.0;
    amp *= 0.5;
  }
  return v;
}
