import * as THREE from 'three';
import { makeFalloff } from './BrushShape.js';
import { LAYER_RES } from './constants.js';

const FORMATS = {
  1: THREE.RedFormat,
  2: THREE.RGFormat,
  4: THREE.RGBAFormat,
};

/**
 * @param {number} e0
 * @param {number} e1
 * @param {number} x
 * @returns {number}
 */
function smoothstep(e0, e1, x) {
  if (e1 <= e0) return x < e1 ? 0 : 1;
  let t = (x - e0) / (e1 - e0);
  t = t < 0 ? 0 : t > 1 ? 1 : t;
  return t * t * (3 - 2 * t);
}

const B64 = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/';

/**
 * @param {Uint8Array} bytes
 * @returns {string} base64
 */
export function toBase64(bytes) {
  let out = '';
  for (let i = 0; i < bytes.length; i += 3) {
    const b0 = bytes[i];
    const b1 = i + 1 < bytes.length ? bytes[i + 1] : 0;
    const b2 = i + 2 < bytes.length ? bytes[i + 2] : 0;
    out += B64[b0 >> 2];
    out += B64[((b0 & 3) << 4) | (b1 >> 4)];
    out += i + 1 < bytes.length ? B64[((b1 & 15) << 2) | (b2 >> 6)] : '=';
    out += i + 2 < bytes.length ? B64[b2 & 63] : '=';
  }
  return out;
}

const B64_INV = (() => {
  const t = new Uint8Array(128);
  for (let i = 0; i < B64.length; i++) t[B64.charCodeAt(i)] = i;
  return t;
})();

/**
 * @param {string} str base64
 * @returns {Uint8Array}
 */
export function fromBase64(str) {
  const clean = str.replace(/[^A-Za-z0-9+/]/g, '');
  const len = Math.floor((clean.length * 3) / 4);
  const out = new Uint8Array(len);
  let o = 0;
  for (let i = 0; i < clean.length; i += 4) {
    const c0 = B64_INV[clean.charCodeAt(i)];
    const c1 = B64_INV[clean.charCodeAt(i + 1)];
    const c2 = B64_INV[clean.charCodeAt(i + 2)];
    const c3 = B64_INV[clean.charCodeAt(i + 3)];
    if (o < len) out[o++] = (c0 << 2) | (c1 >> 4);
    if (o < len) out[o++] = ((c1 & 15) << 4) | (c2 >> 2);
    if (o < len) out[o++] = ((c2 & 3) << 6) | c3;
  }
  return out;
}

/**
 * A single paintable channel-set: a CPU typed array plus the DataTexture that
 * mirrors it. All painting goes through `stamp()`; the GPU upload happens once
 * per frame in `commit()`.
 */
export class PaintLayer {
  /**
   * @param {string} id unique layer id
   * @param {object} [opts]
   * @param {1|2|4} [opts.channels=1]
   * @param {boolean} [opts.float=false] Float32 storage (unclamped world units)
   * @param {number} [opts.initial=0] initial value (0..1 for byte layers)
   * @param {number} [opts.res=LAYER_RES]
   * @param {boolean} [opts.history=true] false for simulated layers that must
   *   not take part in undo (they are rewritten every frame anyway)
   */
  constructor(id, opts = {}) {
    const { channels = 1, float = false, initial = 0, res = LAYER_RES, history = true } = opts;
    if (!FORMATS[channels]) throw new Error(`PaintLayer '${id}': channels must be 1, 2 or 4`);

    /** @type {string} */
    this.id = id;
    /** @type {number} */
    this.res = res;
    /** @type {1|2|4} */
    this.channels = channels;
    /** @type {boolean} */
    this.float = float;
    /** @type {number} */
    this.initial = initial;
    /** @type {boolean} whether History tracks this layer */
    this.history = history;
    /** @type {number} increments on every stamp/clear */
    this.version = 0;
    /** @type {{x0:number,y0:number,x1:number,y1:number}|null} */
    this.dirtyRect = null;

    const count = res * res * channels;
    /** @type {Uint8Array|Float32Array} */
    this.data = float ? new Float32Array(count) : new Uint8Array(count);

    this.texture = new THREE.DataTexture(
      this.data,
      res,
      res,
      FORMATS[channels],
      float ? THREE.FloatType : THREE.UnsignedByteType,
    );
    this.texture.name = `layer:${id}`;
    this.texture.minFilter = THREE.LinearFilter;
    this.texture.magFilter = THREE.LinearFilter;
    this.texture.generateMipmaps = false;
    this.texture.wrapS = THREE.ClampToEdgeWrapping;
    this.texture.wrapT = THREE.ClampToEdgeWrapping;
    this.texture.flipY = false;
    this.texture.colorSpace = THREE.NoColorSpace;
    if (!float) this.texture.unpackAlignment = 1;

    if (initial !== 0) this.fill(initial);
    this.texture.needsUpdate = true;
  }

  /**
   * Raw storage value for a normalised 0..1 (or raw float) value.
   * @param {number} v
   * @returns {number}
   */
  encode(v) {
    if (this.float) return v;
    const c = v < 0 ? 0 : v > 1 ? 1 : v;
    return Math.round(c * 255);
  }

  /**
   * Normalised value for a raw storage value.
   * @param {number} v
   * @returns {number}
   */
  decode(v) {
    return this.float ? v : v / 255;
  }

  /**
   * Overwrite every texel without touching dirty tracking.
   * @param {number} value normalised (byte) or raw (float)
   */
  fill(value) {
    this.data.fill(this.encode(value));
  }

  /**
   * Reset the whole layer and mark it fully dirty.
   * @param {number} [value=this.initial]
   */
  clear(value = this.initial) {
    this.fill(value);
    this.version++;
    this._markDirty(0, 0, this.res - 1, this.res - 1);
  }

  /**
   * Texel index of (x, y, channel).
   * @param {number} x
   * @param {number} y
   * @param {number} [ch=0]
   * @returns {number}
   */
  index(x, y, ch = 0) {
    return (y * this.res + x) * this.channels + ch;
  }

  /**
   * Bilinear read at a UV coordinate, clamped at the edges.
   * @param {number} u
   * @param {number} v
   * @param {number} [ch=0]
   * @returns {number} 0..1 for byte layers, raw value for float layers
   */
  sample(u, v, ch = 0) {
    const res = this.res;
    const fx = u * res - 0.5;
    const fy = v * res - 0.5;
    const x0 = Math.floor(fx);
    const y0 = Math.floor(fy);
    const tx = fx - x0;
    const ty = fy - y0;
    const cx0 = x0 < 0 ? 0 : x0 > res - 1 ? res - 1 : x0;
    const cy0 = y0 < 0 ? 0 : y0 > res - 1 ? res - 1 : y0;
    const x1 = x0 + 1;
    const y1 = y0 + 1;
    const cx1 = x1 < 0 ? 0 : x1 > res - 1 ? res - 1 : x1;
    const cy1 = y1 < 0 ? 0 : y1 > res - 1 ? res - 1 : y1;
    const d = this.data;
    const a = d[this.index(cx0, cy0, ch)];
    const b = d[this.index(cx1, cy0, ch)];
    const c = d[this.index(cx0, cy1, ch)];
    const e = d[this.index(cx1, cy1, ch)];
    const top = a + (b - a) * tx;
    const bot = c + (e - c) * tx;
    return this.decode(top + (bot - top) * ty);
  }

  /**
   * Paint one dab. All coordinates are UV; radius is in UV units.
   * @param {object} op
   * @param {number} op.u
   * @param {number} op.v
   * @param {number} op.radius UV radius
   * @param {number} [op.strength=1]
   * @param {number} [op.hardness=0.5] 0 = soft falloff, 1 = hard edge
   * @param {'add'|'erase'|'set'|'smooth'|'direction'|'raise'|'lower'|'flatten'} [op.mode='add']
   * @param {number} [op.value=1] target for 'set'
   * @param {number} [op.channel=0]
   * @param {{x:number,y:number}} [op.dir] for 'direction'
   * @param {number} [op.flattenTo=0] for 'flatten'
   */
  stamp(op) {
    const {
      u,
      v,
      radius,
      strength = 1,
      hardness = 0.5,
      mode = 'add',
      value = 1,
      channel = 0,
      dir,
      flattenTo = 0,
    } = op;
    if (!(radius > 0)) return;

    const res = this.res;
    // The edge shape (noise, spatter, aspect) lives in one place so every
    // disc a brush stamps agrees on it; see core/BrushShape.js.
    const fall = makeFalloff({ ...op, hardness });
    const rTexels = fall.bound * res;
    const cx = u * res;
    const cy = v * res;
    let x0 = Math.floor(cx - rTexels);
    let x1 = Math.ceil(cx + rTexels);
    let y0 = Math.floor(cy - rTexels);
    let y1 = Math.ceil(cy + rTexels);
    x0 = x0 < 0 ? 0 : x0;
    y0 = y0 < 0 ? 0 : y0;
    x1 = x1 > res - 1 ? res - 1 : x1;
    y1 = y1 > res - 1 ? res - 1 : y1;
    if (x1 < x0 || y1 < y0) return;

    // 'smooth' reads a snapshot so the result does not depend on write order.
    const snap = mode === 'smooth' ? this._snapshot(x0, y0, x1, y1, channel) : null;
    const snapW = x1 - x0 + 1;

    const dirX = dir ? dir.x * 0.5 + 0.5 : 0.5;
    const dirY = dir ? dir.y * 0.5 + 0.5 : 0.5;

    for (let y = y0; y <= y1; y++) {
      const dv = (y + 0.5) / res - v;
      for (let x = x0; x <= x1; x++) {
        const du = (x + 0.5) / res - u;
        const f = fall.f(du, dv, x, y);
        if (f <= 0) continue;
        const s = strength * f;

        if (mode === 'direction') {
          const i0 = this.index(x, y, 0);
          const i1 = this.index(x, y, 1);
          const a0 = this.decode(this.data[i0]);
          const a1 = this.decode(this.data[i1]);
          this.data[i0] = this.encode(a0 + (dirX - a0) * s);
          this.data[i1] = this.encode(a1 + (dirY - a1) * s);
          continue;
        }

        const i = this.index(x, y, channel);
        const a = this.decode(this.data[i]);
        let out = a;
        switch (mode) {
          case 'add':
            out = Math.min(1, a + s);
            break;
          case 'erase':
            out = Math.max(0, a - s);
            break;
          case 'set':
            out = a + (value - a) * s;
            break;
          case 'raise':
            out = a + s;
            break;
          case 'lower':
            out = a - s;
            break;
          case 'flatten':
            out = a + (flattenTo - a) * s;
            break;
          case 'smooth': {
            let sum = 0;
            let n = 0;
            for (let ny = y - 1; ny <= y + 1; ny++) {
              for (let nx = x - 1; nx <= x + 1; nx++) {
                const qx = nx < 0 ? 0 : nx > res - 1 ? res - 1 : nx;
                const qy = ny < 0 ? 0 : ny > res - 1 ? res - 1 : ny;
                const inRect = qx >= x0 && qx <= x1 && qy >= y0 && qy <= y1;
                sum += inRect
                  ? snap[(qy - y0) * snapW + (qx - x0)]
                  : this.decode(this.data[this.index(qx, qy, channel)]);
                n++;
              }
            }
            const mean = sum / n;
            out = a + (mean - a) * s;
            break;
          }
          default:
            throw new Error(`PaintLayer '${this.id}': unknown stamp mode '${mode}'`);
        }
        this.data[i] = this.encode(out);
      }
    }

    this.version++;
    this._markDirty(x0, y0, x1, y1);
  }

  /**
   * Mark a texel rect changed without going through `stamp()` — used by undo
   * when it writes recorded bytes straight into `data`. Bumps `version` so the
   * usual per-frame `onLayerChanged` / terrain rebuild path picks it up.
   * @param {number} x0
   * @param {number} y0
   * @param {number} x1
   * @param {number} y1
   */
  markDirtyRect(x0, y0, x1, y1) {
    this.version++;
    this._markDirty(x0, y0, x1, y1);
    return this;
  }

  /**
   * Upload to the GPU if anything changed since the last commit.
   * @returns {boolean} whether an upload was scheduled
   */
  commit() {
    if (!this.dirtyRect) return false;
    this.texture.needsUpdate = true;
    this.dirtyRect = null;
    return true;
  }

  /** @returns {string} base64 of the raw storage bytes */
  serialize() {
    const bytes = new Uint8Array(this.data.buffer, this.data.byteOffset, this.data.byteLength);
    return toBase64(bytes);
  }

  /**
   * @param {string} b64 output of `serialize()`
   */
  deserialize(b64) {
    const bytes = fromBase64(b64);
    const dst = new Uint8Array(this.data.buffer, this.data.byteOffset, this.data.byteLength);
    if (bytes.length !== dst.length) {
      throw new Error(
        `PaintLayer '${this.id}': expected ${dst.length} bytes, got ${bytes.length}`,
      );
    }
    dst.set(bytes);
    this.version++;
    this._markDirty(0, 0, this.res - 1, this.res - 1);
  }

  dispose() {
    this.texture.dispose();
  }

  /**
   * @private
   */
  _snapshot(x0, y0, x1, y1, channel) {
    const w = x1 - x0 + 1;
    const h = y1 - y0 + 1;
    const out = new Float32Array(w * h);
    for (let y = y0; y <= y1; y++) {
      for (let x = x0; x <= x1; x++) {
        out[(y - y0) * w + (x - x0)] = this.decode(this.data[this.index(x, y, channel)]);
      }
    }
    return out;
  }

  /**
   * @private
   */
  _markDirty(x0, y0, x1, y1) {
    const r = this.dirtyRect;
    if (!r) {
      this.dirtyRect = { x0, y0, x1, y1 };
      return;
    }
    if (x0 < r.x0) r.x0 = x0;
    if (y0 < r.y0) r.y0 = y0;
    if (x1 > r.x1) r.x1 = x1;
    if (y1 > r.y1) r.y1 = y1;
  }
}

/** Registry of every paint layer in the world. */
export class PaintLayers {
  constructor() {
    /** @type {Map<string, PaintLayer>} */
    this.map = new Map();
  }

  /**
   * @param {PaintLayer} layer
   * @returns {PaintLayer} the same layer, for chaining
   */
  add(layer) {
    if (this.map.has(layer.id)) throw new Error(`PaintLayers: duplicate layer '${layer.id}'`);
    this.map.set(layer.id, layer);
    return layer;
  }

  /**
   * @param {string} id
   * @returns {PaintLayer|undefined}
   */
  get(id) {
    return this.map.get(id);
  }

  /**
   * @param {string} id
   * @returns {boolean}
   */
  has(id) {
    return this.map.has(id);
  }

  /** @returns {PaintLayer[]} */
  all() {
    return [...this.map.values()];
  }

  /** Upload every dirty layer. Called once per frame by the App. */
  commitAll() {
    for (const layer of this.map.values()) layer.commit();
  }

  /** @returns {Record<string, string>} base64 payload per layer id */
  serialize() {
    const out = {};
    for (const layer of this.map.values()) out[layer.id] = layer.serialize();
    return out;
  }

  /**
   * @param {Record<string, string>} data output of `serialize()`
   */
  deserialize(data) {
    for (const [id, b64] of Object.entries(data || {})) {
      const layer = this.map.get(id);
      if (layer) layer.deserialize(b64);
    }
  }

  dispose() {
    for (const layer of this.map.values()) layer.dispose();
    this.map.clear();
  }
}
