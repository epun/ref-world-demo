import { makeFalloff } from './BrushShape.js';

/**
 * Pure water-level operations over flat typed arrays, with no Three.js, no
 * DOM and no clocks. `src/elements/Water.js` is the renderer and brush host;
 * these are the parts another project can run on its own heightfield (see
 * docs/port-meridian.md).
 *
 * Conventions shared with Water.js:
 *   - a level field is a Float32Array of absolute surface heights, `DRY`
 *     (-1000) where there is no water; the ground is a Float32Array of the
 *     same length; both are `res × res`, row-major, texel (x, y) at y*res+x
 *   - presence is a Uint8Array 0..255: depth / PRESENCE_DEPTH, saturated
 *   - u, v are 0..1 layer coordinates; radius is in the same units
 *   - every function returns the texel rect it touched, `null` if none, so a
 *     caller can mark textures dirty and re-derive only what changed
 */

/** Sentinel level for "no water here". */
export const DRY = -1000;
/** Depth at which derived presence saturates. */
export const PRESENCE_DEPTH = 0.35;

/**
 * @typedef {{x0:number, y0:number, x1:number, y1:number}} Rect
 */

/**
 * Texel bounds of a disc, clamped to the layer.
 * @param {number} res
 * @param {number} u
 * @param {number} v
 * @param {number} bound radius in layer units
 * @returns {Rect|null}
 */
function discRect(res, u, v, bound) {
  const rt = bound * res;
  if (!(rt > 0)) return null;
  const cx = u * res;
  const cy = v * res;
  const x0 = Math.max(0, Math.floor(cx - rt));
  const x1 = Math.min(res - 1, Math.ceil(cx + rt));
  const y0 = Math.max(0, Math.floor(cy - rt));
  const y1 = Math.min(res - 1, Math.ceil(cy + rt));
  if (x1 < x0 || y1 < y0) return null;
  return { x0, y0, x1, y1 };
}

/**
 * Fill or drain a disc of the level field.
 *
 * 'fill' raises the level to `target` where the ground is below it (basin-
 * aware: a ridge inside the brush stays dry), capped `maxDepth` above the
 * ground with a taper toward the rim so overlapping dabs blend into one
 * channel. 'drain' sets the disc to `DRY`.
 *
 * @param {object} o
 * @param {Float32Array} o.level
 * @param {Float32Array} o.ground
 * @param {number} o.res
 * @param {number} o.u
 * @param {number} o.v
 * @param {number} o.radius layer units
 * @param {number} [o.hardness=0.5]
 * @param {'fill'|'drain'} o.op
 * @param {number} [o.target] absolute surface height for 'fill'
 * @param {number} [o.maxDepth=Infinity] depth cap per texel
 * @param {object} [o.shape] edge-shape op fields (edgeNoise, edgeScale, spatter, aspect, seed, dir)
 * @returns {Rect|null}
 */
export function writeLevelDisc(o) {
  const { level, ground, res, u, v, radius, op } = o;
  const hardness = o.hardness ?? 0.5;
  const maxDepth = o.maxDepth ?? Infinity;
  const target = o.target ?? 0;
  const fall = makeFalloff({ ...(o.shape || {}), radius, hardness });
  const rect = discRect(res, u, v, fall.bound);
  if (!rect) return null;
  let touched = false;
  for (let y = rect.y0; y <= rect.y1; y++) {
    const dv = (y + 0.5) / res - v;
    for (let x = rect.x0; x <= rect.x1; x++) {
      const du = (x + 0.5) / res - u;
      const f = fall.f(du, dv, x, y);
      if (f <= 0.05) continue;
      const i = y * res + x;
      if (op === 'drain') {
        if (level[i] !== DRY) { level[i] = DRY; touched = true; }
        continue;
      }
      const cap = ground[i] + maxDepth * (0.35 + 0.65 * f);
      const t = target < cap ? target : cap;
      if (level[i] < t) { level[i] = t; touched = true; }
    }
  }
  return touched ? rect : null;
}

/**
 * Cut a channel or a bowl into a height field, lowering only.
 *
 * `bed` is the absolute height to cut toward; with `rim` the bed is a bowl,
 * full depth at the centre easing back to `rim` at the edge. `pressure` is
 * the blend toward the bed per call (0..1). `from` freezes the reference the
 * cut is measured against (a stroke's starting heights) so overlapping dabs
 * cannot ratchet deeper than `maxCut` below where the ground stood.
 *
 * @param {object} o
 * @param {Float32Array} o.height
 * @param {Float32Array} [o.from] reference heights; defaults to `height`
 * @param {number} o.res
 * @param {number} o.u
 * @param {number} o.v
 * @param {number} o.radius layer units
 * @param {number} [o.hardness=0.3]
 * @param {number} o.bed
 * @param {number} [o.pressure=1]
 * @param {number} [o.maxCut=Infinity]
 * @param {number} [o.rim]
 * @param {object} [o.shape]
 * @returns {Rect|null}
 */
export function carveDisc(o) {
  const { height, res, u, v, radius, bed } = o;
  const from = o.from || height;
  const hardness = o.hardness ?? 0.3;
  const pressure = Math.max(0, Math.min(1, o.pressure ?? 1));
  const maxCut = o.maxCut ?? Infinity;
  const rim = o.rim;
  const fall = makeFalloff({ ...(o.shape || {}), radius, hardness });
  const rect = discRect(res, u, v, fall.bound);
  if (!rect) return null;
  let touched = false;
  for (let y = rect.y0; y <= rect.y1; y++) {
    const dv = (y + 0.5) / res - v;
    for (let x = rect.x0; x <= rect.x1; x++) {
      const du = (x + 0.5) / res - u;
      const f = fall.f(du, dv, x, y);
      if (f <= 0.02) continue;
      const i = y * res + x;
      const localBed = rim === undefined ? bed : rim - (rim - bed) * f;
      const target = Math.max(localBed, from[i] - maxCut);
      if (height[i] <= target) continue;
      height[i] += (target - height[i]) * pressure * f;
      touched = true;
    }
  }
  return touched ? rect : null;
}

/**
 * Flood a basin: every texel 4-connected to (sx, sy) whose ground is below
 * `target` gets at least that level. Stops at `cap` texels.
 *
 * @param {object} o
 * @param {Float32Array} o.level
 * @param {Float32Array} o.ground
 * @param {number} o.res
 * @param {number} o.sx start texel x
 * @param {number} o.sy start texel y
 * @param {number} o.target absolute surface height
 * @param {number} [o.cap=200000]
 * @returns {{filled:number, rect:Rect|null}}
 */
export function floodFill(o) {
  const { level, ground, res, sx, sy, target } = o;
  const cap = o.cap ?? 200000;
  const start = sy * res + sx;
  if (sx < 0 || sy < 0 || sx >= res || sy >= res || ground[start] >= target) {
    return { filled: 0, rect: null };
  }
  const seen = new Uint8Array(res * res);
  const queue = new Int32Array(Math.min(cap, res * res));
  let head = 0;
  let tail = 0;
  queue[tail++] = start;
  seen[start] = 1;
  let x0 = sx, x1 = sx, y0 = sy, y1 = sy;
  let filled = 0;
  while (head < tail) {
    const i = queue[head++];
    const cy = (i / res) | 0;
    const cx = i - cy * res;
    if (level[i] < target) level[i] = target;
    filled++;
    if (cx < x0) x0 = cx;
    if (cx > x1) x1 = cx;
    if (cy < y0) y0 = cy;
    if (cy > y1) y1 = cy;
    for (let k = 0; k < 4; k++) {
      const nx = cx + (k === 0 ? -1 : k === 1 ? 1 : 0);
      const ny = cy + (k === 2 ? -1 : k === 3 ? 1 : 0);
      if (nx < 0 || ny < 0 || nx >= res || ny >= res) continue;
      const ni = ny * res + nx;
      if (seen[ni] || ground[ni] >= target) continue;
      if (tail >= queue.length) break;
      seen[ni] = 1;
      queue[tail++] = ni;
    }
  }
  return { filled, rect: { x0, y0, x1, y1 } };
}

/**
 * Derive the presence byte layer from level and ground over a rect. The
 * effective level is `max(level, seaLevel)`, so an ocean needs no painting.
 *
 * @param {object} o
 * @param {Float32Array} o.level
 * @param {Float32Array} o.ground
 * @param {Uint8Array|Uint8ClampedArray} o.presence
 * @param {number} o.res
 * @param {number} [o.seaLevel=DRY]
 * @param {Rect} [o.rect] defaults to the whole layer
 */
export function derivePresence(o) {
  const { level, ground, presence, res } = o;
  const sea = o.seaLevel ?? DRY;
  const r = o.rect || { x0: 0, y0: 0, x1: res - 1, y1: res - 1 };
  for (let y = r.y0; y <= r.y1; y++) {
    const row = y * res;
    for (let x = r.x0; x <= r.x1; x++) {
      const i = row + x;
      const lv = level[i] > sea ? level[i] : sea;
      const depth = lv - ground[i];
      const p = depth <= 0 ? 0 : depth >= PRESENCE_DEPTH ? 1 : depth / PRESENCE_DEPTH;
      presence[i] = (p * 255) | 0;
    }
  }
}

/**
 * Untouched-bank height around a point: the mean ground height on a ring of
 * radius `r` (or, with a stroke direction, on the two banks either side of
 * it). Pond and river strokes reference their level to this rather than to
 * the ground under the brush, so a carved centre never ratchets the level
 * down as the stroke goes over it.
 *
 * @param {(x:number, z:number) => number} heightAt
 * @param {number} x
 * @param {number} z
 * @param {number} r world units
 * @param {{x:number, y:number}|null} [dir]
 * @returns {number}
 */
export function bankHeight(heightAt, x, z, r, dir) {
  let sum = 0;
  if (dir) {
    const px = -dir.y;
    const pz = dir.x;
    for (const d of [r, -r, r * 1.4, -r * 1.4]) sum += heightAt(x + px * d, z + pz * d);
    return sum / 4;
  }
  for (let i = 0; i < 8; i++) {
    const a = (i / 8) * Math.PI * 2;
    sum += heightAt(x + Math.cos(a) * r, z + Math.sin(a) * r);
  }
  return sum / 8;
}
