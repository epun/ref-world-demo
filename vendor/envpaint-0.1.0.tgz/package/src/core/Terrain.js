import * as THREE from 'three';
import { WORLD_SIZE, worldToUV } from './constants.js';
import { PaintLayer } from './PaintLayers.js';
import { toonParsVertex, toonShadowVertex, toonParsFragment } from './shaders/toon.glsl.js';

const SEGMENTS = 255;

/** Layer ids the ground shader can blend, mapped to their uniform names. */
const LAYER_UNIFORMS = {
  height: 'uHeight',
  mask: 'uMask',
  path: 'uPath',
  grass: 'uGrass',
  water: 'uWater',
  scorch: 'uScorch',
};

/**
 * @returns {THREE.DataTexture} 1x1 black stand-in for layers that don't exist yet
 */
function blackTexture() {
  const tex = new THREE.DataTexture(new Uint8Array([0, 0, 0, 0]), 1, 1, THREE.RGBAFormat);
  tex.needsUpdate = true;
  return tex;
}

/**
 * The painted ground: a height-sculpted plane drawn with the toon ground
 * shader. Owns the `height`, `mask` and `path` layers and the sculpt/mask/path
 * brush tools.
 */
export class Terrain {
  /**
   * @param {object} ctx shared app context (needs scene, layers, sun, wind)
   */
  constructor(ctx) {
    /** @type {object} */
    this.ctx = ctx;
    /** @type {number} increments whenever the height geometry was rebuilt */
    this.version = 0;

    /** @type {PaintLayer} float height in world units */
    this.heightLayer = ctx.layers.add(new PaintLayer('height', { channels: 1, float: true, initial: 0 }));
    /** @type {PaintLayer} exclusion mask */
    this.maskLayer = ctx.layers.add(new PaintLayer('mask', { channels: 1, float: false, initial: 0 }));
    /** @type {PaintLayer} dirt road */
    this.pathLayer = ctx.layers.add(new PaintLayer('path', { channels: 1, float: false, initial: 0 }));

    this._placeholder = blackTexture();
    this._lastHeightVersion = -1;

    const geometry = new THREE.PlaneGeometry(WORLD_SIZE, WORLD_SIZE, SEGMENTS, SEGMENTS);
    geometry.rotateX(-Math.PI / 2);
    this.geometry = geometry;

    this.material = this._buildMaterial();
    this.material.userData.uiProps = this._materialProps();
    this.material.userData.swatch = ['#8fcf5a', '#6ab545', '#c69a63'];
    ctx.style?.attach?.(this.material, { element: 'terrain' });

    /** @type {THREE.Mesh} */
    this.mesh = new THREE.Mesh(geometry, this.material);
    this.mesh.name = 'terrain';
    this.mesh.receiveShadow = true;
    this.mesh.castShadow = false;
    this.mesh.matrixAutoUpdate = false;
    this.mesh.updateMatrix();
    ctx.scene.add(this.mesh);

    this.setLayerTexture('height', this.heightLayer.texture);
    this.setLayerTexture('mask', this.maskLayer.texture);
    this.setLayerTexture('path', this.pathLayer.texture);

    this.applyHeightToGeometry();
  }

  /** @private */
  _buildMaterial() {
    const { sun, wind } = this.ctx;
    const color = (hex) => ({ value: new THREE.Color(hex) });

    const uniforms = Object.assign(
      THREE.UniformsUtils.clone(THREE.UniformsLib.lights),
      sun.uniforms,
      wind.uniforms,
      {
        uHeight: { value: this._placeholder },
        uMask: { value: this._placeholder },
        uPath: { value: this._placeholder },
        uGrass: { value: this._placeholder },
        uWater: { value: this._placeholder },
        uScorch: { value: this._placeholder },
        uWorldSize: { value: WORLD_SIZE },
        uWetness: { value: 0 },
        uShowMask: { value: 0 },   // the hatch overlay is opt-in
        uMaskTint: color('#ff9999'),   // linear (1.0, 0.22, 0.22), the old literal
        uMaskBare: color('#b9a878'),
        uMeadow: color('#8fcf5a'),
        uLush: color('#6ab545'),
        uDirt: color('#c69a63'),
        uDirtEdge: color('#a57b4d'),
        uWetSand: color('#7f7a55'),
        uRock: color('#9a9aa6'),
        uSnow: color('#f6f9ff'),
        uAsh: color('#4a4643'),
        uChar: color('#2f2a27'),
        uSnowHeight: { value: 7.0 },
      },
    );

    const vertexShader = /* glsl */ `
      ${toonParsVertex}
      void main() {
        vec3 transformedNormal = normalMatrix * normal;
        vec4 worldPosition = modelMatrix * vec4(position, 1.0);
        ${toonShadowVertex}
      }
    `;

    const fragmentShader = /* glsl */ `
      ${toonParsFragment}

      uniform float uStyleId;
      uniform sampler2D uHeight;
      uniform sampler2D uMask;
      uniform sampler2D uPath;
      uniform sampler2D uGrass;
      uniform sampler2D uWater;
      uniform sampler2D uScorch;
      uniform float uWorldSize;
      uniform float uWetness;
      uniform float uShowMask;
      uniform vec3 uMaskTint;
      uniform vec3 uMaskBare;
      uniform float uSnowHeight;
      uniform vec3 uMeadow;
      uniform vec3 uLush;
      uniform vec3 uDirt;
      uniform vec3 uDirtEdge;
      uniform vec3 uWetSand;
      uniform vec3 uRock;
      uniform vec3 uSnow;
      uniform vec3 uAsh;
      uniform vec3 uChar;

      void main() {
        vec2 uv = vWorldPos.xz / uWorldSize + 0.5;
        vec3 n = normalize(vNormalW);

        float grass = clamp(texture2D(uGrass, uv).r, 0.0, 1.0);
        float path  = texture2D(uPath, uv).r;
        float water = texture2D(uWater, uv).r;
        float mask  = texture2D(uMask, uv).r;
        float burn  = texture2D(uScorch, uv).r;

        // Meadow -> lush green under dense grass.
        vec3 albedo = mix(uMeadow, uLush, pow(grass, 0.7));

        // Masked ground reads as dry and bare even when the hatch is hidden.
        albedo = mix(albedo, uMaskBare, smoothstep(0.2, 0.6, mask) * 0.6);

        // Large-scale colour break-up so flat ground isn't a solid slab.
        // --- style branches (see "Style branches" in ARCHITECTURE.md) ---
        float cn = fbm(uv * 6.0, 3);
        float breakUp = 0.12;
        if (uStyleId > 0.5 && uStyleId < 1.5) breakUp = 0.0;        // flat: one ink
        else if (uStyleId > 1.5 && uStyleId < 2.5) breakUp = 0.20;  // realistic: soil variation
        else if (uStyleId > 2.5 && uStyleId < 3.5) breakUp = 0.24;  // painterly: washes
        else if (uStyleId > 3.5) { cn = step(0.5, cn); breakUp = 0.10; }  // pixel: two tones
        albedo *= 0.94 + breakUp * cn;

        // Wet sand in the shallow band around water.
        float wet = step(0.05, water) * (1.0 - step(0.5, water));
        albedo = mix(albedo, uWetSand, wet * 0.8);

        // Dirt road, quantised into a darker edge band and a lighter core.
        float pathEdge = step(0.15, path) * (1.0 - step(0.45, path));
        float pathCore = step(0.45, path);
        albedo = mix(albedo, uDirtEdge, pathEdge);
        albedo = mix(albedo, uDirt, pathCore);

        // Burnt ground: a charred rim around an ash core, quantised like the path.
        float burnEdge = step(0.05, burn) * (1.0 - step(0.25, burn));
        float burnCore = step(0.25, burn);
        albedo = mix(albedo, uChar, burnEdge);
        albedo = mix(albedo, uAsh, burnCore);

        // Rock only on genuinely steep slopes, with a hard but noisy edge so
        // gentle hills stay green.
        float rockEdge = 0.55 + (fbm(uv * 30.0, 2) - 0.5) * 0.15;
        float rock = 1.0 - step(rockEdge, n.y);
        // Realistic ground does not change material at a painted edge.
        if (uStyleId > 1.5 && uStyleId < 2.5) rock = 1.0 - smoothstep(rockEdge - 0.2, rockEdge + 0.1, n.y);
        albedo = mix(albedo, uRock, rock * 0.85);

        // Snow above a noisy height threshold.
        float snowNoise = fbm(vWorldPos.xz * 0.12, 3);
        float snowLine = uSnowHeight + (snowNoise - 0.5) * 2.5;
        float snow = step(snowLine, vWorldPos.y);
        if (uStyleId > 1.5 && uStyleId < 2.5) snow = smoothstep(snowLine - 1.2, snowLine + 0.6, vWorldPos.y);
        albedo = mix(albedo, uSnow, snow);

        // Water darkens the ground beneath it.
        albedo *= 1.0 - 0.35 * smoothstep(0.05, 0.6, water);

        // Rain-soaked ground goes darker and a little bluer.
        albedo *= mix(1.0, 0.72, uWetness);
        albedo = mix(albedo, albedo * vec3(0.88, 0.96, 1.12), uWetness);

        vec3 col = toonLight(albedo, n, toonShadow(), 3.0);

        // Red diagonal hatch where painting is excluded.
        if (uShowMask > 0.5 && mask > 0.02) {
          float hatch = 1.0 - step(0.35, fract((vWorldPos.x + vWorldPos.z) * 2.0));
          col = mix(col, uMaskTint, 0.45 * hatch * clamp(mask, 0.0, 1.0));
        }

        // Ground hatches on its shade side, but rock faces keep their flat
        // cel tone — outline only, like the Rocks element.
        gl_FragColor = vec4(col, mix(toonInkAlpha(), 0.75, rock));
        #include <colorspace_fragment>
      }
    `;

    return new THREE.ShaderMaterial({
      name: 'Ground',
      uniforms,
      vertexShader,
      fragmentShader,
      lights: true,
      toneMapped: false,
    });
  }

  /**
   * Point a ground-shader layer sampler at a real layer texture. Elements that
   * own a layer (grass, water, scorch, …) call this once their layer exists.
   * @param {'height'|'mask'|'path'|'grass'|'water'|'scorch'} name
   * @param {THREE.Texture} texture
   */
  setLayerTexture(name, texture) {
    const uniform = LAYER_UNIFORMS[name];
    if (!uniform) throw new Error(`Terrain: unknown layer texture '${name}'`);
    this.material.uniforms[uniform].value = texture || this._placeholder;
  }

  /**
   * How rain-soaked the ground looks.
   * @param {number} w 0 = dry, 1 = fully wet
   */
  setWetness(w) {
    this.material.uniforms.uWetness.value = Math.max(0, Math.min(1, w));
    return this;
  }

  /** @returns {number} current wetness, 0..1 */
  get wetness() {
    return this.material.uniforms.uWetness.value;
  }

  /** @returns {boolean} whether the red exclusion hatch is drawn */
  get showMask() {
    return this.material.uniforms.uShowMask.value > 0.5;
  }

  set showMask(v) {
    this.material.uniforms.uShowMask.value = v ? 1 : 0;
  }

  /**
   * Re-colour the ground for a style. Only the keys present are written, so a
   * palette may name just `meadow` and leave the rest alone.
   * @param {{meadow?:string, lush?:string, dirt?:string, dirtEdge?:string,
   *          wetSand?:string, rock?:string, snow?:string, ash?:string,
   *          char?:string}} [p]
   */
  applyPalette(p) {
    if (!p) return this;
    const u = this.material.uniforms;
    const map = {
      meadow: 'uMeadow',
      lush: 'uLush',
      dirt: 'uDirt',
      dirtEdge: 'uDirtEdge',
      wetSand: 'uWetSand',
      rock: 'uRock',
      snow: 'uSnow',
      ash: 'uAsh',
      char: 'uChar',
      maskBare: 'uMaskBare',
    };
    for (const [key, name] of Object.entries(map)) {
      if (p[key] != null && u[name]) u[name].value.set(p[key]);
    }
    return this;
  }

  /**
   * @private Ground colours, for the inspector's Material folder. Every setter
   * goes through `applyPalette` so a style switch and a hand edit write the
   * same place. See "Material descriptors" in ARCHITECTURE.md.
   * @returns {Array<object>}
   */
  _materialProps() {
    const u = this.material.uniforms;
    const hex = (name) => `#${u[name].value.getHexString()}`;
    const swatch = (label, key, name, tooltip) => ({
      label,
      kind: 'color',
      tooltip,
      get: () => hex(name),
      set: (v) => this.applyPalette({ [key]: v }),
    });
    return [
      swatch('Meadow', 'meadow', 'uMeadow', 'Bare ground between the grass'),
      swatch('Lush', 'lush', 'uLush', 'Ground under dense grass'),
      swatch('Path', 'dirt', 'uDirt', 'Painted with the Path tool'),
      swatch('Path edge', 'dirtEdge', 'uDirtEdge', 'Rim of a painted path'),
      swatch('Rock', 'rock', 'uRock', 'Steep slopes'),
      swatch('Snow', 'snow', 'uSnow', 'Above the snow height'),
      swatch('Ash', 'ash', 'uAsh', 'Ground a fire has passed over'),
      swatch('Scorch', 'char', 'uChar', 'The burnt heart of a scorch mark'),
      swatch('Masked ground', 'maskBare', 'uMaskBare', 'Dry bare ground where the Mask tool blocks growth'),
      {
        label: 'Mask overlay',
        kind: 'color',
        tooltip: 'Hatch drawn where the Mask tool blocks growth',
        get: () => hex('uMaskTint'),
        set: (v) => u.uMaskTint.value.set(v),
      },
    ];
  }

  /**
   * Register the sculpt / mask / path tools.
   * @param {import('./Brush.js').Brush} brush
   */
  registerTools(brush) {
    brush.registerTool({
      id: 'sculpt',
      label: 'Sculpt',
      color: '#d9b36c',
      key: '0',
      layer: 'height',
      mode: 'raise',
      eraseMode: 'lower',
      altMode: 'smooth',
      strengthScale: 3,
    });
    brush.registerTool({
      id: 'mask',
      label: 'Mask',
      color: '#ff5a5a',
      key: '9',
      layer: 'mask',
      mode: 'add',
      eraseMode: 'erase',
      strengthScale: 4,   // one pass should read as a full mask
    });
    brush.registerTool({
      id: 'path',
      label: 'Path',
      color: '#b08a5a',
      excludes: ['grass', 'flowers'],   // a road clears what grew there
      key: '8',
      layer: 'path',
      mode: 'add',
      eraseMode: 'erase',
      strengthScale: 1,
    });
    return this;
  }

  /** Rewrite every vertex Y from the height layer and rebuild normals. */
  applyHeightToGeometry() {
    const pos = this.geometry.attributes.position;
    const arr = pos.array;
    for (let i = 0; i < pos.count; i++) {
      const o = i * 3;
      const { u, v } = worldToUV(arr[o], arr[o + 2]);
      arr[o + 1] = this.heightLayer.sample(u, v);
    }
    pos.needsUpdate = true;
    this.geometry.computeVertexNormals();
    this.geometry.computeBoundingSphere();
    this.geometry.computeBoundingBox();
    this._lastHeightVersion = this.heightLayer.version;
    this.version++;
    return this;
  }

  /**
   * @param {number} x
   * @param {number} z
   * @returns {number} world height
   */
  heightAt(x, z) {
    const { u, v } = worldToUV(x, z);
    return this.heightLayer.sample(u, v);
  }

  /**
   * @param {number} x
   * @param {number} z
   * @param {THREE.Vector3} [out]
   * @returns {THREE.Vector3} unit world normal
   */
  normalAt(x, z, out = new THREE.Vector3()) {
    const e = WORLD_SIZE / this.heightLayer.res;
    const hx = this.heightAt(x + e, z) - this.heightAt(x - e, z);
    const hz = this.heightAt(x, z + e) - this.heightAt(x, z - e);
    return out.set(-hx, 2 * e, -hz).normalize();
  }

  /** Rebuild the geometry at most once per frame, when the height layer moved. */
  update() {
    if (this.heightLayer.version !== this._lastHeightVersion) this.applyHeightToGeometry();
  }

  dispose() {
    this.ctx.scene.remove(this.mesh);
    this.geometry.dispose();
    this.material.dispose();
    this._placeholder.dispose();
  }
}
