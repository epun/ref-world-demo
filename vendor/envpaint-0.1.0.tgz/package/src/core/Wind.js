import * as THREE from 'three';
import { fbm } from './noise.js';

/** GLSL smoothstep. */
function smoothstep(e0, e1, x) {
  const t = Math.max(0, Math.min(1, (x - e0) / (e1 - e0)));
  return t * t * (3 - 2 * t);
}

const DEG = Math.PI / 180;

/**
 * Global wind: a direction, a strength, and a slowly wandering gust value.
 * `sampleAt()` mirrors the GLSL `windAt()` so CPU-simulated soft bodies agree
 * with GPU-animated geometry.
 */
export class Wind {
  constructor() {
    /** @type {number} degrees */
    this.direction = 30;
    /** @type {number} 0..1 */
    this.strength = 0.5;
    /** @type {number} */
    this.speed = 1.0;
    /** @type {number} 0..1, how much the gust value wanders */
    this.gustiness = 0.5;

    /**
     * Shared with every wind-aware material by reference.
     * @type {{uWindDir:{value:THREE.Vector2}, uWindStrength:{value:number}, uWindSpeed:{value:number}, uGust:{value:number}, uTime:{value:number}}}
     */
    this.uniforms = {
      uWindDir: { value: new THREE.Vector2(1, 0) },
      uWindStrength: { value: this.strength },
      uWindSpeed: { value: this.speed },
      uGust: { value: 0.5 },
      uTime: { value: 0 },
    };

    /** @private smoothed gust, 0..1 before gustiness scaling */
    this._gust = 0.5;
    this.setDirection(this.direction);
  }

  /**
   * @param {number} deg wind heading in degrees
   */
  setDirection(deg) {
    this.direction = deg;
    const a = deg * DEG;
    this.uniforms.uWindDir.value.set(Math.cos(a), Math.sin(a)).normalize();
    return this;
  }

  /**
   * Advance the gust random walk and push state into the uniforms.
   * @param {number} dt seconds
   * @param {number} time seconds since start
   */
  update(dt, time) {
    // Low-frequency noise drives the gust so it wanders smoothly and repeatably.
    const target = fbm(time * 0.23, time * 0.11 + 5.7, 3);
    this._gust += (target - this._gust) * Math.min(1, dt * 1.5);
    this.uniforms.uGust.value = Math.max(0, Math.min(1, this._gust * this.gustiness * 2));
    this.uniforms.uWindStrength.value = this.strength;
    this.uniforms.uWindSpeed.value = this.speed;
    this.uniforms.uTime.value = time;
    this.setDirection(this.direction);
  }

  /**
   * CPU copy of the GLSL `windAt()`.
   * @param {number} x world x
   * @param {number} z world z
   * @param {number} [time] seconds; defaults to the current uniform time
   * @returns {{x:number, z:number}} wind force in world XZ
   */
  sampleAt(x, z, time = this.uniforms.uTime.value) {
    const dir = this.uniforms.uWindDir.value;
    const t = time * this.uniforms.uWindSpeed.value;
    const along = x * dir.x + z * dir.y;
    const across = -x * dir.y + z * dir.x;
    let g = fbm(along * 0.07 - t * 0.7, across * 0.4 + 3.1, 3);
    g = smoothstep(0.3, 0.62, g * 1.15);
    let wave = Math.sin(along * 0.55 - t * 3.6) * 0.5 + 0.5;
    wave *= wave;
    const m =
      this.uniforms.uWindStrength.value *
      (0.18 + 0.82 * g) *
      (0.75 + 0.5 * wave * g) *
      (0.6 + 0.8 * this.uniforms.uGust.value);
    return { x: dir.x * m, z: dir.y * m };
  }

  /** @returns {{direction:number, strength:number, speed:number, gustiness:number}} */
  serialize() {
    return {
      direction: this.direction,
      strength: this.strength,
      speed: this.speed,
      gustiness: this.gustiness,
    };
  }

  /**
   * @param {{direction?:number, strength?:number, speed?:number, gustiness?:number}} o
   */
  deserialize(o = {}) {
    if (typeof o.strength === 'number') this.strength = o.strength;
    if (typeof o.speed === 'number') this.speed = o.speed;
    if (typeof o.gustiness === 'number') this.gustiness = o.gustiness;
    this.setDirection(o.direction ?? this.direction);
  }
}
