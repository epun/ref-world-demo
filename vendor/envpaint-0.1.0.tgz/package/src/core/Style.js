import * as THREE from 'three';
import { STYLE_START, STYLE_END } from './shaders/toon.glsl.js';

/**
 * @typedef {object} StyleDef
 * @property {string} id
 * @property {string} label
 * @property {string} lightingGLSL block replacing everything between the
 *   STYLE_START / STYLE_END markers. MUST define, with these exact signatures:
 *     float toonRamp(float ndl, float bands, float soft);
 *     vec3  toonShadowColor(vec3 albedo, vec3 n);
 *     vec3  toonLight(vec3 albedo, vec3 n, float shadow, float bands);
 *   It may call `toonShadow()`, `fbm`, `hash21`, and read `vWorldPos`,
 *   `vNormalW`, `cameraPosition`, `uSunDir/uSunColor/uSkyColor/uGroundColor`.
 *   Its own uniforms are declared inside the block and named `uStyle*`, except
 *   the six Ghibli look controls which keep their names (uShadowTint,
 *   uBandEdge, uBandSoft, uHalfTone, uRim, uGrain).
 * @property {Record<string, {value: any}>} [uniforms] defaults for the block's
 *   uniforms; one object per name is shared by every attached material.
 * @property {object} [palette] `{ sun, sky, ground, background, skyTop,
 *   skyHorizon, fog, terrain: {...}, <elementId>: {...} }`
 * @property {{shadowRadius?: number}} [post]
 */

/**
 * Copy a plain palette/uniform value onto a live uniform, preserving the
 * existing THREE object identity wherever one is already in place (other
 * modules hold references to `sun.uniforms.*.value`).
 * @param {{value: any}} uniform
 * @param {any} value
 */
function setUniformValue(uniform, value) {
  const target = uniform.value;
  if (target && target.isColor) {
    if (Array.isArray(value)) target.setRGB(value[0], value[1], value[2]);
    else if (value && value.isColor) target.copy(value);
    else target.set(value);
    return;
  }
  if (target && typeof target.fromArray === 'function' && Array.isArray(value)) {
    target.fromArray(value);
    return;
  }
  if (target && target.isVector2 && value && value.isVector2) { target.copy(value); return; }
  if (target && target.isVector3 && value && value.isVector3) { target.copy(value); return; }
  uniform.value = cloneValue(value);
}

/**
 * @param {any} value
 * @returns {any} a private copy, so live edits never mutate a style module
 */
function cloneValue(value) {
  if (Array.isArray(value)) {
    // 3 numbers is a colour by convention (uShadowTint and friends are vec3).
    return value.length === 3 ? new THREE.Color(value[0], value[1], value[2]) : value.slice();
  }
  if (value && typeof value.clone === 'function') return value.clone();
  return value;
}

/**
 * The style system: one lighting block, swapped across every registered
 * material at once.
 *
 * Every toon material's fragment shader carries its lighting functions between
 * the `/*<style>*\/` and `/*</style>*\/` markers emitted by `toonParsFragment`.
 * `attach()` remembers the material's shader as its *base*; `set(id)` rewrites
 * the text between those markers in that base with the chosen style's
 * `lightingGLSL`, merges the style's uniform defaults, and applies the style's
 * palette to the sun, the sky, the fog and every element that implements
 * `applyPalette(p)`.
 *
 * @example
 * ctx.style = new Style(ctx, STYLES);
 * ctx.style.attach(material, { element: 'grass' });
 * ctx.style.set('painterly');
 */
export class Style {
  /**
   * @param {object} ctx shared app context
   * @param {StyleDef[]} styles in panel order; the first is the default
   */
  constructor(ctx, styles = []) {
    /** @type {object} */
    this.ctx = ctx;
    /** @type {Map<string, StyleDef>} */
    this.styles = new Map(styles.map((s) => [s.id, s]));
    /** @type {string} active style id */
    this.current = styles[0]?.id ?? '';
    /** @private @type {string} the style already compiled into the base shaders */
    this._defaultId = this.current;

    /** @private @type {{material: THREE.ShaderMaterial, element: string, base: string}[]} */
    this._attached = [];
    /** @private @type {Map<string, {value: any}>} one uniform object per name */
    this._uniforms = new Map();
    /** @private @type {Map<string, Set<Function>>} */
    this._listeners = new Map();
    /** @private @type {number|null} shadow radius before any style touched it */
    this._baseShadowRadius = null;
  }

  /** @returns {{id: string, label: string}[]} every style, in panel order */
  list() {
    return [...this.styles.values()].map((s) => ({ id: s.id, label: s.label || s.id }));
  }

  /**
   * @param {string} [id] defaults to the active style
   * @returns {StyleDef|undefined}
   */
  get(id = this.current) {
    return this.styles.get(id);
  }

  /**
   * Register a material for style switching. Call it right after building the
   * material, before it is first rendered.
   * @param {THREE.ShaderMaterial} material
   * @param {{element?: string}} [opts] which element the material belongs to
   *   ('terrain', 'grass', …) — picks the palette sub-object
   * @returns {THREE.ShaderMaterial} the same material, for chaining
   */
  attach(material, { element = '' } = {}) {
    if (!material || this._attached.some((e) => e.material === material)) return material;
    const entry = { material, element, base: material.fragmentShader };
    this._attached.push(entry);

    // A material that arrives after a style switch must not stay on the old
    // lighting block: bring it up to date immediately.
    const style = this.get();
    if (style) {
      this._applyMaterial(entry, style);
      // The element may not be in ctx.elements yet (attach usually happens
      // inside init()); palette then lands on the next set() / applyPalette.
      if (this.current !== this._defaultId) this._applyElementPalette(style, element);
    }
    return material;
  }

  /**
   * Stop tracking a material (e.g. it was disposed).
   * @param {THREE.ShaderMaterial} material
   */
  detach(material) {
    const i = this._attached.findIndex((e) => e.material === material);
    if (i >= 0) this._attached.splice(i, 1);
    return this;
  }

  /**
   * Swap the active style: rewrites every attached material's lighting block,
   * merges the style's uniforms, applies its palette, then emits 'change'.
   * @param {string} id
   * @returns {Style}
   */
  set(id) {
    const style = this.styles.get(id);
    if (!style) {
      console.warn(`[EnvPaint] unknown style '${id}'`);
      return this;
    }
    this.current = id;

    // One uniform object per name, shared by every material, so a panel slider
    // bound to it moves the whole scene.
    const shared = new Map();
    for (const [name, def] of Object.entries(style.uniforms || {})) {
      const uniform = this._sharedUniform(name, def.value);
      setUniformValue(uniform, def.value);
      shared.set(name, uniform);
    }

    for (const entry of this._attached) this._applyMaterial(entry, style, shared);

    this._applyPalette(style);
    // The ink / hatch / paper pass is part of the style, not a separate mode.
    this.ctx.postfx?.apply(style.post);
    this._emit('change', { id, style });
    return this;
  }

  /**
   * @param {'change'} event
   * @param {Function} fn
   */
  on(event, fn) {
    if (!this._listeners.has(event)) this._listeners.set(event, new Set());
    this._listeners.get(event).add(fn);
    return this;
  }

  /**
   * @param {'change'} event
   * @param {Function} fn
   */
  off(event, fn) {
    this._listeners.get(event)?.delete(fn);
    return this;
  }

  /** @private @param {string} event @param {any} payload */
  _emit(event, payload) {
    for (const fn of this._listeners.get(event) || []) {
      try {
        fn(payload);
      } catch (err) {
        console.warn(`[EnvPaint] style '${event}' listener failed:`, err);
      }
    }
  }

  /**
   * @private One uniform object per name for the whole scene. If some material
   * already declares the name (the six look controls live on sun.uniforms and
   * are spread by reference into every toon material), that object is adopted
   * so the panel keeps reading the value the shader uses.
   * @param {string} name
   * @param {any} value
   * @returns {{value: any}}
   */
  _sharedUniform(name, value) {
    let uniform = this._uniforms.get(name);
    if (uniform) return uniform;
    for (const entry of this._attached) {
      const existing = entry.material.uniforms?.[name];
      if (existing) { uniform = existing; break; }
    }
    if (!uniform) uniform = { value: cloneValue(value) };
    this._uniforms.set(name, uniform);
    return uniform;
  }

  /**
   * @private Rewrite one material's marked block and merge the style uniforms.
   * @param {{material: THREE.ShaderMaterial, base: string}} entry
   * @param {StyleDef} style
   * @param {Map<string, {value:any}>} [shared] prepared uniform objects
   */
  _applyMaterial(entry, style, shared) {
    const { material, base } = entry;
    const from = base.indexOf(STYLE_START);
    const to = base.indexOf(STYLE_END);
    // No markers means the material does not use the shared toon lighting
    // (fire's light pool, embers, rain …). That is a legitimate thing to
    // attach: it still wants the style's uniforms — `uStyleId` above all — so
    // it can branch on the style itself. Only the swap is skipped.
    if (from >= 0 && to > from) {
      material.fragmentShader =
        `${base.slice(0, from + STYLE_START.length)}\n${style.lightingGLSL}\n${base.slice(to)}`;
    }

    for (const [name, def] of Object.entries(style.uniforms || {})) {
      const uniform = shared?.get(name) || this._sharedUniform(name, def.value);
      if (!material.uniforms[name]) material.uniforms[name] = uniform;
    }
    material.needsUpdate = true;
  }

  /**
   * @private Push the palette at the sun, the sky, the fog and every element.
   * @param {StyleDef} style
   */
  _applyPalette(style) {
    const p = style.palette || {};
    const { sun, scene, app, terrain, elements } = this.ctx;

    if (sun) {
      // Sun.update() copies the lights into the uniforms every frame, so the
      // lights are the source of truth — set both.
      if (p.sun) { sun.light.color.set(p.sun); sun.uniforms.uSunColor.value.set(p.sun); }
      if (p.sky) { sun.hemi?.color.set(p.sky); sun.uniforms.uSkyColor.value.set(p.sky); }
      if (p.ground) {
        sun.hemi?.groundColor.set(p.ground);
        sun.uniforms.uGroundColor.value.set(p.ground);
      }
      const shadow = sun.light?.shadow;
      if (shadow) {
        if (this._baseShadowRadius === null) this._baseShadowRadius = shadow.radius;
        shadow.radius = style.post?.shadowRadius ?? this._baseShadowRadius;
      }
    }

    const sky = /** @type {any} */ (app?.sky)?.material?.uniforms;
    if (sky) {
      if (p.skyTop || p.background) sky.uSkyTop.value.set(p.skyTop || p.background);
      if (p.skyHorizon) sky.uSkyHorizon.value.set(p.skyHorizon);
    }
    if (scene?.fog && p.fog) scene.fog.color.set(p.fog);
    if (p.background && scene?.background?.isColor) scene.background.set(p.background);

    if (p.terrain) terrain?.applyPalette?.(p.terrain);
    elements?.forEach((element, id) => {
      const sub = p[element.constructor?.id || id];
      if (sub) element.applyPalette?.(sub);
    });
  }

  /**
   * @private Palette for a single element id, when it can be resolved.
   * @param {StyleDef} style
   * @param {string} id
   */
  _applyElementPalette(style, id) {
    const sub = style.palette?.[id];
    if (!sub) return;
    if (id === 'terrain') this.ctx.terrain?.applyPalette?.(sub);
    else this.ctx.elements?.get(id)?.applyPalette?.(sub);
  }
}

export default Style;
