import * as THREE from 'three';
import { SHAPE_DEFAULTS, edgeRadius } from './BrushShape.js';
import { WORLD_SIZE } from './constants.js';
import { isTyping } from './dom.js';

const MIN_RADIUS = 0.3;
const MAX_RADIUS = 12;
const RADIUS_STEP = 1.15;
/** Ring colour while the radius is being adjusted: ghost-panel's active amber. */
const PREVIEW_COLOR = '#d9b36c';
/** Vertices around the cursor ring. */
const RING_SEGMENTS = 96;
/** How long the footprint stays highlighted after the last radius change. */
const PREVIEW_MS = 900;

/**
 * @typedef {object} Tool
 * @property {string} id
 * @property {string} label
 * @property {string} color hex, used for the cursor ring
 * @property {string} [key] hotkey (single character)
 * @property {string} [layer] target layer id
 * @property {string} [mode='add'] default stamp mode
 * @property {number} [channel=0]
 * @property {string} [eraseMode='erase'] mode used while erasing (X, or Ctrl/Cmd held)
 * @property {string} [altMode] mode used while Alt is held
 * @property {string[]} [excludes] layer ids this tool clears as it paints, so
 *   the latest stroke wins (a path erases the grass under it). Skipped while
 *   erasing.
 * @property {number} [strengthScale=1]
 * @property {(ctx: object, op: object, hit: object) => void} [onStamp] called instead of layer.stamp
 */

/**
 * @typedef {object} BrushOptions
 * @property {number} [worldSize] ground extent in world units, used for the
 *   world -> layer-UV mapping. Defaults to `ctx.worldSize`, then `WORLD_SIZE`.
 * @property {(event: PointerEvent) => ({x:number,z:number,y:number,u:number,v:number}|null)} [pick]
 *   pointer -> ground hit. Defaults to a raycast against `ctx.terrain.mesh`.
 * @property {(event: PointerEvent) => boolean} [canPaint] extra veto asked
 *   before a stroke starts, on top of the built-in camera check.
 * @property {() => ({x:number,y:number,z:number}|null)} [centre] the point a
 *   pointer-less radius preview is shown at. Defaults to `ctx.iso.target`
 *   lifted onto `ctx.terrain.heightAt()`.
 */

/**
 * Turns pointer drags on the terrain into layer stamps for the active tool,
 * and draws the cursor ring.
 *
 * Everything app-specific — the world size, how a pointer becomes a ground
 * hit, when the camera owns the drag, where a pointer-less preview sits — is
 * injectable through the options bag, so the Brush works against any host that
 * can hand it a canvas, a scene and a `ctx.layers`.
 */
export class Brush {
  /**
   * @param {object} ctx shared app context (needs renderer, scene, camera, layers;
   *   `iso`, `terrain` and `history` are used when present)
   * @param {BrushOptions} [opts] injection points for a non-EnvPaint host
   */
  constructor(ctx, opts = {}) {
    /** @type {object} */
    this.ctx = ctx;
    /** @type {HTMLCanvasElement} */
    this.canvas = ctx.renderer.domElement;
    /** @type {BrushOptions} */
    this.opts = opts;
    /** @type {number} ground extent in world units (world -> UV mapping) */
    this.worldSize = opts.worldSize ?? ctx.worldSize ?? WORLD_SIZE;

    /** @type {{radius:number, strength:number, hardness:number, spacing:number,
     *          edgeNoise:number, edgeScale:number, spatter:number, aspect:number}} */
    this.settings = { radius: 1.0, strength: 0.26, hardness: 0.5, spacing: 0.35, ...SHAPE_DEFAULTS };
    /** @type {boolean} sticky erase toggle (X); Ctrl/Cmd inverts it for one stroke */
    this.erase = false;
    /** @type {boolean} set false to suspend painting (e.g. while an inspector gizmo is dragged) */
    this.enabled = true;
    /** @private last terrain hit under the pointer, where a radius preview is shown */
    this._lastHit = null;
    /** @private whether the pointer is over the terrain right now */
    this._hovering = false;
    /** @private radius-preview timeout handle */
    this._previewTimer = 0;
    /** @private true while the footprint is highlighted for a radius change */
    this._previewing = false;
    /** @type {Map<string, Tool>} */
    this.tools = new Map();
    /** @type {string|null} active tool id */
    this.tool = null;
    /** @type {{x:number,z:number,u:number,v:number,y:number}|null} last terrain hit */
    this.hit = null;
    /** @type {boolean} */
    this.painting = false;

    this._listeners = new Map();
    this._raycaster = new THREE.Raycaster();
    this._ndc = new THREE.Vector2();
    this._pointerId = null;
    this._lastStamp = null;
    this._paintClick = false;
    this._eraseDown = false;
    this._altDown = false;

    this.cursor = this._buildCursor();
    this.cursor.visible = false;
    ctx.scene.add(this.cursor);

    this._bind();
  }

  // --- events -------------------------------------------------------------

  /**
   * @param {'strokestart'|'stroke'|'strokeend'} event
   * @param {(payload: object) => void} fn
   */
  on(event, fn) {
    if (!this._listeners.has(event)) this._listeners.set(event, new Set());
    this._listeners.get(event).add(fn);
    return this;
  }

  /**
   * @param {string} event
   * @param {(payload: object) => void} fn
   */
  off(event, fn) {
    this._listeners.get(event)?.delete(fn);
    return this;
  }

  /**
   * @param {string} event
   * @param {object} payload
   */
  emit(event, payload) {
    const set = this._listeners.get(event);
    if (!set) return;
    for (const fn of set) fn(payload);
  }

  // --- tools --------------------------------------------------------------

  /**
   * @param {Tool} tool
   * @returns {Tool}
   */
  registerTool(tool) {
    this.tools.set(tool.id, tool);
    if (!this.tool) this.setTool(tool.id);
    return tool;
  }

  /**
   * @param {string} id
   * @returns {Tool|undefined}
   */
  getTool(id) {
    return this.tools.get(id);
  }

  /**
   * @param {string} id
   */
  setTool(id) {
    if (!this.tools.has(id)) throw new Error(`Brush: no tool '${id}'`);
    this.tool = id;
    const color = this.tools.get(id).color || '#ffffff';
    this._ringMaterial.color.set(color);
    this._dotMaterial.color.set(color);
    return this;
  }

  /**
   * @param {number} r world units, clamped
   */
  setRadius(r) {
    this.settings.radius = Math.max(MIN_RADIUS, Math.min(MAX_RADIUS, r));
    this._syncCursorScale();
    this.flashRadius();
    return this;
  }

  /**
   * Show the brush footprint on the canvas, highlighted, so a radius change
   * from the slider or `[` / `]` is visible where it will land: under the
   * pointer if it is over the terrain, otherwise at the centre of the view.
   * The highlight fades back to the plain cursor after `ms`.
   * @param {number} [ms]
   */
  flashRadius(ms = PREVIEW_MS) {
    const hit = this._hovering && this._lastHit ? this._lastHit : this._centreHit();
    if (!hit) return this;
    this._previewing = true;
    this.cursor.visible = true;
    this.cursor.position.set(hit.x, hit.y + 0.05, hit.z);
    this._syncCursorScale();
    this._ringMaterial.color.set(PREVIEW_COLOR);
    this._ringMaterial.opacity = 1;
    this._dotMaterial.color.set(PREVIEW_COLOR);
    this._disc.visible = true;
    clearTimeout(this._previewTimer);
    this._previewTimer = setTimeout(() => this._endPreview(), ms);
    return this;
  }

  /** @private Put the cursor back to its tool colour; hide it if nothing hovers. */
  _endPreview() {
    this._previewing = false;
    this._previewTimer = 0;
    const color = (this.tool && this.tools.get(this.tool)?.color) || '#ffffff';
    this._ringMaterial.color.set(color);
    this._ringMaterial.opacity = 0.9;
    this._dotMaterial.color.set(color);
    this._disc.visible = false;
    if (!this._hovering && !this.painting) this.cursor.visible = false;
  }

  /**
   * World position -> layer UV, against this brush's world size.
   * @param {number} x
   * @param {number} z
   * @returns {{u:number, v:number}}
   */
  worldToUV(x, z) {
    return { u: x / this.worldSize + 0.5, v: z / this.worldSize + 0.5 };
  }

  /**
   * @private The terrain point the camera looks at, for a preview with no pointer.
   * @returns {{x:number,y:number,z:number}|null}
   */
  _centreHit() {
    if (this.opts.centre) return this.opts.centre() || null;
    const t = this.ctx.iso?.target;
    const terrain = this.ctx.terrain;
    if (!t || !terrain?.heightAt) return null;
    return { x: t.x, y: terrain.heightAt(t.x, t.z), z: t.z };
  }

  // --- internals ----------------------------------------------------------

  /** @private */
  _buildCursor() {
    const group = new THREE.Group();
    group.name = 'brushCursor';
    group.renderOrder = 999;

    const segments = RING_SEGMENTS;
    const pts = new Float32Array((segments + 1) * 3);
    const ringGeo = new THREE.BufferGeometry();
    ringGeo.setAttribute('position', new THREE.BufferAttribute(pts, 3));
    this._ringPositions = pts;
    this._ringGeo = ringGeo;
    this._shapeRing();
    this._ringMaterial = new THREE.LineBasicMaterial({
      color: 0xffffff,
      depthTest: false,
      transparent: true,
      opacity: 0.9,
      toneMapped: false,
    });
    this._ring = new THREE.Line(ringGeo, this._ringMaterial);
    this._ring.renderOrder = 999;
    group.add(this._ring);

    const dotGeo = new THREE.CircleGeometry(0.07, 12);
    dotGeo.rotateX(-Math.PI / 2);
    this._dotMaterial = new THREE.MeshBasicMaterial({
      color: 0xffffff,
      depthTest: false,
      transparent: true,
      opacity: 0.85,
      toneMapped: false,
    });
    const dot = new THREE.Mesh(dotGeo, this._dotMaterial);
    dot.renderOrder = 999;
    group.add(dot);

    // Translucent fill shown only while the radius is being adjusted, so the
    // footprint reads as an area and not just an outline.
    const discGeo = new THREE.CircleGeometry(1, 64);
    discGeo.rotateX(-Math.PI / 2);
    this._discMaterial = new THREE.MeshBasicMaterial({
      color: PREVIEW_COLOR,
      depthTest: false,
      depthWrite: false,
      transparent: true,
      opacity: 0.16,
      toneMapped: false,
    });
    this._disc = new THREE.Mesh(discGeo, this._discMaterial);
    this._disc.renderOrder = 998;
    this._disc.visible = false;
    group.add(this._disc);

    this._syncCursorScale(group);
    return group;
  }

  /**
   * @private Trace the unit ring with the current edge noise (a fixed preview
   * seed), so the cursor shows the brush's shape and not just its radius.
   */
  _shapeRing() {
    const pts = this._ringPositions;
    if (!pts) return;
    const { edgeNoise, edgeScale } = this.settings;
    for (let i = 0; i <= RING_SEGMENTS; i++) {
      const a = (i / RING_SEGMENTS) * Math.PI * 2;
      const r = edgeRadius(1, a, edgeNoise, edgeScale, 0);
      pts[i * 3] = Math.cos(a) * r;
      pts[i * 3 + 1] = 0;
      pts[i * 3 + 2] = Math.sin(a) * r;
    }
    this._ringGeo.attributes.position.needsUpdate = true;
    this._ringGeo.computeBoundingSphere();
  }

  /**
   * Change one or more edge-shape settings (edgeNoise, edgeScale, spatter,
   * aspect) and show the result on the canvas.
   * @param {Partial<typeof SHAPE_DEFAULTS>} shape
   */
  setShape(shape) {
    Object.assign(this.settings, shape);
    this._shapeRing();
    this.flashRadius();
    return this;
  }

  /** @private */
  _syncCursorScale(group = this.cursor) {
    if (!group || !this._ring) return;
    this._ring.scale.setScalar(this.settings.radius);
    this._disc?.scale.setScalar(this.settings.radius);
  }

  /**
   * @private Raycast the pointer against the terrain mesh.
   * @param {PointerEvent} e
   * @returns {{x:number,z:number,u:number,v:number,y:number}|null}
   */
  _pick(e) {
    if (this.opts.pick) return this.opts.pick(e) || null;
    const mesh = this.ctx.terrain?.mesh;
    if (!mesh) return null;
    const rect = this.canvas.getBoundingClientRect();
    this._ndc.set(
      ((e.clientX - rect.left) / rect.width) * 2 - 1,
      -((e.clientY - rect.top) / rect.height) * 2 + 1,
    );
    this._raycaster.setFromCamera(this._ndc, this.ctx.camera);
    const hits = this._raycaster.intersectObject(mesh, false);
    if (!hits.length) return null;
    const p = hits[0].point;
    const { u, v } = this.worldToUV(p.x, p.z);
    return { x: p.x, y: p.y, z: p.z, u, v };
  }

  /** @private Should the pointer paint rather than pan or orbit? */
  _canPaint(e) {
    if (!this.enabled) return false;
    if (e.button !== undefined && e.button !== 0) return false;
    // The camera's claim on the drag. Only asked when a camera rig is present,
    // so a host without one supplies its own rule through `opts.canPaint`.
    if (this.ctx.iso) {
      if (this.ctx.iso.isPanning || this.ctx.iso.spaceDown) return false;
      // Shift + left drag belongs to the camera (free orbit), never to a stroke.
      if (this.ctx.iso.isOrbiting || e.shiftKey) return false;
    }
    if (this.opts.canPaint && !this.opts.canPaint(e)) return false;
    return true;
  }

  /**
   * @private Apply one dab at a world position.
   * @param {{x:number,z:number,y:number}} at
   * @param {{x:number,y:number}|null} dir stroke direction in UV space
   */
  _stampAt(at, dir) {
    const tool = this.tools.get(this.tool);
    if (!tool) return;
    const erase = this.erase !== this._eraseDown; // Ctrl/Cmd temporarily inverts
    let mode = tool.mode || 'add';
    if (erase) mode = tool.eraseMode || 'erase';
    else if (this._altDown && tool.altMode) mode = tool.altMode;
    if (mode === 'direction' && !dir) return;

    const { u, v } = this.worldToUV(at.x, at.z);
    const op = {
      u,
      v,
      radius: this.settings.radius / this.worldSize,
      strength: this.settings.strength * (tool.strengthScale ?? 1) * 0.25,
      hardness: this.settings.hardness,
      mode,
      channel: tool.channel ?? 0,
      dir: dir || undefined,
      // Edge shape, plus a seed of this dab's own so the rim differs dab to dab.
      edgeNoise: this.settings.edgeNoise,
      edgeScale: this.settings.edgeScale,
      spatter: this.settings.spatter,
      aspect: this.settings.aspect,
      seed: Math.random() * 100,
    };
    const hit = { x: at.x, y: at.y ?? 0, z: at.z, u, v };

    if (tool.onStamp) {
      tool.onStamp(this.ctx, op, hit);
    } else if (tool.layer) {
      this.ctx.layers.get(tool.layer)?.stamp(op);
    }

    // Latest stroke wins: painting one surface clears the ones it displaces.
    // Erasing never triggers this — lifting grass must not also lift the path.
    if (!erase && tool.excludes?.length) {
      const strength = Math.max(op.strength * 2, 0.5);
      for (const id of tool.excludes) {
        const layer = this.ctx.layers.get(id);
        if (!layer) continue;
        layer.stamp({
          ...op,
          mode: 'erase',
          strength,
          channel: op.channel < layer.channels ? op.channel : 0,
        });
      }
    }

    this._lastStamp = { x: at.x, z: at.z };
    return { tool, hit, dir, erase };
  }

  /** @private */
  _bind() {
    const canvas = this.canvas;

    canvas.addEventListener('pointerdown', (e) => {
      if (e.target !== canvas) return;
      if (!this._canPaint(e)) return;
      const hit = this._pick(e);
      this._updateCursor(hit);
      if (!hit) return;
      e.preventDefault();
      this.painting = true;
      this._paintClick = true;
      this._pointerId = e.pointerId;
      this._eraseDown = eraseModifier(e);
      this._altDown = e.altKey;
      this._lastStamp = null;
      canvas.setPointerCapture(e.pointerId);
      this.ctx.history?.begin(this.tools.get(this.tool)?.label || 'Paint');
      const payload = this._stampAt(hit, null) || { tool: this.tools.get(this.tool), hit, dir: null, erase: this.erase };
      this.hit = hit;
      this.emit('strokestart', payload);
    });

    canvas.addEventListener('pointermove', (e) => {
      if (!this.enabled) {
        this.hit = null;
        this._updateCursor(null);
        return;
      }
      const hit = this._pick(e);
      this.hit = hit;
      this._updateCursor(hit);
      if (!this.painting || e.pointerId !== this._pointerId || !hit) return;
      this._eraseDown = eraseModifier(e);
      this._altDown = e.altKey;

      const last = this._lastStamp;
      if (!last) {
        this._stampAt(hit, null);
        return;
      }
      const dx = hit.x - last.x;
      const dz = hit.z - last.z;
      const dist = Math.hypot(dx, dz);
      const step = Math.max(0.01, this.settings.spacing * this.settings.radius);
      if (dist < step) return;

      const nx = dx / dist;
      const nz = dz / dist;
      const dir = { x: nx, y: nz };
      const count = Math.min(256, Math.floor(dist / step));
      let payload = null;
      for (let i = 1; i <= count; i++) {
        payload = this._stampAt(
          { x: last.x + nx * step * i, z: last.z + nz * step * i, y: hit.y },
          dir,
        );
      }
      if (payload) this.emit('stroke', payload);
    });

    const end = (e) => {
      if (!this.painting || e.pointerId !== this._pointerId) return;
      // Only a real release should swallow the inspector's select click.
      if (e.type !== 'pointerup') this._paintClick = false;
      this.painting = false;
      this._pointerId = null;
      if (canvas.hasPointerCapture(e.pointerId)) canvas.releasePointerCapture(e.pointerId);
      this.emit('strokeend', {
        tool: this.tools.get(this.tool),
        hit: this.hit,
        dir: null,
        erase: this.erase,
      });
      this._lastStamp = null;
      this.ctx.history?.end();
    };
    canvas.addEventListener('pointerup', end);
    canvas.addEventListener('pointercancel', end);
    // Losing the window mid-stroke must still close the undo entry.
    window.addEventListener('blur', () => {
      if (!this.painting) return;
      this.painting = false;
      this._pointerId = null;
      this._lastStamp = null;
      this.emit('strokeend', { tool: this.tools.get(this.tool), hit: this.hit, dir: null, erase: this.erase });
      this.ctx.history?.end();
    });

    // A paint click must never double as an inspector click-to-select. This
    // capture-phase listener runs before every pointerup handler the inspector
    // binds to the canvas — including, in Chrome, our own `end` above — so it
    // closes the stroke itself before silencing the rest of the chain. `end`
    // ignores a second call, so browsers that order it first still behave.
    canvas.addEventListener('pointerup', (e) => {
      if (!this._paintClick || e.button !== 0) return;
      this._paintClick = false;
      end(e);
      e.stopImmediatePropagation();
    }, true);
    canvas.addEventListener('pointerleave', () => {
      if (!this.painting) this._updateCursor(null);
    });

    window.addEventListener('keydown', (e) => {
      if (isTyping(e.target)) return;
      if (e.key === '[') {
        this.setRadius(this.settings.radius / RADIUS_STEP);
        return;
      }
      if (e.key === ']') {
        this.setRadius(this.settings.radius * RADIUS_STEP);
        return;
      }
      if (e.code === 'KeyX' && !e.repeat) {
        this.erase = !this.erase;
        return;
      }
      if (e.repeat || e.metaKey || e.ctrlKey) return;
      for (const tool of this.tools.values()) {
        if (tool.key && tool.key === e.key) {
          this.setTool(tool.id);
          return;
        }
      }
    });
  }

  /**
   * @private
   * @param {{x:number,y:number,z:number}|null} hit
   */
  _updateCursor(hit) {
    this._hovering = !!hit;
    if (!hit) {
      // Keep a radius preview on screen where it was; it hides itself.
      if (!this._previewing) this.cursor.visible = false;
      return;
    }
    this._lastHit = hit;
    this.cursor.visible = true;
    this.cursor.position.set(hit.x, hit.y + 0.05, hit.z);
    this._syncCursorScale();
  }

  dispose() {
    this.ctx.scene.remove(this.cursor);
    clearTimeout(this._previewTimer);
    this._ring.geometry.dispose();
    this._ringMaterial.dispose();
    this._dotMaterial.dispose();
    this._disc.geometry.dispose();
    this._discMaterial.dispose();
  }
}

/**
 * @param {PointerEvent} e
 * @returns {boolean} true while the temporary-erase modifier is held
 */
function eraseModifier(e) {
  return Boolean(e.ctrlKey || e.metaKey);
}
