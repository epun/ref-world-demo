import * as THREE from 'three';

const DEG = Math.PI / 180;

/**
 * The world's key light: a warm directional sun with a shadow camera covering
 * the whole ground, plus a cool hemisphere fill. Owns the light uniforms every
 * toon material spreads into its own uniform block.
 */
export class Sun {
  /**
   * @param {THREE.Scene} scene
   */
  constructor(scene) {
    /** @type {THREE.Scene} */
    this.scene = scene;

    /** @type {number} degrees, compass-style around Y */
    this.azimuth = 135;
    /** @type {number} degrees above the horizon */
    this.elevation = 50;
    /** @type {number} how far along the sun direction the light sits */
    this.distance = 60;

    const light = new THREE.DirectionalLight(new THREE.Color('#fff3d6'), 2.2);
    light.castShadow = true;
    light.shadow.mapSize.set(2048, 2048);
    const cam = light.shadow.camera;
    cam.left = -26;
    cam.right = 26;
    cam.top = 26;
    cam.bottom = -26;
    cam.near = 1;
    cam.far = 120;
    light.shadow.bias = -0.0006;
    light.shadow.normalBias = 0.02;
    light.shadow.radius = 1.5;
    light.target.position.set(0, 0, 0);
    scene.add(light);
    scene.add(light.target);
    /** @type {THREE.DirectionalLight} */
    this.light = light;

    /** @type {THREE.HemisphereLight} */
    this.hemi = new THREE.HemisphereLight(new THREE.Color('#dcecff'), new THREE.Color('#9cb07a'), 0.6);
    scene.add(this.hemi);

    /**
     * Shared with every toon material by reference: the light colours plus the
     * six cel-look controls the toon shader reads.
     * @type {Record<string, {value: any}>}
     */
    this.uniforms = {
      uSunDir: { value: new THREE.Vector3() },
      uSunColor: { value: light.color.clone() },
      uSkyColor: { value: this.hemi.color.clone() },
      uGroundColor: { value: this.hemi.groundColor.clone() },
      // Cel look. uShadowTint is a linear multiplier, so its components are set
      // directly rather than through an sRGB hex.
      uShadowTint: { value: new THREE.Color(0.5, 0.66, 0.82) },
      uBandEdge: { value: 0.22 },
      uBandSoft: { value: 0.04 },
      uHalfTone: { value: 0.35 },
      uRim: { value: 0.18 },
      uGrain: { value: 1.0 },
    };

    this.setAngles(this.azimuth, this.elevation);
  }

  /**
   * Place the sun from compass angles.
   * @param {number} azimuthDeg
   * @param {number} elevationDeg
   */
  setAngles(azimuthDeg, elevationDeg) {
    this.azimuth = azimuthDeg;
    this.elevation = elevationDeg;
    const a = azimuthDeg * DEG;
    const e = elevationDeg * DEG;
    const ce = Math.cos(e);
    // Direction from the ground toward the sun.
    const dir = new THREE.Vector3(ce * Math.sin(a), Math.sin(e), ce * Math.cos(a)).normalize();
    this.light.position.copy(dir).multiplyScalar(this.distance);
    this.light.target.position.set(0, 0, 0);
    this.light.target.updateMatrixWorld();
    this.uniforms.uSunDir.value.copy(dir);
    return this;
  }

  /**
   * @param {number} intensity
   */
  setIntensity(intensity) {
    this.light.intensity = intensity;
    return this;
  }

  /** Keep the uniform values in sync with the three lights. Called every frame. */
  update() {
    this.uniforms.uSunColor.value.copy(this.light.color);
    this.uniforms.uSkyColor.value.copy(this.hemi.color);
    this.uniforms.uGroundColor.value.copy(this.hemi.groundColor);
  }

  /** @returns {object} sun angles plus the cel-look controls */
  serialize() {
    const u = this.uniforms;
    return {
      azimuth: this.azimuth,
      elevation: this.elevation,
      intensity: this.light.intensity,
      shadowTint: u.uShadowTint.value.toArray(),
      bandEdge: u.uBandEdge.value,
      bandSoft: u.uBandSoft.value,
      halfTone: u.uHalfTone.value,
      rim: u.uRim.value,
      grain: u.uGrain.value,
    };
  }

  /**
   * @param {object} o output of `serialize()`
   */
  deserialize(o = {}) {
    const u = this.uniforms;
    if (typeof o.intensity === 'number') this.light.intensity = o.intensity;
    if (o.shadowTint) u.uShadowTint.value.fromArray(o.shadowTint);
    if (typeof o.bandEdge === 'number') u.uBandEdge.value = o.bandEdge;
    if (typeof o.bandSoft === 'number') u.uBandSoft.value = o.bandSoft;
    if (typeof o.halfTone === 'number') u.uHalfTone.value = o.halfTone;
    if (typeof o.rim === 'number') u.uRim.value = o.rim;
    if (typeof o.grain === 'number') u.uGrain.value = o.grain;
    this.setAngles(o.azimuth ?? this.azimuth, o.elevation ?? this.elevation);
  }
}
