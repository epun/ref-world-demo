/**
 * Stroke-scoped undo / redo for paint layers and element state.
 *
 * A history *entry* covers one brush stroke (or one `wrap()`ped action). While
 * a scope is open, `App` reports every layer that changed and the texel rect it
 * changed, and History accumulates the union per layer. At `end()` it copies
 * the rect out of a persistent per-layer shadow (the "before" bytes) and out of
 * the live layer (the "after" bytes), then refreshes the shadow.
 *
 * Undo writes the "before" rects back and calls `PaintLayer.markDirtyRect()`,
 * so the normal per-frame `onLayerChanged` / terrain-rebuild path reacts on its
 * own — nothing special has to know about undo.
 *
 * Layers that are simulated rather than painted (Rocks' `press`) opt out with
 * `new PaintLayer(id, { history: false })`. Layers written outside any scope
 * still keep their shadow current, so a later stroke never restores stale data.
 */

/**
 * @typedef {object} LayerDelta
 * @property {string} id layer id
 * @property {number} x0
 * @property {number} y0
 * @property {number} x1
 * @property {number} y1
 * @property {Uint8Array|Float32Array} before
 * @property {Uint8Array|Float32Array} after
 */

/**
 * @typedef {object} HistoryEntry
 * @property {string} label
 * @property {number} time
 * @property {LayerDelta[]} layers
 * @property {{id: string, before: string|null, after: string|null}[]} elements
 * @property {number} bytes
 * @property {boolean} applied
 * @property {boolean} dropped true once evicted for memory; undo/redo no-op
 */

import { toBase64, fromBase64 } from './PaintLayers.js';

const TYPED = {
  Float32Array, Float64Array, Uint8Array, Uint8ClampedArray, Uint16Array, Uint32Array,
  Int8Array, Int16Array, Int32Array,
};

/**
 * JSON.stringify that keeps typed arrays intact. A plain stringify turns a
 * Float32Array into an object of numeric keys, which parses back as a plain
 * object with no `length` — the Water level field silently stopped restoring
 * that way. Typed arrays travel as `{ __typed, b64 }` instead.
 * @param {any} state
 * @returns {string}
 */
export function stringifyState(state) {
  return JSON.stringify(state, (key, value) => {
    if (ArrayBuffer.isView(value) && !(value instanceof DataView)) {
      const bytes = new Uint8Array(value.buffer, value.byteOffset, value.byteLength);
      return { __typed: value.constructor.name, b64: toBase64(bytes) };
    }
    return value;
  });
}

/**
 * Inverse of `stringifyState`.
 * @param {string} json
 * @returns {any}
 */
export function parseState(json) {
  return JSON.parse(json, (key, value) => {
    if (value && typeof value === 'object' && typeof value.__typed === 'string' && TYPED[value.__typed]) {
      const bytes = fromBase64(value.b64);
      const Ctor = TYPED[value.__typed];
      const copy = new Uint8Array(bytes.length);
      copy.set(bytes);
      return new Ctor(copy.buffer, 0, copy.byteLength / Ctor.BYTES_PER_ELEMENT);
    }
    return value;
  });
}

export class History {
  /**
   * @param {object} ctx shared app context (needs layers, elements)
   * @param {object} [opts]
   * @param {number} [opts.maxSteps=60] most entries kept
   * @param {number} [opts.maxBytes=100663296] soft cap on total delta bytes (96 MB)
   */
  constructor(ctx, { maxSteps = 60, maxBytes = 96 << 20 } = {}) {
    /** @type {object} */
    this.ctx = ctx;
    /** @type {number} */
    this.maxSteps = maxSteps;
    /** @type {number} */
    this.maxBytes = maxBytes;
    /** @type {number} total bytes held by all entries */
    this.bytes = 0;
    /** @type {object|null} ghost-panel root, once `attachUI` was called */
    this.ui = null;

    /** @type {HistoryEntry[]} applied entries, oldest first */
    this._past = [];
    /** @type {HistoryEntry[]} undone entries, most recently undone last */
    this._future = [];
    /** @type {Map<string, Uint8Array|Float32Array>} per-layer pre-scope copy */
    this._shadows = new Map();
    /** @type {{label:string, touched:Map<string,object>, elements:Map<string,string|null>}|null} */
    this._scope = null;
    /** @type {Set<Function>} */
    this._listeners = new Set();
    /** @type {boolean} guards re-entry while an entry is being applied */
    this._replaying = false;
    this._keyHandler = null;

    this._bindKeys();
  }

  // --- listeners ----------------------------------------------------------

  /**
   * @param {'change'} event
   * @param {(history: History) => void} fn
   */
  on(event, fn) {
    if (event === 'change') this._listeners.add(fn);
    return this;
  }

  /**
   * @param {'change'} event
   * @param {(history: History) => void} fn
   */
  off(event, fn) {
    if (event === 'change') this._listeners.delete(fn);
    return this;
  }

  /** @private */
  _emit() {
    for (const fn of this._listeners) fn(this);
  }

  // --- ghost-panel integration -------------------------------------------

  /**
   * Merge into ghost-panel's stack so one Ctrl/Cmd+Z walks back through both
   * brush strokes and panel edits in the order they happened. ghost-panel owns
   * the key bindings from then on, so History drops its own.
   * @param {object} ui ghost-panel root (expects `ui._undo`)
   */
  attachUI(ui) {
    if (!ui || !ui._undo || this.ui === ui) return this;
    if (this.ui) return this;
    this.ui = ui;
    this._unbindKeys();
    for (const entry of this._past) ui._undo.push(this._command(entry));
    return this;
  }

  /**
   * @private Adopt ghost-panel's stack as soon as one exists, even if nobody
   * called `attachUI` — otherwise both stacks would answer the same Ctrl+Z.
   * @returns {boolean} whether a panel stack now owns undo
   */
  _syncUI() {
    if (this.ui) return true;
    const ui = this.ctx.app?.ui;
    if (ui && ui._undo) {
      this.attachUI(ui);
      return true;
    }
    return false;
  }

  /**
   * @private ghost-panel command wrapper for one entry.
   * @param {HistoryEntry} entry
   */
  _command(entry) {
    return {
      label: entry.label,
      undo: () => this._applyEntry(entry, 'before'),
      redo: () => this._applyEntry(entry, 'after'),
    };
  }

  // --- scopes -------------------------------------------------------------

  /**
   * Open a scope. Everything painted until `end()` becomes one undo entry.
   * @param {string} [label='Paint'] shown in the undo UI
   * @param {object} [opts]
   * @param {string} [opts.element] element id to snapshot regardless of the
   *   active tool — for buttons such as "Clear rocks" or "Drain all". Snapshot
   *   in addition to the active tool's `element` when they differ.
   */
  begin(label = 'Paint', opts = {}) {
    if (this._replaying) return this;
    if (this._scope) this.end();
    // Fold anything painted since the last frame into the shadows first, so it
    // is not mistaken for part of this stroke.
    this._drainPending();
    this._ensureShadows();

    const tool = this.ctx.brush?.getTool?.(this.ctx.brush?.tool);
    const elements = new Map();
    for (const id of [tool?.element, opts.element]) {
      if (id && !elements.has(id)) elements.set(id, this._captureElement(id));
    }
    this._scope = { label, touched: new Map(), elements };
    return this;
  }

  /**
   * Close the open scope and record an entry (dropped if nothing changed).
   * @returns {HistoryEntry|null}
   */
  end() {
    const scope = this._scope;
    if (!scope) return null;
    this._drainPending();
    this._scope = null;

    /** @type {LayerDelta[]} */
    const layers = [];
    let bytes = 0;
    for (const [id, rect] of scope.touched) {
      const layer = this.ctx.layers.get(id);
      const shadow = this._shadows.get(id);
      if (!layer || !shadow) continue;
      const before = this._readRect(shadow, layer, rect);
      const after = this._readRect(layer.data, layer, rect);
      if (equalArrays(before, after)) continue;
      layers.push({ id, ...rect, before, after });
      bytes += before.byteLength + after.byteLength;
      // The shadow now represents the post-stroke world.
      this._writeRect(shadow, layer, rect, after);
    }

    /** @type {{id:string, before:string|null, after:string|null}[]} */
    const elements = [];
    for (const [id, before] of scope.elements) {
      const after = this._captureElement(id);
      if (after === before) continue;
      elements.push({ id, before, after });
      bytes += (before?.length || 0) + (after?.length || 0);
    }

    if (!layers.length && !elements.length) return null;

    /** @type {HistoryEntry} */
    const entry = {
      label: scope.label,
      time: Date.now(),
      layers,
      elements,
      bytes,
      applied: true,
      dropped: false,
    };
    this._push(entry);
    return entry;
  }

  /**
   * Run a synchronous mutation as one undo entry — for panel buttons such as
   * "Fill layer", "Clear rocks", "Flood fill" or "Drain all".
   * @param {string} label
   * @param {() => void} fn
   * @param {{element?: string}} [opts] element id to snapshot around `fn`,
   *   so the button round-trips whatever tool happens to be active
   */
  wrap(label, fn, opts = {}) {
    this.begin(label, opts);
    try {
      fn();
    } finally {
      this.end();
    }
    return this;
  }

  // --- per-frame bookkeeping ---------------------------------------------

  /**
   * Called by `App` every frame for each dirty layer, before `commitAll()`
   * clears the rect. Outside a scope this just keeps the shadow current.
   * @param {import('./PaintLayers.js').PaintLayer} layer
   * @param {{x0:number,y0:number,x1:number,y1:number}} rect texel bounds
   */
  noteDirty(layer, rect) {
    if (!layer || !rect || layer.history === false || this._replaying) return;
    let shadow = this._shadows.get(layer.id);
    if (!shadow) {
      shadow = layer.data.slice();
      this._shadows.set(layer.id, shadow);
      return; // shadow already reflects this change; nothing to accumulate
    }
    if (!this._scope) {
      this._writeRect(shadow, layer, rect, this._readRect(layer.data, layer, rect));
      return;
    }
    const prev = this._scope.touched.get(layer.id);
    if (!prev) {
      this._scope.touched.set(layer.id, { x0: rect.x0, y0: rect.y0, x1: rect.x1, y1: rect.y1 });
      return;
    }
    if (rect.x0 < prev.x0) prev.x0 = rect.x0;
    if (rect.y0 < prev.y0) prev.y0 = rect.y0;
    if (rect.x1 > prev.x1) prev.x1 = rect.x1;
    if (rect.y1 > prev.y1) prev.y1 = rect.y1;
  }

  /** @private Pull in rects painted since the last frame's noteDirty sweep. */
  _drainPending() {
    for (const layer of this.ctx.layers.all()) {
      if (layer.dirtyRect) this.noteDirty(layer, layer.dirtyRect);
    }
  }

  /** @private Give every history-tracked layer a shadow before a stroke starts. */
  _ensureShadows() {
    for (const layer of this.ctx.layers.all()) {
      if (layer.history === false) continue;
      if (!this._shadows.has(layer.id)) this._shadows.set(layer.id, layer.data.slice());
    }
  }

  // --- undo / redo --------------------------------------------------------

  /** @returns {boolean} */
  canUndo() {
    if (this.ui?._undo) return this.ui._undo.canUndo();
    return this._past.length > 0;
  }

  /** @returns {boolean} */
  canRedo() {
    if (this.ui?._undo) return this.ui._undo.canRedo();
    return this._future.length > 0;
  }

  /**
   * Step back one entry. With a panel attached this drives ghost-panel's merged
   * stack, so panel edits and brush strokes undo in the order they happened.
   * @returns {boolean} whether anything was undone
   */
  undo() {
    if (this._scope) this.end();
    if (this.ui?._undo) return this.ui._undo.undo();
    const entry = this._past.pop();
    if (!entry) return false;
    this._applyEntry(entry, 'before');
    this._future.push(entry);
    this._emit();
    return true;
  }

  /**
   * Step forward one entry.
   * @returns {boolean} whether anything was redone
   */
  redo() {
    if (this._scope) this.end();
    if (this.ui?._undo) return this.ui._undo.redo();
    const entry = this._future.pop();
    if (!entry) return false;
    this._applyEntry(entry, 'after');
    this._past.push(entry);
    this._emit();
    return true;
  }

  /** Forget everything (keeps the shadows, which stay valid). */
  clear() {
    this._past.length = 0;
    this._future.length = 0;
    this.bytes = 0;
    this._emit();
    return this;
  }

  /** @returns {{steps:number, bytes:number, canUndo:boolean, canRedo:boolean}} */
  stats() {
    return {
      steps: this._past.length,
      bytes: this.bytes,
      canUndo: this.canUndo(),
      canRedo: this.canRedo(),
    };
  }

  // --- internals ----------------------------------------------------------

  /** @private */
  _push(entry) {
    this._syncUI();
    for (const dropped of this._future) this.bytes -= dropped.bytes;
    this._future.length = 0;
    this._past.push(entry);
    this.bytes += entry.bytes;
    this._trim();
    this.ui?._undo?.push(this._command(entry));
    this._emit();
  }

  /** @private Evict the oldest entries until both budgets are satisfied. */
  _trim() {
    while (this._past.length > this.maxSteps || (this.bytes > this.maxBytes && this._past.length > 1)) {
      const old = this._past.shift();
      this.bytes -= old.bytes;
      old.dropped = true;
      old.layers.length = 0;
      old.elements.length = 0;
    }
  }

  /**
   * @private Write one side of an entry back into the world.
   * @param {HistoryEntry} entry
   * @param {'before'|'after'} side
   */
  _applyEntry(entry, side) {
    if (entry.dropped) return;
    this._replaying = true;
    try {
      for (const delta of entry.layers) {
        const layer = this.ctx.layers.get(delta.id);
        if (!layer) continue;
        this._writeRect(layer.data, layer, delta, delta[side]);
        const shadow = this._shadows.get(delta.id);
        if (shadow) this._writeRect(shadow, layer, delta, delta[side]);
        layer.markDirtyRect(delta.x0, delta.y0, delta.x1, delta.y1);
      }
      for (const snapshot of entry.elements) {
        this._restoreElement(snapshot.id, snapshot[side]);
      }
      entry.applied = side === 'after';
    } finally {
      this._replaying = false;
    }
  }

  /**
   * @private
   * @param {string} id
   * @returns {string|null} JSON snapshot of the element's history state
   */
  _captureElement(id) {
    const element = this.ctx.elements?.get(id);
    if (!element) return null;
    const state = element.captureHistory ? element.captureHistory() : element.serialize?.();
    return state == null ? null : stringifyState(state);
  }

  /**
   * @private
   * @param {string} id
   * @param {string|null} json
   */
  _restoreElement(id, json) {
    const element = this.ctx.elements?.get(id);
    if (!element || json == null) return;
    const state = parseState(json);
    if (element.restoreHistory) element.restoreHistory(state);
    else element.deserialize?.(state);
  }

  /**
   * @private Copy a texel rect out of a layer-shaped array.
   * @returns {Uint8Array|Float32Array}
   */
  _readRect(source, layer, rect) {
    const { res, channels } = layer;
    const w = rect.x1 - rect.x0 + 1;
    const h = rect.y1 - rect.y0 + 1;
    const out = new source.constructor(w * h * channels);
    const rowLen = w * channels;
    for (let y = 0; y < h; y++) {
      const from = ((rect.y0 + y) * res + rect.x0) * channels;
      out.set(source.subarray(from, from + rowLen), y * rowLen);
    }
    return out;
  }

  /** @private Copy a compact rect buffer back into a layer-shaped array. */
  _writeRect(target, layer, rect, values) {
    const { res, channels } = layer;
    const w = rect.x1 - rect.x0 + 1;
    const h = rect.y1 - rect.y0 + 1;
    const rowLen = w * channels;
    for (let y = 0; y < h; y++) {
      const to = ((rect.y0 + y) * res + rect.x0) * channels;
      target.set(values.subarray(y * rowLen, (y + 1) * rowLen), to);
    }
  }

  /** @private Ctrl/Cmd+Z and Ctrl/Cmd+Shift+Z / Ctrl+Y, only while no panel owns them. */
  _bindKeys() {
    if (typeof window === 'undefined' || this._keyHandler) return;
    this._keyHandler = (e) => {
      // Once a panel exists it owns Ctrl+Z; its own listener handles this very
      // event, so bail out rather than undoing twice.
      if (this._syncUI()) return;
      const tag = (e.target?.tagName || '').toLowerCase();
      if (tag === 'input' || tag === 'textarea' || tag === 'select' || e.target?.isContentEditable) return;
      if (!(e.metaKey || e.ctrlKey)) return;
      const key = (e.key || '').toLowerCase();
      if (key === 'z' && !e.shiftKey) {
        e.preventDefault();
        this.undo();
      } else if ((key === 'z' && e.shiftKey) || key === 'y') {
        e.preventDefault();
        this.redo();
      }
    };
    window.addEventListener('keydown', this._keyHandler);
  }

  /** @private */
  _unbindKeys() {
    if (!this._keyHandler) return;
    window.removeEventListener('keydown', this._keyHandler);
    this._keyHandler = null;
  }

  dispose() {
    this._unbindKeys();
    this._listeners.clear();
    this._shadows.clear();
    this.clear();
  }
}

/**
 * @param {Uint8Array|Float32Array} a
 * @param {Uint8Array|Float32Array} b
 * @returns {boolean}
 */
function equalArrays(a, b) {
  if (a.length !== b.length) return false;
  for (let i = 0; i < a.length; i++) if (a[i] !== b[i]) return false;
  return true;
}
