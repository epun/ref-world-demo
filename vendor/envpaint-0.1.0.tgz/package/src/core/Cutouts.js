import * as THREE from 'three';

/** Most cutout discs a material carries; the vertex shader loops this many. */
export const MAX_CUTOUTS = 8;

/**
 * Keyed set of "nothing grows here" discs handed to an instanced material as
 * a small uniform array. Props that need bare ground under them (the Master
 * Sword) register a disc by key; the vertex shader culls any instance whose
 * root lands inside one. Unlike painting the mask layer, a cutout follows the
 * object, never touches user-painted data, and disappears with the object.
 */
export class Cutouts {
  constructor(max = MAX_CUTOUTS) {
    /** @type {number} */
    this.max = max;
    /** @type {Map<string, {x:number, z:number, r:number}>} */
    this.discs = new Map();
    /** @type {{uCutouts:{value:THREE.Vector3[]}, uCutoutCount:{value:number}}} */
    this.uniforms = {
      uCutouts: { value: Array.from({ length: max }, () => new THREE.Vector3()) },
      uCutoutCount: { value: 0 },
    };
  }

  /**
   * @param {string} key
   * @param {number} x world x
   * @param {number} z world z
   * @param {number} r radius, world units (0 removes)
   */
  set(key, x, z, r) {
    if (!(r > 0)) return this.remove(key);
    const d = this.discs.get(key);
    if (d && d.x === x && d.z === z && d.r === r) return this;
    this.discs.set(key, { x, z, r });
    this._sync();
    return this;
  }

  /** @param {string} key */
  remove(key) {
    if (this.discs.delete(key)) this._sync();
    return this;
  }

  /** @private */
  _sync() {
    const arr = this.uniforms.uCutouts.value;
    let i = 0;
    for (const d of this.discs.values()) {
      if (i >= this.max) break;
      arr[i++].set(d.x, d.z, d.r);
    }
    this.uniforms.uCutoutCount.value = i;
  }
}
