import * as THREE from 'three';

/**
 * Ink / hatch / paper post pass — the half of the Ghibli look that lives in
 * screen space rather than in a material.
 *
 * The scene is rendered into a render target that carries a `DepthTexture`;
 * one full-screen shader then reads colour + depth and draws:
 *
 *  - **silhouette lines** from depth differences, sampled through a pencil
 *    wobble so the line wanders,
 *  - **crease lines** from normals reconstructed out of the depth buffer,
 *  - **thick-and-thin weight** and **breaks** driven by fbm, so a stroke
 *    lifts off the paper here and there,
 *  - **hatching** in ink, only where the frame is dark, anchored to world
 *    position so it does not swim when the camera moves,
 *  - **paper grain**, **pigment pooling** at colour boundaries and a light
 *    vignette.
 *
 * The camera is orthographic, so depth is linear: `near + z * (far - near)`,
 * and a world position is one `inverse(viewProjection)` multiply away.
 *
 * @example
 * app.postfx = new PostFX(app);
 * app.postfx.apply(style.post);   // per-style defaults
 * app.postfx.render();            // instead of renderer.render(scene, camera)
 */

/** Line-style presets the panel's select and every style's `post` block use. */
export const LINE_STYLES = {
  none: { lineWidth: 0, wobble: 0, break: 0, inkOpacity: 0 },
  clean: { lineWidth: 1.2, wobble: 0, break: 0, inkOpacity: 0.9 },
  pencil: { lineWidth: 1.4, wobble: 0.8, break: 0.25, inkOpacity: 0.85 },
  brush: { lineWidth: 2.2, wobble: 1.6, break: 0.35, inkOpacity: 0.7 },
};

/** Defaults for every ink uniform, before a style's `post` block overrides it. */
export const POST_DEFAULTS = {
  enabled: true,
  lineStyle: 'pencil',
  lineWidth: 1.5,
  wobble: 0.7,
  wobbleScale: 220,
  break: 0.2,
  breakScale: 90,
  ink: '#2a2340',
  inkOpacity: 0.8,
  // WORLD units of linear depth difference across the sampled pair. Grass
  // blades sit ~0.5 u in front of the ground behind them, rocks, trees, hills
  // and clouds break 1.5 u, so 0.9 outlines shapes and leaves the meadow flat.
  depthThreshold: 0.9,
  normalThreshold: 0.35,
  hatch: 0.3,
  // Shade index (luminance + 0.35 * saturation) the hatch starts at. Our
  // palettes are bright and their shadows stay saturated in hue but not in
  // chroma, so a plain-luminance threshold never fires on them.
  hatchFrom: 0.8,
  hatchScale: 3.5,
  paper: 0.6,
  // Painterly extras: directional brush strokes over the frame, and a wet
  // smear of colour across edges.
  brush: 0,
  bleed: 0,
  // Realistic extra: unsharp mask, the finishing pass of a photo render.
  sharpen: 0,
  // Pixel extras: the scene is rendered into a 1/N buffer sampled NEAREST,
  // then quantised with a 4x4 Bayer ordered dither (levels 0 = no quantise).
  pixelSize: 1,
  levels: 0,
  dither: 0,
  // Only applied on the object-edge mask (see the shader), so it darkens the
  // boundary of a shape rather than every colour change in a meadow.
  pooling: 0.15,
  vignette: 0.06,
};

/**
 * Turns a style's `hatchScale` into world-space line frequency per unit of
 * world-per-pixel: chosen so the default 3.5 spaces the pencil lines 16 px
 * apart on screen at any zoom.
 */
const HATCH_PX_GAIN = (2 * Math.PI) / (16 * 3.5);

const quadVertexShader = /* glsl */ `
varying vec2 vUv;
void main() {
  vUv = uv;
  gl_Position = vec4(position.xy, 0.0, 1.0);
}
`;

const inkFragmentShader = /* glsl */ `
precision highp float;

uniform sampler2D uScene;
uniform sampler2D uDepth;
uniform vec2  uResolution;
uniform float uNear;
uniform float uFar;
uniform float uTime;

uniform float uLineWidth;
uniform float uWobble;
uniform float uWobbleScale;
uniform float uBreak;
uniform float uBreakScale;
uniform vec3  uInkColor;
uniform float uInkOpacity;
uniform float uDepthThreshold;
uniform float uNormalThreshold;

uniform float uHatch;
uniform float uHatchFrom;
uniform float uHatchScale;

uniform float uPaper;
uniform float uBrush;
uniform float uBleed;
uniform float uSharpen;
uniform float uLevels;
uniform float uDither;
uniform float uPooling;
uniform float uVignette;

uniform mat4 uInvViewProj;

varying vec2 vUv;

float hash21(vec2 p) {
  vec3 p3 = fract(p.xyx * 0.1031);
  p3 += dot(p3, p3.yzx + 33.33);
  return fract((p3.x + p3.y) * p3.z);
}

float vnoise(vec2 p) {
  vec2 i = floor(p);
  vec2 f = fract(p);
  vec2 u = f * f * (3.0 - 2.0 * f);
  float a = hash21(i);
  float b = hash21(i + vec2(1.0, 0.0));
  float c = hash21(i + vec2(0.0, 1.0));
  float d = hash21(i + vec2(1.0, 1.0));
  return mix(mix(a, b, u.x), mix(c, d, u.x), u.y);
}

float fbm(vec2 p, int octaves) {
  float v = 0.0;
  float amp = 0.5;
  vec2 q = p;
  for (int i = 0; i < 5; i++) {
    if (i >= octaves) break;
    v += amp * vnoise(q);
    q = q * 2.02 + 17.0;
    amp *= 0.5;
  }
  return v;
}

// The scene render target is LINEAR (three only applies the output colour
// space when drawing to the canvas), so the pass converts once on the way in
// and writes display-space sRGB straight to the framebuffer on the way out.
vec3 linearToSRGB(vec3 c) {
  c = max(c, vec3(0.0));
  return mix(pow(c, vec3(0.41666)) * 1.055 - vec3(0.055), c * 12.92,
             vec3(lessThanEqual(c, vec3(0.0031308))));
}

float rawDepth(vec2 uv) {
  return texture2D(uDepth, clamp(uv, vec2(0.0), vec2(1.0))).x;
}

// Orthographic projection: depth is linear across the frustum.
float toLinear(float raw) {
  return uNear + raw * (uFar - uNear);
}

// Alpha of the scene buffer is an INK MASK, not opacity: 1 = ink, hatch and
// pool this pixel, 0 = leave it alone (fire, embers, grass blades). See
// "opting out of ink" in ARCHITECTURE.md.
float alphaAt(vec2 uv) {
  return texture2D(uScene, clamp(uv, vec2(0.0), vec2(1.0))).a;
}

vec3 worldPos(vec2 uv, float raw) {
  vec4 clip = vec4(uv * 2.0 - 1.0, raw * 2.0 - 1.0, 1.0);
  vec4 p = uInvViewProj * clip;
  return p.xyz / p.w;
}

// Geometric normal rebuilt from three depth samples.
vec3 normalAt(vec2 uv, vec2 texel) {
  vec3 p = worldPos(uv, rawDepth(uv));
  vec3 px = worldPos(uv + vec2(texel.x, 0.0), rawDepth(uv + vec2(texel.x, 0.0)));
  vec3 py = worldPos(uv + vec2(0.0, texel.y), rawDepth(uv + vec2(0.0, texel.y)));
  return normalize(cross(px - p, py - p));
}

const float SKY = 0.9999;

// 4x4 Bayer matrix, the ordered dither every 16-bit console shipped with.
float bayer4(vec2 cell) {
  vec2 c = mod(floor(cell), 4.0);
  float i = c.x + c.y * 4.0;
  float m[16];
  m[0]=0.0;  m[1]=8.0;  m[2]=2.0;  m[3]=10.0;
  m[4]=12.0; m[5]=4.0;  m[6]=14.0; m[7]=6.0;
  m[8]=3.0;  m[9]=11.0; m[10]=1.0; m[11]=9.0;
  m[12]=15.0;m[13]=7.0; m[14]=13.0;m[15]=5.0;
  float v = 0.0;
  for (int k = 0; k < 16; k++) {
    if (float(k) == i) { v = m[k]; break; }
  }
  return (v + 0.5) / 16.0 - 0.5;
}

void main() {
  vec4 scene = texture2D(uScene, vUv);
  vec3 color = linearToSRGB(scene.rgb);
  vec2 texel = 1.0 / uResolution;

  // Alpha is an ink mask in tiers. Nothing blends against this target, so
  // the channel is free to mean this:
  //   a = 0.0   no ink at all                (fire, embers, grass blades)
  //   a = 0.6   outline only                 (water surface)
  //   a = 0.75  outline + pooling, no hatch  (cel materials in the sun)
  //   a = 1.0   everything                   (cel materials in shade, default)
  float inkMask = smoothstep(0.0, 0.5, scene.a);
  float poolMask = smoothstep(0.65, 0.72, scene.a);
  float hatchMask = smoothstep(0.85, 1.0, scene.a);

  float rC = rawDepth(vUv);
  float depthC = toLinear(rC);

  // Thick-and-thin: the nib swells and thins along the stroke.
  float width = max(uLineWidth * (0.7 + 0.6 * fbm(vUv * 3.0 + 11.0, 2)), 0.0);
  // Pencil wobble, in pixels, so the sampled edge wanders off the true one.
  float w = (vnoise(vUv * uWobbleScale + uTime * 0.03) - 0.5) * uWobble;
  vec2 wob = texel * w;
  vec2 off = texel * width;

  // How much this pixel looks like fine, dense geometry: the linear depth
  // changes wildly from pixel to pixel inside a grass mass and barely at all
  // across ground, rocks or a hillside.
  float grassProxy = smoothstep(0.05, 0.25, abs(fwidth(depthC)));

  float line = 0.0;
  float objectEdge = 0.0;
  if (width > 0.001 && uInkOpacity > 0.001) {
    vec2 uvC = vUv + wob;
    vec2 dx = vec2(off.x, 0.0);
    vec2 dy = vec2(0.0, off.y);

    float rL = rawDepth(uvC - dx);
    float rR = rawDepth(uvC + dx);
    float rU = rawDepth(uvC + dy);
    float rD = rawDepth(uvC - dy);

    float dDiff = max(abs(toLinear(rL) - toLinear(rR)), abs(toLinear(rU) - toLinear(rD)));
    float dThresh = uDepthThreshold * (1.0 + depthC * 0.02);
    float depthEdge = smoothstep(dThresh, dThresh * 1.6, dDiff);
    objectEdge = depthEdge;

    // Creases: inner edges of rocks and canopies, silent on gentle hills and
    // skipped entirely on the sky and on an already-solid silhouette.
    float normalEdge = 0.0;
    if (rC < SKY && depthEdge < 0.9) {
      vec3 nC = normalAt(uvC, texel);
      vec3 nX = normalAt(uvC + dx, texel);
      vec3 nY = normalAt(uvC + dy, texel);
      float nDiff = max(1.0 - dot(nC, nX), 1.0 - dot(nC, nY));
      normalEdge = smoothstep(uNormalThreshold, uNormalThreshold * 1.8, nDiff);
      // A crease inside dense foliage is blade-on-blade noise, not a shape.
      if (dDiff < 0.25) normalEdge *= 1.0 - grassProxy;
    }

    // Opted-out neighbours (alpha 0) take no part in any edge: a flame or a
    // blade must not put a line on the surface behind it either.
    float aL = alphaAt(uvC - dx);
    float aR = alphaAt(uvC + dx);
    float aU = alphaAt(uvC + dy);
    float aD = alphaAt(uvC - dy);
    float neighbours = min(min(aL, aR), min(aU, aD));
    line = max(depthEdge, normalEdge) * step(0.5, neighbours);

    // The outer silhouette against the sky is the shape the frame reads by, so
    // it is drawn from depth alone — but still only between neighbours that
    // take part in ink at all.
    float skyC = step(SKY, rC);
    float skySil = max(
      max(abs(skyC - step(SKY, rL)) * step(0.5, aL), abs(skyC - step(SKY, rR)) * step(0.5, aR)),
      max(abs(skyC - step(SKY, rU)) * step(0.5, aU), abs(skyC - step(SKY, rD)) * step(0.5, aD))
    );
    line = max(line, skySil);

    // Breaks: the pen lifts where the paper noise dips below uBreak.
    float ink = fbm(vUv * uBreakScale, 3);
    line *= smoothstep(uBreak - 0.15, uBreak + 0.15, ink);

    // Distant lines are drawn lighter.
    line *= 1.0 - 0.15 * smoothstep(0.0, 60.0, depthC);
  }

  // Unsharp mask: what finishes a photographic render, not a painted one.
  if (uSharpen > 0.001) {
    vec3 blur = linearToSRGB(texture2D(uScene, vUv + vec2(texel.x, 0.0)).rgb)
              + linearToSRGB(texture2D(uScene, vUv - vec2(texel.x, 0.0)).rgb)
              + linearToSRGB(texture2D(uScene, vUv + vec2(0.0, texel.y)).rgb)
              + linearToSRGB(texture2D(uScene, vUv - vec2(0.0, texel.y)).rgb);
    color += uSharpen * (color - blur * 0.25);
  }

  // Colour bleed: wet paint creeps a pixel across its own edge, in a direction
  // that wanders, so fills stop looking die-cut.
  if (uBleed > 0.001) {
    vec2 drift = vec2(vnoise(vUv * 90.0) - 0.5, vnoise(vUv * 90.0 + 31.0) - 0.5);
    vec3 smear = linearToSRGB(texture2D(uScene, vUv + drift * texel * 2.5).rgb);
    color = mix(color, smear, uBleed * 0.35);
  }

  // Ink is never pure black: the scene colour, darkened and pushed to the tint.
  vec3 ink = mix(color * 0.25, uInkColor, 0.65);

  // Hatching in the dark half of the frame, anchored to world space so it does
  // not swim when the camera moves.
  if (uHatch > 0.001 && rC < SKY) {
    float lum = dot(color, vec3(0.299, 0.587, 0.114));
    // In a cel palette a shadow is not much DARKER than the lit tone, it is
    // cooler and far less saturated (lit meadow and the hill's shadow side
    // measure the same luminance here), so the hatch reads a shade index that
    // mixes luminance with saturation instead of luminance alone.
    float mx = max(max(color.r, color.g), color.b);
    float mn = min(min(color.r, color.g), color.b);
    float sat = mx > 0.001 ? (mx - mn) / mx : 0.0;
    float shade = lum + 0.35 * sat;
    float dark = smoothstep(uHatchFrom, uHatchFrom - 0.25, shade);
    dark *= (1.0 - grassProxy) * inkMask * hatchMask;
    if (dark > 0.001) {
      vec3 wp = worldPos(vUv, rC);
      float jitter = (vnoise(vUv * uWobbleScale * 0.5) - 0.5) * (0.4 + uWobble);
      float h = sin((wp.x + wp.z) * uHatchScale + jitter);
      float hatch = smoothstep(0.6, 0.72, h);
      float h2 = sin((wp.x - wp.z) * uHatchScale * 1.1 + jitter);
      hatch = max(hatch, smoothstep(0.6, 0.72, h2) * smoothstep(0.7, 0.85, dark));
      color = mix(color, ink, hatch * dark * uHatch);
    }
  }

  color = mix(color, ink, clamp(line, 0.0, 1.0) * uInkOpacity * inkMask);

  // Pigment pooling: the boundary of a shape darkens slightly, as wet paint
  // does. Gated by the object-edge mask — grass changes colour at every pixel,
  // and pooling on that would dim the whole meadow.
  if (uPooling > 0.001 && objectEdge > 0.001) {
    float edge = length(fwidth(color));
    color *= 1.0 - uPooling * objectEdge * inkMask * poolMask * smoothstep(0.02, 0.12, edge) * 0.35;
  }

  // Brush: directional strokes, long across the sweep of the hand and narrow
  // through it, rotated off the screen axes so they read as painted marks.
  if (uBrush > 0.001) {
    const float CA = 0.9397;  // cos 20 deg
    const float SA = 0.3420;  // sin 20 deg
    vec2 r = vec2(vUv.x * CA - vUv.y * SA, vUv.x * SA + vUv.y * CA);
    float strokes = fbm(vec2(r.x * 220.0, r.y * 40.0), 2);
    color *= 1.0 + uBrush * (strokes - 0.5) * 0.12;
  }

  // Paper: a broad tooth plus a fine speckle, multiplicative and very subtle.
  if (uPaper > 0.001) {
    float tooth = fbm(vUv * 180.0, 2) - 0.5;
    float speck = hash21(floor(vUv * uResolution * 0.5)) - 0.5;
    color *= 1.0 + uPaper * (0.06 * tooth + 0.03 * speck);
  }

  // Ordered dither, then a hard quantisation per channel: the pixel style's
  // limited palette, with the dither breaking up the bands the way a 16-bit
  // artist would.
  if (uLevels > 1.5) {
    float steps = max(uLevels - 1.0, 1.0);
    // Half a quantisation step of Bayer offset, and none at all where the
    // colour already sits within 15 % of a level: flat fills (a meadow, a
    // sky band) stay flat, and only the gradients between them get dithered.
    vec3 p = clamp(color, 0.0, 1.0) * steps;
    vec3 dist = min(fract(p), 1.0 - fract(p));          // 0 at a level, 0.5 midway
    vec3 onGradient = step(vec3(0.15), dist);
    vec3 d = vec3(bayer4(vUv * uResolution) * uDither * 0.5 / steps) * onGradient;
    color = floor(clamp(color + d, 0.0, 1.0) * steps + 0.5) / steps;
  }

  // Vignette: 6 % at the corners by default.
  vec2 v = vUv - 0.5;
  color *= 1.0 - uVignette * smoothstep(0.15, 0.75, dot(v, v) * 2.0);

  gl_FragColor = vec4(color, 1.0);
}
`;

/**
 * Screen-space ink pass. Owns one render target (colour + depth) and one
 * full-screen quad; `render()` replaces `renderer.render(scene, camera)`.
 */
export class PostFX {
  /**
   * @param {{renderer: THREE.WebGLRenderer, scene: THREE.Scene, iso: {camera: THREE.Camera}}} app
   */
  constructor(app) {
    /** @type {any} */
    this.app = app;
    /** @type {THREE.WebGLRenderer} */
    this.renderer = app.renderer;
    /** @type {boolean} whether the ink pass draws at all */
    this.enabled = true;
    /** @type {string} active line-style preset id */
    this.lineStyle = POST_DEFAULTS.lineStyle;
    /** @type {number} milliseconds the last `render()` spent on the CPU */
    this.lastCost = 0;
    /** @type {number} MSAA samples actually in use (0 = none) */
    this.samples = 0;

    /** @type {number} scene buffer divisor: 1 = full res, 3 = pixel art */
    this.pixelSize = POST_DEFAULTS.pixelSize;
    /** @private hatch density as the style authored it (screen-relative) */
    this._hatchScale = POST_DEFAULTS.hatchScale;

    const size = new THREE.Vector2();
    this.renderer.getSize(size);
    const pr = this.renderer.getPixelRatio();
    /** @private full-resolution device pixels of the canvas */
    this._fullWidth = Math.max(1, Math.floor(size.x * pr));
    this._fullHeight = Math.max(1, Math.floor(size.y * pr));
    this._width = this._fullWidth;
    this._height = this._fullHeight;

    this.target = this._buildTarget(this._width, this._height, 4);
    this.samples = this.target.samples || 0;
    this._depthProbed = false;

    this.material = new THREE.ShaderMaterial({
      name: 'InkPass',
      uniforms: {
        uScene: { value: this.target.texture },
        uDepth: { value: this.target.depthTexture },
        uResolution: { value: new THREE.Vector2(this._width, this._height) },
        uNear: { value: 0.1 },
        uFar: { value: 300 },
        uTime: { value: 0 },
        uLineWidth: { value: POST_DEFAULTS.lineWidth },
        uWobble: { value: POST_DEFAULTS.wobble },
        uWobbleScale: { value: POST_DEFAULTS.wobbleScale },
        uBreak: { value: POST_DEFAULTS.break },
        uBreakScale: { value: POST_DEFAULTS.breakScale },
        // Display-space, to match the sRGB values the pass works in.
        uInkColor: { value: new THREE.Color(POST_DEFAULTS.ink).convertLinearToSRGB() },
        uInkOpacity: { value: POST_DEFAULTS.inkOpacity },
        uDepthThreshold: { value: POST_DEFAULTS.depthThreshold },
        uNormalThreshold: { value: POST_DEFAULTS.normalThreshold },
        uHatch: { value: POST_DEFAULTS.hatch },
        uHatchFrom: { value: POST_DEFAULTS.hatchFrom },
        uHatchScale: { value: POST_DEFAULTS.hatchScale },
        uPaper: { value: POST_DEFAULTS.paper },
        uBrush: { value: POST_DEFAULTS.brush },
        uBleed: { value: POST_DEFAULTS.bleed },
        uSharpen: { value: POST_DEFAULTS.sharpen },
        uLevels: { value: POST_DEFAULTS.levels },
        uDither: { value: POST_DEFAULTS.dither },
        uPooling: { value: POST_DEFAULTS.pooling },
        uVignette: { value: POST_DEFAULTS.vignette },
        uInvViewProj: { value: new THREE.Matrix4() },
      },
      vertexShader: quadVertexShader,
      fragmentShader: inkFragmentShader,
      depthTest: false,
      depthWrite: false,
      // The scene texture is already sRGB-encoded; this pass must not encode
      // a second time, so it writes its colour through untouched.
      toneMapped: false,
    });

    this._quadScene = new THREE.Scene();
    this._quadCamera = new THREE.OrthographicCamera(-1, 1, 1, -1, 0, 1);
    const quad = new THREE.Mesh(new THREE.PlaneGeometry(2, 2), this.material);
    quad.frustumCulled = false;
    this._quadScene.add(quad);
    this._quad = quad;
  }

  /**
   * @private
   * @param {number} width
   * @param {number} height
   * @param {number} samples MSAA samples to ask for
   * @returns {THREE.WebGLRenderTarget}
   */
  _buildTarget(width, height, samples) {
    const depthTexture = new THREE.DepthTexture(width, height, THREE.UnsignedIntType);
    depthTexture.format = THREE.DepthFormat;
    const options = {
      depthBuffer: true,
      depthTexture,
      // Everything upstream already writes sRGB, so a byte target is enough.
      // RGBA, because alpha carries the ink mask (the composite ignores it).
      format: THREE.RGBAFormat,
      type: THREE.UnsignedByteType,
      // NEAREST once the buffer is smaller than the canvas: the upscale IS
      // the pixel-art look, and a linear one would just blur it.
      minFilter: this.pixelSize > 1 ? THREE.NearestFilter : THREE.LinearFilter,
      magFilter: this.pixelSize > 1 ? THREE.NearestFilter : THREE.LinearFilter,
      colorSpace: THREE.NoColorSpace,
    };
    try {
      const target = new THREE.WebGLRenderTarget(width, height, { ...options, samples });
      target.texture.name = 'PostFX.scene';
      return target;
    } catch (err) {
      console.warn('[EnvPaint] PostFX: MSAA render target unavailable, falling back:', err);
      const target = new THREE.WebGLRenderTarget(width, height, { ...options, samples: 0 });
      target.texture.name = 'PostFX.scene';
      return target;
    }
  }

  /**
   * Match the render target to the canvas.
   * @param {number} width CSS pixels
   * @param {number} height CSS pixels
   */
  setSize(width, height) {
    const pr = this.renderer.getPixelRatio();
    this._fullWidth = Math.max(1, Math.floor(width * pr));
    this._fullHeight = Math.max(1, Math.floor(height * pr));
    return this._resizeTarget();
  }

  /**
   * @private Match the scene buffer to the canvas divided by `pixelSize`, and
   * switch its filtering to match. `uResolution` is the BUFFER's size, so the
   * ink pass measures line width and the dither cell in pixel-art pixels.
   */
  _resizeTarget() {
    const div = Math.max(1, Math.round(this.pixelSize));
    const w = Math.max(1, Math.ceil(this._fullWidth / div));
    const h = Math.max(1, Math.ceil(this._fullHeight / div));
    const filter = div > 1 ? THREE.NearestFilter : THREE.LinearFilter;
    const filterChanged = this.target.texture.magFilter !== filter;
    if (!filterChanged && w === this._width && h === this._height) return this;

    this._width = w;
    this._height = h;
    if (filterChanged) {
      // Filtering is baked in when the attachment is allocated, so the target
      // is rebuilt rather than patched.
      const samples = this.target.samples || 0;
      this.target.dispose();
      this.target = this._buildTarget(w, h, samples);
      this.material.uniforms.uScene.value = this.target.texture;
      this.material.uniforms.uDepth.value = this.target.depthTexture;
    } else {
      this.target.setSize(w, h);
    }
    this.material.uniforms.uResolution.value.set(w, h);
    return this;
  }

  /**
   * Apply a style's `post` block. Unknown keys are ignored; missing keys fall
   * back to POST_DEFAULTS, so every style gets a complete, predictable look.
   * @param {object} [post] the style's post block
   */
  apply(post = {}) {
    const merged = { ...POST_DEFAULTS, ...post };
    const preset = LINE_STYLES[merged.lineStyle] || null;
    // A style may name a preset AND override individual numbers; the explicit
    // number wins.
    const value = (key) => (post[key] !== undefined ? post[key]
      : preset && preset[key] !== undefined ? preset[key]
      : merged[key]);

    this.enabled = merged.enabled !== false;
    this.lineStyle = merged.lineStyle;

    const u = this.material.uniforms;
    u.uLineWidth.value = value('lineWidth');
    u.uWobble.value = value('wobble');
    u.uWobbleScale.value = value('wobbleScale');
    u.uBreak.value = value('break');
    u.uBreakScale.value = value('breakScale');
    u.uInkColor.value.set(value('ink')).convertLinearToSRGB();
    u.uInkOpacity.value = value('inkOpacity');
    u.uDepthThreshold.value = value('depthThreshold');
    u.uNormalThreshold.value = value('normalThreshold');
    u.uHatch.value = value('hatch');
    u.uHatchFrom.value = value('hatchFrom');
    this._hatchScale = value('hatchScale');
    u.uPaper.value = value('paper');
    u.uBrush.value = value('brush');
    u.uBleed.value = value('bleed');
    u.uSharpen.value = value('sharpen');
    u.uLevels.value = value('levels');
    u.uDither.value = value('dither');
    u.uPooling.value = value('pooling');
    u.uVignette.value = value('vignette');

    // Pixelation changes the size of the scene buffer, not just a uniform.
    const pixelSize = Math.max(1, Math.round(value('pixelSize')));
    if (pixelSize !== this.pixelSize) {
      this.pixelSize = pixelSize;
      this._resizeTarget();
    }
    return this;
  }

  /**
   * Switch line-style preset without touching the other ink settings.
   * @param {'none'|'clean'|'pencil'|'brush'} id
   */
  setLineStyle(id) {
    const preset = LINE_STYLES[id];
    if (!preset) return this;
    this.lineStyle = id;
    const u = this.material.uniforms;
    u.uLineWidth.value = preset.lineWidth;
    u.uWobble.value = preset.wobble;
    u.uBreak.value = preset.break;
    u.uInkOpacity.value = preset.inkOpacity;
    return this;
  }

  /**
   * @private One-off check that the depth attachment actually reads back —
   * a multisampled target that cannot blit depth renders every pixel at 0,
   * which would ink the whole frame. Falls back to `samples: 0` if so.
   */
  _probeDepth() {
    this._depthProbed = true;
    const probeTarget = new THREE.WebGLRenderTarget(1, 1, { depthBuffer: false });
    const probeMaterial = new THREE.ShaderMaterial({
      uniforms: { uDepth: { value: this.target.depthTexture } },
      vertexShader: quadVertexShader,
      fragmentShader: /* glsl */ `
        uniform sampler2D uDepth;
        varying vec2 vUv;
        void main() { gl_FragColor = vec4(vec3(texture2D(uDepth, vec2(0.5)).x), 1.0); }
      `,
      depthTest: false,
      depthWrite: false,
    });
    const previous = this._quad.material;
    this._quad.material = probeMaterial;
    const pixels = new Uint8Array(4);
    try {
      this.renderer.setRenderTarget(probeTarget);
      this.renderer.render(this._quadScene, this._quadCamera);
      this.renderer.readRenderTargetPixels(probeTarget, 0, 0, 1, 1, pixels);
    } catch (err) {
      console.warn('[EnvPaint] PostFX: depth probe failed:', err);
    } finally {
      this._quad.material = previous;
      this.renderer.setRenderTarget(null);
      probeTarget.dispose();
      probeMaterial.dispose();
    }
    if (pixels[0] === 0 && this.samples > 0) {
      console.warn('[EnvPaint] PostFX: multisampled depth reads 0 — retrying without MSAA');
      this.target.dispose();
      this.target = this._buildTarget(this._width, this._height, 0);
      this.samples = 0;
      this.material.uniforms.uScene.value = this.target.texture;
      this.material.uniforms.uDepth.value = this.target.depthTexture;
    }
  }

  /** Hatch density, in the style's screen-relative units (3.5 = 16 px apart). */
  get hatchScale() {
    return this._hatchScale;
  }

  set hatchScale(v) {
    this._hatchScale = Math.max(0.1, Number(v) || 0.1);
  }

  /**
   * World units covered by one device pixel of the scene buffer's height.
   * Orthographic only (the whole app is); a perspective camera gets a
   * sensible constant so the hatch still draws.
   * @private
   * @param {THREE.Camera} camera
   * @returns {number}
   */
  _unitsPerPixel(camera) {
    const ortho = /** @type {any} */ (camera);
    if (typeof ortho.top !== 'number' || typeof ortho.bottom !== 'number') return 1 / 30;
    const span = (ortho.top - ortho.bottom) / (ortho.zoom || 1);
    return Math.max(1e-4, span / this._fullHeight);
  }

  /**
   * Draw the scene through the ink pass (or straight to the screen when
   * disabled). Records the CPU cost in `lastCost`.
   * @param {THREE.Scene} [scene]
   * @param {THREE.Camera} [camera]
   */
  render(scene = this.app.scene, camera = this.app.iso?.camera || this.app.camera) {
    const renderer = this.renderer;
    if (!this.enabled) {
      renderer.setRenderTarget(null);
      renderer.render(scene, camera);
      this.lastCost = 0;
      return this;
    }

    renderer.setRenderTarget(this.target);
    renderer.clear();
    renderer.render(scene, camera);
    renderer.setRenderTarget(null);

    const t0 = (typeof performance !== 'undefined' ? performance.now() : Date.now());
    const u = this.material.uniforms;
    u.uNear.value = camera.near;
    u.uFar.value = camera.far;
    u.uTime.value = this.app.ctx?.time ?? 0;
    // Hatch lines are anchored in world space (no swimming) but spaced on the
    // screen: the world-space frequency follows the zoom so the pencil stays
    // the same pencil whether you look at the whole meadow or one rock.
    u.uHatchScale.value = this._hatchScale * HATCH_PX_GAIN / this._unitsPerPixel(camera);
    camera.updateMatrixWorld();
    u.uInvViewProj.value
      .copy(camera.projectionMatrix)
      .multiply(camera.matrixWorldInverse)
      .invert();

    renderer.render(this._quadScene, this._quadCamera);
    this.lastCost = (typeof performance !== 'undefined' ? performance.now() : Date.now()) - t0;

    if (!this._depthProbed) this._probeDepth();
    return this;
  }

  dispose() {
    this.target.dispose();
    this.target.depthTexture?.dispose();
    this.material.dispose();
    this._quad.geometry.dispose();
  }
}

export default PostFX;
