import { fbm, hash21 } from './noise.js';

/**
 * Brush edge shape, shared by every disc a brush stamps (paint layers, the
 * water level and carve discs). A plain disc with a smoothstep falloff reads
 * as a stencil; these settings roughen it into a painted mark:
 *
 *   edgeNoise  0..1  how far the rim wanders in and out (1 = about ±35 %)
 *   edgeScale  1..8  how many lobes around the rim (low = blobby, high = ragged)
 *   spatter    0..1  dissolves the feathered zone into speckle (dry brush)
 *   aspect   0.2..1  below 1 the disc is an oval stretched along the stroke
 *
 * Every stamp carries its own `seed`, so consecutive dabs along a stroke
 * disagree about where the rim bulges and the stroke edge breaks up.
 */
export const SHAPE_DEFAULTS = { edgeNoise: 0.35, edgeScale: 3, spatter: 0.25, aspect: 1 };

const clamp = (v, lo, hi) => Math.max(lo, Math.min(hi, v));

/** GLSL smoothstep. */
export function smoothstep(e0, e1, x) {
  if (e1 <= e0) return x < e0 ? 0 : 1;
  const t = clamp((x - e0) / (e1 - e0), 0, 1);
  return t * t * (3 - 2 * t);
}

/**
 * Rim radius in a given direction: the base radius modulated by noise sampled
 * on a circle, so it is continuous all the way round with no seam.
 * @param {number} radius
 * @param {number} angle radians
 * @param {number} edgeNoise 0..1
 * @param {number} edgeScale lobes around the rim
 * @param {number} seed per-stamp
 * @returns {number}
 */
export function edgeRadius(radius, angle, edgeNoise, edgeScale, seed) {
  if (!(edgeNoise > 0)) return radius;
  const n = fbm(
    Math.cos(angle) * edgeScale + seed * 0.37 + 7.1,
    Math.sin(angle) * edgeScale + seed * 0.61 + 3.3,
    3,
  );
  return radius * (1 + edgeNoise * 1.8 * (n - 0.45));
}

/**
 * Build the falloff evaluator for one stamp.
 * @param {{radius:number, hardness?:number, dir?:{x:number,y:number}|null,
 *          edgeNoise?:number, edgeScale?:number, spatter?:number, aspect?:number, seed?:number}} op
 * @returns {{bound:number, f:(du:number, dv:number, tx:number, ty:number) => number}}
 *   `bound` is the largest offset (same units as `radius`) the stamp can
 *   touch; `f(du, dv, tx, ty)` is the weight 0..1 at offset (du, dv) for the
 *   texel at integer (tx, ty).
 */
export function makeFalloff(op) {
  const radius = op.radius;
  const hardness = clamp(op.hardness ?? 0.5, 0, 1);
  const edgeNoise = clamp(op.edgeNoise ?? 0, 0, 1);
  const edgeScale = clamp(op.edgeScale ?? SHAPE_DEFAULTS.edgeScale, 0.5, 16);
  const spatter = clamp(op.spatter ?? 0, 0, 1);
  const aspect = clamp(op.aspect ?? 1, 0.2, 1);
  const seed = op.seed ?? 0;
  const dir = op.dir;
  const hasDir = !!dir && aspect < 0.999 && (dir.x !== 0 || dir.y !== 0);
  let dx = 1;
  let dy = 0;
  if (hasDir) {
    const l = Math.hypot(dir.x, dir.y) || 1;
    dx = dir.x / l;
    dy = dir.y / l;
  }
  const bound = radius * (1 + 0.8 * edgeNoise);

  return {
    bound,
    f(du, dv, tx, ty) {
      let ex = du;
      let ey = dv;
      if (hasDir) {
        // Into the stroke frame: along the stroke keeps its length, across it
        // is stretched by 1/aspect so the disc reads as an oval along the dab.
        const along = du * dx + dv * dy;
        const across = -du * dy + dv * dx;
        ex = along;
        ey = across / aspect;
      }
      const dist = Math.sqrt(ex * ex + ey * ey);
      if (dist > bound) return 0;
      const r = edgeRadius(radius, Math.atan2(ey, ex), edgeNoise, edgeScale, seed);
      if (dist >= r) return 0;
      let f = 1 - smoothstep(hardness * r, r, dist);
      if (spatter > 0 && f < 1) {
        // Dry brush: in the feather zone a texel is either painted or not,
        // with probability f, fixed per texel and per stamp.
        const n = hash21(tx * 1.7 + seed * 13.1, ty * 2.3 - seed * 7.7);
        f += ((n < f ? 1 : 0) - f) * spatter;
      }
      return f;
    },
  };
}
