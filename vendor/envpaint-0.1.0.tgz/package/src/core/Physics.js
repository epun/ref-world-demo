import RAPIER from '@dimforge/rapier3d-compat';
import { WORLD_SIZE } from './constants.js';

/** Fixed simulation step, seconds. */
const FIXED_STEP = 1 / 60;
/** Never run more than this many fixed steps per frame (avoids spirals of death). */
const MAX_SUBSTEPS = 3;
/** Cells per side of the terrain height-field collider (129 x 129 samples). */
export const HEIGHTFIELD_SEGMENTS = 128;
/**
 * Cells per side used while a brush stroke is in progress. Rapier's collider
 * build cost climbs steeply past ~100 cells (measured: 128 -> 6-23 ms, 112 ->
 * 6 ms, 97 -> 0.8-3 ms, 64 -> 0.3 ms), and the ground must keep up with the
 * brush, so strokes rebuild coarse and the full field is restored on release.
 */
export const STROKE_SEGMENTS = 97;
/** Terrain colliders rebuild at most this often, in seconds. */
const REBUILD_INTERVAL = 0.25;

/**
 * Fill the heights buffer of a Rapier height-field collider.
 *
 * Rapier stores the field as an nalgebra `DMatrix`, which is COLUMN-major, and
 * maps the matrix rows to local Z and the columns to local X. The element for
 * (row i = z, column j = x) therefore lives at `heights[j * (nrows + 1) + i]`.
 * `test/Physics.test.js` pins this convention down empirically by dropping
 * bodies onto a field that is raised on its +X half only.
 *
 * @param {(u: number, v: number) => number} sample height at u (along X) and
 *   v (along Z), both 0..1 across the field
 * @param {number} [segments=HEIGHTFIELD_SEGMENTS] cells per side
 * @returns {Float32Array} (segments + 1)^2 heights in Rapier's order
 */
export function buildHeightfieldHeights(sample, segments = HEIGHTFIELD_SEGMENTS) {
  const n = segments + 1;
  const heights = new Float32Array(n * n);
  for (let ix = 0; ix < n; ix++) {
    const u = ix / segments;
    for (let iz = 0; iz < n; iz++) {
      heights[ix * n + iz] = sample(u, iz / segments);
    }
  }
  return heights;
}

/**
 * Rapier world wrapper: fixed-step simulation, the terrain height-field
 * collider, and small helpers for elements that spawn rigid bodies.
 *
 * The instance is normally created lazily by the first element that needs it
 * (currently `Rocks`), which sets `physics.owner = this` and calls
 * `physics.step(dt)` from its own `update()` so exactly one element drives the
 * simulation.
 */
export class Physics {
  /**
   * @param {object} ctx shared app context (needs terrain, and brush if present)
   */
  constructor(ctx) {
    /** @type {object} */
    this.ctx = ctx;
    /** @type {boolean} true once RAPIER.init() resolved and the world exists */
    this.ready = false;
    /** @type {import('@dimforge/rapier3d-compat').World|null} */
    this.world = null;
    /** @type {object|null} whoever created (and therefore steps) this instance */
    this.owner = null;
    /** @type {number} fixed steps run since init */
    this.steps = 0;

    /** @private */
    this._accumulator = 0;
    /** @private */
    this._terrainBody = null;
    /** @private */
    this._terrainCollider = null;
    /** @private a terrain rebuild is wanted as soon as it is allowed */
    this._rebuildPending = false;
    /** @private seconds since the last rebuild */
    this._sinceRebuild = REBUILD_INTERVAL;
    /** @private a brush stroke is in progress: rebuild coarse, not deferred */
    this._strokeActive = false;
    /** @private cells per side of the collider currently in the world */
    this._segments = 0;

    this._onStrokeStart = () => {
      this._strokeActive = true;
    };
    this._onStrokeEnd = () => {
      this._strokeActive = false;
      // Restore the full-resolution field now the brush has let go.
      if (this._segments !== HEIGHTFIELD_SEGMENTS) this._rebuildPending = true;
    };
  }

  /**
   * Load the Rapier WASM module and build the world plus the terrain collider.
   * @returns {Promise<Physics>}
   */
  async init() {
    await RAPIER.init();
    this.world = new RAPIER.World({ x: 0, y: -9.81, z: 0 });
    this.world.timestep = FIXED_STEP;
    this._terrainBody = this.world.createRigidBody(RAPIER.RigidBodyDesc.fixed());
    this.rebuildTerrain();
    this.ready = true;

    const brush = this.ctx.brush;
    if (brush) {
      brush.on('strokestart', this._onStrokeStart);
      brush.on('strokeend', this._onStrokeEnd);
    }
    return this;
  }

  /**
   * Replace the terrain height-field collider with one sampled from the
   * current `terrain.heightLayer`, and wake every body so it reacts to the
   * new ground immediately. Not free (see `STROKE_SEGMENTS`) — go through
   * `requestTerrainRebuild()` for interactive sculpting.
   * @param {number} [segments] cells per side; defaults to the coarse field
   *   while a stroke is in progress and the full one otherwise
   */
  rebuildTerrain(segments = this._strokeActive ? STROKE_SEGMENTS : HEIGHTFIELD_SEGMENTS) {
    const layer = this.ctx.terrain?.heightLayer;
    if (!this.world || !layer) return this;

    const heights = buildHeightfieldHeights((u, v) => layer.sample(u, v), segments);
    if (this._terrainCollider) {
      this.world.removeCollider(this._terrainCollider, false);
      this._terrainCollider = null;
    }
    // FIX_INTERNAL_EDGES makes the contact normals of neighbouring cells agree;
    // without it, bodies rolling across cell boundaries get kicked through the
    // field (verified with scratch probes).
    const desc = RAPIER.ColliderDesc.heightfield(
      segments,
      segments,
      heights,
      { x: WORLD_SIZE, y: 1, z: WORLD_SIZE },
      RAPIER.HeightFieldFlags.FIX_INTERNAL_EDGES,
    )
      .setFriction(1.1)
      .setRestitution(0.02);
    this._terrainCollider = this.world.createCollider(desc, this._terrainBody);
    this._segments = segments;
    this._rebuildPending = false;
    this._sinceRebuild = 0;
    // The ground moved: nothing may stay asleep on top of where it used to be.
    this.wakeAll();
    return this;
  }

  /** Wake every dynamic body, e.g. after the ground under them moved. */
  wakeAll() {
    this.world?.forEachRigidBody((body) => body.wakeUp());
    return this;
  }

  /**
   * Ask for a terrain collider rebuild. It happens on the next `step()` that is
   * at least 250 ms after the last one — mid-stroke included, so bodies react
   * to the ground while it is still being sculpted.
   */
  requestTerrainRebuild() {
    this._rebuildPending = true;
    return this;
  }

  /**
   * Advance the simulation with a fixed-step accumulator.
   * @param {number} dt seconds since the last frame
   */
  step(dt) {
    if (!this.ready) return this;

    this._sinceRebuild += dt;
    if (this._rebuildPending && this._sinceRebuild >= REBUILD_INTERVAL) {
      this.rebuildTerrain();
    }

    this._accumulator += dt;
    let n = 0;
    while (this._accumulator >= FIXED_STEP && n < MAX_SUBSTEPS) {
      this.world.step();
      this._accumulator -= FIXED_STEP;
      this.steps++;
      n++;
    }
    // Drop the backlog rather than fast-forwarding after a long stall.
    if (this._accumulator > FIXED_STEP * MAX_SUBSTEPS) this._accumulator = 0;
    return this;
  }

  /**
   * Create a rigid body with one collider attached.
   * @param {import('@dimforge/rapier3d-compat').RigidBodyDesc} desc
   * @param {import('@dimforge/rapier3d-compat').ColliderDesc} [colliderDesc]
   * @returns {import('@dimforge/rapier3d-compat').RigidBody|null}
   */
  addRigidBody(desc, colliderDesc) {
    if (!this.world) return null;
    const body = this.world.createRigidBody(desc);
    if (colliderDesc) this.world.createCollider(colliderDesc, body);
    return body;
  }

  /**
   * Remove a body and its colliders from the world.
   * @param {import('@dimforge/rapier3d-compat').RigidBody} body
   */
  remove(body) {
    if (this.world && body) this.world.removeRigidBody(body);
    return this;
  }

  /** Drop the world and unsubscribe from brush events. */
  dispose() {
    const brush = this.ctx.brush;
    if (brush) {
      brush.off('strokestart', this._onStrokeStart);
      brush.off('strokeend', this._onStrokeEnd);
    }
    this.ready = false;
    this._terrainCollider = null;
    this._terrainBody = null;
    if (this.world) this.world.free();
    this.world = null;
  }
}
