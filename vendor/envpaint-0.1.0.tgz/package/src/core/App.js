import * as THREE from 'three';
import { IsoCamera } from './IsoCamera.js';
import { Sun } from './Sun.js';
import { Wind } from './Wind.js';
import { PaintLayers } from './PaintLayers.js';
import { Terrain } from './Terrain.js';
import { Brush } from './Brush.js';
import { History } from './History.js';
import { Style } from './Style.js';
import { PostFX } from './PostFX.js';
import { STYLES } from '../styles/index.js';

const MAX_DT = 1 / 20;

/**
 * A screen-filling vertical gradient standing in for the sky: cool blue
 * overhead fading to a warm horizon. Drawn first, writes no depth.
 * @returns {THREE.Mesh}
 */
function buildSky() {
  const material = new THREE.ShaderMaterial({
    name: 'SkyGradient',
    uniforms: {
      uSkyTop: { value: new THREE.Color('#bfe0ff') },
      uSkyHorizon: { value: new THREE.Color('#f3ecd8') },
    },
    vertexShader: /* glsl */ `
      varying float vSkyT;
      void main() {
        vSkyT = position.y * 0.5 + 0.5;
        gl_Position = vec4(position.xy, 1.0, 1.0);
      }
    `,
    fragmentShader: /* glsl */ `
      uniform vec3 uSkyTop;
      uniform vec3 uSkyHorizon;
      varying float vSkyT;
      void main() {
        gl_FragColor = vec4(mix(uSkyHorizon, uSkyTop, smoothstep(0.0, 1.0, vSkyT)), 1.0);
        #include <colorspace_fragment>
      }
    `,
    depthTest: false,
    depthWrite: false,
    toneMapped: false,
    fog: false,
  });
  const mesh = new THREE.Mesh(new THREE.PlaneGeometry(2, 2), material);
  mesh.name = 'sky';
  mesh.frustumCulled = false;
  mesh.renderOrder = -1;
  return mesh;
}

/**
 * Owns the renderer, scene, camera rig and the frame loop, and builds the
 * `ctx` object every Element is handed.
 */
export class App {
  /**
   * @param {HTMLElement} container element the canvas is mounted into
   */
  constructor(container) {
    /** @type {HTMLElement} */
    this.container = container;
    /** @type {boolean} */
    this.running = false;
    /** @type {number} frames rendered since start */
    this.frame = 0;
    /** @type {object|null} ghost-panel instance, assigned by the UI */
    this.ui = null;
    /** @type {Array<(dt:number, time:number) => void>} per-frame hooks */
    this.onFrame = [];

    this._lastVersions = new Map();
    this._lastTerrainVersion = -1;
    this._clock = null;
    this._tick = this._tick.bind(this);
  }

  /** Build the renderer, scene and every core system. */
  async init() {
    const width = this.container.clientWidth || window.innerWidth;
    const height = this.container.clientHeight || window.innerHeight;

    const renderer = new THREE.WebGLRenderer({ antialias: true, powerPreference: 'high-performance' });
    renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
    renderer.setSize(width, height);
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.toneMapping = THREE.NoToneMapping;
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    renderer.domElement.style.display = 'block';
    renderer.domElement.style.touchAction = 'none';
    this.container.appendChild(renderer.domElement);
    /** @type {THREE.WebGLRenderer} */
    this.renderer = renderer;

    /** @type {THREE.Scene} */
    this.scene = new THREE.Scene();
    this.scene.background = new THREE.Color('#bfe0ff');
    this.scene.fog = new THREE.Fog(new THREE.Color('#e9f0f6'), 90, 160);
    /** @type {THREE.Mesh} full-screen gradient sky, drawn before everything */
    this.sky = buildSky();
    this.scene.add(this.sky);

    /** @type {IsoCamera} */
    this.iso = new IsoCamera(renderer.domElement, width, height);
    /** @type {Sun} */
    this.sun = new Sun(this.scene);
    /** @type {Wind} */
    this.wind = new Wind();
    /** @type {PaintLayers} */
    this.layers = new PaintLayers();

    /**
     * The shared context handed to every Element.
     * @type {object}
     */
    this.ctx = {
      app: this,
      scene: this.scene,
      camera: this.iso.camera,
      renderer,
      iso: this.iso,
      sun: this.sun,
      wind: this.wind,
      layers: this.layers,
      terrain: null,
      physics: null,
      brush: null,
      history: null,
      elements: new Map(),
      style: null,
      postfx: null,
      time: 0,
    };

    // The ink / hatch / paper pass every frame is drawn through. Built before
    // the Style, which pushes each style's `post` block into it.
    /** @type {PostFX} */
    this.postfx = new PostFX(this);
    this.ctx.postfx = this.postfx;

    // Built before the terrain and every element, because each of them
    // registers its materials with ctx.style.attach() as it creates them.
    /** @type {Style} */
    this.style = new Style(this.ctx, STYLES);
    this.ctx.style = this.style;
    this.postfx.apply(this.style.get()?.post);

    /** @type {Terrain} */
    this.terrain = new Terrain(this.ctx);
    this.ctx.terrain = this.terrain;

    /** @type {History} stroke-scoped undo / redo */
    this.history = new History(this.ctx);
    this.ctx.history = this.history;

    /** @type {Brush} */
    this.brush = new Brush(this.ctx);
    this.ctx.brush = this.brush;
    this.terrain.registerTools(this.brush);

    this._onResize = () => this.resize();
    window.addEventListener('resize', this._onResize);
    this.resize();
    return this;
  }

  /** Match the renderer and camera to the container size. */
  resize() {
    const width = this.container.clientWidth || window.innerWidth;
    const height = this.container.clientHeight || window.innerHeight;
    this.renderer.setSize(width, height);
    this.iso.resize(width, height);
    this.postfx?.setSize(width, height);
  }

  /**
   * Draw one frame through the ink pass. The PNG export calls this so a saved
   * image matches the screen exactly.
   */
  renderOnce() {
    if (this.postfx) this.postfx.render(this.scene, this.iso.camera);
    else this.renderer.render(this.scene, this.iso.camera);
    return this;
  }

  /**
   * Construct, init and register an Element.
   * @param {import('./Element.js').Element} element
   * @returns {Promise<import('./Element.js').Element>}
   */
  async addElement(element) {
    const id = /** @type {any} */ (element.constructor).id || element.id;
    await element.init();
    this.ctx.elements.set(id, element);
    return element;
  }

  /** @returns {import('./Element.js').Element[]} in `order` */
  elements() {
    return [...this.ctx.elements.values()].sort(
      (a, b) => (a.constructor.order ?? 100) - (b.constructor.order ?? 100),
    );
  }

  /** Start the render loop. */
  start() {
    if (this.running) return this;
    this.running = true;
    this._clock = new THREE.Clock();
    this.renderer.setAnimationLoop(this._tick);
    return this;
  }

  /** Stop the render loop. */
  stop() {
    this.running = false;
    this.renderer.setAnimationLoop(null);
    return this;
  }

  /** @private one frame */
  _tick() {
    const dt = Math.min(MAX_DT, this._clock.getDelta());
    const ctx = this.ctx;
    ctx.time += dt;
    const time = ctx.time;

    this.wind.update(dt, time);
    this.iso.update(dt);
    this.terrain.update();

    const elements = this.elements();
    for (const el of elements) el.update(dt, time);

    // Tell elements about layers that changed this frame.
    for (const layer of this.layers.all()) {
      if (this._lastVersions.get(layer.id) !== layer.version) {
        this._lastVersions.set(layer.id, layer.version);
        for (const el of elements) el.onLayerChanged(layer);
      }
    }
    if (this.terrain.version !== this._lastTerrainVersion) {
      this._lastTerrainVersion = this.terrain.version;
      for (const el of elements) el.onTerrainChanged();
    }

    // History needs the dirty rects before commitAll() clears them.
    for (const layer of this.layers.all()) {
      if (layer.dirtyRect) this.history.noteDirty(layer, layer.dirtyRect);
    }

    this.layers.commitAll();
    this.sun.update();

    for (const hook of this.onFrame) hook(dt, time);

    this.renderOnce();
    this.frame++;
  }

  /** @returns {object} full world snapshot */
  toJSON() {
    const elements = {};
    for (const [id, el] of this.ctx.elements) {
      const data = el.serialize();
      if (data) elements[id] = data;
    }
    return {
      layers: this.layers.serialize(),
      elements,
      camera: this.iso.serialize(),
      sun: this.sun.serialize(),
      wind: this.wind.serialize(),
      style: this.style.current,
    };
  }

  /**
   * @param {object} json output of `toJSON()`
   */
  fromJSON(json = {}) {
    // Style first: it rewrites shaders and repaints the palette, so anything
    // restored after it (sun colours, element colours) wins over the palette.
    if (json.style) this.style.set(json.style);
    if (json.layers) this.layers.deserialize(json.layers);
    if (json.camera) this.iso.deserialize(json.camera);
    if (json.sun) this.sun.deserialize(json.sun);
    if (json.wind) this.wind.deserialize(json.wind);
    for (const [id, data] of Object.entries(json.elements || {})) {
      this.ctx.elements.get(id)?.deserialize(data);
    }
    this.terrain.applyHeightToGeometry();
    return this;
  }

  dispose() {
    this.stop();
    window.removeEventListener('resize', this._onResize);
    for (const el of this.ctx.elements.values()) el.dispose();
    this.brush.dispose();
    this.history.dispose();
    this.terrain.dispose();
    this.postfx?.dispose();
    this.sky.geometry.dispose();
    this.sky.material.dispose();
    this.layers.dispose();
    this.renderer.dispose();
  }
}
