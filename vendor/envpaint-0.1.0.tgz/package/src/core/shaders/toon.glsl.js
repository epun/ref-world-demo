/**
 * Shared GLSL chunks for the Ghibli cel-shaded look.
 *
 * Usage in a ShaderMaterial (lights: true, uniforms merged with
 * THREE.UniformsLib.lights, toneMapped: false):
 *
 *   vertexShader:   toonParsVertex + noiseGLSL + 'void main(){ ... ' + toonShadowVertex + '}'
 *   fragmentShader: toonParsFragment + 'void main(){ ... }'
 *
 * IMPORTANT: `toonParsFragment` already includes `noiseGLSL` (toonLight needs
 * fbm and hash21 for its painterly grain). Fragment shaders must NOT add
 * `noiseGLSL` again — doing so redefines every hash/noise function and the wind
 * uniforms, and the shader fails to compile. Vertex shaders still add it
 * themselves when they need wind or noise.
 *
 * `noiseGLSL` declares the wind uniforms (uWindDir/uWindStrength/uWindSpeed/
 * uGust/uTime), so every toon material MUST spread `wind.uniforms` into its own
 * uniforms — fragment shaders included, since toonParsFragment pulls noiseGLSL
 * in. It deliberately contains no `#include` directives so it can be dropped
 * into a vertex *or* fragment shader without redefining three's chunks.
 *
 * Materials must also spread `sun.uniforms`, which carries the sun/sky colours
 * and the six look controls (uShadowTint, uBandEdge, uBandSoft, uHalfTone,
 * uRim, uGrain).
 *
 * The lighting half of `toonParsFragment` is bracketed by STYLE_START /
 * STYLE_END; `src/core/Style.js` swaps that block for another style's
 * `lightingGLSL`. Register every toon material with `ctx.style.attach()` right
 * after building it so it takes part in style switching.
 */

/** hash/value-noise/fbm + the shared wind field. Safe in vertex and fragment shaders. */
export const noiseGLSL = /* glsl */ `
// --- wind uniforms (a material including noiseGLSL must supply wind.uniforms) ---
uniform vec2  uWindDir;
uniform float uWindStrength;
uniform float uWindSpeed;
uniform float uGust;
uniform float uTime;

// hash<inputDims><outputDims>: sine-free, integer-ish bit mixing on floats.
float hash11(float p) {
  p = fract(p * 0.1031);
  p *= p + 33.33;
  p *= p + p;
  return fract(p);
}

float hash21(vec2 p) {
  vec3 p3 = fract(p.xyx * 0.1031);
  p3 += dot(p3, p3.yzx + 33.33);
  return fract((p3.x + p3.y) * p3.z);
}

float hash31(vec3 p) {
  vec3 p3 = fract(p * 0.1031);
  p3 += dot(p3, p3.zyx + 31.32);
  return fract((p3.x + p3.y) * p3.z);
}

// Value noise, 0..1, smoothstep interpolation.
float vnoise(vec2 p) {
  vec2 i = floor(p);
  vec2 f = fract(p);
  vec2 u = f * f * (3.0 - 2.0 * f);
  float a = hash21(i);
  float b = hash21(i + vec2(1.0, 0.0));
  float c = hash21(i + vec2(0.0, 1.0));
  float d = hash21(i + vec2(1.0, 1.0));
  return mix(mix(a, b, u.x), mix(c, d, u.x), u.y);
}

// Fractal sum of vnoise, roughly 0..1. Up to 5 octaves.
float fbm(vec2 p, int octaves) {
  float v = 0.0;
  float amp = 0.5;
  vec2 q = p;
  for (int i = 0; i < 5; i++) {
    if (i >= octaves) break;
    v += amp * vnoise(q);
    q = q * 2.02 + 17.0;
    amp *= 0.5;
  }
  return v;
}

// Wind push in world XZ, magnitude roughly 0..1 scaled by uWindStrength.
// Wind force at a ground point for wind-time t (seconds x uWindSpeed).
// Gusts are cells stretched 3-4x ALONG the wind that race downwind at about
// 9 u/s, sharpened into fronts with calm patches between them, with a fast
// cat's-paw ripple riding on top: what makes a field read as blown rather
// than breathing in place. Keep Wind.sampleAt() (the CPU mirror) identical.
vec2 windAtT(vec2 p, float t) {
  vec2 perp = vec2(-uWindDir.y, uWindDir.x);
  float along = dot(p, uWindDir);
  float across = dot(p, perp);
  float g = fbm(vec2(along * 0.07 - t * 0.7, across * 0.4 + 3.1), 3);
  g = smoothstep(0.30, 0.62, g * 1.15);
  float wave = sin(along * 0.55 - t * 3.6) * 0.5 + 0.5;
  wave *= wave;
  float m = uWindStrength * (0.18 + 0.82 * g) * (0.75 + 0.5 * wave * g) * (0.6 + 0.8 * uGust);
  return uWindDir * m;
}

vec2 windAt(vec2 p) {
  return windAtT(p, uTime * uWindSpeed);
}
`;

/** Vertex shader preamble: three's shadow plumbing + the shared varyings. */
export const toonParsVertex = /* glsl */ `
#include <common>
#include <shadowmap_pars_vertex>

varying vec3 vWorldPos;
varying vec3 vNormalW;
`;

/**
 * Tail of a vertex main(). Expects `vec4 worldPosition` and
 * `vec3 transformedNormal` (view space) to already exist.
 */
export const toonShadowVertex = /* glsl */ `
  vWorldPos = worldPosition.xyz;
  vNormalW = normalize(inverseTransformDirection(transformedNormal, viewMatrix));
  vec4 mvPosition = viewMatrix * worldPosition;
  gl_Position = projectionMatrix * mvPosition;
  #include <shadowmap_vertex>
`;

/**
 * The Style system rewrites everything between these two markers in a
 * material's `fragmentShader`, so a swapped-in block must redeclare
 * `toonRamp`, `toonShadowColor` and `toonLight` with the same signatures.
 * `toonShadow()`, the varyings, the sun uniforms and `noiseGLSL` deliberately
 * live OUTSIDE the markers, so every style can call them.
 */
export const STYLE_START = '/*<style>*/';
export const STYLE_END = '/*</style>*/';

/**
 * The DEFAULT style's lighting block: everything the Style system swaps out.
 * It is emitted between the `/*<style>*\/` … `/*</style>*\/` markers inside
 * `toonParsFragment`, and every replacement block must declare the same three
 * functions with the same signatures.
 */
export const ghibliLightingGLSL = /* glsl */ `
// --- cel look controls (live on sun.uniforms) ---
uniform vec3  uShadowTint;   // cool violet-blue multiplier, linear
uniform float uBandEdge;     // n.l where lit flips to shadow
uniform float uBandSoft;     // terminator softness
uniform float uHalfTone;     // strength of the thin mid band, 0 = off
uniform float uRim;          // silhouette edge light
uniform float uGrain;        // painterly wobble multiplier

// 0 = shadow, 1 = lit, with a thin half-tone plateau just past the terminator.
// bands <= 1.5 gives a pure two-tone; > 1.5 enables the half-tone.
// soft is kept for call compatibility; uBandSoft drives the terminator.
float toonRamp(float ndl, float bands, float soft) {
  float e = uBandEdge;
  float lit = smoothstep(e - uBandSoft, e + uBandSoft, ndl);
  float mid = smoothstep(e + 0.10 - uBandSoft, e + 0.10 + uBandSoft, ndl);
  return mix(lit, mix(lit * 0.5 + 0.5 * mid, lit, 1.0 - uHalfTone), step(1.5, bands));
}

// The flat colour a surface takes in shadow: hue-shifted cool, not just darker.
vec3 toonShadowColor(vec3 albedo, vec3 n) {
  vec3 s = albedo * uShadowTint;
  // Keep saturation up by pulling slightly away from grey.
  float l = dot(s, vec3(0.2126, 0.7152, 0.0722));
  s = mix(vec3(l), s, 1.08);
  s += uSkyColor * 0.06 * clamp(n.y, 0.0, 1.0);
  // Brush texture on the shadow side, so the flat tone reads as painted.
  s *= 1.0 + 0.07 * (fbm(vWorldPos.xz * 6.0, 2) - 0.5);
  return s;
}

// Two flat tones, a hard rim on the shadow side, and a painterly grain.
vec3 toonLight(vec3 albedo, vec3 n, float shadow, float bands) {
  float ndl = dot(n, uSunDir);
  // Painted terminator: the band edge follows the brush a little, not the maths.
  ndl += (fbm(vWorldPos.xz * 2.0 + vWorldPos.y, 2) - 0.5) * 0.12;
  float lit = toonRamp(ndl, bands, uBandSoft) * shadow;
  gToonLit = lit;

  vec3 shade = toonShadowColor(albedo, n);
  vec3 sunlit = albedo * uSunColor * 1.05;
  vec3 col = mix(shade, sunlit, lit);

  // Rim: silhouette edge on the shadow side, sun-coloured, hard-stepped.
  vec3 viewDir = normalize(cameraPosition - vWorldPos);
  float fres = 1.0 - max(dot(n, viewDir), 0.0);
  float rim = smoothstep(0.62, 0.70, fres) * (1.0 - lit) * uRim;
  col += uSunColor * rim;

  // Painterly grain: low-frequency wobble + fine grain, world-space so it
  // stays put when the camera moves.
  float wob = fbm(vWorldPos.xz * 0.9 + vWorldPos.y * 0.3, 2) - 0.5;
  float fine = hash21(floor(vWorldPos.xz * 60.0)) - 0.5;
  col *= 1.0 + uGrain * (0.08 * wob + 0.03 * fine);

  return col;
}
`;

/**
 * Fragment shader preamble: shadow receive, the noise library, and the
 * two-tone cel lighting model. Do not add noiseGLSL after this.
 */
export const toonParsFragment = /* glsl */ `
#include <common>
#include <packing>
#include <lights_pars_begin>
#include <shadowmap_pars_fragment>

varying vec3 vWorldPos;
varying vec3 vNormalW;

uniform vec3 uSunDir;
uniform vec3 uSunColor;
uniform vec3 uSkyColor;
uniform vec3 uGroundColor;

${noiseGLSL}

// 1.0 = lit, 0.0 = fully shadowed by the sun's shadow map.
float toonShadow() {
  float s = 1.0;
  #if defined( USE_SHADOWMAP ) && NUM_DIR_LIGHT_SHADOWS > 0
    DirectionalLightShadow d = directionalLightShadows[ 0 ];
    s = getShadow(
      directionalShadowMap[ 0 ],
      d.shadowMapSize,
      d.shadowIntensity,
      d.shadowBias,
      d.shadowRadius,
      vDirectionalShadowCoord[ 0 ]
    );
  #endif
  return s;
}

// How lit the last toonLight() call found the surface, 0 = in shade, 1 = in
// sun. Materials read it after lighting to pick their ink-mask alpha (see
// toonInkAlpha): hatching belongs on the shade side, never on a lit face.
float gToonLit = 1.0;

// Ink-mask alpha for an opaque cel material: 1.0 in shade (outline, hatch
// and pooling), 0.75 in the sun (outline and pooling, no hatch).
float toonInkAlpha() {
  return gToonLit > 0.5 ? 0.75 : 1.0;
}
${STYLE_START}
${ghibliLightingGLSL}
${STYLE_END}
`;
