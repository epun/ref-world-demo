/**
 * GLSL chunks shared by the water surface, the ripple simulation and the
 * waterfall sheet.
 *
 * `waterCommonGLSL` builds on `noiseGLSL` from `toon.glsl.js` (it uses
 * `hash21` and `fbm`), so include `noiseGLSL` before it in any shader.
 */
import {
  noiseGLSL,
  toonParsVertex,
  toonShadowVertex,
  toonParsFragment,
} from './toon.glsl.js';

/** Voronoi cells + flow-aligned streak noise. Requires `noiseGLSL`. */
export const waterCommonGLSL = /* glsl */ `
// Two nearest feature-point distances of a jittered grid (Worley / Voronoi).
// x = F1, y = F2; F2 - F1 is small exactly on a cell border.
vec2 voronoiF1F2(vec2 p) {
  vec2 n = floor(p);
  vec2 f = fract(p);
  float f1 = 8.0;
  float f2 = 8.0;
  for (int j = -1; j <= 1; j++) {
    for (int i = -1; i <= 1; i++) {
      vec2 g = vec2(float(i), float(j));
      vec2 c = n + g;
      vec2 o = vec2(hash21(c), hash21(c + 41.7));
      float d = length(g + o - f);
      if (d < f1) {
        f2 = f1;
        f1 = d;
      } else if (d < f2) {
        f2 = d;
      }
    }
  }
  return vec2(f1, f2);
}

// White cell-border web: 1 on the borders, 0 inside a cell.
float voronoiWeb(vec2 p, float thickness) {
  vec2 c = voronoiF1F2(p);
  float edge = c.y - c.x;
  return 1.0 - smoothstep(thickness * 0.35, thickness, edge);
}

// Value noise sampled in a frame aligned with the flow: the across-flow axis
// is stretched so features come out long along the flow and thin across it.
float flowStreaks(vec2 p, vec2 dir, float drift, float scale, float stretch) {
  vec2 perp = vec2(-dir.y, dir.x);
  vec2 q = vec2(dot(p, dir) - drift, dot(p, perp) * stretch);
  return fbm(q * scale, 3);
}
`;

/** Vertex shader for the full-screen simulation quad (PlaneGeometry(2, 2)). */
export const fullscreenVertex = /* glsl */ `
varying vec2 vUv;
void main() {
  vUv = uv;
  gl_Position = vec4(position.xy, 0.0, 1.0);
}
`;

/**
 * Height-field ripple step. RGBA half float:
 * R = height, G = velocity, B = laplacian (foam term for the surface shader).
 */
export const rippleSimFragment = /* glsl */ `
precision highp float;
${noiseGLSL}

uniform sampler2D uPrev;
uniform sampler2D uWaterTex;
uniform vec2 uTexel;
uniform float uStiffness;
uniform float uDamping;
uniform float uWindWaves;
uniform int uImpactCount;
uniform vec4 uImpacts[16];   // xy = uv, z = uv radius, w = strength

varying vec2 vUv;

void main() {
  vec4 c = texture2D(uPrev, vUv);
  float h = c.r;
  float v = c.g;
  float w = texture2D(uWaterTex, vUv).r;

  float l = texture2D(uPrev, vUv - vec2(uTexel.x, 0.0)).r;
  float r = texture2D(uPrev, vUv + vec2(uTexel.x, 0.0)).r;
  float d = texture2D(uPrev, vUv - vec2(0.0, uTexel.y)).r;
  float u = texture2D(uPrev, vUv + vec2(0.0, uTexel.y)).r;

  float lap = (l + r + u + d) * 0.25 - h;
  v += lap * uStiffness;

  // Wind chop: a travelling noise field pushes the surface where there is water,
  // so a strong wind builds waves that drift downwind and calm when it drops.
  v += uWindWaves * uWindStrength * 0.004
     * (vnoise(vUv * 40.0 + uWindDir * uTime * 1.5) - 0.5)
     * step(0.3, w);

  v *= uDamping;
  h += v;

  for (int i = 0; i < 16; i++) {
    if (i >= uImpactCount) break;
    vec4 im = uImpacts[i];
    float rad = max(im.z, 0.0015);
    float dist = length(vUv - im.xy);
    float g = exp(-(dist * dist) / (rad * rad));
    h -= g * im.w;
  }

  // Waves die on the shore and outside the painted water.
  float m = mix(0.35, 1.0, smoothstep(0.1, 0.45, w));
  h *= m;
  v *= m;

  h = clamp(h, -1.0, 1.0);
  v = clamp(v, -1.0, 1.0);
  gl_FragColor = vec4(h, v, lap, 1.0);
}
`;

/** Waterfall droplet Points: constant-size round dots (orthographic camera). */
export const dropletVertex = /* glsl */ `
#include <common>
#include <fog_pars_vertex>

uniform float uPointScale;   // framebuffer pixels per world unit
uniform float uSize;         // droplet diameter in world units

void main() {
  vec4 worldPosition = modelMatrix * vec4(position, 1.0);
  vec4 mvPosition = viewMatrix * worldPosition;
  gl_Position = projectionMatrix * mvPosition;
  gl_PointSize = clamp(uSize * uPointScale, 1.0, 32.0);
  #include <fog_vertex>
}
`;

/** Waterfall droplet Points fragment: flat colour, hard round edge. */
export const dropletFragment = /* glsl */ `
#include <common>
#include <fog_pars_fragment>

uniform vec3 uColor;
uniform float uOpacity;

void main() {
  vec2 d = gl_PointCoord - 0.5;
  if (dot(d, d) > 0.25) discard;
  gl_FragColor = vec4(uColor, uOpacity);
  #include <fog_fragment>
  #include <colorspace_fragment>
}
`;

/** Foam blob quads at a waterfall's base: bobbing, hard wobbly alpha edge. */
export const foamBlobVertex = /* glsl */ `
#include <common>
#include <fog_pars_vertex>
${noiseGLSL}

attribute float aPhase;
varying vec2 vUv;
varying float vPhase;

void main() {
  vUv = uv;
  vPhase = aPhase;
  vec3 pos = position;
  pos.y += sin(uTime * 0.9 + aPhase * 6.2831) * 0.06;
  vec4 worldPosition = modelMatrix * vec4(pos, 1.0);
  vec4 mvPosition = viewMatrix * worldPosition;
  gl_Position = projectionMatrix * mvPosition;
  #include <fog_vertex>
}
`;

/** Foam blob fragment: rounded white blob, no soft edge at all. */
export const foamBlobFragment = /* glsl */ `
#include <common>
#include <fog_pars_fragment>
${noiseGLSL}

uniform vec3 uFoamColor;
uniform vec3 uFoamShade;
uniform float uOpacity;

varying vec2 vUv;
varying float vPhase;

void main() {
  vec2 d = vUv * 2.0 - 1.0;
  float r = length(d);
  // Big, round and hard-edged: a painted cumulus puff, not a noisy blob.
  float wob = fbm(d * 1.4 + vec2(uTime * 0.25 + vPhase * 5.0), 2);
  float edge = 0.74 + 0.14 * wob;
  if (r > edge) discard;
  vec3 col = mix(uFoamColor, uFoamShade, step(edge - 0.16, r));
  gl_FragColor = vec4(col, uOpacity);
  #include <fog_fragment>
  #include <colorspace_fragment>
}
`;

/**
 * Waterfall sheet + lip. One mesh: rows with `aLip == 1` are the rounded cap
 * that curls over the edge, the rest is the ribbon falling to the plunge pool.
 * Uses the shared toon lighting, so the Style system can swap its block.
 */
export const sheetVertex = /* glsl */ `
${toonParsVertex}
#include <fog_pars_vertex>
${noiseGLSL}

attribute float aAlong;
attribute float aAcross;
attribute float aLip;
attribute float aDown;

varying float vAlong;
varying float vAcross;
varying float vLip;
varying float vDown;

void main() {
  vAlong = aAlong;
  vAcross = aAcross;
  vLip = aLip;
  vDown = aDown;

  // The sheet breathes sideways a little, like a hand-inked cel that is redrawn
  // every few frames; the lip stays put so the cap never tears off the edge.
  vec3 pos = position;
  float sway = sin(uTime * 1.6 + aAlong * 3.0) * 0.03 * aAlong * (1.0 - aLip);
  pos.x += sway;
  pos.z += sway;

  vec4 worldPosition = modelMatrix * vec4(pos, 1.0);
  vec3 transformedNormal = normalMatrix * normal;
  ${toonShadowVertex}
  #include <fog_vertex>
}
`;

/**
 * Waterfall sheet fragment: a near-white body with a handful of pale-blue
 * streaks and a few thin mid-blue lines scrolling down, brighter at the foot.
 */
export const sheetFragment = /* glsl */ `
${toonParsFragment}
#include <fog_pars_fragment>

uniform vec3 uBody;
uniform vec3 uStreak;
uniform vec3 uLine;
uniform vec3 uLipColor;
uniform float uScroll;
uniform float uStreaks;
uniform float uStyleId;

varying float vAlong;
varying float vAcross;
varying float vLip;
varying float vDown;

void main() {
  float across01 = vAcross * 0.5 + 0.5;
  // Distance travelled down the sheet, scrolling with the water.
  float down = vDown - uTime * uScroll;

  // Wobbly silhouette: the ribbon's own edge is never a clean straight line.
  float rim = 0.94 + (fbm(vec2(down * 0.6, 11.0), 2) - 0.5) * 0.16;
  if (vLip < 0.5 && abs(vAcross) > rim) discard;

  float wob = fbm(vec2(down * 0.55, across01 * 3.2), 2) - 0.5;
  float q = across01 * uStreaks + wob * 0.9;
  float band = floor(q);
  float f = fract(q) - 0.5;
  float r1 = hash21(vec2(band, 7.0));
  // Streaks are long segments that travel down rather than infinite lines.
  float seg = fbm(vec2(down * 0.22 + r1 * 10.0, band * 3.7), 2) * 1.3333;
  float pale = step(abs(f), 0.13 + 0.13 * r1) * step(0.38, seg);
  float thin = step(abs(fract(q + 0.42 + r1 * 0.4) - 0.5), 0.045) * step(0.44, seg);

  vec3 col = uBody;
  if (uStyleId > 1.5 && uStyleId < 2.5) {
    // REALISTIC — a smooth blue-to-white wash, streaks as soft gradients.
    col = mix(uStreak, uBody, smoothstep(0.0, 0.9, vAlong));
    col = mix(col, uBody, smoothstep(0.0, 0.25, abs(f) * -1.0 + 0.25) * 0.6);
    col += uBody * pow(1.0 - abs(vAcross), 2.0) * 0.12;
  } else if (uStyleId > 2.5 && uStyleId < 3.5) {
    // PAINTERLY — the same streaks, dabbed on with a soft edge.
    col = mix(col, uStreak, smoothstep(0.20, 0.02, abs(f)) * step(0.38, seg));
    col = mix(col, uLine, thin * 0.7);
  } else if (uStyleId > 3.5) {
    // PIXEL — a few hard columns, two inks and white.
    float cq = floor(across01 * 7.0 + wob * 0.5);
    float pr = hash21(vec2(cq, floor(down * 1.5)));
    col = mix(uBody, uStreak, step(0.45, pr));
    col = mix(col, uLine, step(0.86, pr));
  } else {
    // GHIBLI and FLAT — flat white body, hard-edged streaks and hairlines.
    col = mix(col, uStreak, pale);
    if (uStyleId < 0.5) col = mix(col, uLine, thin);
  }
  // Brighter toward the bottom, where the fall breaks up into spray.
  col = mix(col, vec3(1.0), smoothstep(0.55, 1.0, vAlong) * 0.35);

  if (vLip > 0.5) {
    // The curling lip: lighter blue with one white highlight along the crest.
    col = uLipColor;
    col = mix(col, vec3(1.0), step(0.80, -vAlong));
  }

  vec3 n = normalize(vNormalW);
  if (!gl_FrontFacing) n = -n;
  // The column is lit from above whichever way the cliff faces, so it stays a
  // bright white shape; the realistic style keeps most of the real normal.
  float flatten = (uStyleId > 1.5 && uStyleId < 2.5) ? 0.25 : 0.75;
  n = normalize(mix(n, vec3(0.0, 1.0, 0.0), flatten));
  vec3 lit = toonLight(col, n, toonShadow(), 2.0);

  gl_FragColor = vec4(lit, 1.0);
  #include <fog_fragment>
  #include <colorspace_fragment>
}
`;

/** Big cumulus mist puffs at the foot of a fall: camera-facing, bobbing quads. */
export const mistPuffVertex = /* glsl */ `
#include <common>
#include <fog_pars_vertex>
${noiseGLSL}

attribute vec3 aCenter;
attribute vec2 aCorner;
attribute float aSize;
attribute float aPhase;

varying vec2 vCorner;
varying float vPhase;

void main() {
  vCorner = aCorner;
  vPhase = aPhase;

  vec3 c = aCenter;
  c.y += sin(uTime * 0.7 + aPhase * 6.2831) * 0.16;
  vec2 w = windAt(c.xz);
  // Drifting, not flying away: the puffs lean downwind and come back.
  c.xz += w * 0.5 * (0.55 + 0.45 * sin(uTime * 0.45 + aPhase * 4.0));

  vec4 worldPosition = modelMatrix * vec4(c, 1.0);
  vec4 mvPosition = viewMatrix * worldPosition;
  mvPosition.xy += aCorner * aSize;
  gl_Position = projectionMatrix * mvPosition;
  #include <fog_vertex>
}
`;

/** Mist puff fragment: three rounded lobes, hard edge, cool grey underside. */
export const mistPuffFragment = /* glsl */ `
#include <common>
#include <fog_pars_fragment>
${noiseGLSL}

uniform vec3 uMist;
uniform vec3 uMistShade;
uniform float uStyleId;

varying vec2 vCorner;
varying float vPhase;

// Largest of three overlapping lobes: a painted cumulus silhouette.
float cumulus(vec2 d) {
  float m = 1.0 - length((d - vec2(-0.40, -0.16)) / vec2(0.60, 0.52));
  m = max(m, 1.0 - length((d - vec2(0.36, -0.22)) / vec2(0.62, 0.48)));
  m = max(m, 1.0 - length((d - vec2(0.00, 0.20)) / vec2(0.70, 0.72)));
  return m;
}

void main() {
  vec2 d = vCorner;
  float wob = (fbm(d * 1.6 + vec2(uTime * 0.2 + vPhase * 5.0), 2) - 0.5) * 0.10;
  float m = cumulus(d) + wob;
  if (m < 0.0) discard;

  float under = step(-0.12 + wob * 0.6, d.y);
  vec3 col = mix(uMistShade, uMist, under);
  if (uStyleId > 1.5 && uStyleId < 2.5) {
    // REALISTIC — a smooth vertical falloff instead of one cel step.
    col = mix(uMistShade, uMist, smoothstep(-0.6, 0.4, d.y));
  }

  gl_FragColor = vec4(col, 1.0);
  #include <fog_fragment>
  #include <colorspace_fragment>
}
`;

/** The thin sheet of rising mist that hugs the cliff behind the puffs. */
export const mistSheetVertex = /* glsl */ `
#include <common>
#include <fog_pars_vertex>

varying vec2 vUv;

void main() {
  vUv = uv;
  vec4 worldPosition = modelMatrix * vec4(position, 1.0);
  vec4 mvPosition = viewMatrix * worldPosition;
  gl_Position = projectionMatrix * mvPosition;
  #include <fog_vertex>
}
`;

/** Rising mist fragment: soft noise climbing the cliff, faint and ink-exempt. */
export const mistSheetFragment = /* glsl */ `
#include <common>
#include <fog_pars_fragment>
${noiseGLSL}

uniform vec3 uMist;
uniform float uOpacity;

varying vec2 vUv;

void main() {
  float n = fbm(vec2(vUv.x * 3.2, vUv.y * 2.2 - uTime * 0.32), 3) * 1.6;
  float mask = smoothstep(0.42, 0.9, n)
    * smoothstep(0.0, 0.22, vUv.y)
    * (1.0 - smoothstep(0.35, 1.0, vUv.y))
    * (1.0 - smoothstep(0.55, 1.0, abs(vUv.x * 2.0 - 1.0)));
  if (mask < 0.02) discard;
  gl_FragColor = vec4(uMist, mask * uOpacity);
  #include <fog_fragment>
  #include <colorspace_fragment>
}
`;
