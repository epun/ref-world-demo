/**
 * The core's entire dependency on the DOM: one predicate, no module-level
 * access to `document` or `window`. Kept here rather than in `IsoCamera.js` so
 * `core/index.js` (and everything it pulls in) stays importable in Node.
 */

/**
 * @param {EventTarget|null} [el]
 * @returns {boolean} true if a text field currently owns the keyboard
 */
export function isTyping(el) {
  const node = /** @type {HTMLElement|null} */ (el);
  if (!node || !node.tagName) return false;
  const tag = node.tagName.toLowerCase();
  return tag === 'input' || tag === 'textarea' || tag === 'select' || node.isContentEditable === true;
}
