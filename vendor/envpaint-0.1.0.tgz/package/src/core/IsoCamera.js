import * as THREE from 'three';
import { isTyping } from './dom.js';

/** True isometric pitch: atan(1/sqrt(2)) ≈ 35.264°. The default, and what Reset view restores. */
export const ISO_PITCH = Math.atan(1 / Math.SQRT2);
/** Lowest the camera may tip toward the horizon while orbiting (18°). */
export const MIN_PITCH = (18 * Math.PI) / 180;
/** Highest the camera may climb toward straight down while orbiting (70°). */
export const MAX_PITCH = (70 * Math.PI) / 180;

/** Radians of rotation per pixel of orbit drag. */
const ORBIT_RATE = 0.006;
/** Time constant (seconds) of the damped chase toward the yaw/pitch goal. */
const SMOOTH_TAU = 0.09;
/** Yaw of the first 90° snap mark; marks sit at YAW_BASE + k * QUARTER. */
const YAW_BASE = Math.PI / 4;
const QUARTER = Math.PI / 2;
const GROUND = new THREE.Plane(new THREE.Vector3(0, 1, 0), 0);

/**
 * Orthographic isometric rig: pan on the ground plane, zoom by frustum height,
 * free-orbit with Shift + left drag, and snap the view back to 90° marks with
 * Q/E. Yaw and pitch are continuous angles; the projection stays orthographic
 * at every one of them.
 */
export class IsoCamera {
  /**
   * @param {HTMLCanvasElement} canvas the renderer's canvas (owns the input)
   * @param {number} width
   * @param {number} height
   */
  constructor(canvas, width, height) {
    /** @type {HTMLCanvasElement} */
    this.canvas = canvas;

    /** @type {THREE.Vector3} the ground point the camera looks at */
    this.target = new THREE.Vector3(0, 0, 0);
    /** @type {number} half of the vertical view extent, in world units */
    this.frustumHalfHeight = 14;
    /** @type {number} min zoom (closest) */
    this.minHalfHeight = 4;
    /** @type {number} max zoom (widest) */
    this.maxHalfHeight = 40;
    /** @type {number} how far the camera sits back along the view direction */
    this.distance = 80;
    /** @type {number} current yaw in radians, free (animates toward the goal) */
    this.yaw = YAW_BASE;
    /** @type {number} current pitch in radians, clamped to [MIN_PITCH, MAX_PITCH] */
    this.pitch = ISO_PITCH;
    /** @type {boolean} true while a pan drag is in progress */
    this.isPanning = false;
    /** @type {boolean} true while an orbit (Shift + left) drag is in progress */
    this.isOrbiting = false;
    /** @type {boolean} true while the space bar is held */
    this.spaceDown = false;

    this._aspect = width / height;
    this._yawGoal = this.yaw;
    this._pitchGoal = this.pitch;
    this._pointerId = null;
    this._lastX = 0;
    this._lastY = 0;
    this._raycaster = new THREE.Raycaster();

    this.camera = new THREE.OrthographicCamera(-1, 1, 1, -1, 0.1, 300);
    this.camera.up.set(0, 1, 0);
    this.resize(width, height);
    this._apply();
    this._bind();
  }

  /**
   * @private
   * @param {number} index
   * @returns {number} radians
   */
  _yawFor(index) {
    return YAW_BASE + index * QUARTER;
  }

  /**
   * The 90° mark nearest the current yaw goal, 0..3. Derived — the view is a
   * free angle now, so nothing may assume the camera sits on one of these.
   * @returns {number}
   */
  get yawIndex() {
    return ((Math.round((this._yawGoal - YAW_BASE) / QUARTER) % 4) + 4) % 4;
  }

  /** @param {number} index */
  set yawIndex(index) {
    this.setYawIndex(index);
  }

  /** @returns {number} the yaw the view is animating toward, in radians */
  get yawGoal() {
    return this._yawGoal;
  }

  /** @returns {number} the pitch the view is animating toward, in radians */
  get pitchGoal() {
    return this._pitchGoal;
  }

  /**
   * Update the projection for a new canvas size.
   * @param {number} width
   * @param {number} height
   */
  resize(width, height) {
    this._aspect = width / Math.max(1, height);
    this._apply();
  }

  /**
   * Snap the view by whole 90° steps, animated, measured from the 90° mark
   * nearest the current (possibly free) yaw — so one press after an orbit
   * lands on a clean isometric angle. Pitch is left alone.
   * @param {number} steps usually +1 or -1
   */
  rotate(steps) {
    const nearest = Math.round((this._yawGoal - YAW_BASE) / QUARTER);
    this._yawGoal = this._yawFor(nearest + steps);
    return this;
  }

  /**
   * Snap to one of the four isometric marks and restore the default pitch.
   * This is what "Reset view" calls.
   * @param {number} index 0..3
   */
  setYawIndex(index) {
    this._yawGoal = this._yawFor(Math.round(index));
    this._pitchGoal = ISO_PITCH;
    return this;
  }

  /**
   * Set the orbit angles directly (no animation). Pitch is clamped.
   * @param {number} yaw radians
   * @param {number} [pitch] radians, default unchanged
   */
  setYawPitch(yaw, pitch = this._pitchGoal) {
    this._yawGoal = yaw;
    this._pitchGoal = clampPitch(pitch);
    this.yaw = this._yawGoal;
    this.pitch = this._pitchGoal;
    this._apply();
    return this;
  }

  /**
   * Orbit by a screen-space drag delta in pixels. The world follows the
   * pointer: drag right and the scene turns right, drag down and the camera
   * climbs toward a top-down view. Writes the animation goal, so the view
   * chases the pointer with the same damping a Q/E snap uses.
   * @param {number} dx
   * @param {number} dy
   */
  orbit(dx, dy) {
    this._yawGoal -= dx * ORBIT_RATE;
    this._pitchGoal = clampPitch(this._pitchGoal + dy * ORBIT_RATE);
    return this;
  }

  /**
   * @param {number} halfHeight clamped into the zoom range
   */
  setZoom(halfHeight) {
    this.frustumHalfHeight = Math.max(
      this.minHalfHeight,
      Math.min(this.maxHalfHeight, halfHeight),
    );
    this._apply();
  }

  /**
   * @param {number} dt seconds
   */
  update(dt) {
    const dYaw = this._yawGoal - this.yaw;
    const dPitch = this._pitchGoal - this.pitch;
    if (Math.abs(dYaw) < 1e-5 && Math.abs(dPitch) < 1e-5) {
      if (dYaw !== 0 || dPitch !== 0) {
        this.yaw = this._yawGoal;
        this.pitch = this._pitchGoal;
        this._apply();
      }
      return;
    }
    // Exponential chase: frame-rate independent, and a 90° step still settles
    // in about a third of a second.
    const k = 1 - Math.exp(-Math.max(0, dt) / SMOOTH_TAU);
    this.yaw += dYaw * k;
    this.pitch += dPitch * k;
    this._apply();
  }

  /**
   * The unit vector from the target toward the camera.
   * @param {THREE.Vector3} [out]
   * @returns {THREE.Vector3}
   */
  viewDir(out = new THREE.Vector3()) {
    const cp = Math.cos(this.pitch);
    return out.set(cp * Math.sin(this.yaw), Math.sin(this.pitch), cp * Math.cos(this.yaw));
  }

  /** @private Push target/zoom/yaw/pitch into the THREE camera. */
  _apply() {
    const h = this.frustumHalfHeight;
    const w = h * this._aspect;
    const cam = this.camera;
    cam.left = -w;
    cam.right = w;
    cam.top = h;
    cam.bottom = -h;
    cam.updateProjectionMatrix();
    const dir = this.viewDir();
    cam.position.copy(this.target).addScaledVector(dir, this.distance);
    cam.lookAt(this.target);
    cam.updateMatrixWorld();
  }

  /**
   * @private
   * @param {number} clientX
   * @param {number} clientY
   * @param {THREE.Vector3} [out]
   * @returns {THREE.Vector3|null} where the cursor ray meets y = 0
   */
  _groundUnderCursor(clientX, clientY, out = new THREE.Vector3()) {
    const rect = this.canvas.getBoundingClientRect();
    const ndc = new THREE.Vector2(
      ((clientX - rect.left) / rect.width) * 2 - 1,
      -((clientY - rect.top) / rect.height) * 2 + 1,
    );
    this._raycaster.setFromCamera(ndc, this.camera);
    return this._raycaster.ray.intersectPlane(GROUND, out);
  }

  /** @private */
  _bind() {
    const canvas = this.canvas;

    canvas.addEventListener('pointerdown', (e) => {
      // Pan wins over orbit: the middle button and Space are unambiguous.
      const isPan = e.button === 1 || (e.button === 0 && this.spaceDown);
      const isOrbit = !isPan && e.button === 0 && e.shiftKey;
      if (!isPan && !isOrbit) return;
      e.preventDefault();
      this.isPanning = isPan;
      this.isOrbiting = isOrbit;
      this._pointerId = e.pointerId;
      this._lastX = e.clientX;
      this._lastY = e.clientY;
      canvas.setPointerCapture(e.pointerId);
    });

    canvas.addEventListener('pointermove', (e) => {
      if ((!this.isPanning && !this.isOrbiting) || e.pointerId !== this._pointerId) return;
      const dx = e.clientX - this._lastX;
      const dy = e.clientY - this._lastY;
      this._lastX = e.clientX;
      this._lastY = e.clientY;
      if (this.isPanning) this._pan(dx, dy);
      else this.orbit(dx, dy);
    });

    const end = (e) => {
      if (e.pointerId !== this._pointerId) return;
      this.isPanning = false;
      this.isOrbiting = false;
      this._pointerId = null;
      if (canvas.hasPointerCapture(e.pointerId)) canvas.releasePointerCapture(e.pointerId);
    };
    canvas.addEventListener('pointerup', end);
    canvas.addEventListener('pointercancel', end);
    canvas.addEventListener('auxclick', (e) => {
      if (e.button === 1) e.preventDefault();
    });
    canvas.addEventListener('contextmenu', (e) => e.preventDefault());

    canvas.addEventListener(
      'wheel',
      (e) => {
        e.preventDefault();
        const before = this._groundUnderCursor(e.clientX, e.clientY, new THREE.Vector3());
        this.setZoom(this.frustumHalfHeight * Math.exp(e.deltaY * 0.0015));
        if (before) {
          const after = this._groundUnderCursor(e.clientX, e.clientY, new THREE.Vector3());
          if (after) {
            this.target.add(before.sub(after));
            this.target.y = 0;
            this._apply();
          }
        }
      },
      { passive: false },
    );

    window.addEventListener('keydown', (e) => {
      if (isTyping(e.target)) return;
      if (e.code === 'Space') {
        this.spaceDown = true;
        e.preventDefault();
        return;
      }
      if (e.repeat) return;
      if (e.code === 'KeyQ') this.rotate(-1);
      else if (e.code === 'KeyE') this.rotate(1);
    });
    window.addEventListener('keyup', (e) => {
      if (e.code === 'Space') this.spaceDown = false;
    });
    window.addEventListener('blur', () => {
      this.spaceDown = false;
      this.isPanning = false;
      this.isOrbiting = false;
    });
  }

  /**
   * @private Move the target by a screen-space delta in pixels.
   * @param {number} dx
   * @param {number} dy
   */
  _pan(dx, dy) {
    const rect = this.canvas.getBoundingClientRect();
    const worldPerPixel = (this.frustumHalfHeight * 2) / Math.max(1, rect.height);
    const s = Math.sin(this.yaw);
    const c = Math.cos(this.yaw);
    // Screen right and screen "up" (into the distance) projected onto the ground.
    const rightX = c;
    const rightZ = -s;
    const upX = -s;
    const upZ = -c;
    // The ground is foreshortened by the current pitch, not by the iso default.
    const foreshorten = Math.max(0.2, Math.sin(this.pitch));
    this.target.x -= rightX * dx * worldPerPixel;
    this.target.z -= rightZ * dx * worldPerPixel;
    this.target.x += (upX * dy * worldPerPixel) / foreshorten;
    this.target.z += (upZ * dy * worldPerPixel) / foreshorten;
    this._apply();
  }

  /** @returns {{target:number[], halfHeight:number, yaw:number, pitch:number, yawIndex:number}} */
  serialize() {
    return {
      target: this.target.toArray(),
      halfHeight: this.frustumHalfHeight,
      yaw: this._yawGoal,
      pitch: this._pitchGoal,
      // Kept so a file saved here still opens in a build that only knew 90° steps.
      yawIndex: this.yawIndex,
    };
  }

  /**
   * @param {{target?:number[], halfHeight?:number, yaw?:number, pitch?:number, yawIndex?:number}} o
   */
  deserialize(o = {}) {
    if (o.target) this.target.fromArray(o.target);
    if (typeof o.halfHeight === 'number') this.frustumHalfHeight = o.halfHeight;
    let yaw = null;
    let pitch = null;
    if (typeof o.yaw === 'number') yaw = o.yaw;
    else if (typeof o.yawIndex === 'number') yaw = this._yawFor(o.yawIndex & 3);
    if (typeof o.pitch === 'number') pitch = clampPitch(o.pitch);
    else if (yaw !== null) pitch = ISO_PITCH;
    if (yaw !== null) this.setYawPitch(yaw, pitch ?? this._pitchGoal);
    else this._apply();
  }
}

/**
 * @param {number} pitch radians
 * @returns {number} clamped into the orbit range
 */
export function clampPitch(pitch) {
  return Math.max(MIN_PITCH, Math.min(MAX_PITCH, pitch));
}

// `isTyping` lives in `core/dom.js` now (the core must not import the camera);
// re-exported here so every existing import site keeps working.
export { isTyping };
