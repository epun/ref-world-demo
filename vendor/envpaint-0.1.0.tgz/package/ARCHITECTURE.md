# EnvPaint — architecture & module contract

EnvPaint is a Three.js / WebGL environment painter. You paint directly on the
ground to place grass, water, rivers, rocks, trees, fire, smoke, clouds (with rain
and lightning), paths, mountains — and a *mask* that says where things must NOT
grow. The look is an isometric, Ghibli-flavoured toon shader. Everything reacts to
a global wind, and objects use real physics (rigid bodies, spring/soft bodies,
height-field water).

This document is the contract every module is written against. If you change an
interface here, change the doc first.

## Stack

| Piece | Choice |
|---|---|
| Bundler | Vite 5 (`npm run dev`, `npm run build`) — `resolve.dedupe: ['three']` |
| 3D | `three` r170, `WebGLRenderer` (WebGL2), GLSL `ShaderMaterial`s |
| Inspector UI | `ghost-panel` (installed from `github:epun/ghost-panel`) |
| Rigid bodies | `@dimforge/rapier3d-compat` (WASM inlined, `await RAPIER.init()`) |
| Tests | vitest (`npm test`) for pure logic; `scripts/screenshot.mjs` (Playwright + headless Chromium with SwiftShader) for visual smoke checks |

Plain ES modules, no framework, no TypeScript. JSDoc types on public APIs.

## Directory layout

```
index.html                 – single page; mounts #app canvas container
vite.config.js
src/
  main.js                  – bootstrap: creates App, registers Elements, starts loop
  core/
    index.js               – `envpaint/core` barrel: the portable, DOM-free half
    constants.js           – WORLD_SIZE, LAYER_RES, worldToUV(), uvToWorld()
    dom.js                 – isTyping(); the core's only DOM helper
    App.js                 – renderer, scene, camera rig, clock, resize, render loop, ctx object
    IsoCamera.js           – orthographic isometric camera + pan/zoom/90° rotate controls
    Sun.js                 – DirectionalLight + shadow + HemisphereLight + shared light uniforms
    Wind.js                – global wind state + uniforms + CPU sampler
    PaintLayers.js         – PaintLayer (CPU array + DataTexture + stamp()) and PaintLayers registry
    Brush.js               – pointer → terrain raycast → stamp on the active tool's layer; cursor ring
    Terrain.js             – ground mesh, height sculpting, toon ground shader
    Physics.js             – Rapier world wrapper, terrain height-field collider
    Element.js             – base class every environment element extends
    shaders/
      toon.glsl.js         – shared GLSL chunks (hash/noise/fbm, toon lighting, shadow receive)
  elements/
    index.js               – ordered list of all Element classes
    Grass.js  Water.js  Rocks.js  Trees.js  Fire.js  Smoke.js  Clouds.js  ...
  ui/
    index.js               – `envpaint/ui` barrel: createToolStrip, toolIcon, ERASER_ICON
    Panel.js               – ghost-panel setup: tool picker, brush settings, per-element folders, hotkeys
    Toolbar.js             – the floating tool strip (ghost-panel Toolbar)
scripts/
  screenshot.mjs           – headless render to PNG for visual checks
test/                      – vitest unit tests
```

## Package entry points

The repository is also a package other projects consume by commit hash
(`"envpaint": "git+https://github.com/epun/envpaint.git#<sha>"`). Three entry
points are declared in `package.json` `exports`; nothing else is importable
from outside, so everything not listed here is free to move.

| entry | file | types |
|---|---|---|
| `envpaint` | `src/main.js` | – (the app bootstrap; needs a DOM) |
| `envpaint/core` | `src/core/index.js` | `types/core.d.ts` |
| `envpaint/ui` | `src/ui/index.js` | `types/ui.d.ts` |

`envpaint/core` exports `Brush`, `PaintLayer`, `PaintLayers`, `toBase64`,
`fromBase64`, `History`, `stringifyState`, `parseState`, `Cutouts`,
`MAX_CUTOUTS`, `makeFalloff`, `edgeRadius`, `smoothstep`, `SHAPE_DEFAULTS`,
`fbm`, `vnoise`, `hash21`, `hash11`, `hash31`, `Wind`, the world/UV constants
(`WORLD_SIZE`, `HALF`, `LAYER_RES`, `worldToUV`, `uvToWorld`, `clamp01`) and
`isTyping`. It guarantees three things, and every change to `src/core/` has to
keep guaranteeing them:

1. **No DOM at import.** No module in its transitive graph may touch
   `document` or `window` at evaluation time. Binding listeners inside a
   constructor is fine, guarded the way `History._bindKeys` and `Brush._bind`
   are — the graph has to *load* in Node. `test/core-entry.test.js` imports the
   barrel in vitest's node environment and fails the moment that stops holding.
   This is why `isTyping` lives in `core/dom.js` rather than in `IsoCamera.js`
   (which still re-exports it, so existing imports keep working).
2. **World size and picking are injectable.** `new Brush(ctx, opts)` takes
   `opts.worldSize` (default `ctx.worldSize ?? WORLD_SIZE`), `opts.pick(event)`
   (default: the raycast against `ctx.terrain.mesh`), `opts.canPaint(event)` (an
   extra veto on top of the built-in `ctx.iso` orbit/pan check, which is only
   consulted when a `ctx.iso` exists) and `opts.centre()` (default:
   `ctx.iso.target` lifted onto `ctx.terrain.heightAt`). `WORLD_SIZE` and
   `LAYER_RES` are defaults, never requirements: the Brush maps world→UV through
   its own `worldSize`, and a `PaintLayer` takes `res` from its options.
   `History` needs nothing from `ctx` but `layers` and `elements`.
3. **three is a peer** (`>= 0.160`), so the host's copy is the only one in the
   bundle. `ghost-panel` is an optional peer needed by `envpaint/ui` only —
   `envpaint/core` never imports it.

## World conventions

- Ground is the XZ plane, Y up. `WORLD_SIZE = 48` world units, square, centred at
  the origin: x,z ∈ [-24, 24].
- Every paint layer is `LAYER_RES = 512` texels square and maps to the ground by
  `u = x / WORLD_SIZE + 0.5`, `v = z / WORLD_SIZE + 0.5`. **All shaders compute
  layer UVs from world position with this formula** — never from geometry UVs, so
  plane orientation can't bite.
- 1 world unit ≈ 1 metre for physics. Gravity −9.81.
- Time: `ctx.time` seconds since start, `dt` clamped to ≤ 1/20 s.

## ctx — the shared context object

`App` builds one plain object and passes it to every Element:

```js
ctx = {
  app, scene, camera, renderer,     // THREE objects (camera is the IsoCamera's OrthographicCamera)
  iso,                              // IsoCamera instance
  sun,                              // Sun instance   (sun.uniforms, sun.light)
  wind,                             // Wind instance  (wind.uniforms, wind.sampleAt)
  layers,                           // PaintLayers registry
  terrain,                          // Terrain instance
  physics,                          // Physics instance (may be null until ready — check ctx.physics?.ready)
  brush,                            // Brush instance
  elements,                         // Map<id, Element>
  time: 0,                          // seconds
}
```

## PaintLayers

```js
import { PaintLayer, PaintLayers } from './PaintLayers.js';

const layer = new PaintLayer('grass', { channels: 1, float: false, initial: 0 });
layer.id          // 'grass'
layer.res         // 512
layer.channels    // 1 | 2 | 4
layer.data        // Uint8Array (0..255) or Float32Array (float: true)
layer.texture     // THREE.DataTexture — RedFormat/RGFormat/RGBAFormat, Unsigned/Float type,
                  // LinearFilter min+mag, no mipmaps, ClampToEdge, flipY = false
layer.sample(u, v, ch = 0)      // bilinear read → 0..1 (byte) or raw float
layer.stamp(op)                 // see below; marks dirty
layer.commit()                  // uploads if dirty (texture.needsUpdate = true) — called once per frame by PaintLayers.commitAll()
layer.clear(value = initial)
layer.version                   // integer, increments on every stamp/clear (elements poll this to react)
layer.dirtyRect                 // {x0,y0,x1,y1} texel bounds since last commit (null when clean)
```

`stamp(op)` — all coordinates in UV space (0..1), radius in UV units:

```js
{
  u, v, radius,
  strength = 1,       // per-stamp amount (already multiplied by dt/spacing by the Brush)
  hardness = 0.5,     // 0 = fully soft falloff, 1 = hard edge
  mode: 'add' | 'erase' | 'set' | 'smooth' | 'direction' | 'raise' | 'lower' | 'flatten',
  value = 1,          // target for 'set'
  channel = 0,
  dir = { x, y },     // 'direction' mode: writes dir*0.5+0.5 into channels 0,1 (RG), blended by falloff
  flattenTo,          // 'flatten': target float height
}
```

Falloff: `f = 1 - smoothstep(hardness * radius, radius, dist)`. 'add' → `v = min(1, v + strength*f)`;
'erase' → `v = max(0, v - strength*f)`; 'set' → `lerp(v, value, strength*f)`; 'smooth' →
lerp toward 3×3 box blur; 'raise'/'lower' on float layers → `v ± strength*f` (no clamp);
'flatten' → lerp toward `flattenTo`.

`PaintLayers`: `add(layer)`, `get(id)`, `has(id)`, `commitAll()`, `all()`, `serialize()`/`deserialize()` (base64 of data per id).

## Brush & tools

```js
brush.settings = { radius: 1.0 /* world units */, strength: 0.26, hardness: 0.5, spacing: 0.35 /* fraction of radius */,
                   edgeNoise: 0.35, edgeScale: 3, spatter: 0.25, aspect: 1 /* edge shape, see core/BrushShape.js */ }
brush.erase = false           // Ctrl/Cmd while painting, or 'X' toggles
brush.registerTool(tool)
brush.setTool(id)  brush.tool  // active tool id
brush.on('strokestart' | 'stroke' | 'strokeend', ({ tool, hit, dir }) => {})   // hit = { x, z, u, v, y }
brush.cursor                  // THREE.Object3D ring that follows the terrain; colour = tool.color
```

Tool definition:

```js
{
  id: 'grass', label: 'Grass', color: '#7ad24a', key: '1',
  layer: 'grass', mode: 'add', channel: 0,          // default stamp behaviour
  eraseMode: 'erase',                                // what Ctrl/Cmd/X does (default 'erase')
  strengthScale: 1,                                  // multiplies brush.settings.strength for this tool
  element: 'rocks',                                  // optional: History snapshots this element around the stroke
  excludes: ['path'],                                // optional: layer ids this tool clears as it paints
  onStamp: (ctx, op, hit) => {},                     // optional: called INSTEAD of layer.stamp when present
}
```

`excludes` makes the latest stroke win between surfaces that cannot coexist.
After a non-erase stamp — on the tool's own layer, or after `onStamp` — the
Brush also stamps `{ ...op, mode: 'erase', strength: max(op.strength * 2, 0.5) }`
on every listed layer that exists, inside the same stroke so one Ctrl+Z undoes
both. Erase strokes never trigger it, so lifting grass does not also lift the
path underneath. Declared today: `path` excludes `['grass', 'flowers']`, and
`grass` and `flowers` each exclude `['path']`. `mask` and the water tools are
deliberately left alone — masking is an explicit overlay, not a surface.

`new Brush(ctx, opts)` — the second argument is the injection bag described
under [Package entry points](#package-entry-points) (`worldSize`, `pick`,
`canPaint`, `centre`). The App passes none of it and gets the defaults below.

The Brush raycasts the pointer against `terrain.mesh`, converts to UV, and along a
drag emits stamps every `spacing * radius` world units. `dir` in stroke events is
the normalised stroke direction in UV space (used by 'direction' tools such as
rivers and grass comb).

Left button paints, unless Shift is held: **Shift + left drag belongs to the
camera** (free orbit — see below) and never starts a stroke. Ctrl/Cmd held
during a stroke temporarily inverts it to erase; `X` toggles erase stickily.
Middle drag / Space+drag pans the camera; wheel zooms; Q/E snap the view to the
next/previous 90° mark. `[` `]` change radius; any radius change (keys or the Radius slider) flashes the
highlighted brush footprint on the canvas for under a second, under the pointer or at the view centre. Painting never selects
ghost-panel objects (`autoRegister: false`, `gizmo: false`).

## Terrain

```js
terrain.mesh                    // THREE.Mesh, PlaneGeometry(WORLD_SIZE, WORLD_SIZE, 255, 255) rotated to XZ, receiveShadow
terrain.heightAt(x, z)          // world height (bilinear from the float 'height' layer)
terrain.normalAt(x, z, out)     // world normal
terrain.heightLayer             // layers.get('height'), Float32, 1 channel, world units
terrain.version                 // increments when the height geometry was rebuilt (physics rebuilds its collider on change)
```

Built-in layers the Terrain registers: `height` (float), `mask` (byte), `path` (byte).
The ground shader blends: base meadow colour → lush green under high grass density →
dirt/road on `path` → wet dark sand near `water` → rock on steep slopes → snow above a
height threshold, all quantised into toon bands, and shows a red hatch overlay where
`mask` > 0 when `terrain.showMask` is true.

## Sun & Wind uniforms (shared by all shaders)

```js
sun.uniforms = {
  uSunDir:      { value: THREE.Vector3 },  // normalised, pointing FROM surface TO sun
  uSunColor:    { value: THREE.Color },    // warm: #fff1d0 (linear)
  uSkyColor:    { value: THREE.Color },    // hemisphere top
  uGroundColor: { value: THREE.Color },    // hemisphere bottom
}
wind.uniforms = {
  uWindDir:      { value: THREE.Vector2 }, // normalised XZ
  uWindStrength: { value: 0..1 },
  uWindSpeed:    { value: number },
  uGust:         { value: 0..1 },          // slowly varying, computed on CPU every frame
  uTime:         { value: seconds },
}
wind.sampleAt(x, z, time) → { x, z }       // CPU wind force vector (same maths as the GLSL windAt())
```

Materials that light with the toon model **must** spread these uniforms into their
own uniforms (same object references, so updates propagate) and use `lights: true`
plus `THREE.UniformsLib.lights` so three's directional shadow map reaches them.

## Toon shader contract (`src/core/shaders/toon.glsl.js`)

Exports GLSL strings:

- `noiseGLSL` — `hash11/hash21/hash31`, `vnoise(vec2)`, `fbm(vec2, octaves)`, `windAt(vec2 worldXZ)` (uses wind uniforms, returns vec2 XZ force in 0..1-ish).
- `toonParsVertex` — declares nothing fancy, includes `<common>` and `<shadowmap_pars_vertex>`.
- `toonShadowVertex` — the tail of a vertex shader. **Expects two variables already defined** in `main()`: `vec4 worldPosition` and `vec3 transformedNormal` (view-space normal). Sets `vWorldPos`, `vNormalW`, and `gl_Position`, then `#include <shadowmap_vertex>`.
- `toonParsFragment` — includes `<common>`, `<packing>`, `<lights_pars_begin>`, `<shadowmap_pars_fragment>`, declares the sun/wind uniforms + varyings, and defines:
  ```glsl
  float toonShadow();                                   // 1 = lit, uses directionalShadowMap[0] when available
  float toonRamp(float ndl, float bands, float soft);   // quantised diffuse in 0..1
  vec3  toonLight(vec3 albedo, vec3 n, float shadow, float bands);  // full Ghibli lighting: sun*ramp + hemisphere ambient + tiny rim
  ```
  Palette guidance: sun `#fff1d0`, sky `#bcdcff`, ground `#6b7a4a`, shadow tint cools toward blue-violet, 3 bands (`bands = 3.0`), band softness 0.04.
- Every toon material draws with `toneMapped: false`; the renderer uses
  `outputColorSpace = SRGBColorSpace`, no tone mapping; colours declared as sRGB hex go through `new THREE.Color(hex)` (which converts to linear).

## Element interface (`src/core/Element.js`)

```js
export class Element {
  static id = 'grass';          // unique
  static label = 'Grass';
  static order = 10;            // draw/update order
  constructor(ctx) { this.ctx = ctx; }
  async init() {}               // register layers (ctx.layers.add), tools (ctx.brush.registerTool), add meshes to ctx.scene
  buildPanel(ui) {}             // ghost-panel folders for this element (ui.addFolder(...))
  update(dt, time) {}           // per frame
  onLayerChanged(layer) {}      // called when any layer's version changed since last frame
  onTerrainChanged() {}         // height geometry rebuilt
  serialize() / deserialize(o)  // optional per-element params for save/load
  dispose() {}
}
```

`src/elements/index.js` exports `ELEMENTS`, sorted by `order`.
`main.js` constructs each, awaits `init()` in order, then `buildPanel(ui)`.

| order | id | label | what it owns |
|---|---|---|---|
| 10 | `grass` | Grass | the GPU blade field over the `grass` layer |
| 12 | `flowers` | Flowers | scattered blooms over the `flowers` layer |
| 20 | `water` | Water | the level field, the surface mesh, waterfalls, ripples |
| 30 | `rocks` | Rocks | Rapier boulders, and the `press` layer they write |
| 35 | `sword` | Master Sword | one loaded prop, planted blade-down in the ground |
| 40 | `trees` | Trees | instanced toon trees on CPU sway springs |
| 45 | `smoke` | Smoke | drifting puffs over the `smoke` layer |
| 50 | `fire` | Fire | flames, embers, the light pool, the `scorch` layer |
| 60 | `clouds` | Clouds | the cloud deck, rain and lightning |

### Prop elements

Most elements are *painted*: a tool scatters them, and their Outliner row is locked so
the world can never be dragged or deleted out from under the brush. A **prop element** is
the other shape an element can take, and `Sword` is the reference for it. It owns exactly
one object, loaded asynchronously from `public/models/` with `GLTFLoader` (`init()` starts
the load and does not await it, so a slow asset never delays boot); it marks that object's
root `userData.envpaintProp = true`, which is what tells `Panel.js` to register the row
**unlocked** — selectable, gizmo-draggable, deletable, and restored by the undo entry the
element pushes when the Outliner removes it. `sceneObjects()` returns nothing once the
object is gone, so the panel's per-frame rescan cannot resurrect a dead row. In exchange
for being free in X and Z the prop gives up its Y: the element re-derives it from
`terrain.heightAt()` every frame, so however the ground is sculpted or wherever it is
dragged, the same fraction of the blade stays underground — and it holds a disc in the
`press` layer so the grass parts around it, lifting it again when it is deleted.

## Rendering & style rules

- Isometric: `OrthographicCamera`, default yaw 45°, default pitch `atan(1/√2) ≈ 35.26°`. Frustum half-height
  default 14 units, zoom range 4–40 (unchanged by orbiting). Yaw and pitch are **free angles**: Shift + left drag
  orbits (≈0.006 rad per pixel, yaw unbounded, pitch clamped to 18°–70°), Q/E snap yaw to the next/previous 90° mark
  measured from the nearest one, and "Reset view" restores yaw 45° / pitch 35.26°. `iso.yaw`, `iso.pitch`,
  `iso.setYawPitch(yaw, pitch)`, `iso.setYawIndex(0..3)`; both angles are serialized. `iso.yawIndex` survives only as a
  derived read of the nearest mark — nothing may assume the camera sits on one of the four.
- Renderer: antialias on, `shadowMap.enabled = true`, `PCFSoftShadowMap`, sun shadow camera covers the whole world (±26), map 2048.
- Background: soft sky gradient (`#dff3ff` → `#f6e7c9` toward the horizon) as a big inverted dome or `scene.background` colour `#cfe8ff` plus fog `#e8f2ff` for the far edge.
- Grass, trees, rocks: hard 2–3 band toon lighting, saturated but soft palette, slight warm rim on tips. No PBR. No post-processing outline pass in v1 (edge is implied by bands and colour contrast).
- All heavy per-instance work happens on the GPU: painting must never rebuild instance buffers of grass. Elements that spawn discrete objects (rocks, trees) do so on `strokeend` from layer samples or spawn directly on stamp.

## Physics (`src/core/Physics.js`)

```js
physics.ready             // boolean, true after RAPIER.init()
physics.world             // RAPIER.World, gravity (0,-9.81,0)
physics.step(dt)          // fixed 60 Hz sub-stepping, accumulator
physics.rebuildTerrain()  // heightfield collider from terrain.heightLayer (called on terrain.version change, throttled)
physics.addRigidBody(desc, colliderDesc) → RAPIER.RigidBody
physics.remove(body)
```

Soft bodies (trees, tall plants) are simulated as damped angular springs driven by
`wind.sampleAt` on the CPU (per instance: angle θ, velocity ω; `ω += (k·(windTorque − θ) − c·ω)·dt`) and fed to the GPU as a per-instance bend attribute. Water is a GPU
height-field wave simulation (ping-pong render targets) with rain/rock impacts as sources.

## Save / load

`App.toJSON()` = `{ layers: layers.serialize(), elements: { id: element.serialize() }, camera, sun, wind }`.
Ghost-panel's header Save/Load uses these via `ui.toJSON`/`fromJSON` hooks.

## Style system — any material style, not just toon

The Ghibli toon look is the *default style*, not a hard-wiring. Structurally the tool must be able to render the same
painted environment in any material style (toon, flat/unlit, realistic lambert/blinn PBR-ish, painterly, pixel,
wireframe, …). This is achieved by separating *what an element is* (geometry, animation, physics, layers) from
*how it is shaded* (a Style):

```js
// src/core/Style.js
ctx.style.current            // active style id, default 'ghibli-toon'
ctx.style.list()             // [{ id, label }]
ctx.style.set(id)            // swaps every tracked material's lighting chunk + palette, recompiles once
ctx.style.attach(material, { element: 'grass' })   // every element material is registered here after creation
ctx.style.on('change', fn)
```

A style is a plain object in `src/styles/<id>.js`:

```js
export default {
  id: 'ghibli-toon', label: 'Ghibli toon',
  lightingGLSL: `...`,       // defines toonRamp / toonShadowColor / toonLight — see the
                             // implementation section at the end of this document
  uniforms: { uBands: { value: 3 }, uBandSoft: { value: 0.06 }, uRim: { value: 0.25 } },
  palette: { sun: '#fff1d0', sky: '#bcdcff', ground: '#6b7a4a', background: '#cfe8ff', fog: '#e8f2ff',
             grass: { base: '#3f8f3a', tip: '#b6e35a', dry: '#c9d86a' }, water: {...}, rocks: {...}, ... },
  post: { outline: false },   // optional post-processing passes the App enables for this style
}
```

Mechanics: every fragment shader includes the lighting block between the markers `/*<style>*/ … /*</style>*/`
(the `toonParsFragment` chunk emits these markers around the lighting functions; the functions keep their
`toonRamp`/`toonShadowColor`/`toonLight` names in every style, so existing shaders keep working). On `style.set(id)`
the Style module rewrites the marked block in each attached material's `fragmentShader`, merges the style's uniforms,
sets `material.needsUpdate = true`, applies the palette to `sun`/`scene` and calls `element.applyPalette(palette[element.id])`
on every element that implements it. Elements must therefore keep their colours in uniforms (never baked into GLSL) and
expose `applyPalette(p)`.

Styles shipped: `ghibli-toon` (default), `flat` (unlit albedo × hemisphere), `realistic` (lambert + blinn specular,
soft shadows), `painterly` (toon + brush-noise edge wobble + paper grain), `pixel` (posterised; screen-space pixel
snapping is out of scope). The panel shows a **Style** select at the top, with the look sliders and the ink/paper
controls under it.

## Colour-space rule for every custom fragment shader

`ShaderMaterial` output is NOT converted to the renderer's output colour space automatically. Every fragment shader
that writes `gl_FragColor` must end with, in this order:

```glsl
#include <fog_fragment>
#include <colorspace_fragment>
```

(fog first, then the sRGB encode). Omitting `colorspace_fragment` renders that material in linear light, visibly darker
and duller than its neighbours. Colours in uniforms are linear (`new THREE.Color('#hex')` converts from sRGB).

## Press layer (physical interaction between elements)

`press` — byte, `res: 128`, 4 channels, rest state `(128, 128, 0, 255)`. RG = push direction in layer-UV space
(`dir * 0.5 + 0.5`), B = strength 0..1, decays every frame. Written by Rocks (moving rigid bodies); read by Grass
(bend along RG, flatten by B) and by any future element that should react to things moving over the ground.

## Water model — landscape-reactive

Water is a **surface-level field**, not a painted presence. `waterLevel` (float layer, `DRY = -1000` sentinel) holds the
absolute surface height per texel; the effective level is `max(waterLevel, seaLevel)`. Depth = level − terrain height, and
water exists where depth > 0.02. The byte `water` layer (presence 0..1 = clamp(depth / 0.35)) is *derived* from that and
is what other elements read. Consequences: ponds fill basins to a flat level, sculpting terrain up through a lake makes an
island emerge, the sea-level slider floods everything below it with a true shoreline, rivers carry a level that never
rises along the stroke (and carve a channel into the terrain), and the single 511×511 surface mesh forms steep sheets
wherever the level drops over a cliff — those are the waterfalls, rendered by a slope-triggered shader branch with
auto-detected foam/mist emitters at the base. Wind, rain and rigid bodies feed the GPU ripple simulation on top.

## Real-time rule

Every change is visible while the pointer is still moving. Layer stamps upload the same frame; terrain geometry, the
derived water presence/mesh, grass culling, physics colliders (throttled to 250 ms, rebuilt mid-stroke, bodies woken)
and auto-detected waterfalls all update continuously. No element may defer visible work to `strokeend`; the only
stroke-end action allowed is placing a manual emitter.

## Anime post pass (`src/core/PostFX.js`, owned by the Style system)

The cel materials alone are not the look. The frame is rendered to a target with a depth texture and finished by a
screen-space ink pass: silhouette lines from depth and crease lines from depth-reconstructed normals, sampled through a
pencil wobble, with thick-and-thin weight and noise-driven breaks; ink colour is the darkened scene colour pulled toward a
violet-brown tint, never black; hatching (world-anchored diagonal lines, cross-hatched in the darkest areas) where the
frame is dark; paper grain, pigment pooling at colour boundaries, and a light vignette. Line style presets: clean, pencil,
brush, none. Every style's `post` block sets these defaults (realistic disables the pass). Material side: the ghibli
terminator is nudged by low-frequency noise so it reads painted, and shadow fills carry a faint brush texture.

## Style system — implementation notes and what element owners must do

*(Written by the Style-system change. `src/core/Style.js`, `src/core/PostFX.js`, `src/styles/*` and the
style hooks in `Terrain`, `Grass`, `Rocks`, `Clouds` are live; `Water`, `Trees`, `Fire`, `Smoke` and
`Waterfall` still need the two hooks below from their owners.)*

### Marker mechanics

`toon.glsl.js` exports `STYLE_START = '/*<style>*/'` and `STYLE_END = '/*</style>*/'`. `toonParsFragment`
emits, in order: three's includes → the varyings → the sun uniforms → `noiseGLSL` → `toonShadow()` →
`STYLE_START` + `ghibliLightingGLSL` + `STYLE_END`. Only the text **between** the markers is swapped, so
`toonShadow()`, `fbm`, `hash21`, `vWorldPos`, `vNormalW` and the sun uniforms are always available to every
style. `Style.attach(material)` records the material's `fragmentShader` as its *base*; `Style.set(id)` rebuilds
each material's shader as `base[0 … START] + style.lightingGLSL + base[END … ]`, merges the style's uniforms
and sets `needsUpdate = true`.

Every `lightingGLSL` block MUST define exactly these, so call sites compile unchanged:

```glsl
float toonRamp(float ndl, float bands, float soft);
vec3  toonShadowColor(vec3 albedo, vec3 n);
vec3  toonLight(vec3 albedo, vec3 n, float shadow, float bands);
```

Its own uniforms are declared inside the block and prefixed `uStyle…`, except the six Ghibli look controls
(`uShadowTint`, `uBandEdge`, `uBandSoft`, `uHalfTone`, `uRim`, `uGrain`) which keep their names because they
live on `sun.uniforms` and are wired to the panel's look sliders. `Style` keeps **one uniform object per name**
across every material, so a slider moves the whole scene.

### Style branches — `uStyleId`

A style is more than its lighting: a flat blade has no gradient, a pixel blade is fatter and rarer, a realistic
canopy is smooth where a cel one is banded. So every style also declares

```js
uniforms: { uStyleId: { value: 2 }, /* … */ }   // 0 ghibli-toon · 1 flat · 2 realistic · 3 painterly · 4 pixel
```

and `Style.set()` merges it into every attached material like any other style uniform (one shared object, so the whole
scene switches at once). **Each shader declares it itself** — one line, `uniform float uStyleId;`, in every vertex or
fragment shader that branches. The shared chunks deliberately do *not* declare it, so materials that include
`toonParsFragment` (terrain, grass, rocks, trees, clouds, the water surface) and those that do not (fire, smoke, rain)
follow the same rule and never collide with a redefinition. A material the Style system never attached leaves the
uniform unset, which reads as 0 — the Ghibli path.

Branch with a plain runtime `if` on a float range — no `#define`, no recompile, one shader for all five styles:

```glsl
if (uStyleId > 0.5 && uStyleId < 1.5) {        // flat: one printed colour, no gradient
} else if (uStyleId > 1.5 && uStyleId < 2.5) { // realistic: smooth, no quantisation
} else if (uStyleId > 2.5 && uStyleId < 3.5) { // painterly: softer, wobblier, wetter
} else if (uStyleId > 3.5) {                   // pixel: hard steps, few inks
}
```

**The Ghibli path must stay byte-identical.** Write every branch as an *addition* that leaves the `uStyleId == 0` code
exactly as it was — never restructure the default path to make a branch fit. `ghibli-toon`'s `lightingGLSL` is the
block that ships inside `toonParsFragment`, and switching back to it restores each attached shader character for
character (there is a check for this in the Style unit harness).

What is branched today: `Grass` (blade width/height/count, tip gradient, root darkening, per-blade normal jitter, tip
highlight vs specular sheen), `Rocks` (weathering, flecks, moss edge), `Trees` (canopy banding, sun dab), `Clouds`
(underside falloff and mottle), `Terrain` (colour break-up, rock and snow edges). `Water`, `Fire` and `Smoke` branches
belong to their owners — same convention, same id table.

### What Water / Trees / Fire / Smoke / Waterfall owners must add

1. **Register every material that includes `toonParsFragment`**, immediately after building it and before it is
   first rendered:

   ```js
   this.material = new THREE.ShaderMaterial({ /* … */ });
   ctx.style?.attach?.(this.material, { element: Trees.id });   // 'trees', 'water', 'fire', …
   ```

   `attach` is idempotent, cheap, and safe when `ctx.style` is missing (tests). Call `ctx.style?.detach?.(material)`
   in `dispose()` if the element rebuilds materials at runtime. Attaching a material that does **not** include
   `toonParsFragment` (fire's light pool, embers, rain) is fine and often wanted: there is no marked block to swap, so
   only the style's uniforms are merged — which is exactly what a shader branching on `uStyleId` needs.

2. **Implement `applyPalette(p)`** on the element, writing only the keys present and leaving the rest alone; if the
   element keeps a `params` object the panel or `serialize()` reads, update that too (see `Grass.applyPalette`):

   ```js
   /** @param {{deep?:string, shallow?:string, foam?:string}} [p] */
   applyPalette(p) {
     if (!p || !this.material) return this;
     const u = this.material.uniforms;
     if (p.deep != null) { this.params.colorDeep = p.deep; u.uDeep.value.set(p.deep); }
     // …
     return this;
   }
   ```

   Then add the matching sub-object to each of the five palettes in `src/styles/*.js` — key = the element's
   `static id`. `Style.set()` calls `element.applyPalette?.(palette[element.constructor.id])` for every element in
   `ctx.elements`, and `terrain.applyPalette?.(palette.terrain)`. Colours in a palette are sRGB hex strings;
   `THREE.Color.set()` converts them to linear, which is what the shaders want.

Rules that follow from this: never bake a colour into GLSL, never read a colour from a `const` in JS at draw time,
and never assume the lighting model — call `toonLight(...)` and let the style decide what it means.

### Screen-space half: `src/core/PostFX.js`

The App renders through `PostFX` (`app.renderOnce()` and the frame loop both go through it, so PNG exports match
the screen). The scene goes into a `WebGLRenderTarget` carrying a `DepthTexture`, and one full-screen pass draws
ink outlines (depth + reconstructed-normal edges, pencil wobble, thick-and-thin weight, fbm breaks), hatching in
the dark parts of the frame anchored to world position, paper grain, pigment pooling and a vignette. **That render
target is linear** (three applies the output colour space only when drawing to the canvas), so the ink pass converts
to sRGB on the way in and writes display-space colour straight to the framebuffer — anything else added to that
pass must respect the same convention.

A style's `post` block drives it: `{ enabled, lineStyle: 'none'|'clean'|'pencil'|'brush', lineWidth, wobble, break,
ink, inkOpacity, hatch, hatchFrom, hatchScale, paper, pooling, vignette, shadowRadius }` plus the four per-style
features below. `Style.set()` calls `ctx.postfx.apply(style.post)`; `shadowRadius` also reaches
`sun.light.shadow.radius`.

| key | style | what it does |
|---|---|---|
| `sharpen` | realistic | unsharp mask against a 4-tap blur — the finish of a photographic render |
| `brush`, `bleed` | painterly | directional stroke noise (rotated 20°, ±6 % luminance) and a wet 1-px colour smear across edges |
| `pixelSize` | pixel | the scene is rendered into a `1/N` buffer sampled `NearestFilter`, so the upscale *is* the pixel grid; `uResolution` is that buffer, so the outline is one pixel-art pixel wide and drawn after pixelation |
| `levels`, `dither` | pixel | per-channel quantisation with a 4×4 Bayer ordered dither, in display space |

`pixelSize` resizes (and, when the filtering mode flips, rebuilds) the render target — it is the one `post` key with a
cost beyond a uniform write.

**Cutout discs (`src/core/Cutouts.js`).** Grass and Flowers each carry a keyed set of up to eight "nothing grows here" discs as a small uniform array (`uCutouts`, `uCutoutCount`); the vertex shader culls any instance rooted inside one. Props register a disc by key (the Master Sword's `clearing`, 0.5 m by default) and remove it when they leave. Unlike painting the mask layer, a cutout follows the object and never touches user-painted data; the press layer is for leaning and flattening, a cutout is for bare ground.

**Opting out of ink — the alpha channel is an ink mask.** The offscreen target is RGBA and nothing blends against it,
so `gl_FragColor.a` there does not mean opacity; it means *how much of the ink pass touches this pixel*, in tiers:

| alpha | outline | pooling | hatch | who writes it |
|---|---|---|---|---|
| `1.0` | yes | yes | yes | cel materials on their shade side (`toonInkAlpha()` after `toonLight()`), and any material by default |
| `0.75` | yes | yes | no | cel materials in the sun (`toonInkAlpha()`): a lit face is never hatched, whatever its colour; rock always (the `Rocks` element and Terrain's steep-slope rock), so rock keeps its flat two-tone-plus-flecks texture |
| `0.6` | yes | no | no | the `Water` surface — a shape with a drawn edge, but paint does not pool or hatch on water |
| `0.0` | no | no | no | fire flames and embers, grass blades |

The pass reads `inkMask = smoothstep(0.0, 0.5, a)`, which gates everything, `poolMask = smoothstep(0.65, 0.72, a)`
for the pooling and `hatchMask = smoothstep(0.85, 1.0, a)` for the hatching — so the middle tiers keep their line and
lose the texture. `toonLight()` leaves how lit it found the surface in the global `gToonLit`; Terrain and Trees write
`toonInkAlpha()` from it, Rocks writes 0.75 outright. Hatch lines stay anchored in world space (they never swim under the camera) but are
spaced on the screen: `PostFX.render()` scales the style's `hatchScale` by the camera's world-per-pixel each frame,
so the pencil is 16 px apart at the default whether you look at the whole meadow or one rock. Neighbours with alpha 0 are also dropped from the silhouette test, so a flame
never puts a line on the ground behind it. The final composite writes alpha 1 and ignores the channel.

Two kinds of material should write `0.0`: fine, dense geometry (`Grass` writes `vec4(lit, 0.0)` — otherwise every blade
gets a contour and the meadow turns to mud; **tree foliage should do the same**, trunks and rocks keep `1.0`), and
additive/effect materials that are not solid objects (fire flames and embers). Depth alone already spares anything with
`depthWrite: false` (fire quads, rain, splashes, waterfall mist), because it leaves no depth edge to find. Note that
`Smoke` and the `Water` surface *do* write depth, so they are outlined like solid shapes — intentional for painted
Ghibli smoke and a shoreline, but their owners can opt out with the alpha rule if they disagree.

Paper grain is the one effect that ignores the mask: it is the sheet the whole frame is painted on.

`uDepthThreshold` is in **world units of linear depth difference** across the sampled pair (0.9 by default): a grass
blade sits about half a unit in front of the ground behind it, while rocks, trees, hills and clouds break 1.5 u, so
shapes outline and clutter does not. Creases are additionally damped inside dense foliage, detected as a high
per-pixel depth gradient.

One matching material-side rule for anything made of many small pieces: **fade the per-instance detail out with
distance**, or it turns into pixel noise when the camera pulls back. `Grass` takes a `uZoom` uniform (the camera's
`frustumHalfHeight`, pushed every frame in `update()`), derives `far = smoothstep(9, 22, uZoom)`, and uses it to fade
the per-blade normal nudge and to collapse root/tip contrast toward one mid green — at zoom 24 the meadow reads as a
painted fill, at zoom 6 as blades. Trees and any future scatter should do the same.

The panel's **Style** folder carries the style select, the six look sliders, and an *Ink & paper* group (Enable, line
style, width, wobble, break, ink colour and opacity, hatch, hatch scale, paper, pooling) bound straight to the pass's
uniforms, so a style switch visibly moves every control.

### Save / load

`App.toJSON()` now includes `style: ctx.style.current`, and `fromJSON` applies it **first**, before layers, sun and
element params, so anything explicitly saved wins over the style's palette.

## Material descriptors (`material.userData.uiProps`)

Ghost-panel's **Materials** palette (left panel) lists one swatch per material in the scene, and clicking a swatch — or
selecting a mesh in the Outliner — rebuilds the Inspector's shared **Material** folder. For a hand-written
`ShaderMaterial` that folder is nearly empty, and ghost-panel offers no extension hook, so every material we own
declares its own editable properties and `src/ui/Panel.js` appends them to whichever build of the folder is showing:

```js
material.name = 'Grass';                 // the swatch label — name it for people, not for code
material.userData.uiProps = [
  { label: 'Tip', kind: 'color', get: () => p.colorTip, set: (v) => this.applyPalette({ tip: v }),
    tooltip: 'Colour at the tip of a blade' },
  { label: 'Height', min: 0.2, max: 2.5, step: 0.01, get: () => p.height,
    set: (v) => { p.height = v; u.uBladeHeight.value = v; } },
];
```

- `kind` — `'color'` (hex string in `get`/`set`), `'number'` (the default, a slider using `min`/`max`/`step`),
  `'boolean'`, or `'select'` (with `options`). `tooltip` is optional.
- **`get`/`set` are callbacks, never uniform names.** `set` must write everything that owns the value — the element's
  `params` *and* the uniform — so `serialize()` and the element's own folder keep telling the truth. Where the element
  has an `applyPalette()`, route colours through it: that is the same path a style switch takes, so styles keep
  repainting the material and the rows read back correctly the next time the folder opens.
- Rows are rebuilt (and `get` re-read) every time the folder opens, so they always show current values. They are added
  with the id `uip:<label>`, which cannot collide with ghost-panel's own rows.

The palette previews a material by drawing it on a sphere in a scratch renderer, which cannot light a shader that needs
our painted layer textures — ours come out as empty checkerboards. So every material we own also declares a flat
**swatch hint**, which `Panel.js` paints over the failed thumbnail (label, drag and selection are untouched):

```js
material.userData.swatch = '#8fcf5a';                          // one flat colour
material.userData.swatch = [p.colorTip, p.colorBase];          // 2-3 hexes → hard-edged bands
```

Two more rules for the palette:

- **Name every material a person may click**: `Ground`, `Grass`, `Rock`, `Tree`, `Fire`, `Smoke`, `Cloud`, `Water`…
  Anonymous materials show up as `RGB_143-207-90`.
- **Mark helper geometry `userData.__duiIgnore = true`** so it never becomes a swatch (or a selection): rain streaks,
  splash crowns, bolt ribbons, embers, fire light-pool discs, the sky quad, the brush cursor. Panel.js marks the sky
  and the cursor; every element marks its own.

Painted surfaces also carry `userData.envpaintLocked = true` (set by Panel.js when it registers them in the Outliner):
locked objects can be selected and inspected but never gizmo-dragged, deleted from the Outliner, or re-skinned by a
material drop.

## Undo / redo (`src/core/History.js`)

Undo covers **brush strokes**, not just ghost-panel object edits. One entry = one
stroke (or one `wrap()`ped action). `App` builds `ctx.history` before the Brush.

```js
history.begin(label, { element })    // open a scope; everything painted until end() is one entry
history.end()                        // record the entry (dropped when nothing actually changed)
history.wrap(label, fn, { element })  // begin / fn() / end() for a synchronous one-shot mutation
history.undo()  history.redo()
history.canUndo()  history.canRedo()
history.on('change', h => {})        // fires on push / undo / redo / clear
history.stats()             // { steps, bytes, canUndo, canRedo }
history.noteDirty(layer, rect)       // App calls this every frame, BEFORE layers.commitAll()
history.attachUI(ui)        // merge into ghost-panel's stack (see below)
new History(ctx, { maxSteps = 60, maxBytes = 96 << 20 })
```

**How it stores strokes.** History keeps one persistent shadow copy of every
participating layer's typed array, created lazily at the first `begin()` after
the layer appears. `App` reports each dirty layer and its `dirtyRect` every frame
before `commitAll()` clears it; inside a scope those rects are unioned per layer,
outside a scope they are folded straight into the shadow (so simulation writes
never leak into the next stroke). At `end()` the union rect's bytes are copied
out of the shadow ("before") and out of `layer.data` ("after"). A full-world
512×512 float height stroke costs 2.00 MB; a typical 2.5-unit brush stroke costs
20–100 KB. Oldest entries are evicted once `maxSteps` or `maxBytes` is exceeded,
and the redo stack is dropped on any new entry.

Undo writes the "before" rect back into `layer.data` and calls
`layer.markDirtyRect(x0, y0, x1, y1)`, so the normal per-frame
`onLayerChanged` / terrain-rebuild path reacts — nothing needs undo-specific code.

### PaintLayer additions

```js
new PaintLayer('press', { history: false })   // opt out: simulated, never painted
layer.markDirtyRect(x0, y0, x1, y1)           // bumps version + unions the dirty rect
```

Opt a layer out when it is rewritten every frame by a simulation rather than by
the Brush (Rocks' `press` layer does). Painted and derived-from-painted layers
(Water's `water` presence layer, `grass`, `height`, `mask`, `path`) stay in.

### Element additions — spawn tools

Tool definitions gain an optional `element: '<id>'`. When the active tool names
an element, History snapshots that element at `begin()` and again at `end()`, and
undo/redo restore the matching snapshot:

```js
{ id: 'rocks', label: 'Rocks', element: 'rocks', onStamp: (ctx, op, hit) => {...} }
```

```js
class Element {
  captureHistory()          // default: this.serialize()
  restoreHistory(state)     // default: this.deserialize(state)
}
```

`begin()` and `wrap()` also take an explicit `{ element: '<id>' }`, snapshotted
*in addition* to the active tool's element when they differ. Panel buttons must
pass it — "Clear rocks" has to round-trip even when the grass tool is active:

```js
ctx.history.wrap('Clear rocks', () => this.clear(), { element: 'rocks' });
```

`restoreHistory` must leave the element clean — spawners tear down and rebuild
their bodies and instances (Rocks' `deserialize` already does: it calls
`clear()` then recreates every body).

### ghost-panel integration — one stack

ghost-panel exposes a pushable `ui._undo` (`UndoStack`, `push({label, undo, redo})`)
and already binds Cmd/Ctrl+Z and Cmd+Shift+Z / Ctrl+Y, suppressed inside form
fields. History pushes every stroke entry into it, so **one** Ctrl+Z walks back
through brush strokes and panel edits in the order they happened. History adopts
the panel stack automatically the moment `app.ui` exists (and drops its own
fallback key bindings then), so nothing breaks if `attachUI` is never called —
but `Panel.js` may call `app.history.attachUI(ui)` explicitly at mount.

**What Panel.js should add**

- Optionally `app.history.attachUI(ui)` right after `createPanel`.
- Wrap every button that mutates a layer outside a stroke in
  `app.history.wrap('Clear grass', () => layer.clear(0))` — Fill layer, Clear
  layer, Reset terrain, and any "randomise" action. Without the wrap the change
  happens but cannot be undone. Buttons that mutate an *element* rather than a
  layer must also pass `{ element: '<id>' }`, since the active tool is usually
  something else entirely.
- `history.on('change', …)` if the panel wants to show step count / label.

**What Water.js must add**

- Wrap its non-stroke mutations so they become undo entries, passing the
  element id: `ctx.history.wrap('Flood fill basin', run, { element: 'water' })`,
  `ctx.history.wrap('Raise sea to cursor', run, { element: 'water' })` and
  `ctx.history.wrap('Drain all', run, { element: 'water' })`. (Done.)
- Leave the `water` presence layer tracked (the default) — it is painted.
- Any CPU `PaintLayer` that the wave simulation rewrites every frame must be
  constructed with `{ history: false }`. GPU ping-pong render targets are not
  PaintLayers and need no change.
