# EnvPaint

EnvPaint is a Three.js / WebGL environment painter: you paint directly onto a
sculptable terrain with an isometric brush to place grass, water (ponds,
lakes, rivers, waterfalls, a floodable sea level), rocks, trees, fire, smoke,
and clouds that bring rain and lightning — plus a path tool for dirt roads
and a mask tool that keeps growth off an area. The camera is a rotatable
orthographic isometric rig; the default render is a two-tone Ghibli-style cel
shader with a screen-space ink pass (silhouette/crease outlines, hatching,
paper grain, pigment pooling) over hand-painted materials, and the whole look
is swappable to flat/unlit, realistic PBR-ish, painterly, or pixel styles
without touching how anything is painted.

It isn't just decoration sitting on top of a heightmap — the scene actually
behaves like an environment:

- Rigid bodies (Rapier) fall and roll on a heightfield collider built from the
  sculpted terrain.
- Trees sway as damped angular springs driven by a shared wind field, not
  canned animation.
- Water is a GPU height-field ripple simulation, not a flat plane: rain,
  rocks, and waterfalls all inject impacts into it, and the visible surface,
  shoreline, and waterfalls are all derived from one landscape-reactive
  surface-level field.
- Rolling rocks flatten and push over grass through a shared "press" layer.
- Fire spreads across painted grass, burns it down to scorch marks, and
  eventually burns out.
- Rain raises a scene-wide "wetness" that shifts the mood/palette.

The inspector panel is [ghost-panel](https://github.com/epun/ghost-panel).

## Quick start

```bash
npm install
npm run dev      # Vite dev server
npm run build    # production build
npm test         # vitest unit tests (pure logic)
npm run shot      # headless screenshot: node scripts/screenshot.mjs
```

`npm run shot` boots a real Vite server and drives it with Playwright's
Chromium in headless mode, rendering WebGL through SwiftShader (`--use-gl=angle
--use-angle=swiftshader`) rather than a GPU, so it's slow (~1 fps) — the
script gives every wait a generous timeout. It looks for a bundled browser
under `/opt/pw-browsers` first and falls back to Playwright's own install; if
neither is present, install browsers normally (`npx playwright install
chromium`) or point `PLAYWRIGHT_BROWSERS_PATH` at wherever they live. Useful
flags: `--paint` (sculpt some hills and a road before capturing), `--out
<path>`, `--frames <n>`.

## Controls

| Input | Effect |
|---|---|
| Left mouse (drag) | Paint with the active tool |
| Shift + left drag | Rotate the whole scene: sideways orbits the view, up/down tilts it (18°–70°). Never paints. |
| Ctrl/Cmd (held) | Temporarily invert to erase |
| X | Toggle sticky erase on/off |
| Alt (held, sculpt tool) | Smooth instead of raise/lower |
| `[` / `]` | Shrink / grow brush radius |
| Mouse wheel | Zoom |
| Middle-mouse drag, or Space + drag | Pan the camera |
| Q / E | Snap the view to the next / previous 90° mark (from wherever a free orbit left it) |
| Reset view (strip) | Back to yaw 45°, pitch 35.26°, default zoom, centred |
| Number/letter keys | Switch tool (see table below) |
| Shift+D | Hide both panels |

## Tools

| Tool | Key | Layer / behaviour |
|---|---|---|
| Sculpt | `0` | Raises terrain height; Ctrl/Cmd lowers, Alt smooths |
| Mask | `9` | Paints the "nothing grows here" mask |
| Path | `8` | Paints dirt road/path |
| Grass | `1` | Adds grass density |
| Comb | `2` | Sets lean direction for grass (a directional stroke tool) |
| Pond | `3` | Raises local water level to fill a basin |
| River | `4` | Carves a channel and carries a water level downhill along the stroke |
| Waterfall | `5` | Places a manual waterfall emitter |
| Rocks | `6` | Spawns physical rocks (rigid bodies) |
| Trees | `7` | Plants trees |
| Fire | `f` | Paints a fire source that can spread and burn grass |
| Smoke | `s` | Paints a smoke vent |
| Clouds | `c` | Paints clouds (carries rain/lightning) |

## Panel overview

- **Style** — style select (Ghibli toon / Flat / Realistic / Painterly /
  Pixel) plus the six shared "look" sliders (shadow tint, band edge/softness,
  half-tone, rim, grain), and an *Ink & paper* group for the screen-space
  pass (enable, line style, width, wobble, break, ink colour/opacity, hatch,
  hatch scale, paper, pooling).
- **Tools** — the tool picker (pills showing colour + hotkey), erase toggle,
  brush radius/strength/hardness/spacing, clear/fill-active-layer buttons,
  and a show-mask toggle.
- **Wind** — global direction, strength, speed, gustiness.
- **Sun** — azimuth, elevation, colour, intensity.
- **View** — zoom, rotate buttons, reset view.
- **File** — Save/Load scene JSON, Save PNG (also wired to ghost-panel's
  header Save/Load).
- Per-element folders (Grass, Water, Rocks, Master Sword, Trees, Fire, Smoke,
  Clouds & Weather) added by each element as it initializes, each exposing that
  element's own parameters.
- **Scene** outliner (left panel) — lists the terrain, sun, sky, and each
  element's objects; selecting a row inspects it, eye icons toggle
  visibility, and structural/painted objects are locked so they can't be
  dragged or accidentally deleted — the canvas itself only paints.

## Elements

- **Terrain (Sculpt/Mask/Path)** — sculpting raises/lowers/smooths a
  heightfield that everything else reads: grass color bands, water depth,
  rock/tree footing, and the Rapier collider all rebuild from it. Mask keeps
  growth off an area; Path paints a dirt road blended into the ground shader.
- **Grass** — density painted per-texel drives GPU-instanced blades (no CPU
  rebuild while painting); Comb sets a lean direction; grass bends with wind,
  is flattened/pushed by rocks rolling over it via the shared "press" layer,
  and burns down under fire.
- **Water** — a surface-level field, not a painted mesh: ponds fill basins to
  a flat level, sea level floods the whole map with a real shoreline,
  sculpting a lake bed makes islands emerge, rivers carve a channel and carry
  a strictly non-rising level downhill, and waterfalls appear automatically
  wherever that level drops over a cliff (steep sheets with foam/mist). A GPU
  height-field ripple sim overlays wind, rain, and rigid-body impacts.
- **Rocks** — spawns real Rapier rigid bodies (convex hull/ball colliders)
  that fall and roll on the terrain collider, settle at low speed, and leave
  a directional "press" trail that flattens grass as they move.
- **Trees** — plants instanced trees that sway as per-instance damped angular
  springs driven by the shared wind field, refusing to root on slopes steeper
  than a normal-Y threshold.
- **Master Sword** — a hero prop rather than a painted scatter: one glTF model
  loaded at boot and planted blade-down in the ground, cel-shaded from its own
  textures (posterised albedo, one hard-stepped AO band, a stepped anime glint
  that creeps along the blade, a breathing pommel stone). It is an ordinary
  scene object — select it, drag it with the gizmo, delete it — and its Y
  re-snaps to the terrain as it moves, so the same third of the blade stays
  buried and the grass parts around it.
- **Fire** — paints a source that spawns flames/embers, spreads across
  painted grass over time, consumes it down to scorch marks, and burns out.
- **Smoke** — paints vents that emit GPU-billboarded puffs which drift with
  wind and fade out.
- **Clouds** — paints drifting cloud instances that cast shadows and can rain
  (streaks + splashes that feed the water ripple sim and raise scene
  "wetness", shifting the mood/palette) and strike lightning.

## Styles

- **Ghibli toon** (default) — two-tone cel shading, a cool hue-shifted
  shadow, hard rim light, painterly grain, and the ink/hatching/paper post
  pass.
- **Flat / unlit** — no lighting term at all, just albedo with a hemisphere
  tint and shadow-map darkening; reads like a vector illustration.
- **Realistic** — Lambert diffuse + Blinn-Phong specular + hemisphere
  ambient, no quantization, softened shadows.
- **Painterly** — the toon two-tone with an fbm-wobbled terminator and a
  warmer, heavier paper grain.
- **Pixel** — hard three-band diffuse with the final color posterised to a
  small per-channel step count.

## Using the core elsewhere

The painting core ships as its own entry point, so another project can paint
on its own meshes without any of EnvPaint's app wiring:

```json
"envpaint": "git+https://github.com/epun/envpaint.git#<sha>"
```

| entry | what it is | needs |
|---|---|---|
| `envpaint/core` | `Brush`, `PaintLayer`/`PaintLayers`, `History`, `Cutouts`, `Wind`, the brush-shape and noise helpers | `three` (peer, >= 0.160) |
| `envpaint/ui` | `createToolStrip`, `toolIcon`, `ERASER_ICON` | `three` **and** `ghost-panel` (peer) |

Peer dependencies are not installed for you: `envpaint/core` needs `three`
(and `@types/three` in a TypeScript project) in the host project;
`envpaint/ui` additionally needs `ghost-panel`. Nothing under `envpaint/core`
touches `document` or `window` while it is being imported, so it loads in Node
(tests, tooling) as happily as in a browser. Type declarations
(`types/core.d.ts`, `types/ui.d.ts`) are wired through the `exports` map, so a
strict TS project resolves them with `moduleResolution` `bundler` or `node16`.

```js
import { Brush, PaintLayers, PaintLayer } from 'envpaint/core';

const layers = new PaintLayers();
const paint = layers.add(new PaintLayer('paint', { res: 512, channels: 1 }));

const brush = new Brush({ renderer, scene, camera, layers }, {
  worldSize: 64,                                  // your ground extent
  pick: (e) => myRaycastToGround(e),              // -> { x, y, z, u, v } | null
});
brush.registerTool({ id: 'paint', label: 'Paint', color: '#7ad24a', layer: 'paint' });
brush.on('stroke', ({ hit }) => console.log(hit.u, hit.v));   // paint.texture is live
```

`Brush` is the one class with real requirements beyond three: it binds pointer
and key listeners to `ctx.renderer.domElement`, so it needs a **canvas**, and
it adds its cursor ring to `ctx.scene`, so it needs a **scene**. Everything
else it used to assume — the world size, the terrain raycast, the camera's
claim on a Shift-drag, where a pointer-less radius preview sits — is injectable
through the second argument (`worldSize`, `pick`, `canPaint`, `centre`).
`PaintLayer`, `PaintLayers`, `History`, `Cutouts` and `Wind` need neither.

## Architecture

See [`ARCHITECTURE.md`](./ARCHITECTURE.md) for the full module contract
(shared `ctx` object, `PaintLayer`/stamp API, Brush/tool interface, the
Style system's marker-based shader swapping, the physics wrapper, and the
ink post-pass). Rough layout:

```
src/
  core/       App, IsoCamera, Sun, Wind, PaintLayers, Brush, Terrain,
              Physics, Style, PostFX, Element base class, shared shaders
  elements/   Grass, Water, Waterfall, Rocks, Sword, Trees, Fire, Smoke, Clouds
public/       models/ — the converted Master Sword glTF and its textures
  styles/     ghibli-toon, flat, realistic, painterly, pixel
  ui/         Panel.js (ghost-panel wiring)
scripts/      screenshot.mjs (headless visual smoke check)
test/         vitest unit tests
```

## Status

Early build. Known limits:

- Headless rendering (`npm run shot`) runs on SwiftShader software rendering,
  not a GPU, so it's slow (~1 fps) — fine for smoke checks, not for
  performance measurement.
- The GPU height-field water simulation and other float-texture effects rely
  on the WebGL context supporting linear filtering on float textures
  (`OES_texture_float_linear` or WebGL2-equivalent); on a context without it,
  water/ripple quality will degrade.
