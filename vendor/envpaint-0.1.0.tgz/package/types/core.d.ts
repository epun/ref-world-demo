/**
 * Type declarations for `envpaint/core` — the portable painting core.
 *
 * Hand-written from the JSDoc on `src/core/*.js`. three is a peer dependency;
 * nothing here touches the DOM at import time.
 */

import type { DataTexture, Group, Object3D, Vector2, Vector3 } from 'three';

// --- world <-> layer UV -----------------------------------------------------

/** Ground extent in world units EnvPaint itself uses (a default, never a requirement). */
export const WORLD_SIZE: number;
/** Half extent: x, z are in [-HALF, HALF]. */
export const HALF: number;
/** Default paint-layer resolution in texels per side. */
export const LAYER_RES: number;

/** World position -> layer UV, against `WORLD_SIZE`. */
export function worldToUV(x: number, z: number): { u: number; v: number };
/** Layer UV -> world position on the ground plane, against `WORLD_SIZE`. */
export function uvToWorld(u: number, v: number): { x: number; z: number };
/** `x` clamped to 0..1. */
export function clamp01(x: number): number;

/** True if a text field currently owns the keyboard. */
export function isTyping(el?: EventTarget | null): boolean;

// --- brush shape ------------------------------------------------------------

/** Edge-shape half of `Brush.settings`, shared by every disc a brush stamps. */
export interface BrushShape {
  /** 0..1 — how far the rim wanders in and out (1 ≈ ±35 %). */
  edgeNoise: number;
  /** 1..8 — lobes around the rim (low = blobby, high = ragged). */
  edgeScale: number;
  /** 0..1 — dissolves the feathered zone into speckle (dry brush). */
  spatter: number;
  /** 0.2..1 — below 1 the disc is an oval stretched along the stroke. */
  aspect: number;
}

export const SHAPE_DEFAULTS: BrushShape;

/** GLSL `smoothstep`. */
export function smoothstep(e0: number, e1: number, x: number): number;

/** Rim radius in a given direction: `radius` modulated by noise around a circle. */
export function edgeRadius(
  radius: number,
  angle: number,
  edgeNoise: number,
  edgeScale: number,
  seed: number,
): number;

export interface FalloffOp {
  radius: number;
  hardness?: number;
  dir?: { x: number; y: number } | null;
  edgeNoise?: number;
  edgeScale?: number;
  spatter?: number;
  aspect?: number;
  seed?: number;
}

export interface Falloff {
  /** Largest offset (same units as `radius`) the stamp can touch. */
  bound: number;
  /** Weight 0..1 at offset (du, dv) for the texel at integer (tx, ty). */
  f(du: number, dv: number, tx: number, ty: number): number;
}

/** Build the falloff evaluator for one stamp. */
export function makeFalloff(op: FalloffOp): Falloff;

// --- noise (CPU mirror of the GLSL helpers) ---------------------------------

export function hash11(p: number): number;
export function hash21(x: number, y: number): number;
export function hash31(x: number, y: number, z: number): number;
/** Value noise with smoothstep interpolation, 0..1. */
export function vnoise(x: number, y: number): number;
/** Fractal brownian motion over `vnoise`, up to 5 octaves. */
export function fbm(x: number, y: number, octaves?: number): number;

// --- paint layers -----------------------------------------------------------

export type LayerChannels = 1 | 2 | 4;
export type LayerData = Uint8Array | Float32Array;

export type StampMode =
  | 'add'
  | 'erase'
  | 'set'
  | 'smooth'
  | 'direction'
  | 'raise'
  | 'lower'
  | 'flatten';

/** One dab. All coordinates are UV (0..1); `radius` is in UV units. */
export interface StampOp extends FalloffOp {
  u: number;
  v: number;
  radius: number;
  /** Per-stamp amount, already multiplied by dt/spacing by the Brush. */
  strength?: number;
  /** 0 = fully soft falloff, 1 = hard edge. */
  hardness?: number;
  mode?: StampMode;
  /** Target for `'set'`. */
  value?: number;
  channel?: number;
  /** `'direction'`: written as `dir * 0.5 + 0.5` into channels 0 and 1. */
  dir?: { x: number; y: number } | null;
  /** `'flatten'`: target float height. */
  flattenTo?: number;
}

export interface PaintLayerOptions {
  /** 1 | 2 | 4, default 1. */
  channels?: LayerChannels;
  /** Float32 storage (unclamped world units), default false. */
  float?: boolean;
  /** Initial value (0..1 for byte layers), default 0. */
  initial?: number;
  /** Texels per side, default `LAYER_RES`. */
  res?: number;
  /** False for simulated layers that must not take part in undo. */
  history?: boolean;
}

export interface DirtyRect {
  x0: number;
  y0: number;
  x1: number;
  y1: number;
}

/**
 * A single paintable channel-set: a CPU typed array plus the DataTexture that
 * mirrors it.
 */
export class PaintLayer {
  constructor(id: string, opts?: PaintLayerOptions);

  readonly id: string;
  readonly res: number;
  readonly channels: LayerChannels;
  readonly float: boolean;
  readonly initial: number;
  /** Whether History tracks this layer. */
  readonly history: boolean;
  /** Increments on every stamp / clear / markDirtyRect. */
  version: number;
  /** Texel bounds changed since the last commit; null when clean. */
  dirtyRect: DirtyRect | null;
  /** Uint8Array (0..255) or Float32Array (`float: true`). */
  data: LayerData;
  texture: DataTexture;

  /** Raw storage value for a normalised 0..1 (or raw float) value. */
  encode(v: number): number;
  /** Normalised value for a raw storage value. */
  decode(v: number): number;
  /** Overwrite every texel without touching dirty tracking. */
  fill(value: number): void;
  /** Reset the whole layer and mark it fully dirty. */
  clear(value?: number): void;
  /** Texel index of (x, y, channel). */
  index(x: number, y: number, ch?: number): number;
  /** Bilinear read at a UV coordinate, clamped at the edges. */
  sample(u: number, v: number, ch?: number): number;
  /** Paint one dab. */
  stamp(op: StampOp): void;
  /** Mark a texel rect changed without going through `stamp()`. */
  markDirtyRect(x0: number, y0: number, x1: number, y1: number): this;
  /** Upload to the GPU if anything changed; returns whether it did. */
  commit(): boolean;
  /** Base64 of the raw storage bytes. */
  serialize(): string;
  deserialize(b64: string): void;
  dispose(): void;
}

/** Registry of every paint layer in the world. */
export class PaintLayers {
  constructor();
  readonly map: Map<string, PaintLayer>;
  /** Register a layer of any resolution; returns it, for chaining. */
  add(layer: PaintLayer): PaintLayer;
  get(id: string): PaintLayer | undefined;
  has(id: string): boolean;
  all(): PaintLayer[];
  /** Upload every dirty layer. Call once per frame. */
  commitAll(): void;
  serialize(): Record<string, string>;
  deserialize(data: Record<string, string>): void;
  dispose(): void;
}

/** Base64 of raw bytes (no `btoa`, so it works in Node too). */
export function toBase64(bytes: Uint8Array): string;
export function fromBase64(str: string): Uint8Array;

// --- brush ------------------------------------------------------------------

/** Where a pointer landed on the ground. */
export interface BrushHit {
  x: number;
  y: number;
  z: number;
  u: number;
  v: number;
}

export interface BrushSettings extends BrushShape {
  /** World units. */
  radius: number;
  strength: number;
  /** 0 = soft falloff, 1 = hard edge. */
  hardness: number;
  /** Fraction of the radius between dabs along a drag. */
  spacing: number;
}

/** A tool descriptor, as handed to `brush.registerTool()`. */
export interface Tool {
  id: string;
  label: string;
  /** Hex, used for the cursor ring. */
  color?: string;
  /** Hotkey (single character). */
  key?: string;
  /** Target layer id. */
  layer?: string;
  /** Default stamp mode, default `'add'`. */
  mode?: StampMode;
  /** Mode used while erasing (X, or Ctrl/Cmd held); default `'erase'`. */
  eraseMode?: StampMode;
  /** Mode used while Alt is held. */
  altMode?: StampMode;
  /** Multiplies `brush.settings.strength` for this tool; default 1. */
  strengthScale?: number;
  channel?: number;
  /** Element id History snapshots around a stroke with this tool. */
  element?: string;
  /** Layer ids this tool clears as it paints; skipped while erasing. */
  excludes?: string[];
  /** Called instead of `layer.stamp` when present. */
  onStamp?: (ctx: any, op: StampOp, hit: BrushHit) => void;
}

export type BrushEvent = 'strokestart' | 'stroke' | 'strokeend';

export interface StrokePayload {
  tool: Tool | undefined;
  hit: BrushHit | null;
  /** Normalised stroke direction in UV space; null at stroke start/end. */
  dir: { x: number; y: number } | null;
  erase: boolean;
}

/** Injection points that let the Brush run against a non-EnvPaint host. */
export interface BrushOptions {
  /** Ground extent in world units; defaults to `ctx.worldSize`, then `WORLD_SIZE`. */
  worldSize?: number;
  /** Pointer -> ground hit; defaults to a raycast against `ctx.terrain.mesh`. */
  pick?: (event: PointerEvent) => BrushHit | null;
  /** Extra veto asked before a stroke starts, on top of the camera check. */
  canPaint?: (event: PointerEvent) => boolean;
  /** Where a pointer-less radius preview sits; defaults to the camera target. */
  centre?: () => { x: number; y: number; z: number } | null;
}

/** The minimum a Brush needs from its host context. */
export interface BrushContext {
  /** Its `domElement` is the canvas the Brush binds pointer events to. */
  renderer: { domElement: HTMLCanvasElement };
  /** The cursor ring is added to this scene. */
  scene: Object3D;
  /** Used by the default `pick`. */
  camera?: any;
  layers: PaintLayers;
  terrain?: any;
  iso?: any;
  history?: History;
  worldSize?: number;
  [key: string]: any;
}

/**
 * Turns pointer drags into layer stamps for the active tool, and draws the
 * cursor ring. Needs a canvas (`ctx.renderer.domElement`) and a scene
 * (`ctx.scene`) — it binds pointer/keyboard listeners and adds a ring object.
 */
export class Brush {
  constructor(ctx: BrushContext, opts?: BrushOptions);

  readonly ctx: BrushContext;
  readonly canvas: HTMLCanvasElement;
  readonly opts: BrushOptions;
  /** Ground extent used for the world -> layer-UV mapping. */
  worldSize: number;
  settings: BrushSettings;
  /** Sticky erase toggle (X); Ctrl/Cmd inverts it for one stroke. */
  erase: boolean;
  /** Set false to suspend painting (e.g. while a gizmo is dragged). */
  enabled: boolean;
  readonly tools: Map<string, Tool>;
  /** Active tool id. */
  tool: string | null;
  /** Last ground hit under the pointer. */
  hit: BrushHit | null;
  readonly painting: boolean;
  /** Ring + dot + preview disc that follows the ground. */
  readonly cursor: Group;

  on(event: BrushEvent, fn: (payload: StrokePayload) => void): this;
  off(event: BrushEvent, fn: (payload: StrokePayload) => void): this;
  emit(event: BrushEvent, payload: StrokePayload): void;

  registerTool(tool: Tool): Tool;
  getTool(id: string): Tool | undefined;
  /** Throws if no such tool is registered. */
  setTool(id: string): this;
  /** World units, clamped to 0.3..12; flashes the footprint. */
  setRadius(r: number): this;
  /** Change edge-shape settings and show the result on the canvas. */
  setShape(shape: Partial<BrushShape>): this;
  /** Highlight the footprint for `ms` under the pointer, or at the view centre. */
  flashRadius(ms?: number): this;
  /** World position -> layer UV, against this brush's world size. */
  worldToUV(x: number, z: number): { u: number; v: number };
  dispose(): void;
}

// --- history ----------------------------------------------------------------

export interface LayerDelta extends DirtyRect {
  id: string;
  before: LayerData;
  after: LayerData;
}

export interface HistoryEntry {
  label: string;
  time: number;
  layers: LayerDelta[];
  elements: { id: string; before: string | null; after: string | null }[];
  bytes: number;
  applied: boolean;
  /** True once evicted for memory; undo/redo no-op. */
  dropped: boolean;
}

export interface HistoryOptions {
  /** Most entries kept, default 60. */
  maxSteps?: number;
  /** Soft cap on total delta bytes, default 96 MB. */
  maxBytes?: number;
}

/** The minimum a History needs from its host context. */
export interface HistoryContext {
  layers: PaintLayers;
  /** Elements it may snapshot; an empty Map is fine. */
  elements: Map<string, any>;
  brush?: Brush;
  app?: any;
  [key: string]: any;
}

/** `JSON.stringify` that keeps typed arrays intact. */
export function stringifyState(state: any): string;
/** Inverse of `stringifyState`. */
export function parseState(json: string): any;

/** Stroke-scoped undo / redo for paint layers and element state. */
export class History {
  constructor(ctx: HistoryContext, opts?: HistoryOptions);

  readonly ctx: HistoryContext;
  maxSteps: number;
  maxBytes: number;
  /** Total bytes held by all entries. */
  readonly bytes: number;
  /** ghost-panel root, once a panel stack was adopted. */
  readonly ui: any | null;

  on(event: 'change', fn: (history: History) => void): this;
  off(event: 'change', fn: (history: History) => void): this;

  /** Merge into ghost-panel's stack (expects `ui._undo`). */
  attachUI(ui: any): this;
  /** Open a scope: everything painted until `end()` is one entry. */
  begin(label?: string, opts?: { element?: string }): this;
  /** Close the open scope; returns the entry, or null if nothing changed. */
  end(): HistoryEntry | null;
  /** `begin` / `fn()` / `end()` for a synchronous one-shot mutation. */
  wrap(label: string, fn: () => void, opts?: { element?: string }): this;
  /** Call every frame for each dirty layer, before `layers.commitAll()`. */
  noteDirty(layer: PaintLayer, rect: DirtyRect): void;
  canUndo(): boolean;
  canRedo(): boolean;
  undo(): boolean;
  redo(): boolean;
  clear(): this;
  stats(): { steps: number; bytes: number; canUndo: boolean; canRedo: boolean };
  dispose(): void;
}

// --- cutouts ----------------------------------------------------------------

/** Most cutout discs a material carries; the vertex shader loops this many. */
export const MAX_CUTOUTS: number;

/** Keyed set of "nothing grows here" discs, handed to a material as uniforms. */
export class Cutouts {
  constructor(max?: number);
  readonly max: number;
  readonly discs: Map<string, { x: number; z: number; r: number }>;
  readonly uniforms: {
    uCutouts: { value: Vector3[] };
    uCutoutCount: { value: number };
  };
  /** `r <= 0` removes the disc. */
  set(key: string, x: number, z: number, r: number): this;
  remove(key: string): this;
}

// --- wind -------------------------------------------------------------------

export interface WindState {
  direction: number;
  strength: number;
  speed: number;
  gustiness: number;
}

/** Global wind: a direction, a strength, and a slowly wandering gust value. */
export class Wind {
  constructor();
  /** Degrees. */
  direction: number;
  /** 0..1. */
  strength: number;
  speed: number;
  /** 0..1, how much the gust value wanders. */
  gustiness: number;
  /** Shared with every wind-aware material by reference. */
  readonly uniforms: {
    uWindDir: { value: Vector2 };
    uWindStrength: { value: number };
    uWindSpeed: { value: number };
    uGust: { value: number };
    uTime: { value: number };
  };
  setDirection(deg: number): this;
  /** Advance the gust random walk and push state into the uniforms. */
  update(dt: number, time: number): void;
  /** CPU copy of the GLSL `windAt()`. */
  sampleAt(x: number, z: number, time?: number): { x: number; z: number };
  serialize(): WindState;
  deserialize(o?: Partial<WindState>): void;
}

// ── WaterOps: pure water-level operations over flat typed arrays ─────────────

/** Sentinel level for "no water here". */
export const DRY: number;
/** Depth at which derived presence saturates. */
export const PRESENCE_DEPTH: number;

export interface TexelRect { x0: number; y0: number; x1: number; y1: number }

/** Edge-shape fields a stamp op may carry (see `makeFalloff`). */
export interface EdgeShape {
  edgeNoise?: number;
  edgeScale?: number;
  spatter?: number;
  aspect?: number;
  seed?: number;
  dir?: { x: number; y: number } | null;
}

/** Fill or drain a disc of a level field; returns the texel rect touched. */
export function writeLevelDisc(o: {
  level: Float32Array;
  ground: Float32Array;
  res: number;
  u: number;
  v: number;
  radius: number;
  hardness?: number;
  op: 'fill' | 'drain';
  target?: number;
  maxDepth?: number;
  shape?: EdgeShape;
}): TexelRect | null;

/** Cut a channel or bowl into a height field, lowering only. */
export function carveDisc(o: {
  height: Float32Array;
  from?: Float32Array;
  res: number;
  u: number;
  v: number;
  radius: number;
  hardness?: number;
  bed: number;
  pressure?: number;
  maxCut?: number;
  rim?: number;
  shape?: EdgeShape;
}): TexelRect | null;

/** Flood every texel 4-connected to the start whose ground is below `target`. */
export function floodFill(o: {
  level: Float32Array;
  ground: Float32Array;
  res: number;
  sx: number;
  sy: number;
  target: number;
  cap?: number;
}): { filled: number; rect: TexelRect | null };

/** Derive the 0..255 presence layer from level and ground over a rect. */
export function derivePresence(o: {
  level: Float32Array;
  ground: Float32Array;
  presence: Uint8Array | Uint8ClampedArray;
  res: number;
  seaLevel?: number;
  rect?: TexelRect;
}): void;

/** Mean untouched-bank height on a ring, or on the two banks across a stroke direction. */
export function bankHeight(
  heightAt: (x: number, z: number) => number,
  x: number,
  z: number,
  r: number,
  dir?: { x: number; y: number } | null,
): number;
