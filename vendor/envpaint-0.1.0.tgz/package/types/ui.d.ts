/**
 * Type declarations for `envpaint/ui`.
 *
 * This entry needs **ghost-panel** (an optional peer dependency) and a real
 * browser; `envpaint/core` needs neither.
 */

import type { Brush } from './core.js';

export interface ToolStripOptions {
  /** Extra buttons pinned after the erase toggle. */
  extras?: Array<{ icon: string; tooltip: string; onClick: () => void }>;
}

export interface ToolStrip {
  element: HTMLElement;
  /** Rebuild the buttons from `brush.tools`. */
  refresh(): void;
  /** Push the brush's current tool / erase state onto the buttons. */
  sync(): void;
  reposition(): void;
  isVisible(): boolean;
  setVisible(v: boolean): void;
  dispose(): void;
}

/**
 * The floating tool strip: one icon button per registered tool, in
 * registration order, plus an erase toggle. Built on ghost-panel's `Toolbar`.
 */
export function createToolStrip(brush: Brush, opts?: ToolStripOptions): ToolStrip;

/** Inline SVG markup for a tool id; never empty (falls back to a dot). */
export function toolIcon(id: string): string;

/** Eraser glyph, for the strip's erase toggle. */
export const ERASER_ICON: string;

/** House glyph, for the strip's reset-view button. */
export const HOME_ICON: string;
